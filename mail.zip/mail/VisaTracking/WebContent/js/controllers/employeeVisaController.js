resourceMangmntApp.controller("employeeVisaController",['$scope','$rootScope','$location','DataServices','CommonUtils',function($scope,$rootScope,$location,DataServices,CommonUtils){
	
	$scope.showPerDtls = true;
	$scope.showDeskDtls= false;
	$scope.showProjDtls= false;
	$scope.showVisaDtls = false;
	$scope.showPopUpErrorMsg = false;

	$scope.userDtl = {};
	$scope.submitted = false;
	$scope.closeFlag = false;
	$scope.accordianFlg = false;
	$scope.BillableTypList = [{cd:1,desc:"Billable"},{cd:3,desc:"Partial"},{cd:2,desc:"Non-Billable"}];

	$rootScope.roleOfLoggedInEmp=sessionStorage.getItem("roleCD");
	$rootScope.roleDescOfLoggedInEmp=sessionStorage.getItem("roleDesc");
	$rootScope.portfolioOfLoggedInEmp=sessionStorage.getItem("portfolioID");
	$rootScope.portfolioDescOfLoggedInEmp=sessionStorage.getItem("portfolioDesc");
	$scope.showaccordion = function(optn){
		if(optn === 'PERSONAL'){
			$scope.showPerDtls =  true;
			$scope.showDeskDtls= false;
			$scope.showProjDtls= false;
			$scope.showVisaDtls = false;
		}
	};
	$scope.setFocusForDiv = function(optn){
		if((optn === 'PERSONAL' && !$scope.showPerDtls))
		{
			$scope.showaccordion(optn);
		}
	};
	/*
	 * if($rootScope.roleOfLoggedInEmp == 9 || $rootScope.roleOfLoggedInEmp ==6){
				$scope.userDtl.portfolio="";
			}else{
	 */
	
	$scope.$on('initEmpEditDtls',function(){
		$scope.showaccordion('PERSONAL');
		$scope.reset();
		$scope.title = $scope.empEditFlg.substring(0,1).toUpperCase()+$scope.empEditFlg.substring(1).toLowerCase();
		if($scope.empEditFlg != "ADD"){
			$scope.userDtl.empNbr=$rootScope.empNbr;
			$scope.userDtl.firstName=$rootScope.firstName;
			$scope.userDtl.lastName=$rootScope.lastName;
			angular.forEach($scope.travelPeriodlist, function(travelPeriodL, index)
					{
				
				if($rootScope.travelPeriod.indexOf(travelPeriodL.desc)>=0)
					{
					
					$scope.userDtl.travelPeriod=$scope.travelPeriodlist[index];
					}
				
			});
			
			
			angular.forEach($scope.traveltoList, function(traveltoL, index){
				if($rootScope.travelTo.indexOf(traveltoL.desc)>=0 ){
					$scope.userDtl.travelTo=$scope.traveltoList[index];
				}
			});
			/*if($rootScope.travelTo.indexOf("Atlanta")>=0){
				$scope.userDtl.travelTo=$scope.traveltoList[0];
			}else if($rootScope.travelTo.indexOf("Mexico")>=0){
				$scope.userDtl.travelTo=$scope.traveltoList[1];
			}else if($rootScope.travelTo.indexOf("Canada")>=0){
				$scope.userDtl.travelTo=$scope.traveltoList[2];
			}else if($rootScope.travelTo.indexOf("Austin")>=0){
				$scope.userDtl.travelTo=$scope.traveltoList[3];
			}*/
			angular.forEach($scope.initialStatusValue, function(initialStatusValueL, index){
				if($rootScope.initialStatus.indexOf(initialStatusValueL.desc)>=0 ){
					$scope.userDtl.initialStatus=$scope.initialStatusValue[index];
				}
			});
			/*if($rootScope.initialStatus.indexOf("New")>=0){
				$scope.userDtl.initialStatus=$scope.initialStatusValue[0];
			}else if($rootScope.initialStatus.indexOf("Replacement")>=0){
				$scope.userDtl.initialStatus=$scope.initialStatusValue[1];
			}*/
			$scope.userDtl.businessCase=$rootScope.businessCase;
			$scope.userDtl.startDateRequirement=$rootScope.startDateRequirement;
			$scope.userDtl.skillSet=$rootScope.skillSet;
			$scope.userDtl.billingRate=$rootScope.billingRate;
			$scope.userDtl.potentialLoss=$rootScope.potentialLoss;
			angular.forEach($scope.projectList, function(projectL, index){
				if($rootScope.projectType.indexOf(projectL.desc)>=0 ){
					$scope.userDtl.projectType=$scope.projectList[index];
				}
			});
			/*if($rootScope.projectType.indexOf("Support") >= 0){
				$scope.userDtl.projectType=$scope.projectList[0];
			}else if($rootScope.projectType.indexOf("Development") >= 0){
				$scope.userDtl.projectType=$scope.projectList[1];
			}*/
			angular.forEach($scope.porfolioList, function(porfolioL, index)
					{
				if($rootScope.portfolio.indexOf(porfolioL.portfolioDescription)>=0 ){
					$scope.userDtl.portfolio=$scope.porfolioList[index];
				}
			});
			/*if($rootScope.portfolio.indexOf("Stores")>=0){
				$scope.userDtl.portfolio=$scope.porfolioList[0];
			}else if($rootScope.portfolio.indexOf("Merch")>=0){
				$scope.userDtl.portfolio=$scope.porfolioList[1];
			}else if($rootScope.portfolio.indexOf("SCM")>=0){
				$scope.userDtl.portfolio=$scope.porfolioList[2];
			}else if($rootScope.portfolio.indexOf("BI&")>=0){
				$scope.userDtl.portfolio=$scope.porfolioList[3];
			}else if($rootScope.portfolio.indexOf("Ecom")>=0){
				$scope.userDtl.portfolio=$scope.porfolioList[4];
			}else if($rootScope.portfolio.indexOf("QA")>=0){
				$scope.userDtl.portfolio=$scope.porfolioList[5];
			}else if($rootScope.portfolio.indexOf("Account")>=0){
				$scope.userDtl.portfolio=$scope.porfolioList[6];
			}else if($rootScope.portfolio.indexOf("SAP")>=0){
				$scope.userDtl.portfolio=$scope.porfolioList[7];
			}else if($rootScope.portfolio.indexOf("IS Support")>=0){
				$scope.userDtl.portfolio=$scope.porfolioList[8];
			}*/

			angular.forEach($scope.visaTypeList, function(visaTypeL, index){
				if($rootScope.visaType==visaTypeL.visaTypCd){
					$scope.userDtl.visaType=$scope.visaTypeList[index];
				}
			});
			/*if($rootScope.visaType==1){
				$scope.userDtl.visaType=$scope.visaTypeList[0];
			}else if($rootScope.visaType==2){
				$scope.userDtl.visaType=$scope.visaTypeList[1];
			}else if($rootScope.visaType==3){
				$scope.userDtl.visaType=$scope.visaTypeList[2];
			}else if($rootScope.visaType==4){
				$scope.userDtl.visaType=$scope.visaTypeList[3];
			}*/
			angular.forEach($scope.visaStatusList, function(visaStatusL, index){
				if($rootScope.status==visaStatusL.visaStatsCd){
					$scope.userDtl.status=$scope.visaStatusList[index];
				}
			});
			/*if($rootScope.status==1){
				$scope.userDtl.status=$scope.visaStatusList[0];
			}else if($rootScope.status==2){
				$scope.userDtl.status=$scope.visaStatusList[1];
			}else if($rootScope.status==3){
				$scope.userDtl.status=$scope.visaStatusList[2];
			}else if($rootScope.status==4){
				$scope.userDtl.status=$scope.visaStatusList[3];
			}*/
				$scope.$apply();
				$scope.submittedTS=$rootScope.submittedTS;
				$scope.lastUpdatedDate=$rootScope.lastUpdatedDate;
				if((($rootScope.roleDescOfLoggedInEmp.indexOf("GL")!=-1 || $rootScope.roleDescOfLoggedInEmp.indexOf("PM")!=-1 || 
						$rootScope.roleDescOfLoggedInEmp.indexOf("DM")!=-1 )) && 
						(($scope.userDtl.status.visaStatsDesc=="Submitted")||($scope.userDtl.status.visaStatsDesc=="Rejected") )){
					$scope.canSave=1;
				}else{
					$scope.canSave=0;
				}
		}/*else{
			$scope.userDtl.empNbr="";
			$scope.userDtl.firstName="";
			$scope.userDtl.lastName="";
			$scope.userDtl.visaType="";
			$scope.userDtl.status="";
			$scope.userDtl.projectType="";
			$scope.userDtl.travelPeriod="";
			$scope.userDtl.travelTo="";
			$scope.userDtl.initialStatus="";
			$scope.userDtl.businessCase="";
			$scope.userDtl.startDateRequirement="";
			$scope.userDtl.skillSet="";
			$scope.userDtl.billingRate="";
			$scope.userDtl.potentialLoss="";
			$scope.userDtl.portfolio="";
			$scope.submittedTS="";
			$scope.lastUpdatedDate="";
		}*/
	});

	$scope.$on('initEmpDtls',function(e){
		$(".tabint").blur(function (e) 
				{	
	  
			//if(e.keyCode == 9 )
			//	{
				var empNbr=$(this).val();
				var obj = {};
				obj.empNbr = empNbr;
				var jsonData = JSON.stringify(obj);
				console.log(jsonData);
				var dataToSend = {
						data: jsonData,
				};
				
				$scope.getSuccessDetails=function(result)
				{
					
					if(result.header.status==500)
						{
						 $scope.errorMsg="Given employee id does not exist.";
						 $scope.showPopUpErrorMsg = true;
						 
							 $('.onlystring').val("");
								
							 
						
						 
						 $scope.$apply();
						
						
						}
					else{
						
						
							
					if(($rootScope.roleDescOfLoggedInEmp.indexOf("PM")!=-1 || $rootScope.roleDescOfLoggedInEmp.indexOf("DM")!=-1) &&
							($rootScope.portfolioOfLoggedInEmp==result.portfolio))
						{
					$scope.userDtl.firstName=result.firstName;
					$scope.userDtl.lastName=result.lastName;
					$scope.$apply();
						}
					
					else if($rootScope.roleDescOfLoggedInEmp.indexOf("RMG")!=-1 || $rootScope.roleDescOfLoggedInEmp.indexOf("GL")!=-1)
						{
						$scope.userDtl.firstName=result.firstName;
						$scope.userDtl.lastName=result.lastName;
						
						var obj = {};
						obj.portfolioCd = result.portfolio;
						obj.portfolioDescription = result.portfolioName;
						
						/*$scope.porfolioList = [];
						$scope.porfolioList.push(obj);*/
						angular.forEach($scope.porfolioList, function(porfolioL, index){
							if(result.portfolioName.indexOf(porfolioL.portfolioDescription)>=0 ){
								$scope.userDtl.portfolio = $scope.porfolioList[index];
							}
						});
						
						
						$scope.$apply();
						
						}
					else
						{
						$('.tabint').val("");
						$('.onlystring').val("");
						$('.onlystring').val("");
						$scope.errorMsg="Employee portfolio and "+$rootScope.roleDescOfLoggedInEmp+" portfolio does not match.";
						 $scope.showPopUpErrorMsg = true;
						 $scope.$apply();
						 
						}
					
					
					
							
						
				}
				};
				$scope.getFailurDetails=function(result)
				{
					
					if(result=="")
					{
						$scope.errorMsg = "No results found, please enter the correct emp id.";
						$scope.showPopUpErrorMsg = true;
					}
					if(result.header.status == 400)
					{
						$scope.errorMsg = result.header.message;
					}
					else{
						$scope.errorMsg = "Application encountered a problem, please contact system administration.";
					}
					$scope.showPopUpErrorMsg = true;
				};
				
				if(angular.isDefined($scope.userDtl.empNbr) && $scope.userDtl.empNbr != "")
				{
					DataServices.getTeamDetails(dataToSend, $scope.getSuccessDetails, $scope.getFailurDetails);
				}
				else
					{
					
					 $scope.errorMsg="Please enter employee id.";
					 $scope.showPopUpErrorMsg = true;
					 $scope.$apply();
					
					}
				
					
				
				
				//}
		}); 
		$(".reqDate").keydown(function (e) {

			if ( e.ctrlKey || e.altKey) {
				e.preventDefault();
				} else {
				var key = e.keyCode;
				if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
				e.preventDefault();
				}
				}
		}); 
		$scope.title="Initiate";
			$scope.userDtl.empNbr="";
			$scope.userDtl.firstName="";
			$scope.userDtl.lastName="";
			$scope.userDtl.visaType="";
			$scope.userDtl.status=$scope.visaStatusList[0]; 
			$scope.userDtl.projectType="";
			$scope.userDtl.travelPeriod="";
			$scope.userDtl.travelTo="";
			$scope.userDtl.initialStatus="";
			$scope.userDtl.businessCase="";
			$scope.userDtl.startDateRequirement="";
			$scope.userDtl.skillSet="";
			$scope.userDtl.billingRate="";
			$scope.userDtl.potentialLoss="";
			if($rootScope.roleOfLoggedInEmp == 9 || $rootScope.roleOfLoggedInEmp ==6)
			{
				$scope.userDtl.portfolio="";
				
			}
			
			else{
				if($rootScope.portfolioDescOfLoggedInEmp.indexOf("Stores")>=0){
					$scope.userDtl.portfolio=$scope.porfolioList[0];
				}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("Merch")>=0){
					$scope.userDtl.portfolio=$scope.porfolioList[1];
				}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("SCM")>=0){
					$scope.userDtl.portfolio=$scope.porfolioList[2];
				}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("BI&")>=0){
					$scope.userDtl.portfolio=$scope.porfolioList[3];
				}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("Ecom")>=0){
					$scope.userDtl.portfolio=$scope.porfolioList[4];
				}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("QA")>=0){
					$scope.userDtl.portfolio=$scope.porfolioList[5];
				}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("Account")>=0){
					$scope.userDtl.portfolio=$scope.porfolioList[6];
				}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("SAP")>=0){
					$scope.userDtl.portfolio=$scope.porfolioList[7];
				}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("IS Support")>=0){
					$scope.userDtl.portfolio=$scope.porfolioList[8];
				}
			}
			$scope.submittedTS="";
			$scope.lastUpdatedDate="";
		
	}); 
	$scope.onclickOfSubmit_visa =function(){

		$scope.accordianFlg = false;
		$scope.isSubmittable = true;
		//$scope.submitted = true;

		if((!(angular.isDefined($scope.userDtl.empNbr)) || $scope.userDtl.empNbr == "" )
				|| (!(angular.isDefined($scope.userDtl.firstName)) || $scope.userDtl.firstName == "" )
				|| (!(angular.isDefined($scope.userDtl.lastName)) || $scope.userDtl.lastName == "" )
				|| (!(angular.isDefined($scope.userDtl.visaType)) || $scope.userDtl.visaType == "" )
				|| (!(angular.isDefined($scope.userDtl.status)) || $scope.userDtl.status == "" )
				|| (!(angular.isDefined($scope.userDtl.projectType)) || $scope.userDtl.projectType == "" )
				|| (!(angular.isDefined($scope.userDtl.travelPeriod)) || $scope.userDtl.travelPeriod == "" )
				|| (!(angular.isDefined($scope.userDtl.travelTo)) || $scope.userDtl.travelTo == "" )
				|| (!(angular.isDefined($scope.userDtl.initialStatus)) || $scope.userDtl.initialStatus == "" )
				|| (!(angular.isDefined($scope.userDtl.skillSet)) || $scope.userDtl.skillSet == "" )
				|| (!(angular.isDefined($scope.userDtl.startDateRequirement)) || $scope.userDtl.startDateRequirement == "" )
				|| (!(angular.isDefined($scope.userDtl.billingRate)) || $scope.userDtl.billingRate == "" )
				|| (!(angular.isDefined($scope.userDtl.portfolio)) || $scope.userDtl.portfolio == "" )
				|| (!(angular.isDefined($scope.userDtl.potentialLoss)) || $scope.userDtl.potentialLoss == "" )
				|| (!(angular.isDefined($scope.userDtl.businessCase)) || $scope.userDtl.businessCase == "" ))
		{

			
			
				$scope.isSubmittable = false;


		} 
		else 
		{
			$scope.isSubmittable=true;
			
		}




		if($scope.isSubmittable)
		{
			console.log('$scope.userDtl.firstName.............'+$scope.userDtl.firstName);
			$scope.saveEmpDetails();
		}


	};

	$scope.saveEmpDetails = function()
	{


		if(!$scope.isSubmittable){
			return false;
		}
		$scope.isSubmittableCheck=true;
		var associateObj= {};
		if(angular.isDefined($scope.userDtl.empNbr) && $scope.userDtl.empNbr != "")
		{
			
			 
				if(!isNaN($scope.userDtl.empNbr))
				{
				
					associateObj.empNbr = $scope.userDtl.empNbr;

				}
				else
					{
					
					 $scope.isSubmittableCheck=false;
					 
					
					  $scope.errorMsg = "Emp Id should be a number";
					  $scope.showPopUpErrorMsg = true;
					  	return false;		  
					 
					}
				
			
		}
		if(angular.isDefined($scope.userDtl.status) && $scope.userDtl.status != "")
		{
			associateObj.status = $scope.userDtl.status.visaStatsCd;
			if($rootScope.roleDescOfLoggedInEmp.indexOf("GL")!=-1 || $rootScope.roleDescOfLoggedInEmp.indexOf("PM")!=-1 || 
					$rootScope.roleDescOfLoggedInEmp.indexOf("DM")!=-1 ){
				if(($scope.userDtl.status.visaStatsDesc=="Rejected")){
					associateObj.status = 1;
				}
			}
			if($rootScope.roleDescOfLoggedInEmp.indexOf("RMG")!=-1){
				if(($rootScope.status==4)){
					associateObj.status = 1;
					$rootScope.status=1;
				}
			}
		}
		if(angular.isDefined($scope.userDtl.firstName) && $scope.userDtl.firstName != "")
		 {
			 console.log('$scope.userDtl.firstName.length...........'+($scope.userDtl.firstName).length);
			 if($scope.userDtl.firstName.length > 1)
				 {
			 
			 associateObj.firstName =  $scope.userDtl.firstName;
				 }
			 else
				 {
				 $scope.isSubmittableCheck=false;
				 console.log('$scope.userDtl.firstName.length.......11....'+$scope.userDtl.firstName.length);
				
				  $scope.errorMsg = "First Name should be at least of 3 characters";
				  $scope.showPopUpErrorMsg = true;
				  
				  
				  return false;
				 
				 }
				
		 }
		if(angular.isDefined($scope.userDtl.lastName) && $scope.userDtl.lastName != ""){
			associateObj.lastName = $scope.userDtl.lastName;
		}
		if(angular.isDefined($scope.userDtl.visaType) && $scope.userDtl.visaType != "")
		{
			associateObj.visaType = $scope.userDtl.visaType.visaTypCd;

		}
		if(angular.isDefined($scope.userDtl.skillSet) && $scope.userDtl.skillSet != ""){
			associateObj.skillSet = $scope.userDtl.skillSet;
		}
		if(angular.isDefined($scope.userDtl.projectType) && $scope.userDtl.projectType != "")
		{


			associateObj.projectType = $scope.userDtl.projectType.desc;


		}
		//associateObj.secondaryContactNumber;
		if(angular.isDefined($scope.userDtl.travelPeriod) && $scope.userDtl.travelPeriod != null){
			
			associateObj.travelPeriod = $scope.userDtl.travelPeriod.cd;
			
		}
		if(angular.isDefined($scope.userDtl.travelTo) && $scope.userDtl.travelTo != null){
			associateObj.travelTo = $scope.userDtl.travelTo.desc;
		}

		if(angular.isDefined($scope.userDtl.initialStatus) && $scope.userDtl.initialStatus != null){
			associateObj.initialStatus = $scope.userDtl.initialStatus.desc;
			// associateObj.secondaryTechnologyDesc = $scope.userDtl.empSecTech.desc;
		}

		if(angular.isDefined($scope.userDtl.businessCase) && $scope.userDtl.businessCase != null){
			associateObj.businessCase =  $scope.userDtl.businessCase;
			// associateObj.roleDesc =  $scope.userDtl.empRole.desc;
		}

		




		if(angular.isDefined($scope.userDtl.startDateRequirement) && $scope.userDtl.startDateRequirement != ""){
			associateObj.startDateRequirement = $scope.userDtl.startDateRequirement;
			// associateObj.designationDesc = $scope.userDtl.empDesgn.desc;
		}

		if(angular.isDefined($scope.userDtl.billingRate) && $scope.userDtl.billingRate != null){
			
			if(!isNaN($scope.userDtl.billingRate))
			{
			
				associateObj.billingRate = $scope.userDtl.billingRate;

			}
			else
				{
				
				 $scope.isSubmittableCheck=false;
				 
				
				  $scope.errorMsg = "Billing rate should be a number";
				  $scope.showPopUpErrorMsg = true;
				  	return false;		  
				 
				}
			
		}
		if(angular.isDefined($scope.userDtl.potentialLoss) && $scope.userDtl.potentialLoss != null){
			associateObj.potentialLoss = $scope.userDtl.potentialLoss;
		}

		if(angular.isDefined($scope.userDtl.portfolio) && $scope.userDtl.portfolio != "")
		{
			associateObj.portfolio = $scope.userDtl.portfolio.portfolioDescription ;
		}




		var tempRequest = {};
		tempRequest.associateDetails = associateObj;
		if (angular.isDefined($rootScope.userDtl.empNbr) && $rootScope.userDtl.empNbr != "" && $rootScope.userDtl.empNbr != null){
			tempRequest.loggedInempNbr = $rootScope.userDtl.empNbr;
		}else{
			$scope.errorMsg = "You are not in valid session. Please log in and try again!";
			$scope.showPopUpErrorMsg = true;
			return false;
		} 
		var jsonData = JSON.stringify(tempRequest);
		console.log("-----Save Associate----"+jsonData);
		console.log('$scope.userDtl.visaType....'+$scope.userDtl.visaType.visaTypDesc);
		var dataToSend = {
				data: jsonData,
		};
		CommonUtils.refreshCookie();
		if($scope.isSubmittableCheck){
			if($scope.empEditFlg == "ADD")
			{
				console.log('create called......'+dataToSend);

				if($rootScope.roleDescOfLoggedInEmp.indexOf("GL")!=-1 || $rootScope.roleDescOfLoggedInEmp.indexOf("PM")!=-1 || $rootScope.roleDescOfLoggedInEmp.indexOf("DM")!=-1 || $rootScope.roleDescOfLoggedInEmp.indexOf("RMG")!=-1 )
				{

					DataServices.createAssociate(dataToSend, $scope.handleSuccess, $scope.errorFunc);
				}
				else
				{

					$scope.errorMsg = "You are not allowed to add employee details!";
					$scope.showPopUpErrorMsg = true;
					return false;

				}
			}
			else{
				if($rootScope.roleDescOfLoggedInEmp.indexOf("GL")!=-1 || $rootScope.roleDescOfLoggedInEmp.indexOf("PM")!=-1 || $rootScope.roleDescOfLoggedInEmp.indexOf("DM")!=-1 ||$rootScope.roleDescOfLoggedInEmp.indexOf("RMG")!=-1) 
				{
					if((($rootScope.roleDescOfLoggedInEmp.indexOf("GL")!=-1 || $rootScope.roleDescOfLoggedInEmp.indexOf("PM")!=-1 || 
							$rootScope.roleDescOfLoggedInEmp.indexOf("DM")!=-1 )) && 
							(($scope.userDtl.status.visaStatsDesc=="Submitted")||($scope.userDtl.status.visaStatsDesc=="Rejected") ))
					{
						
						DataServices.updateAssociate(dataToSend, $scope.handleSuccess, $scope.errorFunc);
					}
					else if($rootScope.roleDescOfLoggedInEmp.indexOf("RMG")!=-1)
						{
						
						DataServices.updateAssociate(dataToSend, $scope.handleSuccess, $scope.errorFunc);
						}
					else
						{
						$scope.errorMsg = "You can edit employee details only when the status is Submitted or Rejected";
						$scope.showPopUpErrorMsg = true;
						return false;
						
						}
				}
				else
				{
					$scope.errorMsg = "You are not allowed to add employee details!";
					$scope.showPopUpErrorMsg = true;
					return false;

				}

			}
		}
		else
		{
			console.log('reached here.....');
			$scope.errorMsg = "You are not allowed to add employee details!";
			$scope.showPopUpErrorMsg = true;

			return false;

		}
	};
	$scope.undoDelete=function()
	{
		$scope.empDeletFlg = "delete";
		var undoData={};
		
		undoData.emp_nbr = $scope.userDtl.empNbr;
		undoData.visaType = $scope.userDtl.visaType.visaTypCd;
		undoData.loggedInempNbr = $rootScope.userDtl.empNbr;
		
		var jsondata=JSON.stringify(undoData);
		var dataToSend={
				
				data : jsondata
		};
		
		DataServices.undoDeletedRecord(dataToSend, $scope.handleSuccess, $scope.errorFunc);
		
	};
	$scope.handleSuccess = function(result)
	{
		console.log('result.header.status.....'+result.header.status);
		if(result.header.status == 200)
		{
			if($scope.empEditFlg == "EDIT")
			{
				

														
					$scope.errorMsg = "Employee changes updated successfully";

										$scope.searchResults_visa();
				

			}
			
			
			else
			{
				console.log('result.header.code...'+result.header.code);
				if(result.header.code == 299)
				{
					$scope.errorMsg = result.header.message;
				}

				else
				{
					$scope.errorMsg = "Employee added successfully";
				}

			}
			$scope.closeFlag = true;
			$scope.showPopUpErrorMsg = true;
			CommonUtils.getTeamComboList();
			
		}
		else
			$scope.errorFunc(result); 
	};
	$scope.errorFunc = function(result){
		if(result.header.status == 400 || result.header.status == 500)
		{
			$scope.errorMsg = result.header.message;
		}
		else{
			$scope.errorMsg = "Application encountered a problem, please contact system administration.";
		}
		$scope.showPopUpErrorMsg = true;
	};
	$scope.closeErrorPopup = function(){
		$scope.showPopUpErrorMsg = false;
		$scope.submitted = false;
		if($scope.closeFlag){
			$scope.cancelDetails_visa();
		}
	};
	$scope.reset = function(){
		$scope.submitted = false;
		$scope.userDtl ={};
		$scope.showPopUpErrorMsg = false;
		$scope.closeFlag = false;
	};
	$scope.cancelDetails_visa = function(){
		$scope.reset();
		$rootScope.showEmplVisaDtls = false;
	};

	$scope.clickfunction=function(value)
	{
		$scope.visible = !$scope.visible;
		$scope.value="This information is coming from databse";
	};
	$scope.onReplacementSelected = function(){
		if($scope.userDtl.initialStatus.desc == "Replacement"){
			// showing alert
			$scope.errorMsg = "Please enter replacement details and provide reason in business case";
			$scope.showPopUpErrorMsg = true;
		}
	}; 
	
	
	$scope.onChangePortfolio=function()
	{
		/*$scope.confirmMessage = "Do you want to change current portfolio?? If yes click on Confirm";
		$scope.showConfirmBox = true;*/
		$scope.errorMsg = "You are changing portfolio make sure about portfolio.";
		$scope.showPopUpErrorMsg = true;
	};
	//$rootScope.disablePortfolio = ($rootScope.roleOfLoggedInEmp != 9 && $rootScope.roleOfLoggedInEmp !=6) || ($rootScope.deleteFlag=='RecordAbsent' && $rootScope.empEditFlg !='ADD');
	$scope.onclickOfEnablePortfolio=function()
	{
		$rootScope.disablePortfolio = false;
	};

}]);