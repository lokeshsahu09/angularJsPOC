 resourceMangmntApp.controller("userProfileController",['$scope','$rootScope','$location','DataServices',function($scope,$rootScope,$location,DataServices){
	 $scope.changePwdObj = {};
	 $scope.showErrorMsg = false;
	 $scope.showSuccessMsg = false;
	 
	  //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
  $scope.openChnagePwdWindow = function (index){  
		  $rootScope.showChngPwd = true;
  };
  //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
  $scope.logOut = function (index){  
		 document.cookie = "userDtl=someValue; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
		 window.location = "/VisaTracking/login.html";  
  };
  
  //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	        
  /** Onclick of search Button**/	  
	  $scope.changePassword = function (index){  
		  
		  var tempRequest = {};
		  
		  if( (angular.isUndefined( $scope.changePwdObj.newPwd) || $scope.changePwdObj.newPwd == ""  || $scope.changePwdObj.newPwd == null) ||
		   (angular.isUndefined($scope.changePwdObj.reNewPwd) || $scope.changePwdObj.reNewPwd == ""  || $scope.changePwdObj.reNewPwd == null) ||
			  (angular.isUndefined($scope.changePwdObj.currPwd) || $scope.changePwdObj.currPwd == ""  || $scope.changePwdObj.currPwd == null) ){
			  $scope.errorMsg = "Please enter all fields.";
			  $scope.showErrorMsg = true;
			  
			  return false;
		 }
		  
		  if($scope.changePwdObj.newPwd != $scope.changePwdObj.reNewPwd ){
					  $scope.errorMsg = "Entered passwords do not match, please enter correctly.";
					  $scope.showErrorMsg = true;
					  return false;
				 }
		 
		  if (angular.isDefined($scope.changePwdObj.currPwd) && $scope.changePwdObj.currPwd != "" && $scope.changePwdObj.currPwd !=null){
			  tempRequest.password = $scope.changePwdObj.currPwd; 
		  }
		  if (angular.isDefined($scope.changePwdObj.newPwd) && $scope.changePwdObj.newPwd != "" && $scope.changePwdObj.newPwd != null){
			  tempRequest.newPassword = $scope.changePwdObj.newPwd;
		  }
		  if (angular.isDefined($scope.userDtl.empNbr) && $scope.userDtl.empNbr != "" && $scope.userDtl.empNbr != null){
			  tempRequest.empNumber = $scope.userDtl.empNbr;
		  }else{
			  $scope.errorMsg = "You are not in valid session. Please log in and try again!!";
			  $scope.showErrorMsg = true;
			  return false;
		  }  
		  	var jsonData = JSON.stringify(tempRequest);
			 console.log(jsonData);
			 
		  	var dataToSend = {
                    data: jsonData,
            };
		  	
		  	DataServices.changePassword(dataToSend, $scope.changePwdSuccess, $scope.errorFunc);
			//$scope.authenticateUser(dataToSend, "rs/auth/login",$scope.authSuccess, $scope.authFailure);
	  };

	   //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
      $scope.changePwdSuccess = function (result) {
    	  
    	  
    	  if(result.header.status == 200){
    		  
    		  $scope.successMsg = "Your password has been changed sucessfully";
    		  $scope.showSuccessMsg = true;
    		
    	  }
    	  else
		  {
		  	$scope.errorFunc(result);
		  }
    	  
      };
      //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
      $scope.errorFunc = function (result) {
    	  if(result.header.status == 400){
    		  $scope.errorMsg = result.header.message;
    		  $scope.showErrorMsg = true;
    	  }
    	  else{
    		  $scope.errorMsg = "Application encountered a problem, please contact system administration.";
    		  $scope.showErrorMsg = true;
    	  }
      };

	     //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-

	  $scope.closeErrorPopup = function(){
		  $scope.showErrorMsg = false;
	  };
	  
	     //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-

	  $scope.closeMessagePopup = function(){
		  $scope.showSuccessMsg = false;
		  $rootScope.showChngPwd = false;
	  };
	  
	     //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
		 $scope.cancelChangePwd = function(){
			 $rootScope.showChngPwd = false;
			 $scope.showErrorMsg = false;
		 };
		 
		 

		 
		 
}]);
	
