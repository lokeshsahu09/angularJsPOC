 resourceMangmntApp.controller("commonController",['$scope','$rootScope','CommonUtils','$cookies',function($scope,$rootScope,CommonUtils,$cookies){
	 $rootScope.teamDefaultComboList = {};
	 $rootScope.projDefaultComboList = {};
	 $rootScope.yearComboList = [];
	 $rootScope.userDtl = {};
	 $rootScope.isAdditionalFeatureAllowed = false;
	 $rootScope.showChngPwd = false;
	 $rootScope.loginPage=false;
	 //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
     $scope.loadDefaultComboList = function () {
    	 $rootScope.userDtl = JSON.parse($cookies.userDtl);
    	 $rootScope.masterDtl = JSON.parse($cookies.masterDtl);
    	// alert( $rootScope.userDtl.firstName);
    	 CommonUtils.getTeamComboList();
    	 //$scope.setAdditionalFunctionData();
    	 $scope.setYearComboList();
    	 
     };
     
     //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
     $scope.setYearComboList = function(){
    	var curYear = $rootScope.currentYear = new Date().getFullYear();
    	 $rootScope.yearComboList = [(curYear-1),curYear,(curYear+1)];
     };
     //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
     //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
    /* $scope.setAdditionalFunctionData = function(){
    	 angular.forEach($rootScope.teamDefaultComboList.porfolioList, function(portfolio, index){
             if(portfolio.additionalFunction  === "Y"){
            	 
            	 if(portfolio.cd === $rootScope.userDtl.portfolioCd)
        		 {
            		 $rootScope.isAdditionalFeatureAllowed = true;
        		 }
             }
          });
     };*/
     //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-

     
     var x = document.cookie;
     //alert("cokkie is :"+x);
 	  if(x.indexOf("empNbr") == -1 ){
 		  window.location = "/VisaTracking/login.html";
 	  }
     

 }]);