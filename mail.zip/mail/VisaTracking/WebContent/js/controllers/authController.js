 var loginApp  = angular.module('loginApp',['ngCookies']);
 loginApp.directive('ngEnter', function() {
	 return function( scope, elem, attrs ) {
	     elem.bind('keydown keyup', function(event) {
	         if(event.which === 13){
	             setTimeout(function(){
	                 scope.$apply(attrs.ngEnter);
	                 var functionToCall =  scope.$eval(attrs.ngEnter);
	                 functionToCall();
	             },5);
	             event.preventDefault();
	         }
	     });
	   }; 
	 });
 loginApp.controller("authController",['$rootScope','$scope','$http','$cookies',function($rootScope,$scope,$http,$cookies){
	 $scope.authObj = {};
	 $scope.changePwdauthObj = {};
	 $scope.securityQuestionList = [
	      			{ desc:"Mother's Maiden Name",cd:1 },
	      			{ desc:"Name of Birth City",cd:2 },
	      			{ desc:"Who is your childhood hero",cd:3 },
	      			{ desc:"what is your pets Name",cd:4 },
	      			{ desc:"Driving License Number",cd:5 },
	      			{ desc:"Favorite Cricket Player",cd:6 },
	      			{ desc:"Favorite Country",cd:7 },
	      	];
	 $scope.showErrorMsg = false;
	 $scope.loginPage=true;
	 
  //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	        
  /** Onclick of search Button**/	
	 $scope.changePwdFirstTime = function (index){  
		  
		  var tempRequest = {};
		  if( (angular.isUndefined( $scope.changePwdauthObj.userName) || $scope.changePwdauthObj.userName == ""  || $scope.changePwdauthObj.userName == null) ||
		   (angular.isUndefined($scope.changePwdauthObj.password) || $scope.changePwdauthObj.password == ""  || $scope.changePwdauthObj.password == null) ||
		   (angular.isUndefined($scope.changePwdauthObj.confPassword) || $scope.changePwdauthObj.confPassword == ""  || $scope.changePwdauthObj.confPassword == null) ||
		   (angular.isUndefined($scope.changePwdauthObj.reConfPassword) || $scope.changePwdauthObj.reConfPassword == ""  || $scope.changePwdauthObj.reConfPassword == null) ||
		   (angular.isUndefined($scope.changePwdauthObj.questionCd) || $scope.changePwdauthObj.questionCd == ""  || $scope.changePwdauthObj.questionCd == null) ||
		   (angular.isUndefined($scope.changePwdauthObj.SecurityAns) || $scope.changePwdauthObj.SecurityAns == ""  || $scope.changePwdauthObj.SecurityAns == null) 
		  ){
			  $scope.errorMsg = "Please enter all the required details!!";
			  $scope.showErrorMsg = true;
			  
			  //alert("Enter atleat one search Criteria");
			  return false;
		 }
		 
	  
		  
		  if (angular.isDefined($scope.changePwdauthObj.userName) && $scope.changePwdauthObj.userName != "" && $scope.changePwdauthObj.userName !=null){
			  tempRequest.empNumber = $scope.changePwdauthObj.userName; 
		  }
		  if (angular.isDefined($scope.changePwdauthObj.password) && $scope.changePwdauthObj.password != "" && $scope.changePwdauthObj.password != null){
			  tempRequest.password = $scope.changePwdauthObj.password;
		  }  
		  if (angular.isDefined($scope.changePwdauthObj.confPassword) && $scope.changePwdauthObj.confPassword != "" && $scope.changePwdauthObj.confPassword != null){
			  tempRequest.newPassword = $scope.changePwdauthObj.confPassword;
		  } 
		  if (angular.isDefined($scope.changePwdauthObj.reConfPassword) && $scope.changePwdauthObj.reConfPassword != "" && $scope.changePwdauthObj.reConfPassword != null){
			  
			  if($scope.changePwdauthObj.confPassword != $scope.changePwdauthObj.reConfPassword ){
				  $scope.errorMsg = "Entered passwords do not match, please enter correctly.";
				  $scope.showErrorMsg = true;
				  return false;
			 }
		  } 
		  if (angular.isDefined($scope.changePwdauthObj.questionCd) && $scope.changePwdauthObj.questionCd != "" && $scope.changePwdauthObj.questionCd != null){
			  tempRequest.securityQuestionCd = $scope.changePwdauthObj.questionCd.cd;
		  } 
		  if (angular.isDefined($scope.changePwdauthObj.SecurityAns) && $scope.changePwdauthObj.SecurityAns != "" && $scope.changePwdauthObj.SecurityAns != null){
			  tempRequest.securityAns = $scope.changePwdauthObj.SecurityAns;
		  } 
		  
		  
		  	var jsonData = JSON.stringify(tempRequest);
			 console.log(jsonData);
		  	var dataToSend = {
                   data: jsonData,
           };
			$scope.authenticateUser(dataToSend, "rs/auth/changePasswordFirstTime",$scope.authSuccess, $scope.authFailure);
	  };
	 
	 
	  $scope.authenticate = function (index){  
		  
		  var tempRequest = {};
		  if( (angular.isUndefined( $scope.authObj.userName) || $scope.authObj.userName == ""  || $scope.authObj.userName == null) &&
		   (angular.isUndefined($scope.authObj.password) || $scope.authObj.password == ""  || $scope.authObj.password == null) ){
			  $scope.errorMsg = "Please enter your credentials!";
			  $scope.showErrorMsg = true;
			  
			  //alert("Enter atleat one search Criteria");
			  return false;
		 }
		 
		  
		  if (angular.isDefined($scope.authObj.userName) && $scope.authObj.userName != "" && $scope.authObj.userName !=null){
			  tempRequest.empNumber = $scope.authObj.userName; 
		  }
		  if (angular.isDefined($scope.authObj.password) && $scope.authObj.password != "" && $scope.authObj.password != null){
			  tempRequest.password = $scope.authObj.password;
		  }  
		  	var jsonData = JSON.stringify(tempRequest);
			 console.log(jsonData);
		  	var dataToSend = {
                    data: jsonData,
            };
			$scope.authenticateUser(dataToSend, "rs/auth/login",$scope.authSuccess, $scope.authFailure);
	  };
	  /**  Call POST service to load data **/
	  $scope.authenticateUser = function (data,_url, success, error) {
      	console.log("Auth Data---"+data);
      	var reqData = $.param(data);
          $http({
              method: 'POST',
              url: _url,
              data:reqData,
              cache: false
          })
              .success(function (data, status, headers, config) {
                  if (status === 200) {
                      success(data);
                  }
                  else {
                      error(data);
                  }
                  return false;
              })
              .error(function (data, status, headers, config) {
                  error(data);
                  return false;
              });
      };
	   //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
      $scope.authSuccess = function (result) {
    	  if(result.header.status == 200){
    		  var twentyMinutesLater = new Date();
    		  twentyMinutesLater.setMinutes(twentyMinutesLater.getMinutes() + 20);
    		  
    		  if(result.userDetails.isFirstTime != null && result.userDetails.isFirstTime == "Y")
			  {
    			  
    			  //$scope.securityQuestionList = result.userDetails.securityQuestions;
    			  window.location = "/VisaTracking/ChangePasswordFirstTimeLogin.html"; 
			  }
    		  else if(result.userDetails.isFirstTime != null && result.userDetails.isFirstTime == "N")
			  {
    			  document.cookie = "userDtl="+JSON.stringify(result.userDetails) +"; expires="+twentyMinutesLater+"; path=/";
    	    		 // document.cookie = "userDtl="+JSON.stringify(result.userDetails) +";path=/ResourceManagementTool ;expires="+twentyMinutesLater+";";
    	    		  sessionStorage.setItem("portfolioID",result.userDetails.portfolioCd);
    	    		  sessionStorage.setItem("portfolioDesc",result.userDetails.portfolioDesc);
    	    		  sessionStorage.setItem("roleCD",result.userDetails.roleCd);
    	    		  sessionStorage.setItem("roleDesc",result.userDetails.roleDesc);
    			  window.location = "/VisaTracking/index.html"; 
			  }
    		  else
			  {
    			  document.cookie = "userDtl="+JSON.stringify(result.userDetails) +"; expires="+twentyMinutesLater+"; path=/";
    	    		 // document.cookie = "userDtl="+JSON.stringify(result.userDetails) +";path=/ResourceManagementTool ;expires="+twentyMinutesLater+";";
    	    		  sessionStorage.setItem("portfolioID",result.userDetails.portfolioCd); 
    			  window.location = "/VisaTracking/index.html"; 
			  }
    		  document.cookie = "masterDtl="+JSON.stringify(result.masterDetails) +"; path=/";
    		  sessionStorage.setItem("masterDetails",JSON.stringify(result.masterDetails));
    	  }
    	  else
		  {
		  	$scope.authFailure(result);
		  }
    	
      };
      //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
      $scope.authFailure = function (result) {
    	  if(result.header.status == 400){
    		  $scope.errorMsg = result.header.message;
    		  $scope.showErrorMsg = true;
    	  }
    	  else{
    		  $scope.errorMsg = "Application encountered a problem, please contact system administration.";
    		  $scope.showErrorMsg = true;
    	  }
      };

	     //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-

	  $scope.closeErrorPopup = function(){
		  $scope.showErrorMsg = false;
	  };
}]);
	
