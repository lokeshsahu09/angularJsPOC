resourceMangmntApp.controller('tabNavigatorController', function($rootScope, $scope, $location)
{

	
    $rootScope.tabs = [{
   	 name : 'Visa Tracking',
     url : "/visaTracking",
     image:"images/TeamDetails.png",
     allowNavigation : false
    }  
    ];

    $scope.roleCd = $rootScope.userDtl.roleCd;//= 2; //$rootScope.userDtl.roleCd;
    
    $scope.currIndex = 0;
    $scope.navigatePage = function (index){
            $location.path($rootScope.tabs[index].url);
            $scope.currIndex =0;
    };
    $rootScope.$on('$viewContentLoaded', function () {
        var absURL= $location.absUrl();
        var pageIndex = 0;
        for(var i=1;i<$rootScope.tabs.length;i++){
            if(absURL.indexOf($rootScope.tabs[i].url) !=-1){
                pageIndex = i;
                break;
            }
        }
        if(pageIndex!== 0){
            $scope.currIndex =pageIndex;
        }
        
      var x = document.cookie;
  	  if(x.indexOf("empNbr") == -1 ){
  		  window.location = "/VisaTracking/login.html";
  	  }

    });


});