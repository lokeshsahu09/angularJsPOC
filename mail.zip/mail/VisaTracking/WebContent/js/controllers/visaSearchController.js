resourceMangmntApp.controller("visaSearchController",['$scope','$window', '$rootScope','DataServices','CommonUtils','$filter',function($scope,$window,$rootScope,DataServices,CommonUtils,$filter){
	/*$(".integer").keydown(function (e) {

		 if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
	             // Allow: Ctrl+A, Command+A
	            (e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) || 
	             // Allow: home, end, left, right, down, up
	            (e.keyCode >= 35 && e.keyCode <= 40)) {

	                 return;
	        }
	        // Ensure that it is a number and stop the keypress
	        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {

	            e.preventDefault();

	        }
	}); */
	$(".endDate").keydown(function (e) {

		if ( e.ctrlKey || e.altKey) {
			e.preventDefault();
			} else {
			var key = e.keyCode;
			if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
			e.preventDefault();
			}
			}
	}); 
	$(".startDate").keydown(function (e) {

		if ( e.ctrlKey || e.altKey) {
			e.preventDefault();
			} else {
			var key = e.keyCode;
			if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
			e.preventDefault();
			}
			}
	}); 

	$scope.months = [
	                 { label:"Jan",index:1 },
	                 { label:"Feb",index:2 },
	                 { label:"Mar",index:3 },
	                 { label:"Apr",index:4 },
	                 { label:"May",index:5 },
	                 { label:"Jun",index:6 },
	                 { label:"Jul",index:7 },
	                 { label:"Aug",index:8 },
	                 { label:"Sep",index:9 },
	                 { label:"Oct",index:10 },
	                 { label:"Nov",index:11 },
	                 { label:"Dec",index:12 }
	                 ];

	$scope.costTyp = [{cd:1,desc:"Billable"},{cd:3,desc:"Partial"},{cd:2,desc:"Non-Billable"}];
	$scope.associateStatus = [{cd:1,desc:"Active"},{cd:-1,desc:"Archived"}];
	$rootScope.showEmplVisaDtls = false;
	$scope.showResults = false;
	$scope.showErrorMsg = false;
	$rootScope.associateSearchResults = null;
	$scope.visaSearchObj = {};
	//$rootScope.deleteFlag="RecordPresent";
		
	$scope.searchReq = null;
	$rootScope.roleOfLoggedInEmp=sessionStorage.getItem("roleCD");
	$rootScope.roleDescOfLoggedInEmp=sessionStorage.getItem("roleDesc");
	$rootScope.portfolioOfLoggedInEmp=sessionStorage.getItem("portfolioID");
	$rootScope.portfolioDescOfLoggedInEmp=sessionStorage.getItem("portfolioDesc");
	$rootScope.masterDetails=sessionStorage.getItem("masterDetails");
	
	//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	        
	/** lConfiguration for JQGrid-Employee Table**/
	$scope.config = {
			datatype: "local",
			height: 250,
			colNames:['Emp #','First Name','Last Name','Visa Type','Visa Status','Project Name','Travel Period','Travel To',
			          'Initiate Status','Business Case','Date of Request',
			          'Skill/Role','Billing Rate','Potential Loss','Portfolio','SubmittedTS','lastUpdatedDate'],
			          colModel:[
			                    {name:'empNbr',index:'empNbr', width:50, sorttype:"int",align:"center",resizable:false},
			                    {name:'firstName',index:'firstName', width:55,sorttype:"text",align:"left",resizable:false},
			                    {name:'lastName',index:'lastName', width:55, sorttype:"text",align:"left",resizable:false},
			                    {name:'visaType',index:'visaType', width:55, sorttype:"text",align:"center",resizable:false},
			                    {name:'status',index:'status', width:65, sorttype:"text",align:"center",resizable:false},
			                    {name:'projectType',index:'projectType', sorttype:"text",width:75, align:"center",resizable:false},
			                    {name:'travelPeriodTerm',index:'travelPeriodTerm', sorttype:"text",width:70,align:"center",resizable:false},
			                    {name:'travelTo',index:'travelTo', sorttype:"text",width:48, align:"center",resizable:false},
			                    {name:'initialStatus',index:'initialStatus', sorttype:"text",width:85,align:"center",resizable:false},
			                    {name:'businessCase',index:'businessCase', sorttype:"text",width:75, align:"center",resizable:false},
			                    {name:'startDateRequirement',index:'startDateRequirement', sorttype:"text",width:90, sorttype:"int",align:"center",resizable:false},
			                    {name:'skillSet',index:'skillSet', width:55, sorttype:"text",align:"center",resizable:false},
			                    {name:'billingRate',index:'billingRate', width:65, sorttype:"text",align:"center",resizable:false},
			                    {name:'potentialLoss',index:'potentialLoss', width:80, sorttype:"text",align:"center",resizable:false},
			                    {name:'portfolio',index:'portfolio', width:48, sorttype:"text",align:"center",resizable:false},
			                    {name:'submittedTS',index:'submittedTS', width:75, sorttype:"text",align:"center",resizable:false},
			                    {name:'lastUpdatedDate',index:'lastUpdatedDate', width:90, sorttype:"text",align:"center",resizable:false}

			                    ],
			                    //width:($(".viewClass").width() - 100),
			                    sortname: 'id',
			                    rowNum: 20,
			                     rowList: [5,10 ,15,20],
			                     sortname: 'id',
			                     toolbarfilter: true,
			     	             viewrecords: true,
			     	             pgbuttons: true,
			                     loadonce: true,
			                     pager: '#pager',
			                     jsonReader: {cell:""},
			                     viewrecords: true,
			                     height: "100%",
			                     forceFit: true,
			                     autowidth: true,
			                    //  minWidth:($(".viewClass").width() - 20),
			                    gridview:true,
			                    shrinkToFit:false,
			                    multiselect:true,
			                    forceFit:true,
			                    viewrecords: true,
			                    altRows     : true,
			                    altclass    : 'oddRow',
			                    rowattr: function (rd) { 
			                    	if (rd.costTyp == 2 && $rootScope.isAdditionalFeatureAllowed) {
			                    		return {"class": "non-billable-color"};
			                    	}
			                    	if (rd.costTyp == 3 && $rootScope.isAdditionalFeatureAllowed) {
			                    		return {"class": "partial-color"};
			                    	}
			                    }, 
			                    ondblClickRow: function(rowid)
			                    {  
			                    	$rootScope.disablePortfolio = ($rootScope.roleOfLoggedInEmp != 9 && $rootScope.roleOfLoggedInEmp !=6) || ($rootScope.deleteFlag=='RecordAbsent' && $rootScope.empEditFlg !='ADD');
			                    	var grid = $('#grid_visaSearch');    
			                    	var empNbr = grid.jqGrid('getCell', rowid, 'empNbr');
			                    	var firstName = grid.jqGrid('getCell', rowid, 'firstName');
			                    	var lastName = grid.jqGrid('getCell', rowid, 'lastName');
			                    	var visaType = grid.jqGrid('getCell', rowid, 'visaType');
			                    	var status = grid.jqGrid('getCell', rowid, 'status');
			                    	var projectName = grid.jqGrid('getCell', rowid, 'projectType'); 
			                    	var travelPeriod = grid.jqGrid('getCell', rowid, 'travelPeriodTerm');
			                    	var travelTo = grid.jqGrid('getCell', rowid, 'travelTo');
			                    	var initialStatus = grid.jqGrid('getCell', rowid, 'initialStatus');
			                    	var businessCase = grid.jqGrid('getCell', rowid, 'businessCase');
			                    	var startDateRequirement = grid.jqGrid('getCell', rowid, 'startDateRequirement');
			                    	var skillSet = grid.jqGrid('getCell', rowid, 'skillSet');
			                    	var billingRate = grid.jqGrid('getCell', rowid, 'billingRate');
			                    	var potentialLoss = grid.jqGrid('getCell', rowid, 'potentialLoss');
			                    	var portfolio = grid.jqGrid('getCell', rowid, 'portfolio');
			                    	var lastUpdatedDate = grid.jqGrid('getCell', rowid, 'lastUpdatedDate');
			                    	var submittedTS = grid.jqGrid('getCell', rowid, 'submittedTS');
			                    	$scope.$apply(function(){
			                    		$scope.selempNbr = empNbr;
			                    		$scope.openEmpDtlsEditPopup("EDIT",empNbr,firstName,lastName,visaType,status,projectName,travelPeriod,travelTo,initialStatus,businessCase,
			                    				startDateRequirement,skillSet,billingRate,potentialLoss,portfolio,submittedTS,lastUpdatedDate);
			                    	});

			                    }

	};

	function formatDate( cellvalue, options, rowObject )
	{
		var dateString ="";
		if(cellvalue!= null  && cellvalue!= ""){
			dateString =  $filter('date')(cellvalue, "dd-MMM-yyyy");
//			date = Date.parse(cellvalue);
//			dateString = date.toString('dd-MMM-yy');//("dd-mmm-yy"); 
//			String MyString = "12-30-2014"; // get value from text field
//			DateTime MyDateTime = new DateTime();
//			MyDateTime = DateTime.ParseExact(cellvalue, "yyyy-mm-dd",null);
//			String MyString_new = MyDateTime.ToString("dd-MMM-yyyy");
		}
		return dateString;
	}    
	function setName( cellvalue, options, rowObject )
	{
		return cellvalue + ' ' + rowObject.lastName;
	} 

	function setAllocated ( cellvalue, options, rowObject ){
		if(angular.isDefined(cellvalue) && cellvalue!= ""){
//			$window.alert(cellvalue);
			if(cellvalue == "Y"){
				return "YES";
			}else{
				return "NO";
			}
		} 
	}

	function setManagerName( cellvalue, options, rowObject )
	{
		if(angular.isDefined(cellvalue) && cellvalue != ""){
			return cellvalue;
		}
		else if(angular.isDefined(rowObject.thdSrManagerName) && rowObject.thdSrManagerName != ""){
			return rowObject.thdSrManagerName;
		}
		else{
			return "";
		}
	} 

	/** Onclick of search Button**/	  
	$scope.searchResults_visa = function (){  
		
		$scope.showResults = false;
		$rootScope.associateSearchResults = null;
		$scope.searchReq = null;
		var tempRequest = {};
		if( (angular.isUndefined( $scope.visaSearchObj.empNbr) || $scope.visaSearchObj.empNbr == "" || $scope.visaSearchObj.empNbr ==null) &&
				(angular.isUndefined($scope.visaSearchObj.portfolio) || $scope.visaSearchObj.portfolio == "" || $scope.visaSearchObj.portfolio ==null) &&
				(angular.isUndefined($scope.visaSearchObj.visaType) || $scope.visaSearchObj.visaType == "" || $scope.visaSearchObj.visaType ==null) &&
				(angular.isUndefined($scope.visaSearchObj.visaStatus) || $scope.visaSearchObj.visaStatus == "" || $scope.visaSearchObj.visaStatus ==null) &&
				(angular.isUndefined($scope.visaSearchObj.startDate) || $scope.visaSearchObj.startDate == null || $scope.visaSearchObj.startDate == "") &&
				(angular.isUndefined($scope.visaSearchObj.endDate) || $scope.visaSearchObj.endDate == null || $scope.visaSearchObj.endDate == "")&&
				(angular.isUndefined($scope.visaSearchObj.projectType) || $scope.visaSearchObj.projectType == null || $scope.visaSearchObj.projectType == "")&&
				(angular.isUndefined($scope.visaSearchObj.skillSet) || $scope.visaSearchObj.skillSet == null || $scope.visaSearchObj.skillSet == "") &&
				(angular.isUndefined($scope.visaSearchObj.DeleteValue) || $scope.visaSearchObj.DeleteValue == null || $scope.visaSearchObj.DeleteValue == "")){
			
			$scope.errorMsg = "Please enter at least one search criteria."; 
			$scope.showErrorMsg = true;
			//alert("Enter atleat one search Criteria");
			return false;
		}else{
			var startEndCombo=true;
			var empcheck=true;
			if (angular.isDefined($scope.visaSearchObj.empNbr) && $scope.visaSearchObj.empNbr != "" 
				&& $scope.visaSearchObj.empNbr !=null)
			
			{
                  if(!isNaN($scope.visaSearchObj.empNbr))
                	  {
				tempRequest.empNbr = $scope.visaSearchObj.empNbr;
                	  }
                  else
                	  {
                	  empcheck=false;
                	  $scope.errorMsg="Employee id should be number.";
                	  $scope.showErrorMsg = true;
					  	return false;		  
                	  }
			}
			if (angular.isDefined($scope.visaSearchObj.portfolio) && $scope.visaSearchObj.portfolio != ""
				&& $scope.visaSearchObj.portfolio !=null){
				tempRequest.portfolio = $scope.visaSearchObj.portfolio.portfolioDescription;
			}
			if (angular.isDefined($scope.visaSearchObj.visaType) && $scope.visaSearchObj.visaType != ""
				&& $scope.visaSearchObj.visaType !=null){
				tempRequest.visaType = $scope.visaSearchObj.visaType.visaTypDesc;
			}
			if (angular.isDefined($scope.visaSearchObj.visaStatus) && $scope.visaSearchObj.visaStatus != ""
				&& $scope.visaSearchObj.visaStatus !=null){
				tempRequest.visaStatus= $scope.visaSearchObj.visaStatus.visaStatsDesc;
			}
			
			if (angular.isDefined($scope.visaSearchObj.startDate) && $scope.visaSearchObj.startDate != null && $scope.visaSearchObj.startDate != ""){
				tempRequest.startDate = $scope.visaSearchObj.startDate;
				startEndCombo=false;
				if(!angular.isDefined($scope.visaSearchObj.endDate) || ($scope.visaSearchObj.endDate == null ||  $scope.visaSearchObj.endDate == "")){
					$scope.errorMsg = "Please put end date with start date."; 
					$scope.showErrorMsg = true;
				}else
				{
					startEndCombo=true;
				}
			}
			if (angular.isDefined($scope.visaSearchObj.endDate) && $scope.visaSearchObj.endDate != null && $scope.visaSearchObj.endDate != ""){
				tempRequest.endDate = $scope.visaSearchObj.endDate;
				startEndCombo=false;
				if(!angular.isDefined($scope.visaSearchObj.startDate) || ($scope.visaSearchObj.startDate == null ||  $scope.visaSearchObj.startDate == "")){
					$scope.errorMsg = "Please put start date with end date."; 
					$scope.showErrorMsg = true;
				}else{
					startEndCombo=true;
				}
			}
			if (angular.isDefined($scope.visaSearchObj.projectType) && $scope.visaSearchObj.projectType != null){
				tempRequest.projectType = $scope.visaSearchObj.projectType.desc;
			}
			if (angular.isDefined($scope.visaSearchObj.skillSet) && $scope.visaSearchObj.skillSet != null)
			{
				tempRequest.skillSet = $scope.visaSearchObj.skillSet;
			}
			
			if (angular.isDefined($scope.visaSearchObj.DeleteValue && $scope.visaSearchObj.DeleteValue != null))
			{
				$rootScope.deleteFlag="RecordPresent";
				if($scope.visaSearchObj.DeleteValue=="deleted")
				{
					tempRequest.isDeleted = $scope.visaSearchObj.DeleteValue;
					$rootScope.deleteFlag="RecordAbsent";
				}
				else
				{
					tempRequest.isDeleted = $scope.visaSearchObj.DeleteValue;
					$rootScope.deleteFlag="RecordPresent";
				}

			}
			
			

			var jsonData = JSON.stringify(tempRequest);
			console.log(jsonData);
			var dataToSend = {
					data: jsonData,
			};
			CommonUtils.refreshCookie();
			$scope.searchReq = encodeURI(jsonData);
			if(startEndCombo==true && empcheck==true)
				DataServices.getVisaDetails(dataToSend, $scope.populateGrid, $scope.errorFunc);
		}
	};
	//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
	$scope.onLoadOfVisaSearch = function () {
		$scope.years =  $rootScope.yearComboList;
		if(angular.isDefined($rootScope.teamDefaultComboList) && $rootScope.teamDefaultComboList != ""){
			$scope.populateComboList($rootScope.teamDefaultComboList);
		}
	};
	//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
	$scope.$watch('teamDefaultComboList', function (value) {
		$scope.populateComboList($rootScope.teamDefaultComboList);
	});
	//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
	$scope.populateComboList = function (result) {
		 $scope.visaSearchObj.DeleteValue = "undeleted";
		$scope.location = result.locationList;
		$scope.travelPeriodlist=result.travelPeriodlist;
		$scope.visaTypeList = ($rootScope.masterDtl.visaTypeList);
		$scope.traveltoList = result.traveltoList;
		$scope.visaStatusList = $rootScope.masterDtl.visaStatusList;
        $scope.initialStatusValue=result.initialStatusValue;
		$scope.porfolioList =  $scope.tempPorfolioList =  $rootScope.masterDtl.porfolioList;
		if($rootScope.roleOfLoggedInEmp == 9 || $rootScope.roleOfLoggedInEmp ==6)
		{
			$scope.visaSearchObj.portfolio="";
			
		}
		else
		{
			angular.forEach($scope.porfolioList, function(porfolioL, index){
				if($rootScope.portfolioDescOfLoggedInEmp.indexOf(porfolioL.portfolioDescription)>=0 ){
					$scope.visaSearchObj.portfolio=$scope.porfolioList[index];
				}
			});
			/*if($rootScope.portfolioDescOfLoggedInEmp.indexOf("Stores")>=0){
				$scope.visaSearchObj.portfolio=$scope.porfolioList[0];
			}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("Merch")>=0){
				$scope.visaSearchObj.portfolio=$scope.porfolioList[1];
			}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("SCM")>=0){
				$scope.visaSearchObj.portfolio=$scope.porfolioList[2];
			}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("BI&")>=0){
				$scope.visaSearchObj.portfolio=$scope.porfolioList[3];
			}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("Ecom")>=0){
				$scope.visaSearchObj.portfolio=$scope.porfolioList[4];
			}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("QA")>=0){
				$scope.visaSearchObj.portfolio=$scope.porfolioList[5];
			}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("Account")>=0){
				$scope.visaSearchObj.portfolio=$scope.porfolioList[6];
			}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("SAP")>=0){
				$scope.visaSearchObj.portfolio=$scope.porfolioList[7];
			}else if($rootScope.portfolioDescOfLoggedInEmp.indexOf("IS Support")>=0){
				$scope.visaSearchObj.portfolio=$scope.porfolioList[8];
			}*/
		}
		$scope.roleList = result.roleList;
		$scope.secRoleList = result.secRoleList;
		$scope.designationList = result.designationList;
		$scope.projectManagerList = $scope.tempProjectManagerList = result.projectManagerList;
		$scope.deliveryManagerList =  $scope.tempDeliveryManagerList = result.deliveryManagerList;
		$scope.groupLeadList = result.groupLeadList;
		$scope.contractTypList = result.contractTypList;
		$scope.technologyList = result.technologyList;
		$scope.projectList = $scope.tempProjectList = result.projectList;
		$scope.projectLeadList = $scope.tempProjectLeadList = result.projectLeadList;
		$scope.techLvlList = result.techLvlList;
		$scope.setCurrentMon();
		$scope.setDefaultAssocaiteStatus();
	};
	//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-

	$scope.setCurrentMon = function(){
		$scope.visaSearchObj.selMon=  $scope.months[new Date().getMonth()];
		$scope.visaSearchObj.selYear =  $scope.years[1];
		CommonUtils.setDefaultPortfolio($scope,$scope.visaSearchObj, $scope.changeofPortfolio);
		CommonUtils.setDefaultPm($scope,$scope.visaSearchObj, $scope.changeofPortfolio);
		if($rootScope.userDtl.roleCd <=3){ 
			angular.forEach($scope.projectLeadList, function(projLead, index){
				if(projLead.empNbr  === $rootScope.userDtl.empNbr){
					$scope.visaSearchObj.projLead = projLead;
				}
			});
		}
	};


	$scope.setDefaultAssocaiteStatus = function(){

		$scope.visaSearchObj.searchAssocStat = 1;
	};
	//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
	$scope.populateGrid = function (result)

	{
		$("#grid_visaSearch").trigger('reloadGrid');
		if(result=="" || result.visaTracerList.length==0){
			$scope.errorMsg = "No results found, please change the search criteria.";
			$scope.showErrorMsg = true;
		}else{
			console.log('for search result.header.status.......'+result.header.status);
			if(result.header.status == 200)
	
			{
				if(result.totalResults == "0" || result.visaTracerList.length == 0){
					$scope.errorMsg = "No results found, please change the search criteria.";
					$scope.showErrorMsg = true;
				}
				else
					
				{
					//$rootScope.associateSearchResults = result;
					$rootScope.visaTracerList = result.visaTracerList;
					$scope.data = result.visaTracerList;
					$scope.footerData =  result;
					$scope.showResults = true;
				}
			}
			else
			{
				$scope.errorFunc(result);
			}
		}

	};
	//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
	/**Exception handling**/
	$scope.errorFunc = function (result) {
		if(result==""){
			$scope.errorMsg = "No results found, please change the search criteria.";
			$scope.showErrorMsg = true;
		}
		if(result.header.status == 400){
			$scope.errorMsg = result.header.message;
		}
		else{
			$scope.errorMsg = "Application encountered a problem, please contact system administration.";
		}
		$scope.showErrorMsg = true;
	};
	//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
	$scope.changeofPortfolio = function(optn){
		CommonUtils.changeofPortfolioDetails(optn,$scope.visaSearchObj,$scope.populatePortfolioDetails,$scope.errorFunc);
	};

	$scope.populatePortfolioDetails = function(result){
		CommonUtils.populatePortfolioDetails($scope, $scope.visaSearchObj,result,true);
	};


	$scope.resetSearch_visa = function()
	{
		$("#grid_visaSearch").trigger('reloadGrid');
		$scope.visaSearchObj = {};
		$rootScope.associateSearchResults = null;
		$scope.porfolioList =  $scope.tempPorfolioList;
		if($rootScope.roleOfLoggedInEmp == 9 || $rootScope.roleOfLoggedInEmp ==6){
			$scope.visaSearchObj.portfolio="";
		}else{
			angular.forEach($scope.porfolioList, function(porfolioL, index){
				if($rootScope.portfolioDescOfLoggedInEmp.indexOf(porfolioL.portfolioDescription)>=0 ){
					$scope.visaSearchObj.portfolio=$scope.porfolioList[index];
				}
			});
		}
		$scope.projectManagerList = $scope.tempProjectManagerList; 
		$scope.deliveryManagerList =  $scope.tempDeliveryManagerList;
		$scope.projectLeadList = $scope.tempProjectLeadList;
		$scope.projectList = $scope.tempProjectList;
		$scope.setCurrentMon();
		$scope.searchReq = null;
		 $scope.visaSearchObj.DeleteValue = "undeleted";
	};

	/** Onclick of Add Emploee Button**/	  
	$scope.addEmployee_visa = function(){
		$rootScope.disablePortfolio = ($rootScope.roleOfLoggedInEmp != 9 && $rootScope.roleOfLoggedInEmp !=6) || ($rootScope.deleteFlag=='RecordAbsent' && $rootScope.empEditFlg !='ADD');
		
		$scope.selempNbr ="";
		$scope.openEmpDtlsPopup("ADD");
		//$scope.empEditFlg = optn;
		$scope.empNbr="";
		$scope.firstName="";
		$scope.lastName="";
		$scope.visaType="";
		$scope.status="";
		$scope.projectType="";
		$scope.travelPeriod="";
		$scope.travelTo="";
		$scope.initialStatus="";
		$scope.businessCase="";
		$scope.startDateRequirement="";
		$scope.skillSet="";
		$scope.billingRate="";
		$scope.potentialLoss="";
		$scope.portfolio="";
	};
	

	$scope.editEmployee_visa = function(){
		$rootScope.disablePortfolio = ($rootScope.roleOfLoggedInEmp != 9 && $rootScope.roleOfLoggedInEmp !=6) || ($rootScope.deleteFlag=='RecordAbsent' && $rootScope.empEditFlg !='ADD');
		var selectedIDs = $('#grid_visaSearch').jqGrid('getGridParam', 'selarrrow');
		var myCellData;
		if(selectedIDs.length  == 0){
			$scope.errorMsg = "Please select at least one row to edit.";
			$scope.showErrorMsg = true;
		}
		else if(selectedIDs.length > 1){
			$scope.errorMsg = "Multiple rows are selected. Please choose one row.";
			$scope.showErrorMsg = true;
		}
		else{

			myCellData = $('#grid_visaSearch').jqGrid('getCell', selectedIDs[0], 'empNbr');
			console.log('myCellData..............'+myCellData);
			if($rootScope.userDtl.roleCd <=2 && myCellData != $rootScope.userDtl.empNbr){
				$scope.errorMsg = "Authorization not provided to edit the employee";
				$scope.showErrorMsg = true;
				return false;
			}
			$scope.selempNbr = myCellData;
			var rowid=selectedIDs[0];
			var grid = $('#grid_visaSearch');    
        	var empNbr = grid.jqGrid('getCell', rowid, 'empNbr');
			var firstName = grid.jqGrid('getCell', rowid, 'firstName');
        	var lastName = grid.jqGrid('getCell', rowid, 'lastName');
        	var visaType = grid.jqGrid('getCell', rowid, 'visaType');
        	var status = grid.jqGrid('getCell', rowid, 'status');
        	var projectName = grid.jqGrid('getCell', rowid, 'projectType'); 
        	var travelPeriod = grid.jqGrid('getCell', rowid, 'travelPeriodTerm');
        	var travelTo = grid.jqGrid('getCell', rowid, 'travelTo');
        	var initialStatus = grid.jqGrid('getCell', rowid, 'initialStatus');
        	var businessCase = grid.jqGrid('getCell', rowid, 'businessCase');
        	var startDateRequirement = grid.jqGrid('getCell', rowid, 'startDateRequirement');
        	var skillSet = grid.jqGrid('getCell', rowid, 'skillSet');
        	var billingRate = grid.jqGrid('getCell', rowid, 'billingRate');
        	var potentialLoss = grid.jqGrid('getCell', rowid, 'potentialLoss');
        	var portfolio = grid.jqGrid('getCell', rowid, 'portfolio');
        	var lastUpdatedDate = grid.jqGrid('getCell', rowid, 'lastUpdatedDate');
        	var submittedTS = grid.jqGrid('getCell', rowid, 'submittedTS');
        	$scope.openEmpDtlsEditPopup("EDIT",empNbr,firstName,lastName,visaType,status,projectName,travelPeriod,travelTo,initialStatus,businessCase,
    				startDateRequirement,skillSet,billingRate,potentialLoss,portfolio,submittedTS,lastUpdatedDate);

		}
	};
	//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
	$scope.deleteConfirmBox = function(){
		var selectedIDs = $('#grid_visaSearch').jqGrid('getGridParam', 'selarrrow');
		var myCellData=[];
		if(selectedIDs.length  == 0){
			$scope.errorMsg = "Please select at least one row to delete.";
			$scope.showErrorMsg = true;
		}else{
			$scope.confirmMessage = "Are you sure you want to delete this item? If yes click on Confirm";
			$scope.showConfirmBox = true;
		}
	};
	
	$scope.deleteEmployee_visa = function()
	{
		$scope.showConfirmBox = false;
		var selectedIDs = $('#grid_visaSearch').jqGrid('getGridParam', 'selarrrow');
		var myCellData=[];
		if(selectedIDs.length  == 0){
			$scope.errorMsg = "Please select at least one row to delete.";
			$scope.showErrorMsg = true;
		}
		/*else if(selectedIDs.length > 1){
			$scope.errorMsg = "Multiple rows are selected. Please choose one row to delete.";
			$scope.showErrorMsg = true;
		}*/
		else{
			
			
			for (i = 0, n = selectedIDs.length; i < n; i++) {
				//myCellData = $('#grid_visaSearch').jqGrid('getCell', selectedIDs[i], 'empNbr');
				
				
				/*$.each(json, function(arrayID,group) {
					console.log('<a href="'+group.GROUP_ID+'">');
					$.each(group.EVENTS, function(eventID,eventData) {
						console.log('<p>'+eventData.SHORT_DESC+'</p>');
					});
				});*/
				//grid.jqGrid('getCell', rowid, 'visaType');
				var visaType=$('#grid_visaSearch').jqGrid('getCell', selectedIDs[i], 'visaType');
				visaType=visaType.substring(0,visaType.length-1);
				angular.forEach($scope.visaTypeList, function(visaTypeL, index){
					if(visaTypeL.visaTypDesc.indexOf(visaType)>=0 ){
						myCellData.push($('#grid_visaSearch').jqGrid('getCell', selectedIDs[i], 'empNbr'));
						myCellData.push(visaTypeL.visaTypCd);
					}
				});
				
			}
			var senddata=[];
			senddata=myCellData.join(",");
			console.log('cellValues.join(",")..........'+myCellData.join(","));
			if (angular.isDefined($rootScope.userDtl.empNbr) && $rootScope.userDtl.empNbr != "" && $rootScope.userDtl.empNbr != null){
				// $scope.tempRequest.loggedInempNbr = $rootScope.userDtl.empNbr;
			}else{
				$scope.errorMsg = "You are not in valid session. Please log in and try again!";
				$scope.showPopUpErrorMsg = true;
				return false;
			} 
			
			var dataToSend = 
			{
					empNbr: senddata,
					loggedIn: $rootScope.userDtl.empNbr

			};
			console.log("-----delete Associate----"+myCellData);
			CommonUtils.refreshCookie();
			DataServices.deleteAssociate(dataToSend, $scope.handleDeleteSuccess, $scope.errorFunc);
		}
	}; 
	//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
	$scope.handleDeleteSuccess = function(result){
		if(result.header.status == 200){
			$scope.errorMsg = "Employee deleted successfully.";
			$scope.showErrorMsg = true;
			$scope.searchResults_visa();
		}
		else
			$scope.errorFunc(result);
	};

	$scope.openEmpDtlsPopup = function(optn){
		//for empid
		/*$(".integer").keydown(function (e) 
				{

			 if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 16, 110, 190]) !== -1 ||
		             // Allow: Ctrl+A, Command+A
		            (e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) || 
		             // Allow: home, end, left, right, down, up
		            (e.keyCode >= 35 && e.keyCode <= 40) ) {

		                 return;
		        }
		        // Ensure that it is a number and stop the keypress
		        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105))
		        
		        {

		            e.preventDefault();

		        }
		}); */
		
		//for firstname
		$('.onlystring').keydown(function (e) 
				{
			if ((e.shiftKey || e.ctrlKey || e.altKey)) 
			{
				//e.preventDefault();
				}
			
			else 
				
				{
				var key = e.keyCode;
				if (!((key == 8) || (key == 9)  || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90)|| e.shiftKey || e.ctrlKey || e.altKey)) {
				e.preventDefault();
				}
				}
				
			});
		$scope.empEditFlg = optn;
		$rootScope.showEmplVisaDtls = true;  
		$scope.$broadcast ('initEmpDtls');
	};
	
	$scope.openEmpDtlsEditPopup = function(optn,empNbr,firstName,lastName,visaType,status,projectName,travelPeriod,travelTo,initialStatus,businessCase,
			startDateRequirement,skillSet,billingRate,potentialLoss,portfolio,submittedTS,lastUpdatedDate){
		$scope.empEditFlg = optn;
		//clearing the list 1st
		$rootScope.empNbr="";
		$rootScope.firstName="";
		$rootScope.lastName="";
		
		$rootScope.projectType="";
		$rootScope.travelPeriod="";
		$rootScope.travelTo="";
		$rootScope.initialStatus="";
		$rootScope.businessCase="";
		$rootScope.startDateRequirement="";
		$rootScope.skillSet="";
		$rootScope.billingRate="";
		$rootScope.potentialLoss="";
		$rootScope.portfolio="";
		$rootScope.visaType=0;
		$rootScope.status=0;
		$rootScope.submittedTS="";
		$rootScope.lastUpdatedDate="";
		//populating the values
		$rootScope.empNbr=empNbr;
		$rootScope.firstName=firstName;
		$rootScope.lastName=lastName;
		
		$rootScope.projectType=projectName;
		$rootScope.travelPeriod=travelPeriod;
		$rootScope.travelTo=travelTo;
		$rootScope.initialStatus=initialStatus;
		$rootScope.businessCase=businessCase;
		$rootScope.startDateRequirement=startDateRequirement;
		$rootScope.skillSet=skillSet;
		$rootScope.billingRate=billingRate;
		$rootScope.potentialLoss=potentialLoss;
		$rootScope.portfolio=portfolio;
		//visaType=visaType.substring(0,visaType.length-1);
		angular.forEach($scope.visaTypeList, function(visaTypeL, index){
			if(visaTypeL.visaTypDesc===(visaType) ){
				$rootScope.visaType=visaTypeL.visaTypCd;
			}
		});	
		/*if(visaType.indexOf('H1 B')!=-1){
			$rootScope.visaType=1;
		}else if(visaType.indexOf('L1 B')!=-1){
			$rootScope.visaType=2;
		}else if(visaType.indexOf('L1 A')!=-1){
			$rootScope.visaType=3;
		}else if(visaType.indexOf('B1')!=-1){
			$rootScope.visaType=4;
		}*/
		if(status.indexOf('Submitted')!=-1){
			$rootScope.status=1;
		}else if(status.indexOf('Approval In Progress')!=-1){
			$rootScope.status=2;
		}else if(status.indexOf('Approved')!=-1){
			$rootScope.status=3;
		}else if(status.indexOf('Rejected')!=-1){
			$rootScope.status=4;
		}
		$rootScope.submittedTS=submittedTS;
		$rootScope.lastUpdatedDate=lastUpdatedDate;
		
		$rootScope.showEmplVisaDtls = true;  
		$scope.$broadcast ('initEmpEditDtls');
	};

	$scope.closeErrorPopup = function(){
		$scope.showErrorMsg = false;
	};
	$scope.closeConfirmPopup = function(){
		$scope.showConfirmBox = false;
	};
	$scope.exportEmployee_visa = function()
	{
		if(angular.isDefined($rootScope.visaTracerList) && $rootScope.visaTracerList!=null)
		{
			if($scope.searchReq)
			{
				console.log("---Export Associate--"+$scope.searchReq);
				CommonUtils.refreshCookie();
				DataServices.exportAssociate($scope.searchReq,null, null);
			}
		}
		else
			{
			$scope.errorMsg = "Please search before clicking on export";
			$scope.showErrorMsg = true;
			return false;
			
			}
	};

}]);
