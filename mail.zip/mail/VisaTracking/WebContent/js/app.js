var resourceMangmntApp  = angular.module('resourceManagementApp',['ngRoute','ngCookies']);

resourceMangmntApp.config(['$routeProvider', function($routeProvider) {
	$routeProvider.when('/visaTracking',
	{
		controller:'visaSearchController',
		templateUrl:'pages/visasearch.html',
	});
}]);

