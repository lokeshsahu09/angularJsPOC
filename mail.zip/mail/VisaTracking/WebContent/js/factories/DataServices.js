resourceMangmntApp.factory('DataServices', ['$rootScope', '$http',
    function ($rootScope, $http, $q) {
        var DataServicesInstance = {};
        DataServicesInstance.teamCombo_Url ="data/combo.json";
        DataServicesInstance.teamDetails_Url ="rs/associate/prepopulate";
        DataServicesInstance.projCombo_Url = "rs/cache/project"; 
        DataServicesInstance.undoDeleted_Url="rs/associate/undodelete"; 
        DataServicesInstance.createAssociate_Url ="rs/visaAdd/addEmpVisaDetails"; 
        DataServicesInstance.updateAssociate_Url ="rs/associate/update"; 
        DataServicesInstance.deleteAssociate_Url ="rs/associate/delete"; 
        DataServicesInstance.portfolioSearch_Url ="data/combo.json";//"rs/associate/dropdown"; 
        DataServicesInstance.projectSearch_Url ="rs/project/search"; 
        
        DataServicesInstance.visaSearch_Url ="rs/associate/search";
        
        DataServicesInstance.createProject_Url ="rs/project/create"; 
        DataServicesInstance.updateProject_Url ="rs/project/update"; 
        DataServicesInstance.deleteProject_Url ="rs/project/delete";
        DataServicesInstance.changePassword_Url ="rs/auth/changePassword";
        DataServicesInstance.searchWOdetails_Url ="rs/workorder/search";
        DataServicesInstance.validateWoEmpdetails_Url ="rs/workorder/validateEmpNbrs";
        DataServicesInstance.createWorkOrder_Url ="rs/workorder/create"; 
        DataServicesInstance.updateWorkOrder_Url ="rs/workorder/update";
        DataServicesInstance.deleteWorkOrder_Url ="rs/workorder/delete"; 
        DataServicesInstance.getEmpList_Proj_Url ="rs/workorder/getEmpListForProject"; 
        DataServicesInstance.exportAssociate_Url ="rs/spreadsheet/associate"; 
        DataServicesInstance.exportWorkOrder_Url ="rs/spreadsheet/getwoexcel";
        
          
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	        
        DataServicesInstance.getTeamComboList = function (success, error)
        {
        	var url = DataServicesInstance.teamCombo_Url+"?portfolioCd="+ $rootScope.userDtl.portfolioCd;
            DataServicesInstance.Get(url, success, error);
        };
        
        DataServicesInstance.undoDeletedRecord=function(data, success, error)
        {
        	
        	DataServicesInstance.Post(data,  DataServicesInstance.undoDeleted_Url, success, error);
        };
        DataServicesInstance.getTeamDetails = function (data, success, error)
        {
        	
            DataServicesInstance.Post(data,  DataServicesInstance.teamDetails_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	        
        DataServicesInstance.getProjectComboList = function (success, error) {
            DataServicesInstance.Get(DataServicesInstance.projCombo_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	        
       /* DataServicesInstance.getTeamDetails = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.teamSearch_Url, success, error);
        };*/
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	        
        DataServicesInstance.createAssociate = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.createAssociate_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        DataServicesInstance.updateAssociate = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.updateAssociate_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        DataServicesInstance.deleteAssociate = function (data, success, error) {
            DataServicesInstance.Delete(data,DataServicesInstance.deleteAssociate_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        DataServicesInstance.getPortfolioSearchDetails = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.portfolioSearch_Url, success, error);
        };
        //
        DataServicesInstance.getProjectSearchDetails = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.projectSearch_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	        
        DataServicesInstance.createProject = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.createProject_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        DataServicesInstance.updateProject = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.updateProject_Url, success, error);
        };
       //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        DataServicesInstance.changePassword = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.changePassword_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        DataServicesInstance.searchWOdetails = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.searchWOdetails_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        DataServicesInstance.validateWoEmpdetails = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.validateWoEmpdetails_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	        
        DataServicesInstance.createWorkOrder = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.createWorkOrder_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        DataServicesInstance.updateWorkOrder = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.updateWorkOrder_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        DataServicesInstance.deleteWorkOrder = function (data, success, error) {
            DataServicesInstance.Delete(data,DataServicesInstance.deleteWorkOrder_Url, success, error);
        };
        DataServicesInstance.getVisaDetails = function (data, success, error) {
        	console.log('searched...............');
            DataServicesInstance.Post(data,DataServicesInstance.visaSearch_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        DataServicesInstance.exportAssociate = function (data, success, error) {
        	var url = DataServicesInstance.exportAssociate_Url+"?data="+ data+"&portfolioCd="+$rootScope.userDtl.portfolioCd;
        	window.open(url, "_blank"); 
           // DataServicesInstance.Get(url,success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        DataServicesInstance.exportWorkOrder = function (data, success, error) {
        	var url = DataServicesInstance.exportWorkOrder_Url+"?data= "+ data;
        	window.open(url, "_blank"); 
           // DataServicesInstance.Get(url,success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
        DataServicesInstance.getEmpDtlsofProj = function (data, success, error) {
            DataServicesInstance.Post(data,DataServicesInstance.getEmpList_Proj_Url, success, error);
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
     
        /**  Call POST service to load data **/
        DataServicesInstance.Post = function (data,_url, success, error)
        {
        	var reqData = $.param(data);
            $http({
                method: 'POST',
                url: _url,
                data:reqData,
                cache: false
            })
                .success(function (data, status, headers, config) {
                    if (status === 200) {
                        success(data);
                    }
                    else {
                        error(data);
                    }
                    return false;
                })
                .error(function (data, status, headers, config) {
                    error(data);
                    return false;
                });
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	        
        /**  Call GET service to load data **/
        DataServicesInstance.Get = function (_url, success, error) {
            $http({
                method: 'GET',
                url: _url,
                cache: false
            })
                .success(function (data, status, headers, config) {
                    if (status === 200) {
                        success(data);
                    }
                    else {
                        error(data);
                    }
                    return false;
                })
                .error(function (data, status, headers, config) {
                    error(data);
                    return false;
                });
        };
        //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	        
        DataServicesInstance.Delete = function (data,_url, success, error) {
        	var reqData = $.param(data);
            $http({
                method: 'DELETE',
                url: _url,
                data:reqData,
                cache: false
            })
                .success(function (data, status, headers, config) {
                    if (status === 200) {
                        success(data);
                    }
                    else {
                        error(data);
                    }
                    return false;
                })
                .error(function (data, status, headers, config) {
                    error(data);
                    return false;
                });
        };
        return DataServicesInstance;
    }
]);