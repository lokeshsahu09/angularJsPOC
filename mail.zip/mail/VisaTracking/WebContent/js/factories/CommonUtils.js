resourceMangmntApp.factory('CommonUtils', ['$rootScope','$location','DataServices','$filter', function($rootScope,$location,DataServices,$filter)
{
    var CommonUtils = {};
    CommonUtils.tempList = {};

    
    CommonUtils.getTeamComboList = function (){
    	 DataServices.getTeamComboList( CommonUtils.populateTeamComboList, CommonUtils.defaultErrorFunc);
    };
    //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
    CommonUtils.populateTeamComboList = function (result) {
   	 	$rootScope.teamDefaultComboList = result;
   	 	
   	 angular.forEach(result.porfolioList, function(portfolio, index){
         if(portfolio.additionalFunction  === "Y"){
        	 
        	 if(portfolio.cd === $rootScope.userDtl.portfolioCd)
    		 {
        		 $rootScope.isAdditionalFeatureAllowed = true;
    		 }
         }
      });
    }; 

    //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
    CommonUtils.defaultErrorFunc = function (result) {
   	 console.log("---defaultErrorFunc--"+result);
    };
    //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
    
    
    
    CommonUtils.changeofPortfolioDetails = function (optn,obj,successFunc,errorfunc) {
    	  var tempRequest = {};
    	  var setOption = false;
    	   
    /*	  
    		  if (angular.isDefined(obj.portfolio) && obj.portfolio != null){
    			  tempRequest.portfolioCd = obj.portfolio.cd;
    			  setOption = true;
    		  }

    		  if (angular.isDefined(obj.delMngr) && obj.delMngr != null){
    			  tempRequest.deliveryManagerEmpNumber = obj.delMngr.empNumber;
    			  setOption = true;
    		  }
    		  if (angular.isDefined(obj.projMngr) && obj.projMngr != null){
    			  tempRequest.projectManagerEmpNumber = obj.projMngr.empNumber;
    			  setOption = true;
    		  }

    		  if (angular.isDefined(obj.projLead) && obj.projLead != null){
    			  tempRequest.projectLeadEmpNumber = obj.projLead.empNumber;
    			  setOption = true;
    		  }
    		  if (obj.hasOwnProperty('searchProj') && angular.isDefined(obj.searchProj) && obj.searchProj != null){
    			  tempRequest.projectId = obj.searchProj.cd;
    			  setOption = true;
    		  }
*/
    	  
    	  if(optn == 'PORTFOLIO'){
    		  if (angular.isDefined(obj.portfolio) && obj.portfolio != null){
    			  tempRequest.portfolioCd = obj.portfolio.cd;
    			  setOption = true;
    		  }
    		  
    		  
    		  if($rootScope.userDtl.portfolioCd != 7)
    		  {
        		  if($rootScope.userDtl.roleCd == 4)
    			  {
        			  
            		  if (angular.isDefined($rootScope.userDtl.empNbr) && $rootScope.userDtl.empNbr != null){
            			  tempRequest.projectManagerEmpNumber = $rootScope.userDtl.empNbr;
            			  setOption = true;
            		  }   			  
            		  tempRequest.portfolioCd = 0;
    			  }
    		  }
		  }
    	  else if(optn == 'DM'){
    		  if (angular.isDefined(obj.delMngr) && obj.delMngr != null){
    			  tempRequest.deliveryManagerEmpNumber = obj.delMngr.empNumber;
    			  setOption = true;
    		  }
    	  }else if(optn == 'PM'){
    		  if (angular.isDefined(obj.projMngr) && obj.projMngr != null){
    			  tempRequest.projectManagerEmpNumber = obj.projMngr.empNumber;
    			  setOption = true;
    		  }
    	  }
    	  else if(optn == 'PL'){
    		  if (angular.isDefined(obj.projLead) && obj.projLead != null){
    			  tempRequest.projectLeadEmpNumber = obj.projLead.empNumber;
    			  setOption = true;
    		  }
    	  }
    	  else if(optn == 'PROJECT'){
    		  if (obj.hasOwnProperty('searchProj') && angular.isDefined(obj.searchProj) && obj.searchProj != null){
    			  tempRequest.projectId = obj.searchProj.cd;
    			  setOption = true;
    		  }
    	  }
    	 /* if($rootScope.userDtl.portfolioCd != 7)
		  {
    		  if($rootScope.userDtl.roleCd == 4)
			  {
    			  
        		  if (angular.isDefined($rootScope.userDtl.empNbr) && $rootScope.userDtl.empNbr != null){
        			  tempRequest.projectManagerEmpNumber = $rootScope.userDtl.empNbr;
        			  setOption = true;
        		  }   			  
        		  
        		  
        		  tempRequest.portfolioCd = 0;
        		  tempRequest.deliveryManagerEmpNumber = 0;
        		  tempRequest.projectLeadEmpNumber = 0;
        		  tempRequest.projectId = 0;
        		  
			  }*/
    		/*  else if($rootScope.userDtl.roleCd == 5)
			  {
    			  if (angular.isDefined($rootScope.userDtl.portfolioCd) && $rootScope.userDtl.portfolioCd != null){
        			  tempRequest.portfolioCd = $rootScope.userDtl.portfolioCd;
        			  setOption = true;
        		  }			  
			  }*/ 

    	  
    	  if(setOption){
	    	  var jsonData = JSON.stringify(tempRequest);
			  	var dataToSend = {
	                  data: jsonData,
	          };
			  	 CommonUtils.refreshCookie();
				DataServices.getPortfolioSearchDetails(dataToSend, successFunc, errorfunc);
    	  }
    };
    
  //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
    CommonUtils.populatePortfolioDetails = function(scopeObj,searchObj,result,projFlag){
  	  if(angular.isUndefined(result.dropdown)){
  		  return false;
  	  }
  	  var temp;
  	  var  i;
  	  if (angular.isDefined(result.dropdown.porfolioList) &&  ($rootScope.userDtl.roleCd == 6)){
  		  	temp ={};
  		  	if (angular.isDefined(searchObj.portfolio) && searchObj.portfolio != null){
  		  		temp = searchObj.portfolio;
  		  	}
  		  	scopeObj.porfolioList =  result.dropdown.porfolioList;
  		  var portfolio;
  		  	for(i=0; i<scopeObj.porfolioList.length;i++){
  		  		 portfolio = scopeObj.porfolioList[i];
              if( parseInt(temp.cd) === portfolio.cd ){
            	  searchObj.portfolio = portfolio;
              }
  		  	};
//  			  if(scopeObj.porfolioList.length == 1){
//  				searchObj.portfolio = scopeObj.porfolioList[0];
//  			  }
    	   }
  	  if (angular.isDefined(result.dropdown.deliveryManagerList)){
	  		temp ={};
			  	if (angular.isDefined(searchObj.delMngr) && searchObj.delMngr != null){
			  		temp = searchObj.delMngr;
			  	}
	  		scopeObj.deliveryManagerList =  result.dropdown.deliveryManagerList;
	  		var delMngr;
	  		for(i=0; i<scopeObj.deliveryManagerList.length;i++){
	  			delMngr = scopeObj.deliveryManagerList[i];
	             if( parseInt(temp.empNumber) === delMngr.empNumber ){
	            	 searchObj.delMngr = delMngr;
	             }
	  		 };
//  		  if(scopeObj.deliveryManagerList.length == 1){
//				  searchObj.delMngr = scopeObj.deliveryManagerList[0];
//			  }
  	  }
  	  if (angular.isDefined(result.dropdown.projectManagerList)){
	  		temp ={};
		  	if (angular.isDefined(searchObj.projMngr) && searchObj.projMngr != null){
		  		temp = searchObj.projMngr;
		  	}
	  		scopeObj.projectManagerList =  result.dropdown.projectManagerList;
	  		var projMngr;
	  		for(i=0; i<scopeObj.projectManagerList.length;i++){
	  			projMngr = scopeObj.projectManagerList[i];
	             if( parseInt(temp.empNumber) === projMngr.empNumber ){
	            	 searchObj.projMngr = projMngr;
	             }
	       };
//  		  if(scopeObj.projectManagerList.length == 1){
//				  searchObj.projMngr = scopeObj.projectManagerList[0];
//			  }
  	  }
  	  
  	  if (angular.isDefined(result.dropdown.projectLeadList)){
	  		temp ={};
		  	if (angular.isDefined(searchObj.projLead) && searchObj.projLead != null){
		  		temp = searchObj.projLead;
		  	}
	  		scopeObj.projectLeadList =  result.dropdown.projectLeadList;
	  		var projLead;
	  		for(i=0; i<scopeObj.projectLeadList.length;i++){
	  			projLead = scopeObj.projectLeadList[i];
	             if( parseInt(temp.empNumber) === projLead.empNumber ){
	            	 searchObj.projLead = projLead;
	             }
	       };
//		  if(scopeObj.projectManagerList.length == 1){
//				  searchObj.projMngr = scopeObj.projectManagerList[0];
//			  }
	  }
  	  
  	  if (angular.isDefined(result.dropdown.projectList)){
  		 if(projFlag){
  			temp ={};
		  	if (angular.isDefined(searchObj.searchProj) && searchObj.searchProj != null){
		  		temp = searchObj.searchProj;
		  	}
	  		 scopeObj.projectList = result.dropdown.projectList;
	  		var proj;
	  		for(i=0; i<scopeObj.projectList.length;i++){
	  			proj = scopeObj.projectList[i];
                 if( parseInt(temp.cd) === parseInt(proj.cd)){
                	 searchObj.searchProj = proj;
                 }
	  		 };
//	  			  if(scopeObj.projectList.length == 1){
//	  				  searchObj.searchProj = scopeObj.projectList[0];
//	  			  }
	    	 }
  	   }
    };
    //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
    CommonUtils.setDefaultPortfolio = function(scopeObj,searchObj,callback){
    	  if($rootScope.userDtl.roleCd <=5){
      		 angular.forEach(scopeObj.porfolioList, function(portfolio, index){
                   if(portfolio.cd  === $rootScope.userDtl.portfolioCd){
                	   searchObj.portfolio = portfolio;
                   }
                });
      		 callback('PORTFOLIO');	

      	  } 
    };
    CommonUtils.setDefaultPm = function(scopeObj,searchObj,callback){
  	  if($rootScope.userDtl.roleCd <=4){
    		 angular.forEach(scopeObj.projectManagerList, function(projMngr, index){
                 if(projMngr.empNumber  === $rootScope.userDtl.empNbr){
              	   searchObj.projMngr = projMngr;
                 }
              });
    		 callback('PM');	

    	  }
  	
  };
  //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
    CommonUtils.formatDate = function(cellvalue, options, rowObject){
	   	 var dateString ="";
		 if(cellvalue!= null  && cellvalue!= ""){
			 dateString =  $filter('date')(cellvalue, "dd-MMM-yyyy");
		 }
	      return dateString;
    	
    };
    //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-	  
    CommonUtils.refreshCookie = function(){
    	 if (angular.isDefined($rootScope.userDtl) && $rootScope.userDtl != "" && $rootScope.userDtl != null){
    		 var twentyMinutesLater =  new Date();
    		 twentyMinutesLater.setMinutes(twentyMinutesLater.getMinutes() + 20);
    		 document.cookie = "userDtl=someValue; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
    		 // document.cookie = escape("userDtl") + '=;expires=' + date;
    		 document.cookie = "userDtl="+JSON.stringify($rootScope.userDtl) +"; expires="+twentyMinutesLater+"; path=/";
    	 }
    };
    
    
    return CommonUtils;
}]);



