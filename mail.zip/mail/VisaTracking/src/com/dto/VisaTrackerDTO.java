package com.dto;

import java.util.Date;

public class VisaTrackerDTO {
	private int empNbr;

	private int travelPeriod;
	private String travelPeriodTerm;

	private String firstName;

	private String lastName;
	private String visaType;
	private String travelTo;
	private String initialStatus;

	private String businessCase;
	private Date startDateRequirement;
	private Double billingRate;

	private String skillSet;
	private String potentialLoss;

	private String status;

	private String projectType;
	private String portfolio;

	//B.SUBMITTED_TS,B.SUBMITTED_user_id, V.Last_updated_date,v.last_updated_by
	private String submittedTS;
	private String lastUpdatedDate;

	public String getTravelPeriodTerm() {
		return travelPeriodTerm;
	}

	public void setTravelPeriodTerm(String travelPeriodTerm) {
		this.travelPeriodTerm = travelPeriodTerm;
	}
	public int getEmpNbr() {
		return empNbr;
	}

	public void setEmpNbr(int empNbr) {
		this.empNbr = empNbr;
	}

	public String getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}

	public String getProjectType() {
		return projectType;
	}

	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}

	public String getInitialStatus() {
		return initialStatus;
	}

	public Date getStartDateRequirement() {
		return startDateRequirement;
	}

	public void setStartDateRequirement(Date startDateRequirement) {
		this.startDateRequirement = startDateRequirement;
	}

	public void setInitialStatus(String initialStatus) {
		this.initialStatus = initialStatus;
	}

	public Double getBillingRate() {
		return billingRate;
	}

	public void setBillingRate(Double billingRate) {
		this.billingRate = billingRate;
	}

	public String getPotentialLoss() {
		return potentialLoss;
	}

	public void setPotentialLoss(String potentialLoss) {
		this.potentialLoss = potentialLoss;
	}

	public int getTravelPeriod() {
		return travelPeriod;
	}

	public void setTravelPeriod(int travelPeriod) {
		this.travelPeriod = travelPeriod;
	}

	public String getTravelTo() {
		return travelTo;
	}

	public void setTravelTo(String travelTo) {
		this.travelTo = travelTo;
	}

	public String getBusinessCase() {
		return businessCase;
	}

	public void setBusinessCase(String businessCase) {
		this.businessCase = businessCase;
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	public String getVisaType() {
		return visaType;
	}

	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubmittedTS() {
		return submittedTS;
	}

	public void setSubmittedTS(String submittedTS) {
		this.submittedTS = submittedTS;
	}

	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	
}
