package com.dto;

import java.util.Date;

public class EditDTO {

	private int status;
	private String firstName;
	private String lastName;
	private int visaType;
	private String projectType;
	private int travelPeriod;
	private String travelTo;
	private String initialStatus;
	private String businessCase;
	private Date startDateRequirement;
	private Double billingRate;
	private String skillSet;
	private String potentialLoss;
	private int empNbr;
	private String portfolio;
	public String getPortfolio() {
		return portfolio;
	}
	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}
	public int getEmpNbr() {
		return empNbr;
	}
	public void setEmpNbr(int empNbr) {
		this.empNbr = empNbr;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getVisaType() {
		return visaType;
	}
	public void setVisaType(int visaType) {
		this.visaType = visaType;
	}
	public String getProjectType() {
		return projectType;
	}
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}
	public int getTravelPeriod() {
		return travelPeriod;
	}
	public void setTravelPeriod(int travelPeriod) {
		this.travelPeriod = travelPeriod;
	}
	public String getTravelTo() {
		return travelTo;
	}
	public void setTravelTo(String travelTo) {
		this.travelTo = travelTo;
	}
	public String getInitialStatus() {
		return initialStatus;
	}
	public void setInitialStatus(String initialStatus) {
		this.initialStatus = initialStatus;
	}
	public String getBusinessCase() {
		return businessCase;
	}
	public void setBusinessCase(String businessCase) {
		this.businessCase = businessCase;
	}
	public Double getBillingRate() {
		return billingRate;
	}
	public void setBillingRate(Double billingRate) {
		this.billingRate = billingRate;
	}
	public String getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}
	public String getPotentialLoss() {
		return potentialLoss;
	}
	public void setPotentialLoss(String potentialLoss) {
		this.potentialLoss = potentialLoss;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int visaStatus) {
		this.status = visaStatus;
	}
	public Date getStartDateRequirement() {
		return startDateRequirement;
	}
	public void setStartDateRequirement(Date startDateRequirement) {
		this.startDateRequirement = startDateRequirement;
	}
	
}
