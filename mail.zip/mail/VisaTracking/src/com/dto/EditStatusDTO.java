package com.dto;

public class EditStatusDTO {
	private String nextPendingStatus;
    private int empNbr;
    private int visaTypCd;
    
     public int getVisaTypCd() {
		return visaTypCd;
	}
	public void setVisaTypCd(int visaTypCd) {
		this.visaTypCd = visaTypCd;
	}
	public String getNextPendingStatus() {
		return nextPendingStatus;
	}
	public void setNextPendingStatus(String nextPendingStatus) {
		this.nextPendingStatus = nextPendingStatus;
	}
	public int getEmpNbr() {
		return empNbr;
	}
	public void setEmpNbr(int empNbr) {
		this.empNbr = empNbr;
	}
	
}
