package com.dto;

public class EmpVisaDTO {
	private int empNbr;//
	private int travelPeriod;//
	private String travelTo;//
	private String initialStatus;//new/replacement
	private String businessCase;//
	private String startDateRequirement;//
	private double billingRate;
	private String skillSet;//
	private String potentialLoss;//
	private String firstName;//
	private String lastName;//
	private String projectType;//
	private String portfolio;//
	private String deletionStatus;//
	private String lastUpdatedDate;//
	private int lastUpdatedBy;//
	private String deletedOn;//
	private int vtsId;
	private int visaType;//
	private int visaStatusCd;//
	private String remarks;
	private String tentativeTravelDate;
	private int submittedUserId;//
	private String submittedTimeStamp;//
	
	public String getProjectType() {
		return projectType;
	}
	public void setProjectType(String projectType) {
		this.projectType = projectType;
	}
	public int getEmpNbr() {
		return empNbr;
	}
	public void setEmpNbr(int empNbr) {
		this.empNbr = empNbr;
	}
	public int getTravelPeriod() {
		return travelPeriod;
	}
	public void setTravelPeriod(int travelPeriod) {
		this.travelPeriod = travelPeriod;
	}
	public String getTravelTo() {
		return travelTo;
	}
	public void setTravelTo(String travelTo) {
		this.travelTo = travelTo;
	}
	public String getInitialStatus() {
		return initialStatus;
	}
	public void setInitialStatus(String initialStatus) {
		this.initialStatus = initialStatus;
	}
	public String getBusinessCase() {
		return businessCase;
	}
	public void setBusinessCase(String businessCase) {
		this.businessCase = businessCase;
	}
	
	
	public String getStartDateRequirement() {
		return startDateRequirement;
	}
	public void setStartDateRequirement(String startDateRequirement) {
		this.startDateRequirement = startDateRequirement;
	}
	public double getBillingRate() {
		return billingRate;
	}
	public void setBillingRate(double billingRate) {
		this.billingRate = billingRate;
	}
	public String getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}
	public String getPotentialLoss() {
		return potentialLoss;
	}
	public void setPotentialLoss(String potentialLoss) {
		this.potentialLoss = potentialLoss;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPortfolio() {
		return portfolio;
	}
	public void setPortfolio(String portfolio) {
		this.portfolio = portfolio;
	}
	public String getDeletionStatus() {
		return deletionStatus;
	}
	public void setDeletionStatus(String deletionStatus) {
		this.deletionStatus = deletionStatus;
	}
	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public int getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(int lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public String getDeletedOn() {
		return deletedOn;
	}
	public void setDeletedOn(String deletedOn) {
		this.deletedOn = deletedOn;
	}
	public int getVtsId() {
		return vtsId;
	}
	public void setVtsId(int vtsId) {
		this.vtsId = vtsId;
	}
	public int getVisaType() {
		return visaType;
	}
	public void setVisaType(int visaType) {
		this.visaType = visaType;
	}
	public int getVisaStatusCd() {
		return visaStatusCd;
	}
	public void setVisaStatusCd(int visaStatusCd) {
		this.visaStatusCd = visaStatusCd;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getTentativeTravelDate() {
		return tentativeTravelDate;
	}
	public void setTentativeTravelDate(String tentativeTravelDate) {
		this.tentativeTravelDate = tentativeTravelDate;
	}
	public int getSubmittedUserId() {
		return submittedUserId;
	}
	public void setSubmittedUserId(int submittedUserId) {
		this.submittedUserId = submittedUserId;
	}
	public String getSubmittedTimeStamp() {
		return submittedTimeStamp;
	}
	public void setSubmittedTimeStamp(String submittedTimeStamp) {
		this.submittedTimeStamp = submittedTimeStamp;
	}
	
}
