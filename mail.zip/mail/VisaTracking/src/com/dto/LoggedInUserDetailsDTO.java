package com.dto;

import java.util.List;

public class LoggedInUserDetailsDTO {
	
	private int empNbr;

	private String firstName;

	private String lastName;

	private int roleCd;

	private String roleDesc;
	
	private List<TypeDTO> secRoleList;

	private int portfolioCd;

	private String portfolioDesc;
	
	private String isFirstTime;
	
	private List<TypeDTO> securityQuestions;

	private String token;

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the roleCd
	 */
	public int getRoleCd() {
		return roleCd;
	}

	/**
	 * @param roleCd
	 *            the roleCd to set
	 */
	public void setRoleCd(int roleCd) {
		this.roleCd = roleCd;
	}

	/**
	 * @return the roleDesc
	 */
	public String getRoleDesc() {
		return roleDesc;
	}

	/**
	 * @param roleDesc
	 *            the roleDesc to set
	 */
	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

	/**
	 * @return the portfolioCd
	 */
	public int getPortfolioCd() {
		return portfolioCd;
	}

	/**
	 * @param portfolioCd
	 *            the portfolioCd to set
	 */
	public void setPortfolioCd(int portfolioCd) {
		this.portfolioCd = portfolioCd;
	}

	/**
	 * @return the portfolioDesc
	 */
	public String getPortfolioDesc() {
		return portfolioDesc;
	}

	/**
	 * @param portfolioDesc
	 *            the portfolioDesc to set
	 */
	public void setPortfolioDesc(String portfolioDesc) {
		this.portfolioDesc = portfolioDesc;
	}

	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token
	 *            the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}

	public int getEmpNbr() {
		return empNbr;
	}

	public void setEmpNbr(int empNbr) {
		this.empNbr = empNbr;
	}

	public List<TypeDTO> getSecRoleList() {
		return secRoleList;
	}

	public void setSecRoleList(List<TypeDTO> secRoleList) {
		this.secRoleList = secRoleList;
	}

	public String getIsFirstTime() {
		return isFirstTime;
	}

	public void setIsFirstTime(String isFirstTime) {
		this.isFirstTime = isFirstTime;
	}

	public List<TypeDTO> getSecurityQuestions() {
		return securityQuestions;
	}

	public void setSecurityQuestions(List<TypeDTO> securityQuestions) {
		this.securityQuestions = securityQuestions;
	}

}
