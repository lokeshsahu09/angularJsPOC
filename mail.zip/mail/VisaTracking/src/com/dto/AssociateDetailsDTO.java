package com.dto;

import java.sql.Date;
import java.util.List;

public class AssociateDetailsDTO {
	private int empNumber;

	private String ldapId;

	private String firstName;

	private String lastName;

	private String primaryContactNumber;

	private String secondaryContactNumber;

	private int primaryTechnologyCd;
	
	private int primaryTechnologyLvlCd;
	
	private String primaryTechnologyLvlDesc;
	
	private int costTyp;

	private String primaryTechnologyDesc;

	private int secondaryTechnologyCd;

	private String secondaryTechnologyDesc;

	private int roleCd;

	private String roleDesc;
	
	private String secRoles;
	
	private List<TypeDTO> secRoleList;
	
	private int designationCd;

	private String designationDesc;

	private int portfolioCd;

	private String portfolioDesc;

	private int contractTypCd;

	private String contractTypDesc;

	private int prevExpMonths;

	private int prevExpYears;
	
	private Date updatedDt;

	private Date dob;

	private Date doj;

	private Date thdDoj;

	private int accessCardNumber;

	private String comments;

	private int locationCd;

	private String locationDesc;

	private int workOrderNumber;
	
	private int projectId;

	private String projectName;

	private String isPartial;

	private Date woStartDate;

	private Date woEndDate;

	private int supervisorEmpNumber;

	private String supervisorEmpName;

	private String projectLeadName;

	private String projectManagerName;

	private String deliveryManagerName;

	private String groupLeadName;
	

	private String projectLeadNameByProject;

	private String projectManagerNameByProject;

	private String deliveryManagerNameByProject;

	
	private String thdMgr;
	
	private String thdSrMgr;
	
	private String thdDir;
	
	private String thdSrDir;
	
	private String thdVp;
	
	private String thdSrVp;


	private int projectIdFromAsscTable;

	private String projectNameFromAsscTable;

	private String isAllocated;
	
	private int billableType;
	
	/**
	 * @return the empNumber
	 */
	public int getEmpNumber() {
		return empNumber;
	}

	/**
	 * @param empNumber
	 *            the empNumber to set
	 */
	public void setEmpNumber(int empNumber) {
		this.empNumber = empNumber;
	}

	/**
	 * @return the ldapId
	 */
	public String getLdapId() {
		return ldapId;
	}

	/**
	 * @param ldapId
	 *            the ldapId to set
	 */
	public void setLdapId(String ldapId) {
		this.ldapId = ldapId;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the primaryContactNumber
	 */
	public String getPrimaryContactNumber() {
		return primaryContactNumber;
	}

	/**
	 * @param primaryContactNumber
	 *            the primaryContactNumber to set
	 */
	public void setPrimaryContactNumber(String primaryContactNumber) {
		this.primaryContactNumber = primaryContactNumber;
	}

	/**
	 * @return the secondaryContactNumber
	 */
	public String getSecondaryContactNumber() {
		return secondaryContactNumber;
	}

	/**
	 * @param secondaryContactNumber
	 *            the secondaryContactNumber to set
	 */
	public void setSecondaryContactNumber(String secondaryContactNumber) {
		this.secondaryContactNumber = secondaryContactNumber;
	}

	/**
	 * @return the primaryTechnologyCd
	 */
	public int getPrimaryTechnologyCd() {
		return primaryTechnologyCd;
	}

	/**
	 * @param primaryTechnologyCd
	 *            the primaryTechnologyCd to set
	 */
	public void setPrimaryTechnologyCd(int primaryTechnologyCd) {
		this.primaryTechnologyCd = primaryTechnologyCd;
	}

	/**
	 * @return the primaryTechnologyDesc
	 */
	public String getPrimaryTechnologyDesc() {
		return primaryTechnologyDesc;
	}

	/**
	 * @param primaryTechnologyDesc
	 *            the primaryTechnologyDesc to set
	 */
	public void setPrimaryTechnologyDesc(String primaryTechnologyDesc) {
		this.primaryTechnologyDesc = primaryTechnologyDesc;
	}

	/**
	 * @return the secondaryTechnologyCd
	 */
	public int getSecondaryTechnologyCd() {
		return secondaryTechnologyCd;
	}

	/**
	 * @param secondaryTechnologyCd
	 *            the secondaryTechnologyCd to set
	 */
	public void setSecondaryTechnologyCd(int secondaryTechnologyCd) {
		this.secondaryTechnologyCd = secondaryTechnologyCd;
	}

	/**
	 * @return the secondaryTechnologyDesc
	 */
	public String getSecondaryTechnologyDesc() {
		return secondaryTechnologyDesc;
	}

	/**
	 * @param secondaryTechnologyDesc
	 *            the secondaryTechnologyDesc to set
	 */
	public void setSecondaryTechnologyDesc(String secondaryTechnologyDesc) {
		this.secondaryTechnologyDesc = secondaryTechnologyDesc;
	}

	/**
	 * @return the roleCd
	 */
	public int getRoleCd() {
		return roleCd;
	}

	/**
	 * @param roleCd
	 *            the roleCd to set
	 */
	public void setRoleCd(int roleCd) {
		this.roleCd = roleCd;
	}

	/**
	 * @return the roleDesc
	 */
	public String getRoleDesc() {
		return roleDesc;
	}

	/**
	 * @param roleDesc
	 *            the roleDesc to set
	 */
	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

	/**
	 * @return the designationCd
	 */
	public int getDesignationCd() {
		return designationCd;
	}

	/**
	 * @param designationCd
	 *            the designationCd to set
	 */
	public void setDesignationCd(int designationCd) {
		this.designationCd = designationCd;
	}

	/**
	 * @return the designationDesc
	 */
	public String getDesignationDesc() {
		return designationDesc;
	}

	/**
	 * @param designationDesc
	 *            the designationDesc to set
	 */
	public void setDesignationDesc(String designationDesc) {
		this.designationDesc = designationDesc;
	}

	/**
	 * @return the portfolioCd
	 */
	public int getPortfolioCd() {
		return portfolioCd;
	}

	/**
	 * @param portfolioCd
	 *            the portfolioCd to set
	 */
	public void setPortfolioCd(int portfolioCd) {
		this.portfolioCd = portfolioCd;
	}

	/**
	 * @return the portfolioDesc
	 */
	public String getPortfolioDesc() {
		return portfolioDesc;
	}

	/**
	 * @param portfolioDesc
	 *            the portfolioDesc to set
	 */
	public void setPortfolioDesc(String portfolioDesc) {
		this.portfolioDesc = portfolioDesc;
	}

	/**
	 * @return the contractTypCd
	 */
	public int getContractTypCd() {
		return contractTypCd;
	}

	/**
	 * @param contractTypCd
	 *            the contractTypCd to set
	 */
	public void setContractTypCd(int contractTypCd) {
		this.contractTypCd = contractTypCd;
	}

	/**
	 * @return the contractTypDesc
	 */
	public String getContractTypDesc() {
		return contractTypDesc;
	}

	/**
	 * @param contractTypDesc
	 *            the contractTypDesc to set
	 */
	public void setContractTypDesc(String contractTypDesc) {
		this.contractTypDesc = contractTypDesc;
	}

	/**
	 * @return the prevExpMonths
	 */
	public int getPrevExpMonths() {
		return prevExpMonths;
	}

	/**
	 * @param prevExpMonths
	 *            the prevExpMonths to set
	 */
	public void setPrevExpMonths(int prevExpMonths) {
		this.prevExpMonths = prevExpMonths;
	}

	/**
	 * @return the prevExpYears
	 */
	public int getPrevExpYears() {
		return prevExpYears;
	}

	/**
	 * @param prevExpYears
	 *            the prevExpYears to set
	 */
	public void setPrevExpYears(int prevExpYears) {
		this.prevExpYears = prevExpYears;
	}

	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}

	/**
	 * @param dob
	 *            the dob to set
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}

	/**
	 * @return the doj
	 */
	public Date getDoj() {
		return doj;
	}

	/**
	 * @param doj
	 *            the doj to set
	 */
	public void setDoj(Date doj) {
		this.doj = doj;
	}

	/**
	 * @return the thdDoj
	 */
	public Date getThdDoj() {
		return thdDoj;
	}

	/**
	 * @param thdDoj
	 *            the thdDoj to set
	 */
	public void setThdDoj(Date thdDoj) {
		this.thdDoj = thdDoj;
	}

	/**
	 * @return the accessCardNumber
	 */
	public int getAccessCardNumber() {
		return accessCardNumber;
	}

	/**
	 * @param accessCardNumber
	 *            the accessCardNumber to set
	 */
	public void setAccessCardNumber(int accessCardNumber) {
		this.accessCardNumber = accessCardNumber;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments
	 *            the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return the locationCd
	 */
	public int getLocationCd() {
		return locationCd;
	}

	/**
	 * @param locationCd
	 *            the locationCd to set
	 */
	public void setLocationCd(int locationCd) {
		this.locationCd = locationCd;
	}

	/**
	 * @return the locationDesc
	 */
	public String getLocationDesc() {
		return locationDesc;
	}

	/**
	 * @param locationDesc
	 *            the locationDesc to set
	 */
	public void setLocationDesc(String locationDesc) {
		this.locationDesc = locationDesc;
	}

	/**
	 * @return the deskDetails
	 */

	/**
	 * @return the workOrderNumber
	 */
	public int getWorkOrderNumber() {
		return workOrderNumber;
	}

	/**
	 * @param workOrderNumber
	 *            the workOrderNumber to set
	 */
	public void setWorkOrderNumber(int workOrderNumber) {
		this.workOrderNumber = workOrderNumber;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName
	 *            the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the isPartial
	 */
	public String getIsPartial() {
		return isPartial;
	}

	/**
	 * @param isPartial
	 *            the isPartial to set
	 */
	public void setIsPartial(String isPartial) {
		this.isPartial = isPartial;
	}

	/**
	 * @return the woStartDate
	 */
	public Date getWoStartDate() {
		return woStartDate;
	}

	/**
	 * @param woStartDate
	 *            the woStartDate to set
	 */
	public void setWoStartDate(Date woStartDate) {
		this.woStartDate = woStartDate;
	}

	/**
	 * @return the woEndDate
	 */
	public Date getWoEndDate() {
		return woEndDate;
	}

	/**
	 * @param woEndDate
	 *            the woEndDate to set
	 */
	public void setWoEndDate(Date woEndDate) {
		this.woEndDate = woEndDate;
	}

	/**
	 * @return the supervisorEmpNumber
	 */
	public int getSupervisorEmpNumber() {
		return supervisorEmpNumber;
	}

	/**
	 * @param supervisorEmpNumber
	 *            the supervisorEmpNumber to set
	 */
	public void setSupervisorEmpNumber(int supervisorEmpNumber) {
		this.supervisorEmpNumber = supervisorEmpNumber;
	}

	/**
	 * @return the supervisorEmpName
	 */
	public String getSupervisorEmpName() {
		return supervisorEmpName;
	}

	/**
	 * @param supervisorEmpName
	 *            the supervisorEmpName to set
	 */
	public void setSupervisorEmpName(String supervisorEmpName) {
		this.supervisorEmpName = supervisorEmpName;
	}

	/**
	 * @return the projectLeadName
	 */
	public String getProjectLeadName() {
		return projectLeadName;
	}

	/**
	 * @param projectLeadName
	 *            the projectLeadName to set
	 */
	public void setProjectLeadName(String projectLeadName) {
		this.projectLeadName = projectLeadName;
	}

	/**
	 * @return the projectManagerName
	 */
	public String getProjectManagerName() {
		return projectManagerName;
	}

	/**
	 * @param projectManagerName
	 *            the projectManagerName to set
	 */
	public void setProjectManagerName(String projectManagerName) {
		this.projectManagerName = projectManagerName;
	}

	/**
	 * @return the deliveryManagerName
	 */
	public String getDeliveryManagerName() {
		return deliveryManagerName;
	}

	/**
	 * @param deliveryManagerName
	 *            the deliveryManagerName to set
	 */
	public void setDeliveryManagerName(String deliveryManagerName) {
		this.deliveryManagerName = deliveryManagerName;
	}

	/**
	 * @return the groupLeadName
	 */
	public String getGroupLeadName() {
		return groupLeadName;
	}

	/**
	 * @param groupLeadName
	 *            the groupLeadName to set
	 */
	public void setGroupLeadName(String groupLeadName) {
		this.groupLeadName = groupLeadName;
	}

	/**
	 * @return the projectId
	 */
	public int getProjectId() {
		return projectId;
	}

	/**
	 * @param projectId
	 *            the projectId to set
	 */
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	/**
	 * @return the projectNameFromAsscTable
	 */
	public String getProjectNameFromAsscTable() {
		return projectNameFromAsscTable;
	}

	/**
	 * @param projectNameFromAsscTable
	 *            the projectNameFromAsscTable to set
	 */
	public void setProjectNameFromAsscTable(String projectNameFromAsscTable) {
		this.projectNameFromAsscTable = projectNameFromAsscTable;
	}

	public int getCostTyp() {
		return costTyp;
	}

	public void setCostTyp(int costTyp) {
		this.costTyp = costTyp;
	}

	public int getProjectIdFromAsscTable() {
		return projectIdFromAsscTable;
	}

	public void setProjectIdFromAsscTable(int projectIdFromAsscTable) {
		this.projectIdFromAsscTable = projectIdFromAsscTable;
	}

	public int getPrimaryTechnologyLvlCd() {
		return primaryTechnologyLvlCd;
	}

	public void setPrimaryTechnologyLvlCd(int primaryTechnologyLvlCd) {
		this.primaryTechnologyLvlCd = primaryTechnologyLvlCd;
	}

	public String getPrimaryTechnologyLvlDesc() {
		return primaryTechnologyLvlDesc;
	}

	public void setPrimaryTechnologyLvlDesc(String primaryTechnologyLvlDesc) {
		this.primaryTechnologyLvlDesc = primaryTechnologyLvlDesc;
	}

	public String getAllocated() {
		return isAllocated;
	}

	public void setAllocated(String isAllocated) {
		this.isAllocated = isAllocated;
	}

	public String getProjectLeadNameByProject() {
		return projectLeadNameByProject;
	}

	public void setProjectLeadNameByProject(String projectLeadNameByProject) {
		this.projectLeadNameByProject = projectLeadNameByProject;
	}

	public String getProjectManagerNameByProject() {
		return projectManagerNameByProject;
	}

	public void setProjectManagerNameByProject(String projectManagerNameByProject) {
		this.projectManagerNameByProject = projectManagerNameByProject;
	}

	public String getDeliveryManagerNameByProject() {
		return deliveryManagerNameByProject;
	}

	public void setDeliveryManagerNameByProject(String deliveryManagerNameByProject) {
		this.deliveryManagerNameByProject = deliveryManagerNameByProject;
	}

	public String getThdMgr() {
		return thdMgr;
	}

	public void setThdMgr(String thdMgr) {
		this.thdMgr = thdMgr;
	}

	public String getThdSrMgr() {
		return thdSrMgr;
	}

	public void setThdSrMgr(String thdSrMgr) {
		this.thdSrMgr = thdSrMgr;
	}

	public String getThdDir() {
		return thdDir;
	}

	public void setThdDir(String thdDir) {
		this.thdDir = thdDir;
	}

	public String getThdSrDir() {
		return thdSrDir;
	}

	public void setThdSrDir(String thdSrDir) {
		this.thdSrDir = thdSrDir;
	}

	public String getThdVp() {
		return thdVp;
	}

	public void setThdVp(String thdVp) {
		this.thdVp = thdVp;
	}

	public String getThdSrVp() {
		return thdSrVp;
	}

	public void setThdSrVp(String thdSrVp) {
		this.thdSrVp = thdSrVp;
	}

	public List<TypeDTO> getSecRoleList() {
		return secRoleList;
	}

	public void setSecRoleList(List<TypeDTO> secRoleList) {
		this.secRoleList = secRoleList;
	}

	public String getSecRoles() {
		return secRoles;
	}

	public void setSecRoles(String secRoles) {
		this.secRoles = secRoles;
	}
	
	
	public boolean checkForKeyChanges(AssociateDetailsDTO newAssociateDetails)
	{
		boolean isChanged = false;
		if(this.getPortfolioCd() != newAssociateDetails.getPortfolioCd())
		{
			isChanged = true;
		}
		else if(this.getSupervisorEmpNumber() != newAssociateDetails.getSupervisorEmpNumber())
		{
			isChanged = true;
		}
		else if(this.getProjectIdFromAsscTable() != newAssociateDetails.getProjectIdFromAsscTable())
		{
			isChanged = true;
		}
		else if(this.getBillableType() != newAssociateDetails.getBillableType())
		{
			isChanged = true;
		}
		else if(this.getLocationCd() != newAssociateDetails.getLocationCd())
		{
			isChanged = true;
		}
		else if(this.getDesignationCd() != newAssociateDetails.getDesignationCd())
		{
			isChanged = true;
		}
		else if(this.getRoleCd() != newAssociateDetails.getRoleCd())
		{
			isChanged = true;
		}
		else if(this.getLdapId() != null || newAssociateDetails.getLdapId() != null)
		{
			
			if(this.getLdapId() != null && !this.getLdapId().equalsIgnoreCase(newAssociateDetails.getLdapId()))
			{
				isChanged = true;
			}
			else if(newAssociateDetails.getLdapId() != null && !newAssociateDetails.getLdapId().equalsIgnoreCase(this.getLdapId()))
			{
				isChanged = true;
			}
			
		}
			
		return isChanged;
	}

	public Date getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	public int getBillableType() {
		return billableType;
	}

	public void setBillableType(int billableType) {
		this.billableType = billableType;
	}

}
