package com.dto;

public class AssociateDTO {

	private int empNumber;

	private String firstName;

	private String lastName;

	private String name;
	
	private int portfolioCd;

	/**
	 * @return the empNumber
	 */
	public int getEmpNumber() {
		return empNumber;
	}

	/**
	 * @param empNumber
	 *            the empNumber to set
	 */
	public void setEmpNumber(int empNumber) {
		this.empNumber = empNumber;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		//this.firstName = firstName;
		
		if(firstName != null)
		{
			this.firstName = firstName;
			if(this.name == null || this.name.equalsIgnoreCase(""))
			{
				this.name = firstName + " ";			
			}
			else
			{
				this.name = this.name + firstName + " ";
			}			
		}
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		//this.lastName = lastName;
		if(lastName != null && !lastName.equalsIgnoreCase(""))
		{
			this.lastName = lastName;
			if(this.name == null || this.name.equalsIgnoreCase(""))
			{
				this.name = lastName;			
			}
			else
			{
				this.name = this.name + lastName;
			}
		}
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + empNumber;
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AssociateDTO)) {
			return false;
		}
		AssociateDTO other = (AssociateDTO) obj;
		if (empNumber != other.empNumber) {
			return false;
		}
		return true;
	}

	public int getPortfolioCd() {
		return portfolioCd;
	}

	public void setPortfolioCd(int portfolioCd) {
		this.portfolioCd = portfolioCd;
	}

}
