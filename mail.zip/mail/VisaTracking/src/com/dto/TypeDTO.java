package com.dto;

public class TypeDTO {
	private String desc;

	private int cd;
	
	private String additionalFunction;
	
	private int portfolioCd;

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc
	 *            the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * @return the cd
	 */
	public int getCd() {
		return cd;
	}

	/**
	 * @param cd
	 *            the cd to set
	 */
	public void setCd(int cd) {
		this.cd = cd;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + cd;
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof TypeDTO)) {
			return false;
		}
		TypeDTO other = (TypeDTO) obj;
		if (cd != other.cd) {
			return false;
		}
		return true;
	}

	public String getAdditionalFunction() {
		return additionalFunction;
	}

	public void setAdditionalFunction(String additionalFunction) {
		this.additionalFunction = additionalFunction;
	}

	public int getPortfolioCd() {
		return portfolioCd;
	}

	public void setPortfolioCd(int portfolioCd) {
		this.portfolioCd = portfolioCd;
	}

}
