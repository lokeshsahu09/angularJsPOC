package com.dto;

public class THDAssociateDTO {

	private String ldapId;

	private String firstName;

	private String lastName;
	
	private String fullName;
	
	private int roleCd;
	
	private int portfolioCd;

	/**
	 * @return the ldapId
	 */
	public String getLdapId() {
		return ldapId;
	}

	/**
	 * @param ldapId
	 *            the ldapId to set
	 */
	public void setLdapId(String ldapId) {
		this.ldapId = ldapId;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		if(firstName != null)
		{
			this.firstName = firstName;
			if(this.fullName == null || this.fullName.equalsIgnoreCase(""))
			{
				this.fullName = firstName + " ";			
			}
			else
			{
				this.fullName = this.fullName + firstName + " ";
			}			
		}

 
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		if(lastName != null)
		{
			this.lastName = lastName;
			if(this.fullName == null || this.fullName.equalsIgnoreCase(""))
			{
				this.fullName = lastName+ " ";			
			}
			else
			{
				this.fullName = this.fullName + lastName;
			}
		}
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getPortfolioCd() {
		return portfolioCd;
	}

	public void setPortfolioCd(int portfolioCd) {
		this.portfolioCd = portfolioCd;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ldapId == null) ? 0 : ldapId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		THDAssociateDTO other = (THDAssociateDTO) obj;
		if (ldapId == null) {
			if (other.ldapId != null)
				return false;
		} else if (!ldapId.equals(other.ldapId))
			return false;
		return true;
	}

	public int getRoleCd() {
		return roleCd;
	}

	public void setRoleCd(int roleCd) {
		this.roleCd = roleCd;
	}

	



}
