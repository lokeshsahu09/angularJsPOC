package com.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.util.VisaTrackingUtil;

public class CacheDTO {

	private List<TypeDTO> locationList;

	private List<TypeDTO> visaTypeList;

	private List<TypeDTO> visaStatusList;

	private List<TypeDTO> porfolioList;

	private List<TypeDTO> roleList;
	
	private List<TypeDTO> secRoleList;

	private List<TypeDTO> designationList;

	private List<TypeDTO> technologyList;
	
	private List<TypeDTO> techLvlList;

	private List<TypeDTO> contractTypList;

	private List<AssociateDTO> projectLeadList;
	
	private Map<Integer, List<AssociateDTO>> projectLeadListMap = new HashMap<Integer, List<AssociateDTO>>();

	private List<AssociateDTO> projectManagerList;
	
	private Map<Integer, List<AssociateDTO>> projectManagerListMap = new HashMap<Integer, List<AssociateDTO>>();

	private List<AssociateDTO> deliveryManagerList;
	
	private Map<Integer, List<AssociateDTO>> deliveryManagerListMap = new HashMap<Integer, List<AssociateDTO>>();

	private List<AssociateDTO> groupLeadList;
	
	private Map<Integer, String> locationMap = new HashMap<Integer, String>();
	private Map<String, Integer> locationIdMap = new HashMap<String, Integer>();
	

	private Map<Integer, String> visaTypeMap = new HashMap<Integer, String>();

	private Map<Integer, String> visaStatusMap = new HashMap<Integer, String>();

	private Map<Integer, String> porfolioMap = new HashMap<Integer, String>();
	private Map<String, Integer> porfolioIdMap = new HashMap<String, Integer>();

	private Map<Integer, String> roleMap = new HashMap<Integer, String>();
	private Map<String, Integer> roleIdMap = new HashMap<String, Integer>();
	
	private Map<Integer, String> secRoleMap = new HashMap<Integer, String>();

	private Map<Integer, String> designationMap = new HashMap<Integer, String>();
	private Map<String, Integer> designationIdMap = new HashMap<String, Integer>();

	private Map<Integer, String> contractMap = new HashMap<Integer, String>();
	private Map<String, Integer> contractIdMap = new HashMap<String, Integer>();

	private Map<Integer, String> technologyMap = new HashMap<Integer, String>();
	private Map<String, Integer> technologyIdMap = new HashMap<String, Integer>();
	
	private Map<Integer, String> technologyLvlMap = new HashMap<Integer, String>();
	private Map<String, Integer> technologyLvlIdMap = new HashMap<String, Integer>();

	private Map<Integer, AssociateDTO> projectLeadMap = new HashMap<Integer, AssociateDTO>();

	private Map<Integer, AssociateDTO> projectManagerMap = new HashMap<Integer, AssociateDTO>();

	private Map<Integer, AssociateDTO> deliveryManagerMap = new HashMap<Integer, AssociateDTO>();

	private Map<Integer, AssociateDTO> groupLeadMap = new HashMap<Integer, AssociateDTO>();

	private List<THDAssociateDTO> thdManagerList;
	private Map<Integer, List<THDAssociateDTO>> thdManagerListMap = new HashMap<Integer, List<THDAssociateDTO>>();

	private List<THDAssociateDTO> thdSrManagerList;
	private Map<Integer, List<THDAssociateDTO>> thdSrManagerListMap = new HashMap<Integer, List<THDAssociateDTO>>();
	
	private List<THDAssociateDTO> thdDirectorList;
	private Map<Integer, List<THDAssociateDTO>> thdDirectorListMap = new HashMap<Integer, List<THDAssociateDTO>>();

	private List<THDAssociateDTO> thdSrDirectorList;
	private Map<Integer, List<THDAssociateDTO>> thdSrDirectorListMap = new HashMap<Integer, List<THDAssociateDTO>>();

	private List<THDAssociateDTO> thdVPList;
	private Map<Integer, List<THDAssociateDTO>> thdVPListMap = new HashMap<Integer, List<THDAssociateDTO>>();

	private List<THDAssociateDTO> thdSrVPList;
	private Map<Integer, List<THDAssociateDTO>> thdSrVPListMap = new HashMap<Integer, List<THDAssociateDTO>>();

	private Map<String, String> thdManagerMap = new HashMap<String, String>();

	private Map<String, String> thdSrManagerMap = new HashMap<String, String>();

	private Map<String, String> thdDirectorMap = new HashMap<String, String>();

	private Map<String, String> thdSrDirectorMap = new HashMap<String, String>();

	private Map<String, String> thdVPMap = new HashMap<String, String>();

	private Map<String, String> thdSrVPMap = new HashMap<String, String>();

	private Map<Integer, AssociateDTO> supervisorMap = new HashMap<Integer, AssociateDTO>();

	private List<TypeDTO> projectList;
	private Map<Integer, List<TypeDTO>> projectListMap = new HashMap<Integer, List<TypeDTO>>();
	

	private Map<Integer, String> projectMap = new HashMap<Integer, String>();
	
	private Map<String, Integer> projectIdMap = new HashMap<String, Integer>();

	private List<TypeDTO> woStatusList;

	private List<THDFiscalMonthDTO> fiscalList;

	private Map<Integer, String> woStatusMap = new HashMap<Integer, String>();

	private List<TypeDTO> serviceLineDescList;

	private Map<Integer, String> serviceLineDescMap = new HashMap<Integer, String>();
	private Map<String, Integer> serviceLineIdMap = new HashMap<String, Integer>();

	/**
	 * @return the locationList
	 */
	public List<TypeDTO> getLocationList() {
		return locationList;
	}

	/**
	 * @param locationList
	 *            the locationList to set
	 */
	public void setLocationList(List<TypeDTO> locationList) {
		this.locationList = locationList;

		for (TypeDTO location : locationList) {
			locationMap.put(location.getCd(), location.getDesc());
			locationIdMap.put(VisaTrackingUtil.trimString(location.getDesc()), location.getCd());
		}
	}

	/**
	 * @return the visaTypeList
	 */
	public List<TypeDTO> getVisaTypeList() {
		return visaTypeList;
	}

	/**
	 * @param visaTypeList
	 *            the visaTypeList to set
	 */
	public void setVisaTypeList(List<TypeDTO> visaTypeList) {
		this.visaTypeList = visaTypeList;

		for (TypeDTO visaType : visaTypeList) {
			visaTypeMap.put(visaType.getCd(), visaType.getDesc());
		}
	}

	/**
	 * @return the visaStatusList
	 */
	public List<TypeDTO> getVisaStatusList() {
		return visaStatusList;
	}

	/**
	 * @param visaStatusList
	 *            the visaStatusList to set
	 */
	public void setVisaStatusList(List<TypeDTO> visaStatusList) {
		this.visaStatusList = visaStatusList;

		for (TypeDTO visaStatus : visaStatusList) {
			visaStatusMap.put(visaStatus.getCd(), visaStatus.getDesc());
		}
	}

	/**
	 * @return the porfolioList
	 */
	public List<TypeDTO> getPorfolioList() {
		return porfolioList;
	}

	/**
	 * @param porfolioList
	 *            the porfolioList to set
	 */
	public void setPorfolioList(List<TypeDTO> porfolioList) {
		this.porfolioList = porfolioList;

		for (TypeDTO portfolio : porfolioList) {
			porfolioMap.put(portfolio.getCd(), portfolio.getDesc());
			porfolioIdMap.put(VisaTrackingUtil.trimString(portfolio.getDesc()), portfolio.getCd());
		}
	}

	/**
	 * @return the roleList
	 */
	public List<TypeDTO> getRoleList() {
		return roleList;
	}

	
	/**
	 * @param secRoleList
	 *            the secRoleList to set
	 */
	public void setRoleList(List<TypeDTO> roleList) {
		this.roleList = roleList;

		for (TypeDTO role : roleList) {
			roleMap.put(role.getCd(), role.getDesc());
			roleIdMap.put(VisaTrackingUtil.trimString(role.getDesc()), role.getCd());
		}
	}
	
	/**
	 * @param roleList
	 *            the roleList to set
	 */
	public void setSecRoleList(List<TypeDTO> secRoleList) {
		this.secRoleList = secRoleList;

		for (TypeDTO secRole : secRoleList) {
			secRoleMap.put(secRole.getCd(), secRole.getDesc());
		}
	}
	
	
	/**
	 * @return the secRoleList
	 */
	public List<TypeDTO> getSecRoleList() {
		return secRoleList;
	}



	/**
	 * @return the designationList
	 */
	public List<TypeDTO> getDesignationList() {
		return designationList;
	}

	/**
	 * @param designationList
	 *            the designationList to set
	 */
	public void setDesignationList(List<TypeDTO> designationList) {
		this.designationList = designationList;

		for (TypeDTO designation : designationList) {
			designationMap.put(designation.getCd(), designation.getDesc());
			designationIdMap.put(VisaTrackingUtil.trimString(designation.getDesc()), designation.getCd());
		}
	}

	/**
	 * @return the technologyList
	 */
	public List<TypeDTO> getTechnologyList() {
		return technologyList;
	}

	/**
	 * @param technologyList
	 *            the technologyList to set
	 */
	public void setTechnologyList(List<TypeDTO> technologyList) {
		this.technologyList = technologyList;

		for (TypeDTO technology : technologyList) {
			technologyMap.put(technology.getCd(), technology.getDesc());
			technologyIdMap.put(VisaTrackingUtil.trimString(technology.getDesc()), technology.getCd());
		}
	}

	/**
	 * @return the contractTypList
	 */
	public List<TypeDTO> getContractTypList() {
		return contractTypList;
	}

	/**
	 * @param contractTypList
	 *            the contractTypList to set
	 */
	public void setContractTypList(List<TypeDTO> contractTypList) {
		this.contractTypList = contractTypList;

		for (TypeDTO contract : contractTypList) {
			contractMap.put(contract.getCd(), contract.getDesc());
			contractIdMap.put(VisaTrackingUtil.trimString(contract.getDesc()), contract.getCd());
		}
	}

	/**
	 * @return the projectLeadList
	 */
	public List<AssociateDTO> getProjectLeadList(int portfolioCd) {
		
		if(portfolioCd != 0 && portfolioCd != 7)
		{
			List<AssociateDTO> plList = (List<AssociateDTO>)projectLeadListMap.get(portfolioCd);
			
			if(plList != null)
			{
				return plList;
			}
			else
			{
				return new ArrayList<AssociateDTO>();
			}
			
		}
		else
		{
			return projectLeadList;			
		}

	}

	/**
	 * @param projectLeadList
	 *            the projectLeadList to set
	 */
	public void setProjectLeadList(List<AssociateDTO> projectLeadList) {
		this.projectLeadList = projectLeadList;

		projectLeadListMap = new HashMap<Integer, List<AssociateDTO>>();
		
		for (AssociateDTO associate : projectLeadList) {
			projectLeadMap.put(associate.getEmpNumber(), associate);
			supervisorMap.put(associate.getEmpNumber(), associate);
			
			int portfolioCd = associate.getPortfolioCd();
			
			if(portfolioCd != 0 && projectLeadListMap.containsKey(portfolioCd))
			{
				//portfolio already present
				List<AssociateDTO> associateList = (List<AssociateDTO>)projectLeadListMap.get(portfolioCd);
				if(!associateList.contains(associate))
				{
					associateList.add(associate);
				}
			}
			else if (portfolioCd != 0)
			{
				List<AssociateDTO> associateList = new ArrayList<AssociateDTO>();
				associateList.add(associate);
				projectLeadListMap.put(portfolioCd, associateList);
			}
			
		}
	}

	/**
	 * @return the projectManagerList
	 */
	public List<AssociateDTO> getProjectManagerList(int portfolioCd) {
		
		if(portfolioCd != 0 && portfolioCd != 7)
		{
			List<AssociateDTO> pmList = (List<AssociateDTO>)projectManagerListMap.get(portfolioCd);
			
			if(pmList != null)
			{
				return pmList;
			}
			else
			{
				return new ArrayList<AssociateDTO>();
			}
			
		}
		else
		{
			return projectManagerList;			
		}
		
		

	}

	/**
	 * @param projectManagerList
	 *            the projectManagerList to set
	 */
	public void setProjectManagerList(List<AssociateDTO> projectManagerList) {
		this.projectManagerList = projectManagerList;

		projectManagerListMap = new HashMap<Integer, List<AssociateDTO>>();
		
		for (AssociateDTO associate : projectManagerList) {
			projectManagerMap.put(associate.getEmpNumber(),associate);
			supervisorMap.put(associate.getEmpNumber(), associate);
			
			int portfolioCd = associate.getPortfolioCd();
			
			if(portfolioCd != 0 && projectManagerListMap.containsKey(portfolioCd))
			{
				//portfolio already present
				List<AssociateDTO> associateList = (List<AssociateDTO>)projectManagerListMap.get(portfolioCd);
				if(!associateList.contains(associate))
				{
					associateList.add(associate);
				}
			}
			else if (portfolioCd != 0)
			{
				List<AssociateDTO> associateList = new ArrayList<AssociateDTO>();
				associateList.add(associate);
				projectManagerListMap.put(portfolioCd, associateList);
			}
		}
	}

	/**
	 * @return the deliveryManagerList
	 */
	public List<AssociateDTO> getDeliveryManagerList(int portfolioCd) {
		
		if(portfolioCd != 0 && portfolioCd != 7)
		{
			List<AssociateDTO> dmlist = (List<AssociateDTO>)deliveryManagerListMap.get(portfolioCd);
			
			if(dmlist != null)
			{
				return dmlist;
			}
			else
			{
				return new ArrayList<AssociateDTO>();
			}
			
		}
		else
		{
			return deliveryManagerList;			
		}
	}

	/**
	 * @param deliveryManagerList
	 *            the deliveryManagerList to set
	 */
	public void setDeliveryManagerList(List<AssociateDTO> deliveryManagerList) {
		this.deliveryManagerList = deliveryManagerList;

		deliveryManagerListMap = new HashMap<Integer, List<AssociateDTO>>();
		
		for (AssociateDTO associate : deliveryManagerList) {
			deliveryManagerMap.put(associate.getEmpNumber(), associate);
			supervisorMap.put(associate.getEmpNumber(), associate);
			
			int portfolioCd = associate.getPortfolioCd();
			
			if(portfolioCd != 0 && deliveryManagerListMap.containsKey(portfolioCd))
			{
				//portfolio already present
				List<AssociateDTO> associateList = (List<AssociateDTO>)deliveryManagerListMap.get(portfolioCd);
				if(!associateList.contains(associate))
				{
					associateList.add(associate);
				}
			}
			else if (portfolioCd != 0)
			{
				List<AssociateDTO> associateList = new ArrayList<AssociateDTO>();
				associateList.add(associate);
				deliveryManagerListMap.put(portfolioCd, associateList);
			}
		}
	}

	/**
	 * @return the groupLeadList
	 */
	public List<AssociateDTO> getGroupLeadList() {
		return groupLeadList;
	}

	/**
	 * @param groupLeadList
	 *            the groupLeadList to set
	 */
	public void setGroupLeadList(List<AssociateDTO> groupLeadList) {
		this.groupLeadList = groupLeadList;

		for (AssociateDTO associate : groupLeadList) {
			groupLeadMap.put(associate.getEmpNumber(), associate);
			supervisorMap.put(associate.getEmpNumber(), associate);
		}
	}

	/**
	 * @return the locationMap
	 */
	public Map<Integer, String> getLocationMap() {
		return locationMap;
	}

	/**
	 * @param locationMap
	 *            the locationMap to set
	 */
	public void setLocationMap(Map<Integer, String> locationMap) {
		this.locationMap = locationMap;
	}

	/**
	 * @return the visaTypeMap
	 */
	public Map<Integer, String> getVisaTypeMap() {
		return visaTypeMap;
	}

	/**
	 * @param visaTypeMap
	 *            the visaTypeMap to set
	 */
	public void setVisaTypeMap(Map<Integer, String> visaTypeMap) {
		this.visaTypeMap = visaTypeMap;
	}

	/**
	 * @return the visaStatusMap
	 */
	public Map<Integer, String> getVisaStatusMap() {
		return visaStatusMap;
	}

	/**
	 * @param visaStatusMap
	 *            the visaStatusMap to set
	 */
	public void setVisaStatusMap(Map<Integer, String> visaStatusMap) {
		this.visaStatusMap = visaStatusMap;
	}

	/**
	 * @return the porfolioMap
	 */
	public Map<Integer, String> getPorfolioMap() {
		return porfolioMap;
	}

	/**
	 * @param porfolioMap
	 *            the porfolioMap to set
	 */
	public void setPorfolioMap(Map<Integer, String> porfolioMap) {
		this.porfolioMap = porfolioMap;
	}

	/**
	 * @return the roleMap
	 */
	public Map<Integer, String> getRoleMap() {
		return roleMap;
	}

	/**
	 * @param roleMap
	 *            the roleMap to set
	 */
	public void setRoleMap(Map<Integer, String> roleMap) {
		this.roleMap = roleMap;
	}

	/**
	 * @return the designationMap
	 */
	public Map<Integer, String> getDesignationMap() {
		return designationMap;
	}

	/**
	 * @param designationMap
	 *            the designationMap to set
	 */
	public void setDesignationMap(Map<Integer, String> designationMap) {
		this.designationMap = designationMap;
	}

	/**
	 * @return the contractMap
	 */
	public Map<Integer, String> getContractMap() {
		return contractMap;
	}

	/**
	 * @param contractMap
	 *            the contractMap to set
	 */
	public void setContractMap(Map<Integer, String> contractMap) {
		this.contractMap = contractMap;
	}

	/**
	 * @return the technologyMap
	 */
	public Map<Integer, String> getTechnologyMap() {
		return technologyMap;
	}

	/**
	 * @param technologyMap
	 *            the technologyMap to set
	 */
	public void setTechnologyMap(Map<Integer, String> technologyMap) {
		this.technologyMap = technologyMap;
	}

	/**
	 * @return the projectLeadMap
	 */
	public Map<Integer, AssociateDTO> getProjectLeadMap() {
		return projectLeadMap;
	}

	/**
	 * @param projectLeadMap
	 *            the projectLeadMap to set
	 */
	public void setProjectLeadMap(Map<Integer, AssociateDTO> projectLeadMap) {
		this.projectLeadMap = projectLeadMap;
	}

	/**
	 * @return the projectManagerMap
	 */
	public Map<Integer, AssociateDTO> getProjectManagerMap() {
		return projectManagerMap;
	}

	/**
	 * @param projectManagerMap
	 *            the projectManagerMap to set
	 */
	public void setProjectManagerMap(Map<Integer, AssociateDTO> projectManagerMap) {
		this.projectManagerMap = projectManagerMap;
	}

	/**
	 * @return the deliveryManagerMap
	 */
	public Map<Integer, AssociateDTO> getDeliveryManagerMap() {
		return deliveryManagerMap;
	}

	/**
	 * @param deliveryManagerMap
	 *            the deliveryManagerMap to set
	 */
	public void setDeliveryManagerMap(Map<Integer, AssociateDTO> deliveryManagerMap) {
		this.deliveryManagerMap = deliveryManagerMap;
	}

	/**
	 * @return the groupLeadMap
	 */
	public Map<Integer, AssociateDTO> getGroupLeadMap() {
		return groupLeadMap;
	}

	/**
	 * @param groupLeadMap
	 *            the groupLeadMap to set
	 */
	public void setGroupLeadMap(Map<Integer, AssociateDTO> groupLeadMap) {
		this.groupLeadMap = groupLeadMap;
	}

	/**
	 * @return the thdManagerList
	 */
	public List<THDAssociateDTO> getThdManagerList(int portfolioCd) {
		
		if(portfolioCd != 0 && portfolioCd != 7)
		{
			
			List<THDAssociateDTO> thdMgrList = new ArrayList<THDAssociateDTO>();
			
			thdMgrList.addAll((List<THDAssociateDTO>)thdManagerListMap.get(7)); 
			if(thdManagerListMap.get(portfolioCd) != null)
			{
				thdMgrList.addAll((List<THDAssociateDTO>)thdManagerListMap.get(portfolioCd));				
			}
			return thdMgrList;
		}
		else
		{
			if(thdManagerList != null && !(thdManagerList.isEmpty()))
			{
				List<THDAssociateDTO> thdMgrListNoDuplicate = removeDuplicates(thdManagerList);
				return thdMgrListNoDuplicate;			
			}
			else
			{
				return new ArrayList<THDAssociateDTO>();
			}
		
		}
		
	}

	/**
	 * @param thdManagerList
	 *            the thdManagerList to set
	 */
	public void setThdManagerList(List<THDAssociateDTO> thdManagerList) {
		this.thdManagerList = thdManagerList;

		thdManagerListMap = new HashMap<Integer, List<THDAssociateDTO>>();
		
		for (THDAssociateDTO associate : thdManagerList) {
			thdManagerMap.put(associate.getLdapId(), VisaTrackingUtil.getName(associate.getFirstName(), associate.getLastName()));
			
			int portfolioCd = associate.getPortfolioCd();
			
			if(portfolioCd != 0 && thdManagerListMap.containsKey(portfolioCd))
			{
				//portfolio already present
				List<THDAssociateDTO> associateList = (List<THDAssociateDTO>)thdManagerListMap.get(portfolioCd);
				if(!associateList.contains(associate))
				{
					associateList.add(associate);
				}
			}
			else if (portfolioCd != 0)
			{
				List<THDAssociateDTO> associateList = new ArrayList<THDAssociateDTO>();
				associateList.add(associate);
				thdManagerListMap.put(portfolioCd, associateList);
			}
			
		}
	}

	/**
	 * @return the thdSrManagerList
	 */
	public List<THDAssociateDTO> getThdSrManagerList(int portfolioCd) {
		
		if(portfolioCd != 0 && portfolioCd != 7)
		{
			
			List<THDAssociateDTO> thdSrMgrList = new ArrayList<THDAssociateDTO>();
			
			thdSrMgrList.addAll((List<THDAssociateDTO>)thdSrManagerListMap.get(7)); 
			if(thdSrManagerListMap.get(portfolioCd) != null)
			{
				thdSrMgrList.addAll((List<THDAssociateDTO>)thdSrManagerListMap.get(portfolioCd));				
			}
			return thdSrMgrList;
			
			
		}
		else
		{
			if(thdSrManagerList != null && !(thdSrManagerList.isEmpty()))
			{
				List<THDAssociateDTO> thdsrMgrListNoDuplicate = removeDuplicates(thdSrManagerList);
				return thdsrMgrListNoDuplicate;			
			}
			else
			{
				return new ArrayList<THDAssociateDTO>();
			}
		}
		
	}

	/**
	 * @param thdSrManagerList
	 *            the thdSrManagerList to set
	 */
	public void setThdSrManagerList(List<THDAssociateDTO> thdSrManagerList) {
		this.thdSrManagerList = thdSrManagerList;
		
		thdSrManagerListMap = new HashMap<Integer, List<THDAssociateDTO>>();
		
		for (THDAssociateDTO associate : thdSrManagerList) {
			thdSrManagerMap.put(associate.getLdapId(), VisaTrackingUtil.getName(associate.getFirstName(), associate.getLastName()));
			
			int portfolioCd = associate.getPortfolioCd();
			
			if(portfolioCd != 0 && thdSrManagerListMap.containsKey(portfolioCd))
			{
				//portfolio already present
				List<THDAssociateDTO> associateList = (List<THDAssociateDTO>)thdSrManagerListMap.get(portfolioCd);
				if(!associateList.contains(associate))
				{
					associateList.add(associate);
				}
			}
			else if (portfolioCd != 0)
			{
				List<THDAssociateDTO> associateList = new ArrayList<THDAssociateDTO>();
				associateList.add(associate);
				thdSrManagerListMap.put(portfolioCd, associateList);
			}
		}
	}

	/**
	 * @return the thdDirectorList
	 */
	public List<THDAssociateDTO> getThdDirectorList(int portfolioCd) {
		
		if(portfolioCd != 0 && portfolioCd != 7)
		{
			List<THDAssociateDTO> thdDirList = new ArrayList<THDAssociateDTO>();
					
			thdDirList.addAll((List<THDAssociateDTO>)thdDirectorListMap.get(7)); 
			if(thdDirectorListMap.get(portfolioCd) != null)
			{
				thdDirList.addAll((List<THDAssociateDTO>)thdDirectorListMap.get(portfolioCd));				
			}
			return thdDirList;
		}
		else
		{
			if(thdDirectorList != null && !(thdDirectorList.isEmpty()))
			{
				List<THDAssociateDTO> thdDirListNoDuplicate = removeDuplicates(thdDirectorList);
				return thdDirListNoDuplicate;			
			}
			else
			{
				return new ArrayList<THDAssociateDTO>();
			}
		
		}
	}

	/**
	 * @param thdDirectorList
	 *            the thdDirectorList to set
	 */
	public void setThdDirectorList(List<THDAssociateDTO> thdDirectorList) {
		this.thdDirectorList = thdDirectorList;
		
		thdDirectorListMap = new HashMap<Integer, List<THDAssociateDTO>>();
		
		for (THDAssociateDTO associate : thdDirectorList) {
			thdDirectorMap.put(associate.getLdapId(), VisaTrackingUtil.getName(associate.getFirstName(), associate.getLastName()));
			
			int portfolioCd = associate.getPortfolioCd();
			
			if(portfolioCd != 0 && thdDirectorListMap.containsKey(portfolioCd))
			{
				//portfolio already present
				List<THDAssociateDTO> associateList = (List<THDAssociateDTO>)thdDirectorListMap.get(portfolioCd);
				if(!associateList.contains(associate))
				{
					associateList.add(associate);
				}
			}
			else if (portfolioCd != 0)
			{
				List<THDAssociateDTO> associateList = new ArrayList<THDAssociateDTO>();
				associateList.add(associate);
				thdDirectorListMap.put(portfolioCd, associateList);
			}
		}
	}

	/**
	 * @return the thdSrDirectorList
	 */
	public List<THDAssociateDTO> getThdSrDirectorList(int portfolioCd) {
		
		if(portfolioCd != 0 && portfolioCd != 7)
		{
			List<THDAssociateDTO> thdSrDirList = new ArrayList<THDAssociateDTO>();
			thdSrDirList.addAll((List<THDAssociateDTO>)thdSrDirectorListMap.get(7)); 
			if(thdSrDirectorListMap.get(portfolioCd) != null)
			{
				thdSrDirList.addAll((List<THDAssociateDTO>)thdSrDirectorListMap.get(portfolioCd));				
			}
			return thdSrDirList;
		}
		else
		{
			if(thdSrDirectorList != null && !(thdSrDirectorList.isEmpty()))
			{
				List<THDAssociateDTO> thdSrDirListNoDuplicate = removeDuplicates(thdSrDirectorList);
				return thdSrDirListNoDuplicate;			
			}
			else
			{
				return new ArrayList<THDAssociateDTO>();
			}
		
		}
		
	}

	/**
	 * @param thdSrDirectorList
	 *            the thdSrDirectorList to set
	 */
	public void setThdSrDirectorList(List<THDAssociateDTO> thdSrDirectorList) {
		this.thdSrDirectorList = thdSrDirectorList;
		
		thdSrDirectorListMap = new HashMap<Integer, List<THDAssociateDTO>>();
		
		for (THDAssociateDTO associate : thdSrDirectorList) {
			thdSrDirectorMap.put(associate.getLdapId(), VisaTrackingUtil.getName(associate.getFirstName(), associate.getLastName()));
			
			int portfolioCd = associate.getPortfolioCd();
			
			if(portfolioCd != 0 && thdSrDirectorListMap.containsKey(portfolioCd))
			{
				//portfolio already present
				List<THDAssociateDTO> associateList = (List<THDAssociateDTO>)thdSrDirectorListMap.get(portfolioCd);
				if(!associateList.contains(associate))
				{
					associateList.add(associate);
				}
			}
			else if (portfolioCd != 0)
			{
				List<THDAssociateDTO> associateList = new ArrayList<THDAssociateDTO>();
				associateList.add(associate);
				thdSrDirectorListMap.put(portfolioCd, associateList);
			}
		}
	}

	/**
	 * @return the thdVPList
	 */
	public List<THDAssociateDTO> getThdVPList(int portfolioCd) {
		
		if(portfolioCd != 0 && portfolioCd != 7)
		{
			List<THDAssociateDTO> thdVPList = new ArrayList<THDAssociateDTO>();
			thdVPList.addAll((List<THDAssociateDTO>)thdVPListMap.get(7)); 
			if(thdVPListMap.get(portfolioCd) != null)
			{
				thdVPList.addAll((List<THDAssociateDTO>)thdVPListMap.get(portfolioCd));				
			}
			return thdVPList;
		}
		else
		{
			if(thdVPList != null && !(thdVPList.isEmpty()))
			{
				List<THDAssociateDTO> thdVPListNoDuplicate = removeDuplicates(thdVPList);
				return thdVPListNoDuplicate;			
			}
			else
			{
				return new ArrayList<THDAssociateDTO>();
			}
		}
		
	}

	private List<THDAssociateDTO> removeDuplicates(List<THDAssociateDTO> thdList) {
		List<THDAssociateDTO> thdListNoDuplicate = new ArrayList<THDAssociateDTO>();
		for(THDAssociateDTO dto : thdList)
		{
			if(!(thdListNoDuplicate.contains(dto)))
			{
				thdListNoDuplicate.add(dto);
			}
		}
		
		
		return thdListNoDuplicate;
	}

	/**
	 * @param thdVPList
	 *            the thdVPList to set
	 */
	public void setThdVPList(List<THDAssociateDTO> thdVPList) {
		this.thdVPList = thdVPList;
		
		thdVPListMap = new HashMap<Integer, List<THDAssociateDTO>>();
		
		for (THDAssociateDTO associate : thdVPList) {
			thdVPMap.put(associate.getLdapId(), VisaTrackingUtil.getName(associate.getFirstName(), associate.getLastName()));
			
			int portfolioCd = associate.getPortfolioCd();
			
			if(portfolioCd != 0 && thdVPListMap.containsKey(portfolioCd))
			{
				//portfolio already present
				List<THDAssociateDTO> associateList = (List<THDAssociateDTO>)thdVPListMap.get(portfolioCd);
				if(!associateList.contains(associate))
				{
					associateList.add(associate);
				}
			}
			else if (portfolioCd != 0)
			{
				List<THDAssociateDTO> associateList = new ArrayList<THDAssociateDTO>();
				associateList.add(associate);
				thdVPListMap.put(portfolioCd, associateList);
			}
		}
	}

	/**
	 * @return the thdSrVPList
	 */
	public List<THDAssociateDTO> getThdSrVPList(int portfolioCd) {
		
		if(portfolioCd != 0 && portfolioCd != 7)
		{
			List<THDAssociateDTO> thdSVPList = new ArrayList<THDAssociateDTO>();
			thdSVPList.addAll((List<THDAssociateDTO>)thdSrVPListMap.get(7)); 
			if(thdSrVPListMap.get(portfolioCd) != null)
			{
				thdSVPList.addAll((List<THDAssociateDTO>)thdSrVPListMap.get(portfolioCd));				
			}
			return thdSVPList;
		}
		else
		{
			
			if(thdSrVPList != null && !(thdSrVPList.isEmpty()))
			{
				List<THDAssociateDTO> thdSVPListNoDuplicate = removeDuplicates(thdSrVPList);
				return thdSVPListNoDuplicate;			
			}
			else
			{
				return new ArrayList<THDAssociateDTO>();
			}
		
		}
	}

	/**
	 * @param thdSrVPList
	 *            the thdSrVPList to set
	 */
	public void setThdSrVPList(List<THDAssociateDTO> thdSrVPList) {
		this.thdSrVPList = thdSrVPList;
		
		thdSrVPListMap = new HashMap<Integer, List<THDAssociateDTO>>();
		
		for (THDAssociateDTO associate : thdSrVPList) {
			thdSrVPMap.put(associate.getLdapId(), VisaTrackingUtil.getName(associate.getFirstName(), associate.getLastName()));
			
			int portfolioCd = associate.getPortfolioCd();
			
			if(portfolioCd != 0 && thdSrVPListMap.containsKey(portfolioCd))
			{
				//portfolio already present
				List<THDAssociateDTO> associateList = (List<THDAssociateDTO>)thdSrVPListMap.get(portfolioCd);
				if(!associateList.contains(associate))
				{
					associateList.add(associate);
				}
				
			} 
			else if (portfolioCd != 0)
			{
				List<THDAssociateDTO> associateList = new ArrayList<THDAssociateDTO>();
				associateList.add(associate);
				thdSrVPListMap.put(portfolioCd, associateList);
			}
		}
	}

	/**
	 * @return the thdManagerMap
	 */
	public Map<String, String> getThdManagerMap() {
		return thdManagerMap;
	}

	/**
	 * @return the thdSrManagerMap
	 */
	public Map<String, String> getThdSrManagerMap() {
		return thdSrManagerMap;
	}

	/**
	 * @return the thdDirectorMap
	 */
	public Map<String, String> getThdDirectorMap() {
		return thdDirectorMap;
	}

	/**
	 * @return the thdSrDirectorMap
	 */
	public Map<String, String> getThdSrDirectorMap() {
		return thdSrDirectorMap;
	}

	/**
	 * @return the thdVPMap
	 */
	public Map<String, String> getThdVPMap() {
		return thdVPMap;
	}

	/**
	 * @return the thdSrVPMap
	 */
	public Map<String, String> getThdSrVPMap() {
		return thdSrVPMap;
	}

	/**
	 * @return the supervisorMap
	 */
	public Map<Integer, AssociateDTO> getSupervisorMap() {
		return supervisorMap;
	}

	/**
	 * @param supervisorMap
	 *            the supervisorMap to set
	 */
	public void setSupervisorMap(Map<Integer, AssociateDTO> supervisorMap) {
		this.supervisorMap = supervisorMap;
	}

	/**
	 * @return the projectList
	 */
	public List<TypeDTO> getProjectList(int portfolioCd) {
		
		
		if(portfolioCd != 0 && portfolioCd != 7)
		{
			List<TypeDTO> projList = (List<TypeDTO>)projectListMap.get(portfolioCd);
			
			if(projList != null)
			{
				return projList;
			}
			else
			{
				return new ArrayList<TypeDTO>();
			}
			
		}
		else
		{
			return projectList;			
		}
	}

	/**
	 * @param projectList
	 *            the projectList to set
	 */
	public void setProjectList(List<TypeDTO> projectList) {
		this.projectList = projectList;

		projectListMap = new HashMap<Integer, List<TypeDTO>>();
		
		for (TypeDTO project : projectList) {
			projectMap.put(project.getCd(), project.getDesc());
			projectIdMap.put(VisaTrackingUtil.trimString(project.getDesc()), project.getCd());
			
			
			int portfolioCd = project.getPortfolioCd();
			
			if(portfolioCd != 0 && projectListMap.containsKey(portfolioCd))
			{
				//portfolio already present
				List<TypeDTO> projList = (List<TypeDTO>)projectListMap.get(portfolioCd);
				if(!projList.contains(project))
				{
					projList.add(project);
				}
			}
			else if (portfolioCd != 0)
			{
				List<TypeDTO> projList = new ArrayList<TypeDTO>();
				projList.add(project);
				projectListMap.put(portfolioCd, projList);
			}
			
		}
	}

	/**
	 * @return the projectMap
	 */
	public Map<Integer, String> getProjectMap() {
		return projectMap;
	}

	/**
	 * @return the woStatusList
	 */
	public List<TypeDTO> getWoStatusList() {
		return woStatusList;
	}

	/**
	 * @param woStatusList
	 *            the woStatusList to set
	 */
	public void setWoStatusList(List<TypeDTO> woStatusList) {
		this.woStatusList = woStatusList;

		for (TypeDTO woStatus : woStatusList) {
			woStatusMap.put(woStatus.getCd(), woStatus.getDesc());
		}
	}

	/**
	 * @return the fiscalList
	 */
	public List<THDFiscalMonthDTO> getFiscalList() {
		return fiscalList;
	}

	/**
	 * @param fiscalList
	 *            the fiscalList to set
	 */
	public void setFiscalList(List<THDFiscalMonthDTO> fiscalList) {
		this.fiscalList = fiscalList;
	}

	/**
	 * @return the woStatusMap
	 */
	public Map<Integer, String> getWoStatusMap() {
		return woStatusMap;
	}

	/**
	 * @return the serviceLineDescList
	 */
	public List<TypeDTO> getServiceLineDescList() {
		return serviceLineDescList;
	}

	/**
	 * @param serviceLineDescList
	 *            the serviceLineDescList to set
	 */
	public void setServiceLineDescList(List<TypeDTO> serviceLineDescList) {
		this.serviceLineDescList = serviceLineDescList;

		for (TypeDTO serviceLineDesc : serviceLineDescList) {
			serviceLineDescMap.put(serviceLineDesc.getCd(), serviceLineDesc.getDesc());
			serviceLineIdMap.put(VisaTrackingUtil.trimString(serviceLineDesc.getDesc()), serviceLineDesc.getCd());
		}
	}

	/**
	 * @return the serviceLineDescMap
	 */
	public Map<Integer, String> getServiceLineDescMap() {
		return serviceLineDescMap;
	}

	public List<TypeDTO> getTechLvlList() {
		return techLvlList;
	}

	public void setTechLvlList(List<TypeDTO> techLvlList) {
		this.techLvlList = techLvlList;
		
		for (TypeDTO techlvl : techLvlList) {
			technologyLvlMap.put(techlvl.getCd(), techlvl.getDesc());
			technologyLvlIdMap.put(VisaTrackingUtil.trimString(techlvl.getDesc()), techlvl.getCd());
		}
	}

	public Map<Integer, String> getTechnologyLvlMap() {
		return technologyLvlMap;
	}

	public void setTechnologyLvlMap(Map<Integer, String> technologyLvlMap) {
		this.technologyLvlMap = technologyLvlMap;
	}

	public Map<String, Integer> getProjectIdMap() {
		return projectIdMap;
	}

	public void setProjectIdMap(Map<String, Integer> projectIdMap) {
		this.projectIdMap = projectIdMap;
	}

	public Map<String, Integer> getLocationIdMap() {
		return locationIdMap;
	}

	public void setLocationIdMap(Map<String, Integer> locationIdMap) {
		this.locationIdMap = locationIdMap;
	}

	public Map<String, Integer> getPorfolioIdMap() {
		return porfolioIdMap;
	}

	public void setPorfolioIdMap(Map<String, Integer> porfolioIdMap) {
		this.porfolioIdMap = porfolioIdMap;
	}

	public Map<String, Integer> getRoleIdMap() {
		return roleIdMap;
	}

	public void setRoleIdMap(Map<String, Integer> roleIdMap) {
		this.roleIdMap = roleIdMap;
	}

	public Map<String, Integer> getDesignationIdMap() {
		return designationIdMap;
	}

	public void setDesignationIdMap(Map<String, Integer> designationIdMap) {
		this.designationIdMap = designationIdMap;
	}

	public Map<String, Integer> getContractIdMap() {
		return contractIdMap;
	}

	public void setContractIdMap(Map<String, Integer> contractIdMap) {
		this.contractIdMap = contractIdMap;
	}

	public Map<String, Integer> getTechnologyIdMap() {
		return technologyIdMap;
	}

	public void setTechnologyIdMap(Map<String, Integer> technologyIdMap) {
		this.technologyIdMap = technologyIdMap;
	}

	public Map<String, Integer> getTechnologyLvlIdMap() {
		return technologyLvlIdMap;
	}

	public void setTechnologyLvlIdMap(Map<String, Integer> technologyLvlIdMap) {
		this.technologyLvlIdMap = technologyLvlIdMap;
	}

	public Map<String, Integer> getServiceLineIdMap() {
		return serviceLineIdMap;
	}

	public void setServiceLineIdMap(Map<String, Integer> serviceLineIdMap) {
		this.serviceLineIdMap = serviceLineIdMap;
	}

}
