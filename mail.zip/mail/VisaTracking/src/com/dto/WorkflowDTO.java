package com.dto;

public class WorkflowDTO {
	public int empNbr;
	public int approvedId;
	public String approvedDt;
	public String oldWorkflowStatus;//inserting in history= current status
	public String newWorkflowStatus;//inserting in history= next Pending
	public String transactionId;
	public String approverName;
	public String approverRole;
	public String nextPendingStatus;//search flow
	public String comments;
	public String currentStatus;//search flow
	public boolean resultStatus;
	public int getEmpNbr() {
		return empNbr;
	}
	public void setEmpNbr(int empNbr) {
		this.empNbr = empNbr;
	}
	public int getApprovedId() {
		return approvedId;
	}
	public void setApprovedId(int approvedId) {
		this.approvedId = approvedId;
	}
	public String getApprovedDt() {
		return approvedDt;
	}
	public void setApprovedDt(String approvedDt) {
		this.approvedDt = approvedDt;
	}
	public String getOldWorkflowStatus() {
		return oldWorkflowStatus;
	}
	public void setOldWorkflowStatus(String oldWorkflowStatus) {
		this.oldWorkflowStatus = oldWorkflowStatus;
	}
	public String getNewWorkflowStatus() {
		return newWorkflowStatus;
	}
	public void setNewWorkflowStatus(String newWorkflowStatus) {
		this.newWorkflowStatus = newWorkflowStatus;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getApproverName() {
		return approverName;
	}
	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}
	public String getApproverRole() {
		return approverRole;
	}
	public void setApproverRole(String approverRole) {
		this.approverRole = approverRole;
	}
	
	public String getNextPendingStatus() {
		return nextPendingStatus;
	}
	public void setNextPendingStatus(String nextPendingStatus) {
		this.nextPendingStatus = nextPendingStatus;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	public boolean isResultStatus() {
		return resultStatus;
	}
	public void setResultStatus(boolean resultStatus) {
		this.resultStatus = resultStatus;
	}
	
	
	
}
