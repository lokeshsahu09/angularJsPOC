package com.dto;

import java.util.List;

public class MasterDetailsDTO {
	private List<PortfolioDTO> porfolioList;
	/**
	 * @return the porfolioList
	 */
	public List<PortfolioDTO> getPorfolioList() {
		return porfolioList;
	}
	/**
	 * @param porfolioList the porfolioList to set
	 */
	public void setPorfolioList(List<PortfolioDTO> porfolioList) {
		this.porfolioList = porfolioList;
	}
	/**
	 * @return the visaTypeList
	 */
	public List<VisaTypeDTO> getVisaTypeList() {
		return visaTypeList;
	}
	/**
	 * @param visaTypeList the visaTypeList to set
	 */
	public void setVisaTypeList(List<VisaTypeDTO> visaTypeList) {
		this.visaTypeList = visaTypeList;
	}
	/**
	 * @return the visaStatusList
	 */
	public List<VisaStatusDTO> getVisaStatusList() {
		return visaStatusList;
	}
	/**
	 * @param visaStatusList the visaStatusList to set
	 */
	public void setVisaStatusList(List<VisaStatusDTO> visaStatusList) {
		this.visaStatusList = visaStatusList;
	}
	/**
	 * @return the projectList
	 */
	public List<ProjectTypeDTO> getProjectList() {
		return projectList;
	}
	/**
	 * @param projectList the projectList to set
	 */
	public void setProjectList(List<ProjectTypeDTO> projectList) {
		this.projectList = projectList;
	}
	/**
	 * @return the traveltoList
	 */
	public List<TravelToDTO> getTraveltoList() {
		return traveltoList;
	}
	/**
	 * @param traveltoList the traveltoList to set
	 */
	public void setTraveltoList(List<TravelToDTO> traveltoList) {
		this.traveltoList = traveltoList;
	}
	
	public class PortfolioDTO{
		int portfolioCd;
		String portfolioDescription;
		/**
		 * @return the portfolioCd
		 */
		public int getPortfolioCd() {
			return portfolioCd;
		}
		/**
		 * @param portfolioCd the portfolioCd to set
		 */
		public void setPortfolioCd(int portfolioCd) {
			this.portfolioCd = portfolioCd;
		}
		/**
		 * @return the portfolioDescription
		 */
		public String getPortfolioDescription() {
			return portfolioDescription;
		}
		/**
		 * @param portfolioDescription the portfolioDescription to set
		 */
		public void setPortfolioDescription(String portfolioDescription) {
			this.portfolioDescription = portfolioDescription;
		}
	}
	private List<VisaTypeDTO> visaTypeList;
	
	public class VisaStatusDTO{
		int visaStatsCd;
		String visaStatsDesc;
		/**
		 * @return the visaStatsCd
		 */
		public int getVisaStatsCd() {
			return visaStatsCd;
		}
		/**
		 * @param visaStatsCd the visaStatsCd to set
		 */
		public void setVisaStatsCd(int visaStatsCd) {
			this.visaStatsCd = visaStatsCd;
		}
		/**
		 * @return the visaStatsDesc
		 */
		public String getVisaStatsDesc() {
			return visaStatsDesc;
		}
		/**
		 * @param visaStatsDesc the visaStatsDesc to set
		 */
		public void setVisaStatsDesc(String visaStatsDesc) {
			this.visaStatsDesc = visaStatsDesc;
		}
	}
	private List<VisaStatusDTO> visaStatusList;
	
	public class VisaTypeDTO{
		int visaTypCd;
		String visaTypDesc;
		/**
		 * @return the visaTypCd
		 */
		public int getVisaTypCd() {
			return visaTypCd;
		}
		/**
		 * @param visaTypCd the visaTypCd to set
		 */
		public void setVisaTypCd(int visaTypCd) {
			this.visaTypCd = visaTypCd;
		}
		/**
		 * @return the visaTypDesc
		 */
		public String getVisaTypDesc() {
			return visaTypDesc;
		}
		/**
		 * @param visaTypDesc the visaTypDesc to set
		 */
		public void setVisaTypDesc(String visaTypDesc) {
			this.visaTypDesc = visaTypDesc;
		}
	}
	private List<ProjectTypeDTO> projectList;
	
	public class ProjectTypeDTO{
		int cd;
		String desc;
		/**
		 * @return the cd
		 */
		public int getCd() {
			return cd;
		}
		/**
		 * @param cd the cd to set
		 */
		public void setCd(int cd) {
			this.cd = cd;
		}
		/**
		 * @return the desc
		 */
		public String getDesc() {
			return desc;
		}
		/**
		 * @param desc the desc to set
		 */
		public void setDesc(String desc) {
			this.desc = desc;
		}
	}
	private List<TravelToDTO> traveltoList;
	public class TravelToDTO{
		int cd;
		String desc;
		/**
		 * @return the cd
		 */
		public int getCd() {
			return cd;
		}
		/**
		 * @param cd the cd to set
		 */
		public void setCd(int cd) {
			this.cd = cd;
		}
		/**
		 * @return the desc
		 */
		public String getDesc() {
			return desc;
		}
		/**
		 * @param desc the desc to set
		 */
		public void setDesc(String desc) {
			this.desc = desc;
		}
	}
}
