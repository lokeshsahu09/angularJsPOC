/**
 * This program is proprietary to The Home Depot and is not to be reproduced,
 * used, or disclosed without permission of:
 * 
 *    The Home Depot
 *    2455 Paces Ferry Road, NW
 *    Atlanta, GA 30339-4024
 *
 *  FileName : Error
 */
package com.dto;

import com.util.ApplicationConstants;

/**
 * Holds error related data.
 * 
 * @ author TCS
 */
public class ErrorDTO {

	private int status = ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS;

	private int code;

	private String message;

	private String developerMessage;

	/**
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(int status) {
		this.status = status;
	}

	/**
	 * @return the code
	 */
	public int getCode() {
		return code;
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(int code) {
		this.code = code;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 *            the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the developerMessage
	 */
	public String getDeveloperMessage() {
		return developerMessage;
	}

	/**
	 * @param developerMessage
	 *            the developerMessage to set
	 */
	public void setDeveloperMessage(String developerMessage) {
		this.developerMessage = developerMessage;
	}

	/**
	 * Generates a String representation of the ErrorDTO Object.
	 * 
	 * @return String value of the object
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder(this.getClass().getName());
		builder.append(" Object {");
		builder.append(ApplicationConstants.NEW_LINE);
		builder.append("status: ").append(status).append(ApplicationConstants.NEW_LINE);
		builder.append("code: ").append(code).append(ApplicationConstants.NEW_LINE);
		builder.append("message: ").append(message).append(ApplicationConstants.NEW_LINE);
		builder.append("developerMessage: ").append(developerMessage).append(ApplicationConstants.NEW_LINE);
		builder.append("}");

		return builder.toString();
	}
}
