package com.dto;

import java.sql.Date;

public class THDFiscalMonthDTO {

	private Date startDate;

	private Date endDate;

	private int monthId;

	private String monthDesc;
	
	private int year;

	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate
	 *            the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the monthId
	 */
	public int getMonthId() {
		return monthId;
	}

	/**
	 * @param monthId
	 *            the monthId to set
	 */
	public void setMonthId(int monthId) {
		this.monthId = monthId;
	}

	/**
	 * @return the monthDesc
	 */
	public String getMonthDesc() {
		return monthDesc;
	}

	/**
	 * @param monthDesc
	 *            the monthDesc to set
	 */
	public void setMonthDesc(String monthDesc) {
		this.monthDesc = monthDesc;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

}
