package com.manager;

import java.security.NoSuchProviderException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.StringTokenizer;

import com.dao.AssociateDAO;
import com.dao.AuthenticateDAO;
import com.dto.AssociateDetailsDTO;
import com.dto.LoggedInUserDetailsDTO;
import com.dto.ResponseHeaderDTO;
import com.dto.TypeDTO;
import com.exception.VisaTrackingServiceException;
import com.request.dto.AuthenticateRequest;
import com.request.dto.ChangePasswordRequest;
import com.response.dto.AuthenticateResponse;
import com.util.ApplicationConstants;
import com.util.VisaTrackingEncriptorDecriptor;

public class AuthenticateManager {

	private static volatile AuthenticateManager instance = null;

	public static AuthenticateManager getInstance() {
		if (instance == null) {
			synchronized (AuthenticateManager.class) {
				if (instance == null) {
					instance = new AuthenticateManager();
				}
			}
		}
		return instance;
	}

	public AuthenticateResponse authenticate(AuthenticateRequest authenticateRequest) throws VisaTrackingServiceException {
		AuthenticateResponse authenticateResponse = new AuthenticateResponse();
		ResponseHeaderDTO responseHeader = new ResponseHeaderDTO();

		AuthenticateDAO authenticateDAO = AuthenticateDAO.getInstance();

		try {
			
			if(((authenticateRequest.getEmpNumber() == 0 || authenticateRequest.getPassword() == null )) && (authenticateRequest.getToken() != null))
			{
				String decryptedToken = VisaTrackingEncriptorDecriptor.getInstance().decrypt(authenticateRequest.getToken());
				
				if(decryptedToken != null && decryptedToken.contains("-"))
				{
					StringTokenizer st = new StringTokenizer(decryptedToken, "-");
					authenticateRequest.setEmpNumber(Integer.parseInt(st.nextToken()));
					authenticateRequest.setPassword(st.nextToken());
				}
			}
						
			String encryptedPwd = VisaTrackingEncriptorDecriptor.getInstance().encrypt(authenticateRequest.getPassword());

			LoggedInUserDetailsDTO loggedInUserDetailsDTO = authenticateDAO.authenticateAndGetDetials(authenticateRequest.getEmpNumber(), encryptedPwd);
			
	

			
			if (loggedInUserDetailsDTO != null) {
				//loggedInUserDetailsDTO = AssociateDAO.getInstance().getLoggedInUserDetails(authenticateRequest.getEmpNumber());

				if(loggedInUserDetailsDTO.getIsFirstTime() != null && loggedInUserDetailsDTO.getIsFirstTime().equalsIgnoreCase("Y"));
				{
					List<TypeDTO> securityQuestions = authenticateDAO.getSecurityQuestions();
					loggedInUserDetailsDTO.setSecurityQuestions(securityQuestions);
				}
				
				String token = VisaTrackingEncriptorDecriptor.getInstance().encrypt(authenticateRequest.getEmpNumber() + "-" + encryptedPwd);

				loggedInUserDetailsDTO.setToken(token);

				responseHeader.setStatus(ApplicationConstants.OK_STATUS);
			} else {
				responseHeader.setStatus(ApplicationConstants.VALIDATION_ERROR_STATUS);
				responseHeader.setMessage("Please verify username and password.");
			}

			authenticateResponse.setHeader(responseHeader);
			authenticateResponse.setUserDetails(loggedInUserDetailsDTO);

		} catch (NoSuchProviderException ne) {
			throw new VisaTrackingServiceException(ne);
		} catch (SQLException se) {
			throw new VisaTrackingServiceException(se);
		}

		return authenticateResponse;
	}

	
	public AuthenticateResponse changePasswordFirstTime(ChangePasswordRequest changePasswordRequest) throws VisaTrackingServiceException {
		AuthenticateResponse authenticateResponse = new AuthenticateResponse();
		ResponseHeaderDTO responseHeader = new ResponseHeaderDTO();
		LoggedInUserDetailsDTO loggedInUserDetailsDTO = null;

		AuthenticateDAO authenticateDAO = AuthenticateDAO.getInstance();

		try {
			String encryptedPwd = VisaTrackingEncriptorDecriptor.getInstance().encrypt(changePasswordRequest.getPassword());

			boolean status = authenticateDAO.authenticate(changePasswordRequest.getEmpNumber(), encryptedPwd);

			if (status) {
				encryptedPwd = VisaTrackingEncriptorDecriptor.getInstance().encrypt(changePasswordRequest.getNewPassword());
				
				String encryptedSecurityAns = VisaTrackingEncriptorDecriptor.getInstance().encrypt(changePasswordRequest.getSecurityans());

				status = authenticateDAO.changePasswordFirstTime(changePasswordRequest.getEmpNumber(), encryptedPwd, changePasswordRequest.getSecurityQuestionCd(), encryptedSecurityAns);

				loggedInUserDetailsDTO = authenticateDAO.authenticateAndGetDetials(changePasswordRequest.getEmpNumber(), encryptedPwd);
				
				responseHeader.setStatus(ApplicationConstants.OK_STATUS);
			} else {
				responseHeader.setStatus(ApplicationConstants.VALIDATION_ERROR_STATUS);
				responseHeader.setMessage("Please verify username and password.");
			}
			
			authenticateResponse.setHeader(responseHeader);
			authenticateResponse.setUserDetails(loggedInUserDetailsDTO);
			
		} catch (NoSuchProviderException ne) {
			throw new VisaTrackingServiceException(ne);
		} catch (SQLException se) {
			throw new VisaTrackingServiceException(se);
		}

		return authenticateResponse;
	}
	
	
	public ResponseHeaderDTO changePassword(ChangePasswordRequest changePasswordRequest) throws VisaTrackingServiceException {
		ResponseHeaderDTO responseHeader = new ResponseHeaderDTO();

		AuthenticateDAO authenticateDAO = AuthenticateDAO.getInstance();

		try {
			String encryptedPwd = VisaTrackingEncriptorDecriptor.getInstance().encrypt(changePasswordRequest.getPassword());

			boolean status = authenticateDAO.authenticate(changePasswordRequest.getEmpNumber(), encryptedPwd);

			if (status) {
				encryptedPwd = VisaTrackingEncriptorDecriptor.getInstance().encrypt(changePasswordRequest.getNewPassword());

				status = authenticateDAO.changePassword(changePasswordRequest.getEmpNumber(), encryptedPwd);

				responseHeader.setStatus(ApplicationConstants.OK_STATUS);
			} else {
				responseHeader.setStatus(ApplicationConstants.VALIDATION_ERROR_STATUS);
				responseHeader.setMessage("Please verify username and password.");
			}
		} catch (NoSuchProviderException ne) {
			throw new VisaTrackingServiceException(ne);
		} catch (SQLException se) {
			throw new VisaTrackingServiceException(se);
		}

		return responseHeader;
	}

	public ResponseHeaderDTO resetPassword(AuthenticateRequest changePasswordRequest) throws VisaTrackingServiceException {
		ResponseHeaderDTO responseHeader = new ResponseHeaderDTO();

		AuthenticateDAO authenticateDAO = AuthenticateDAO.getInstance();

		try {
			Date dob = (Date) AssociateDAO.getInstance().getDOBOfAssociate(changePasswordRequest.getEmpNumber());

			String newPwd = Integer.toString(changePasswordRequest.getEmpNumber()).concat("@").concat(dob.toString());

			String encryptedPwd = VisaTrackingEncriptorDecriptor.getInstance().encrypt(newPwd);

			boolean status = authenticateDAO.changePassword(changePasswordRequest.getEmpNumber(), encryptedPwd);

			if (status) {
				responseHeader.setStatus(ApplicationConstants.OK_STATUS);
			} else {
				responseHeader.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
			}
		} catch (NoSuchProviderException ne) {
			throw new VisaTrackingServiceException(ne);
		} catch (SQLException se) {
			throw new VisaTrackingServiceException(se);
		}

		return responseHeader;
	}

	public boolean createUser(AssociateDetailsDTO associateDetails, Connection connection) throws VisaTrackingServiceException {
		boolean status = false;


		AuthenticateDAO authenticateDAO = AuthenticateDAO.getInstance();

		try {
			//Date dob = AssociateDAO.getInstance().getDOBOfAssociate(empNumber);

			String newPwd = associateDetails.getPrimaryContactNumber().substring(1,3)+"#"+associateDetails.getEmpNumber() ; // Integer.toString(empNumber).concat("@").concat(dob.toString());

			String encryptedPwd = VisaTrackingEncriptorDecriptor.getInstance().encrypt(newPwd);

			status = authenticateDAO.createUser(associateDetails, encryptedPwd, connection);

		} catch (NoSuchProviderException ne) {
			throw new VisaTrackingServiceException(ne);
		} catch (SQLException se) {
			throw new VisaTrackingServiceException(se);
		}

		return status;
	}
	
	
	public boolean isUserAuthPresent(AssociateDetailsDTO associateDetails, Connection connection) throws VisaTrackingServiceException {
		boolean status = false;

		AuthenticateDAO authenticateDAO = AuthenticateDAO.getInstance();

		try {
			status = authenticateDAO.isUserAuthPresent(associateDetails,  connection);

		} catch (SQLException se) {
			throw new VisaTrackingServiceException(se);
		}

		return status;
	}

}
