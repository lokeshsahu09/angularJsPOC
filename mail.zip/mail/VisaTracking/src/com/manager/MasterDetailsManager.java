package com.manager;

import java.security.NoSuchProviderException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;

import com.dao.MasterDetailsDAO;
import com.dao.util.DAOFactory;
import com.dto.MasterDetailsDTO;
import com.exception.VisaTrackingException;
import com.exception.VisaTrackingServiceException;

public class MasterDetailsManager {
	private static volatile MasterDetailsManager instance = null;

	public static MasterDetailsManager getInstance() {
		if (instance == null) {
			synchronized (MasterDetailsManager.class) {
				if (instance == null) {
					instance = new MasterDetailsManager();
				}
			}
		}
		return instance;
	}

	public MasterDetailsDTO getMasterDetails()
			throws VisaTrackingServiceException{
		Connection connection = null;
		MasterDetailsDTO searchResponse = new MasterDetailsDTO();
		MasterDetailsDAO masterDetailsDAO = MasterDetailsDAO.getInstance();
		try {
			connection = DAOFactory.getConnectionInManualCommitMode();
			searchResponse = masterDetailsDAO.getMasterDetails(connection);
		} catch (VisaTrackingServiceException ne) {
			throw new VisaTrackingServiceException(ne);
		} catch (SQLException se) {
			throw new VisaTrackingServiceException(se);
		}
		return searchResponse;
	}

}
