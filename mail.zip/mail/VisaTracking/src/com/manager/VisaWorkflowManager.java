package com.manager;

import java.sql.Connection;
import java.sql.SQLException;

import com.dao.VisaWorkflowDAO;
import com.dao.util.DAOFactory;
import com.dto.ResponseHeaderDTO;
import com.dto.WorkflowDTO;
import com.exception.VisaTrackingServiceException;
import com.google.gson.Gson;
import com.util.GsonConverter;
import com.util.RefreshCache;

public class VisaWorkflowManager {
	
	private static volatile VisaWorkflowManager instance = null;

	public static VisaWorkflowManager getInstance() {
		if (instance == null) {
			synchronized (VisaWorkflowManager.class) {
				if (instance == null) {
					instance = new VisaWorkflowManager();
				}
			}
		}
		return instance;
	}
	
	public String updateVisaStatus(int emp_nbr,String comments, int approvalStatus, int loggedInEmp) throws VisaTrackingServiceException {
		
		Connection connection = null;
		VisaWorkflowDAO visaWorkflowDAO = VisaWorkflowDAO.getInstance();
		WorkflowDTO workflowDTO = new WorkflowDTO();
		try{
			connection = DAOFactory.getConnectionInManualCommitMode();
			//business wise
			
			workflowDTO= visaWorkflowDAO.updateVisaStatusWorkflow(connection,emp_nbr,comments,approvalStatus,
					loggedInEmp);
		}catch (SQLException se) {
			try {
				DAOFactory.rollBackConnection(connection);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			throw new VisaTrackingServiceException(se);
		} finally {
			DAOFactory.close(null, null, connection);
		}
		RefreshCache refreshCache = new RefreshCache();
		refreshCache.start();
		
		return GsonConverter.toJson(workflowDTO);
	}
	
	/*public ResponseHeaderDTO update(CreateAssociateRequest updateAssociateRequest) throws TMSServiceException {
		ResponseHeaderDTO response = new ResponseHeaderDTO();

		AssociateDAO assicoateDAO = AssociateDAO.getInstance();
		AssociateHierarchyDTO assocHierarchyDTO = new AssociateHierarchyDTO();
		Connection connection = null;

		try {
			connection = DAOFactory.getConnectionInManualCommitMode();

			AssociateDetailsDTO currAssociateDetails = updateAssociateRequest.getAssociateDetails();
			AssociateDetailsDTO oldAssociateDetails = null;
			
			SearchAssociateRequest searchAssociateRequest = new SearchAssociateRequest();
			searchAssociateRequest.setEmpNumber(currAssociateDetails.getEmpNumber());
			
			
			SearchAssociateResponse oldAssociateDetailsResponse = assicoateDAO.search(searchAssociateRequest);
			if(oldAssociateDetailsResponse != null && oldAssociateDetailsResponse.getAssociateDetailsList() != null && !oldAssociateDetailsResponse.getAssociateDetailsList().isEmpty())
			{
				oldAssociateDetails = oldAssociateDetailsResponse.getAssociateDetailsList().get(0);
			}
	
			
			currAssociateDetails.setProjectIdFromAsscTable(currAssociateDetails.getProjectId());
			
			if (0 == assicoateDAO.checkAssociate(currAssociateDetails.getEmpNumber())) {
				response.setStatus(ApplicationConstants.VALIDATION_ERROR_STATUS);
				response.setMessage("Associate not present.");
)
				return response;
			} 

			int oldRoleCd = assicoateDAO.getEmpRoleCd(associateDetails.getEmpNumber());

			if (oldRoleCd < associateDetails.getRoleCd()) {
				assicoateDAO.updateEmpHierarchy(connection, oldRoleCd, associateDetails.getRoleCd(), associateDetails.getEmpNumber(),
						updateAssociateRequest.getLoggedInEmpNumber());
			}

			boolean status = assicoateDAO.updateAssociateDetails(connection, currAssociateDetails, updateAssociateRequest.getLoggedInEmpNumber());

			
			if (status && 0 != currAssociateDetails.getProjectId()) {
				AssociateHierarchyDTO associateHierarchy = assicoateDAO.retrieveEmpHierarchyByProject(currAssociateDetails.getProjectId(),connection);
				
				//AssociateHierarchyDTO assocHierarchyDTO = new AssociateHierarchyDTO();
				assocHierarchyDTO.setEmpNumber(currAssociateDetails.getEmpNumber());
				
				
				assocHierarchyDTO.setPlEmpNumber(associateHierarchy.getPlEmpNumber());
				assocHierarchyDTO.setPmEmpNumber(associateHierarchy.getPmEmpNumber());
				assocHierarchyDTO.setDmEmpNumber(associateHierarchy.getDmEmpNumber());
				assocHierarchyDTO.setGlEmpNumber(associateHierarchy.getGlEmpNumber());
				assocHierarchyDTO.setPortfolioCd(currAssociateDetails.getPortfolioCd());
								
				status = assicoateDAO.updateEmpHierarchy(connection, assocHierarchyDTO, updateAssociateRequest.getLoggedInEmpNumber());
			}
			else if (status && 0 != currAssociateDetails.getSupervisorEmpNumber()) {
				AssociateHierarchyDTO associateHierarchy = assicoateDAO.retrieveEmpHierarchy(currAssociateDetails.getSupervisorEmpNumber());

				if (null != associateHierarchy) {
					int supervisorRoleCd = assicoateDAO.getEmpRoleCd(currAssociateDetails.getSupervisorEmpNumber());

					//AssociateHierarchyDTO assocHierarchyDTO = new AssociateHierarchyDTO();

					assocHierarchyDTO.setEmpNumber(currAssociateDetails.getEmpNumber());

					if (supervisorRoleCd == 3) {
						assocHierarchyDTO.setPlEmpNumber(currAssociateDetails.getSupervisorEmpNumber());
						assocHierarchyDTO.setPmEmpNumber(associateHierarchy.getPmEmpNumber());
						assocHierarchyDTO.setDmEmpNumber(associateHierarchy.getDmEmpNumber());
						assocHierarchyDTO.setGlEmpNumber(associateHierarchy.getGlEmpNumber());
						assocHierarchyDTO.setPortfolioCd(currAssociateDetails.getPortfolioCd());
					} else if (supervisorRoleCd == 4) {
						if(currAssociateDetails.getRoleCd() == 3)
						{
							assocHierarchyDTO.setPlEmpNumber(currAssociateDetails.getEmpNumber());
						}
						assocHierarchyDTO.setPmEmpNumber(currAssociateDetails.getSupervisorEmpNumber());
						assocHierarchyDTO.setDmEmpNumber(associateHierarchy.getDmEmpNumber());
						assocHierarchyDTO.setGlEmpNumber(associateHierarchy.getGlEmpNumber());
						assocHierarchyDTO.setPortfolioCd(currAssociateDetails.getPortfolioCd());
					} else if (supervisorRoleCd == 5) {
						if(currAssociateDetails.getRoleCd() == 4)
						{
							assocHierarchyDTO.setPmEmpNumber(currAssociateDetails.getEmpNumber());
						}
						assocHierarchyDTO.setDmEmpNumber(currAssociateDetails.getSupervisorEmpNumber());
						assocHierarchyDTO.setGlEmpNumber(associateHierarchy.getGlEmpNumber());
						assocHierarchyDTO.setPortfolioCd(currAssociateDetails.getPortfolioCd());
					} else if (supervisorRoleCd == 6) {
						if(currAssociateDetails.getRoleCd() == 5)
						{
							assocHierarchyDTO.setDmEmpNumber(currAssociateDetails.getEmpNumber());
						}
						assocHierarchyDTO.setGlEmpNumber(currAssociateDetails.getSupervisorEmpNumber());
						assocHierarchyDTO.setPortfolioCd(currAssociateDetails.getPortfolioCd());
					} else {
						response.setStatus(ApplicationConstants.VALIDATION_ERROR_STATUS);
						response.setMessage("Please Enter a supervisor who is having a role as PL or above.");

						return response;
					}
					status = assicoateDAO.updateEmpHierarchy(connection, assocHierarchyDTO, updateAssociateRequest.getLoggedInEmpNumber());
					
					if(status && oldAssociateDetails.getRoleCd() != currAssociateDetails.getRoleCd())
					{
						assicoateDAO.updateOtherEmpHierarchy(connection, oldAssociateDetails.getRoleCd(), assocHierarchyDTO, updateAssociateRequest.getLoggedInEmpNumber());
						assicoateDAO.updateSupervisorEmpHierarchy(connection, assocHierarchyDTO, updateAssociateRequest.getLoggedInEmpNumber());
					}

				}
			}

			if (status && null != currAssociateDetails.getVisaDetails() && 0 != currAssociateDetails.getVisaDetails().getVtsId()) {
				if (null != assicoateDAO.retrieveVisaDetails(connection, currAssociateDetails.getEmpNumber())) {
					status = assicoateDAO.updateVisaDetails(connection, currAssociateDetails.getEmpNumber(), currAssociateDetails.getVisaDetails(),
							updateAssociateRequest.getLoggedInEmpNumber());
				} else {
					status = assicoateDAO.insertVisaDetails(connection, currAssociateDetails.getEmpNumber(), currAssociateDetails.getVisaDetails(),
							updateAssociateRequest.getLoggedInEmpNumber());
				}
			}

			if (status && null != currAssociateDetails.getDeskDetails()
					&& (0 != currAssociateDetails.getLocationCd() || !currAssociateDetails.getDeskDetails().isEmpty())) {
				if (null != assicoateDAO.retrieveDeskDetails(connection, currAssociateDetails.getEmpNumber())) {
					status = assicoateDAO.updateDeskDetails(connection, currAssociateDetails.getEmpNumber(), currAssociateDetails.getLocationCd(),
							currAssociateDetails.getDeskDetails(), updateAssociateRequest.getLoggedInEmpNumber());
				} else {
					status = assicoateDAO.insertDeskDetails(connection, currAssociateDetails.getEmpNumber(), currAssociateDetails.getLocationCd(),
							currAssociateDetails.getDeskDetails(), updateAssociateRequest.getLoggedInEmpNumber());
				}
			}

			
			
			
			

			
			boolean ischanged = oldAssociateDetails.checkForKeyChanges(currAssociateDetails);
			
			if(ischanged)
			{
				//update the associate history table for old and new records
				boolean updateAndinsertRec = assicoateDAO.checkForSameDayupdateAssociateHistory(connection, currAssociateDetails.getEmpNumber(), updateAssociateRequest.getLoggedInEmpNumber());
				
				if(updateAndinsertRec)
				{
					status = assicoateDAO.updateAssociateHistory(connection, currAssociateDetails, assocHierarchyDTO, updateAssociateRequest.getLoggedInEmpNumber());					
				}
				else
				{
					status = assicoateDAO.updateForSameDayupdateAssociateHistory(connection, currAssociateDetails, assocHierarchyDTO, updateAssociateRequest.getLoggedInEmpNumber());
				}
				

			}
			
			//update auth table with the user details
			status = AuthenticateDAO.getInstance().updateUserDetails(connection, currAssociateDetails);
			
			
			if (status) {
				connection.commit();
				response.setStatus(ApplicationConstants.OK_STATUS);
			} else {
				DAOFactory.rollBackConnection(connection);
				response.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
			}
		} catch (SQLException se) {
			try {
				DAOFactory.rollBackConnection(connection);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			throw new TMSServiceException(se);
		} finally {
			DAOFactory.close(null, null, connection);
		}

		RefreshCache refreshCache = new RefreshCache();
		refreshCache.start();

		return response;
	}
*/
}
