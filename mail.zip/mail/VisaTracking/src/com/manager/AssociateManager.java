package com.manager;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;

import com.dao.AssociateDAO;
import com.dao.EmpVisaDetailsDAO;
import com.dao.util.DAOFactory;
import com.dto.EditDTO;
import com.dto.EditStatusDTO;
import com.dto.ResponseHeaderDTO;
import com.exception.VisaTrackingException;
import com.request.dto.SearchRequest;
import com.request.dto.UndoDeleteRequest;
import com.response.dto.PrepopulateResponse;
import com.response.dto.SearchResponse;
import com.util.ApplicationConstants;

public class AssociateManager {
	private static volatile AssociateManager instance = null;
	

	public static AssociateManager getInstance() {
		if (instance == null) {
			synchronized (AssociateManager.class) {
				if (instance == null) {
					instance = new AssociateManager();
				}
			}
		}
		return instance;
	}

	public SearchResponse searchAssociate(SearchRequest searchRequest)
			throws VisaTrackingException, ParseException {

		SearchResponse searchResponse = new SearchResponse();
		AssociateDAO assicoateDAO = AssociateDAO.getInstance();
		try {
			searchResponse = assicoateDAO.searchAssociate(searchRequest);
		} catch (SQLException se) {
			throw new VisaTrackingException(se);
		}
		return searchResponse;
	}

	public ResponseHeaderDTO update(EditDTO updateAssociateRequest, int loggedInEmpNbr)
			throws VisaTrackingException, ParseException {
		// TODO Auto-generated method stub
		ResponseHeaderDTO response = new ResponseHeaderDTO();
		AssociateDAO assicoateDAO = AssociateDAO.getInstance();
		Connection connection = null;

		try {
			connection = DAOFactory.getConnectionInManualCommitMode();

			boolean status = assicoateDAO.updateVisaTracker(connection,
					updateAssociateRequest,loggedInEmpNbr);
			// visa type is a primary key
			/*boolean isVisa = assicoateDAO.updateVisaType(connection,
					updateAssociateRequest);
			*/
			EditStatusDTO statusDTO=new EditStatusDTO();
			statusDTO.setEmpNbr(updateAssociateRequest.getEmpNbr());
			statusDTO.setNextPendingStatus(updateAssociateRequest.getStatus()+"");
			statusDTO.setVisaTypCd(updateAssociateRequest.getVisaType());
			status = assicoateDAO.updateStatus(connection, statusDTO);

			if (status) {
				connection.commit();
				response.setStatus(ApplicationConstants.OK_STATUS);
			} else {
				DAOFactory.rollBackConnection(connection);
				response.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
			}
		} catch (SQLException se) {
			try {
				DAOFactory.rollBackConnection(connection);
				response.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
			} catch (Exception e) {
				throw new VisaTrackingException(e);
			}
			throw new VisaTrackingException(se);

		} finally {
			DAOFactory.close(null, null, connection);
		}
		return response;

	}

	public ResponseHeaderDTO softDelete (int empNbrs[]) throws VisaTrackingException{
		EmpVisaDetailsDAO empVisaDetailsDAO= EmpVisaDetailsDAO.getInstance();
		Connection connection = null;
		ResponseHeaderDTO response=new ResponseHeaderDTO();
		try{
			connection=DAOFactory.getConnectionInManualCommitMode();
			response=empVisaDetailsDAO.softDeleteEmpVisas(connection, empNbrs);
			if(response.getStatus()==200){
				connection.commit();
			}else{
				DAOFactory.rollBackConnection(connection);
				response.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
			}
		}catch (SQLException se) {
			try {
				DAOFactory.rollBackConnection(connection);
				response.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
			} catch (Exception e) {
				throw new VisaTrackingException(e);
			}
			throw new VisaTrackingException(se);

		} finally {
			DAOFactory.close(null, null, connection);
		}
		return response;
	}
	public ResponseHeaderDTO updateStatus(EditStatusDTO updateAssociateRequest)
			throws VisaTrackingException {
		// TODO Auto-generated method stub
		ResponseHeaderDTO response = new ResponseHeaderDTO();
		AssociateDAO assicoateDAO = AssociateDAO.getInstance();
		Connection connection = null;

		try {
			connection = DAOFactory.getConnectionInManualCommitMode();

			boolean isStatus = assicoateDAO.updateStatus(connection,
					updateAssociateRequest);

			// boolean isProjectType=assicoateDAO.updateProjectType(connection,
			// updateAssociateRequest);
			if (isStatus) {
				connection.commit();
				response.setStatus(ApplicationConstants.OK_STATUS);
			} else {
				DAOFactory.rollBackConnection(connection);
				response.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
			}
		} catch (SQLException se) {
			try {
				DAOFactory.rollBackConnection(connection);
				response.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
			} catch (Exception e) {
				throw new VisaTrackingException(e);
			}
			throw new VisaTrackingException(se);

		} finally {
			DAOFactory.close(null, null, connection);
		}
		return response;

	}
	public PrepopulateResponse prepopulate(int empNbr) throws VisaTrackingException {
		PrepopulateResponse prepopulateResponse = new PrepopulateResponse();
		AssociateDAO assicoateDAO = AssociateDAO.getInstance();
		try {
			prepopulateResponse = assicoateDAO.prepopulate(empNbr);
		} catch (SQLException se) {
			throw new VisaTrackingException(se);
		}
		
	
		return prepopulateResponse;
	}
	public ResponseHeaderDTO undoDelete(UndoDeleteRequest undo) throws VisaTrackingException {
		ResponseHeaderDTO response = new ResponseHeaderDTO();
		AssociateDAO assicoateDAO = AssociateDAO.getInstance();
		Connection connection = null;
		try {
			connection = DAOFactory.getConnectionInManualCommitMode();

			boolean isStatus = assicoateDAO.undoDelete(connection,
					undo);
			if (isStatus) {
				connection.commit();
				response.setStatus(ApplicationConstants.OK_STATUS);
			} else {
				DAOFactory.rollBackConnection(connection);
				response.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
			}
		} catch (SQLException se) {
			try {
				DAOFactory.rollBackConnection(connection);
				response.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
			} catch (Exception e) {
				throw new VisaTrackingException(e);
			}
			throw new VisaTrackingException(se);

		} finally {
			DAOFactory.close(null, null, connection);
		}

		return response;
	}


}
