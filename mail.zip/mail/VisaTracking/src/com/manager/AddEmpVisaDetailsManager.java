package com.manager;

import java.sql.Connection;
import java.sql.SQLException;

import com.dao.EmpVisaDetailsDAO;
import com.dao.VisaWorkflowDAO;
import com.dao.util.DAOFactory;
import com.dto.EmpVisaDTO;
import com.dto.ResponseHeaderDTO;
import com.dto.WorkflowDTO;
import com.exception.VisaTrackingServiceException;
import com.google.gson.Gson;
import com.response.dto.AddEmpVisaResponse;
import com.util.GsonConverter;
import com.util.RefreshCache;

public class AddEmpVisaDetailsManager {
	
	private static volatile AddEmpVisaDetailsManager instance = null;

	public static AddEmpVisaDetailsManager getInstance() {
		if (instance == null) {
			synchronized (AddEmpVisaDetailsManager.class) {
				if (instance == null) {
					instance = new AddEmpVisaDetailsManager();
				}
			}
		}
		return instance;
	}
	
	public String addEmpVisaDetails(int loggedInEmp, EmpVisaDTO empVisaDTO) throws VisaTrackingServiceException{
		Connection connection = null;
		EmpVisaDetailsDAO visaDetailsDAO = EmpVisaDetailsDAO.getInstance();
		AddEmpVisaResponse empVisaResponse= null;
		try{
			connection = DAOFactory.getConnectionInManualCommitMode();
			//business wise
			empVisaResponse= visaDetailsDAO.addEmpVisaDetails(connection, empVisaDTO, loggedInEmp);

		}catch (SQLException se) {
			try {
				DAOFactory.rollBackConnection(connection);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new VisaTrackingServiceException(e);
			}
			throw new VisaTrackingServiceException(se);
		} finally {
			DAOFactory.close(null, null, connection);
		}
		RefreshCache refreshCache = new RefreshCache();
		refreshCache.start();
		return GsonConverter.toJson(empVisaResponse);
	}
}
