package com.manager;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import org.apache.log4j.Logger;

import com.dao.CacheDAO;
import com.dao.util.DAOFactory;
import com.dto.CacheDTO;
import com.dto.TypeDTO;
import com.exception.VisaTrackingServiceException;
import com.util.ApplicationConstants;
import com.util.LoggerUtil;

/**
 * Caching resource.
 * 
 * @author TCS
 */
public final class CacheManager {
	private static final Logger LOGGER = Logger.getLogger(CacheManager.class);

	private static Date refreshedTime;

	private static long twentyFourHoursInMilliSecs = ApplicationConstants.NUM_TWENTY_FOUR_HRS_IN_MILLISEC;

	private static CacheDTO cache;

	private static CacheManager cacheService = null;

	private static final String CLASS_NAME = "CacheManager";

	/**
	 * Private Constructor to avoid instantiating the class as all the methods in class are static.
	 */
	private CacheManager() {
	}

	/**
	 * This method returns the instance of CacheManager class.
	 * 
	 * @return
	 * @throws VisaTrackingServiceException
	 */
	public static synchronized CacheManager getInsatance() throws VisaTrackingServiceException {
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getInsatance", null);

		if (cacheService == null) {
			// The singleton has not been initialized yet, enter a synchronized block
			LoggerUtil.info(LOGGER, "Singleton instance has not been initialized, entering synchronized block");
			// Creating new instance.
			cacheService = new CacheManager();
		}

		// Checking for cache refreshed time and setting the cache.
		if (null == refreshedTime || checkFor24Hours(refreshedTime)) {
			if (null == cache) {
				cache = new CacheDTO();
			}
			setCache();
		}

		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getInsatance");

		return cacheService;
	}

	/**
	 * This method checks if current time is greater than cache refreshed time.
	 * 
	 * @param refreshedTime
	 * 
	 * @return
	 */
	private static boolean checkFor24Hours(Date refreshedTime) {
		Date currTime = new Date(System.currentTimeMillis());

		Date refreshedTimePlus24Hours = new Date(refreshedTime.getTime() + twentyFourHoursInMilliSecs);

		return (currTime.compareTo(refreshedTimePlus24Hours) > 1);
	}

	/**
	 * This method resets the cache and loads all values from DB again.
	 * 
	 * @throws VisaTrackingServiceException
	 */
	private static void setCache() throws VisaTrackingServiceException {
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "setAssociateCache", null);

		Connection connection = null;

		try {
			connection = DAOFactory.getConnection();

			CacheDAO.updateAllocationData();

			cache.setPorfolioList(CacheDAO.retrievePortfolios(connection));
			cache.setTechnologyList(CacheDAO.retrieveTechnologies(connection));
			cache.setContractTypList(CacheDAO.retrieveContractTypes(connection));
			cache.setLocationList(CacheDAO.retrieveLocations(connection));
			cache.setVisaTypeList(CacheDAO.retrieveVisaTypes(connection));
			cache.setVisaStatusList(CacheDAO.retrieveVisaStatuses(connection));
			cache.setRoleList(CacheDAO.retrieveRoles(connection));
			cache.setSecRoleList(CacheDAO.retrieveSecRoles(connection));
			cache.setDesignationList(CacheDAO.retrieveDesignations(connection));
			cache.setProjectManagerList(CacheDAO.retrieveProjectManagers(connection));
			cache.setDeliveryManagerList(CacheDAO.retrieveDeliveryManagers(connection));
			cache.setGroupLeadList(CacheDAO.retrieveGroupLeads(connection));
			cache.setProjectList(CacheDAO.retrieveProjects(connection));
			cache.setProjectLeadList(CacheDAO.retrieveProjectLeads(connection));
			cache.setThdManagerList(CacheDAO.retrieveThdManagers(connection));
			cache.setThdSrManagerList(CacheDAO.retrieveThdSrManagers(connection));
			cache.setThdDirectorList(CacheDAO.retrieveThdDirectors(connection));
			cache.setThdSrDirectorList(CacheDAO.retrieveThdSrDirectors(connection));
			cache.setThdVPList(CacheDAO.retrieveThdVPs(connection));
			cache.setThdSrVPList(CacheDAO.retrieveThdSrVPs(connection));
			cache.setServiceLineDescList(CacheDAO.retrieveServiceLineDesc(connection));
			cache.setWoStatusList(CacheDAO.retrieveWOStatuses(connection));
			cache.setFiscalList(CacheDAO.retrieveThdFiscalDetails(connection));
			cache.setTechLvlList(CacheDAO.retrieveTechLvlList(connection));

			// Setting refreshed time as current time.
			refreshedTime = new Date(System.currentTimeMillis());
		} catch (SQLException se) {
			throw new VisaTrackingServiceException(se);
		} finally {
			DAOFactory.close(null, null, connection);
		}

		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "setAssociateCache");
	}

	/**
	 * @return the cache
	 */
	public CacheDTO getCache() throws VisaTrackingServiceException {
		return cache;
	}
	
	
	public boolean isAdditionFeatureAllowed(int portfolioCd) throws VisaTrackingServiceException {
		boolean allowed = false;
		
		for(TypeDTO type :cache.getPorfolioList())
		{
			if(type.getCd() == portfolioCd)
			{
				if(type.getAdditionalFunction().equalsIgnoreCase("Y"))
				{
					allowed = true;
				}
			}
		}
		
		return allowed;
	}
	
	/**
	 * @return the cache
	 */
	public boolean refreshCache() throws VisaTrackingServiceException {

		setCache();
		
		return true;
	}

}
