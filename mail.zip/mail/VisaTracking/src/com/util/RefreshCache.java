package com.util;

import java.sql.Connection;
import java.sql.SQLException;

import com.dao.CacheDAO;
import com.dao.util.DAOFactory;
import com.exception.VisaTrackingServiceException;
import com.manager.CacheManager;

public class RefreshCache extends Thread {

	public void run() {
		Connection connection = null;

		try {
			CacheManager cacheManager = CacheManager.getInsatance();

			connection = DAOFactory.getConnection();
			cacheManager.getCache().setProjectManagerList(CacheDAO.retrieveProjectManagers(connection));
			cacheManager.getCache().setDeliveryManagerList(CacheDAO.retrieveDeliveryManagers(connection));
			cacheManager.getCache().setGroupLeadList(CacheDAO.retrieveGroupLeads(connection));
			cacheManager.getCache().setProjectList(CacheDAO.retrieveProjects(connection));
			cacheManager.getCache().setProjectLeadList(CacheDAO.retrieveProjectLeads(connection));
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (VisaTrackingServiceException e) {
			e.printStackTrace();
		} finally {
			DAOFactory.close(null, null, connection);
		}
	}
}
