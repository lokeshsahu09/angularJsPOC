/**
 * This program is proprietary to The Home Depot and is not to be reproduced,
 * used, or disclosed without permission of:
 * 
 *    The Home Depot
 *    2455 Paces Ferry Road, NW
 *    Atlanta, GA 30339-4024
 *
 *  FileName : LoggerUtil
 */
package com.util;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;

/**
 * Contains required methods for logging at different levels.
 * 
 * @author TCS
 */
public final class LoggerUtil {

	/**
	 * Private Constructor to avoid instantiating the class as all the methods in class are static.
	 */
	private LoggerUtil() {
	}

	/**
	 * This method can be used to log a message at info level.
	 * 
	 * @param logger
	 * @param message
	 */
	public static void info(Logger logger, String message) {
		logger.info(message);
	}

	/**
	 * This method can be used to log a message at debug level.
	 * 
	 * @param logger
	 * @param message
	 */
	public static void debug(Logger logger, String message) {
		if (logger.isDebugEnabled()) {
			logger.debug(message);
		}
	}

	/**
	 * This method can be used to log a message at warn level.
	 * 
	 * @param logger
	 * @param message
	 * @param cause
	 */
	public static void warn(Logger logger, String message, Throwable cause) {
		logger.warn(message, cause);
	}

	/**
	 * This method can be used to log a message at error level.
	 * 
	 * @param logger
	 * @param message
	 */
	public static void error(Logger logger, String message) {
		logger.error(message);
	}

	/**
	 * This method can be used to log a message along with throwable cause at error level.
	 * 
	 * @param logger
	 * @param message
	 * @param cause
	 */
	public static void error(Logger logger, String message, Throwable cause) {
		logger.error(message, cause);
	}

	/**
	 * This method can be used to log a method entry statement at info level.
	 * 
	 * 
	 * @param logger
	 * @param className
	 * @param methodName
	 * @param inputOfMethod
	 */
	public static void methodEntryInfo(Logger logger, String className, String methodName, Object inputOfMethod) {
		if (null != inputOfMethod) {
			logger.info("Entering into " + methodName + "  method of " + className + " with data: " + inputOfMethod.toString());
		} else {
			logger.info("Entering into " + methodName + "  method of " + className);
		}
	}

	/**
	 * This method can be used to log a method exit statement at info level.
	 * 
	 * @param logger
	 * @param className
	 * @param methodName
	 */
	public static void methodExitInfo(Logger logger, String className, String methodName) {
		logger.info("Exiting from " + methodName + " method of " + className);
	}

	/**
	 * This method can be used for preparing a HashMap than can be used for Orange logging.
	 * 
	 * @param orderNo
	 * @param className
	 * @param methodName
	 * @param componentStep
	 * @param status
	 * @param statusDesc
	 * @param additionalInfo
	 * 
	 * @return
	 */
	public static Map<String, String> getOrangeLogMap(String orderNo, String className, String methodName, String componentStep, String status,
			String statusDesc, String additionalInfo) {

		Map<String, String> keyValue = new HashMap<String, String>();
		keyValue.put("LOG_DT", new Date(System.currentTimeMillis()).toString());
		keyValue.put("LOG_ID", UUID.randomUUID().toString());
		keyValue.put("APP_NAME", "ICONX");
		keyValue.put("COMP_NAME", className + "." + methodName);
		keyValue.put("COMP_STEP", componentStep);
		keyValue.put("STATUS", status);
		keyValue.put("STATUS_DESC", statusDesc);
		keyValue.put("ORDER_NBR", orderNo);
		if (null != additionalInfo && additionalInfo.trim().length() != 0) {
			keyValue.put("ADDITIONAL_INFO", additionalInfo);
		}
		return keyValue;
	}

	/**
	 * This method can be used for preparing a HashMap than can be used for Orange logging.
	 * 
	 * @param orderNo
	 * @param className
	 * @param methodName
	 * @param additionalInfo
	 * 
	 * @return
	 */
	public static Map<String, String> getOrangeLogMapForException(String input, String className, String methodName, String additionalInfo) {

		Map<String, String> keyValue = new HashMap<String, String>();
		keyValue.put("LOG_DT", new Date(System.currentTimeMillis()).toString());
		keyValue.put("LOG_ID", UUID.randomUUID().toString());
		keyValue.put("APP_NAME", "ICONX");
		keyValue.put("COMP_NAME", className + "." + methodName);
		keyValue.put("INPUT", input);
		if (null != additionalInfo && additionalInfo.trim().length() != 0) {
			keyValue.put("ADDITIONAL_INFO", additionalInfo);
		}
		return keyValue;
	}

	/**
	 * This method can be used to log time taken to execute the query.
	 * 
	 * @param logger
	 * @param startTime
	 * @param endTime
	 */
	public static void logTime(Logger logger, Timestamp startTime, Timestamp endTime) {
		debug(logger, "Total time taken for execution of query: " + (endTime.getTime() - startTime.getTime()) / ApplicationConstants.NUM_THOUSAND
				+ " secs");
	}

	/**
	 * This method can be used to log time taken to execute the query.
	 * 
	 * @param logger
	 * @param startTime
	 * @param endTime
	 */
	public static void logTotalTimeForResponse(Logger logger, Timestamp startTime, Timestamp endTime) {
		debug(logger, "Total time taken for servce response: " + (endTime.getTime() - startTime.getTime()) / ApplicationConstants.NUM_THOUSAND
				+ " secs");
	}

}
