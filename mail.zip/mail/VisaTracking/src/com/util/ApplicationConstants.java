package com.util;

import java.util.regex.Pattern;

public final class ApplicationConstants {
	public static final String SUCCESS = "SUCCESS";

	public static final String FAILURE = "FALIURE";

	public static final String NEW_LINE = System.getProperty("line.separator");

	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
	
	public static final String UPLOAD_DATE_FORMAT = "MM/dd/yyyy";

	public static final String DATE_WITH_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

	public static final String DEFAULT_TIME_FORMAT = "HH:mm:ss";

	public static final String COMMA_DELIMITER = ", ";
	
	public static final String SPACE_DELIMITER = " ";

	public static final String SINGLE_QUOTE = "'";

	private static final String ONLY_DATE_REGEX = "^[0-9]{4}-(((0[13578]|(10|12))-(0[1-9]|[1-2][0-9]|3[0-1]))|(02-(0[1-9]|[1-2][0-9]))|((0[469]|11)-(0[1-9]|[1-2][0-9]|30)))$";

	private static final String ONLY_NUMBERS_REGEX = "^?\\d+$";

	private static final String NO_SPECIAL_CHARS_REGEX = "^[ ,.a-zA-Z0-9]*$";

	private static final String NUMBERS_COMMA_SPERATED_REGEX = "^[ ,0-9]*$";

	private static final String EMAIL_REGEX = ".+@.+\\.[a-z0-9]+";

	public static final Pattern ONLY_DATE_REGEX_PATTERN = Pattern.compile(ONLY_DATE_REGEX);

	public static final Pattern ONLY_NUMBERS_REGEX_PATTERN = Pattern.compile(ONLY_NUMBERS_REGEX);

	public static final Pattern NO_SPECIAL_CHARS_REGEX_PATTERN = Pattern.compile(NO_SPECIAL_CHARS_REGEX);

	public static final Pattern NUMBERS_COMMA_SPERATED_REGEX_PATTERN = Pattern.compile(NUMBERS_COMMA_SPERATED_REGEX);

	public static final Pattern EMAIL_REGEX_PATTERN = Pattern.compile(EMAIL_REGEX);

	public static final int NUM_THOUSAND = 1000;
	
	public static final int PORTFOLIO_CD_STORES = 1;
	
	public static final int BILLABLE_TYPE_BILLABLE = 1;
	public static final int BILLABLE_TYPE_NONBILLABLE = 2;
	public static final int BILLABLE_TYPE_PARTIAL = 3;
	
	public static final int EMP_ACTIVE = 1;
	
	public static final int EMP_INACTIVE = -1;
	
	
	public static final int EMP_ROLE_TM = 1;
	public static final int EMP_ROLE_ML = 2;
	public static final int EMP_ROLE_PL = 3;
	public static final int EMP_ROLE_PM = 4;
	public static final int EMP_ROLE_DM = 5;
	public static final int EMP_ROLE_GL = 6;
	public static final int EMP_ROLE_NA = 7;
	public static final int EMP_ROLE_PMO = 8;
	
	public static final int OK_STATUS = 200;
	
	public static final int EMP_NOT_IN_ALLOCATION_ERROR_STATUS = 299;

	public static final int VALIDATION_ERROR_STATUS = 400;

	public static final int INTERNAL_SERVER_ERROR_STATUS = 500;

	public static final long NUM_TWENTY_FOUR_HRS_IN_MILLISEC = 86400000;

	public static final String APPL_ERROR = "Application encountered fatal error.";

	public static final String APPL_RETRY_ERROR = "Application encountered fatal error. Please retry after some time.";

	public static final String ROLL_BACK_ERROR = "Error while rolling back after a failure in middle of the flow. ";
	
	public static final String MESSAGE_0 = "0`Yet to Submit`next-Submit";
	public static final String MESSAGE_1 = "1`Submitted`next-Approval Pending";
	public static final String MESSAGE_2 = "2`Approved`next-Petition In Progress";
	public static final String MESSAGE_3 = "3`Petition Done`next-PA Pending";
	public static final String MESSAGE_4 = "4`PA Done`next-Visa Stamping Pending";
	public static final String MESSAGE_5 = "5`Visa Stamped`next-Ready To Go";
	
	public static final int firstTransId=1234;

	public static final String EMPTY_DATA = "NO INPUT MATCHED";
	
	public static final String APPENDING_AND=" AND";
	public static final String DATE_FORMAT_SQL="E MMM dd HH:mm:ss Z yyyy";
	
	public static final String FOLDER_PATH = "C:\\Users\\664133\\Desktop\\Export\\";

	public static final String[] titles = { "Emp No", "Emp Name",
		 "Visa Type", "Project Type", "Travel Period",
			"Travel To", "New / Replacement", "Business Case",
			"Start Date of Requirement", "Billing Rate @ onsite",
			"Skillset & Role", 
			"Potential Loss if not fulfilled", "Portfolio" };

}
