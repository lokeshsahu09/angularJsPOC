package com.util;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.exception.VisaTrackingServiceException;
import com.manager.CacheManager;

public class CacheScheduler implements ServletContextListener, Runnable  {

	private ScheduledExecutorService scheduler;

    @Override
    public void contextInitialized(ServletContextEvent event) {
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(new CacheScheduler(), 0, 4, TimeUnit.HOURS);
    }

    @Override
    public void contextDestroyed(ServletContextEvent event) {
        scheduler.shutdownNow();
    }


    @Override
    public void run() {
         
    	System.out.println("Refershing cache from scheduler");
         try {
			CacheManager.getInsatance().refreshCache();
		} catch (VisaTrackingServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error while refreshing cache... ");
			
		} 
    }

	
}
