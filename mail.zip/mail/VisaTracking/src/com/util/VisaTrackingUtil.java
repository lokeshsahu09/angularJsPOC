/**
 * This program is proprietary to The Home Depot and is not to be reproduced,
 * used, or disclosed without permission of:
 * 
 *    The Home Depot
 *    2455 Paces Ferry Road, NW
 *    Atlanta, GA 30339-4024
 *
 *  FileName : IConXUtil
 */
package com.util;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

import com.dto.ResponseHeaderDTO;
import com.exception.VisaTrackingException;
import com.exception.VisaTrackingServiceException;

/**
 * This class contains following utility methods which can be accessed in a static way: - semptyString - trimString
 * 
 * @author TCS
 */
public final class VisaTrackingUtil {

	/**
	 * Private Constructor to avoid instantiating the class as all the methods in class are static.
	 */
	private VisaTrackingUtil() {
	}

	/**
	 * This method can be used to check if a String is null or empty.
	 * 
	 * @param input
	 * 
	 * @return
	 */
	public static boolean isemptyString(String input) {
		return (input == null || trimString(input).length() == 0) ? true : false;
	}

	/**
	 * This method can be used to check if a String is null or empty.
	 * 
	 * @param input
	 * 
	 * @return
	 */
	public static boolean isNotEmptyString(String input) {
		return (input == null || trimString(input).length() == 0) ? false : true;
	}

	/**
	 * This method can be used to trim white spaces in a String. Returns null if input is null.
	 * 
	 * @param input
	 * 
	 * @return
	 */
	public static String trimString(String input) {
		if (input != null) {
			return input.trim();
		}
		else
		{
			input = "";
		}
		return input;
	}

	/**
	 * This method returns a String with _dev attached to the error code. This is used to retrieve developer message.
	 * 
	 * @param errorCode
	 * 
	 * @return
	 */
	public static String getDevCode(int errorCode) {
		return Integer.toString(errorCode) + "_dev";
	}

	/**
	 * This method returns a new Date object if input is not null.
	 * 
	 * @param date
	 * 
	 * @return
	 */
	public static Date copyDate(Date date) {
		return date == null ? null : new Date(date.getTime());
	}

	/**
	 * This method can be used to get non null value from mixture of null and non null Timestamp values.
	 * 
	 * @param values
	 * 
	 * @return
	 */
	public static Date getNonNullDate(Timestamp... values) {
		for (int i = 0; i < values.length; i++) {
			if (null != values[i]) {
				return new Date(values[i].getTime());
			}
		}

		return null;
	}

	/**
	 * This method can be used to get String value of date.
	 * 
	 * @param values
	 * 
	 * @return
	 */
	public static String getDateStr(Date date) {
		if (null != date) {
			DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DEFAULT_DATE_FORMAT);
			sdFormat.setLenient(false);

			return sdFormat.format(date.getTime());
		}

		return null;
	}

	/**
	 * This method can be used to get String value of time.
	 * 
	 * @param values
	 * 
	 * @return
	 */
	public static String getTimeStr(Time time) {
		if (null != time) {
			DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DEFAULT_TIME_FORMAT);
			sdFormat.setLenient(false);

			return sdFormat.format(time.getTime());
		}

		return null;
	}

	/**
	 * This method can be used to get String time value of date.
	 * 
	 * @param values
	 * 
	 * @return
	 */
	public static String getTimeStr(Date date) {
		if (null != date) {
			DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DEFAULT_TIME_FORMAT);
			sdFormat.setLenient(false);

			return sdFormat.format(date.getTime());
		}

		return null;
	}

	/**
	 * This method can be used to get String value of date along with time.
	 * 
	 * @param values
	 * 
	 * @return
	 */
	public static String getDateStrWithTime(Date date) {
		if (null != date) {
			DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DATE_WITH_TIME_FORMAT);
			sdFormat.setLenient(false);

			return sdFormat.format(date.getTime());
		}

		return null;
	}

	/**
	 * This methods returns today's date with time set to 0.
	 * 
	 * @return
	 * 
	 * @throws ParseException
	 */
	public static Date getTodaysDate() throws ParseException {
		Calendar calendar = new GregorianCalendar();
		DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DEFAULT_DATE_FORMAT);
		sdFormat.setLenient(false);

		Date returnDate = sdFormat.parse(sdFormat.format(calendar.getTime()));

		return returnDate;
	}

	/**
	 * This method returns current Timestamp.
	 * 
	 * @return
	 */
	public static Timestamp getCurrentTimestamp() {
		return new Timestamp(System.currentTimeMillis());
	}

	/**
	 * This methods returns date from string with format yyyy-MM-dd.
	 * 
	 * @return
	 * 
	 * @throws ParseException
	 */
	public static Date getDateFromString(String dateStr) throws ParseException {
		DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DEFAULT_DATE_FORMAT);
		sdFormat.setLenient(false);

		Date returnDate = sdFormat.parse(dateStr);

		return returnDate;
	}
	
	public static java.sql.Date getDateFrmDataUpload(String dateStr) throws ParseException {
		java.sql.Date dt = null;
		
		if(dateStr != null && dateStr.length() > 0)
		{
			DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.UPLOAD_DATE_FORMAT);
			sdFormat.setLenient(false);

			Date returnDate = sdFormat.parse(dateStr);
			
			 new java.sql.Date(returnDate.getTime());
			
		}

		return dt;
	}

	/**
	 * This methods returns date from string with format yyyy-MM-dd.
	 * 
	 * @return
	 * 
	 * @throws ParseException
	 */
	public static Date getDateFromStringTime(String dateStr) throws ParseException {
		DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DATE_WITH_TIME_FORMAT);
		sdFormat.setLenient(false);
 
		Date returnDate = sdFormat.parse(dateStr);

		return returnDate;
	}

	/**
	 * This methods returns date from string with format yyyy-MM-dd.
	 * 
	 * @return
	 * 
	 * @throws ParseException
	 */
	public static java.sql.Date getSQLDateFromString(String dateStr) throws ParseException {
		DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DEFAULT_DATE_FORMAT);
		sdFormat.setLenient(false);

		java.sql.Date returnDate = new java.sql.Date(sdFormat.parse(dateStr).getTime());

		return returnDate;
	}

	/**
	 * This methods pads input String with given String.
	 * 
	 * @param inputStr
	 *            Input String
	 * @param padStr
	 *            Pad String
	 * @return returnStr Result String
	 */
	public static String padString(String inputStr, String padStr) {
		String returnStr = inputStr;

		if (VisaTrackingUtil.isNotEmptyString(inputStr) && VisaTrackingUtil.isNotEmptyString(padStr)) {
			returnStr = padStr.substring(0, padStr.length() - returnStr.length()) + VisaTrackingUtil.trimString(inputStr);
		}

		return returnStr;
	}

	/**
	 * This method converts ByteArrayOutputStream to String.
	 * 
	 * @param input
	 * 
	 * @return
	 * 
	 * @throws VisaTrackingServiceException
	 */
	public static String convertToStringWithEncoding(ByteArrayOutputStream input) throws VisaTrackingServiceException {
		try {
			return input.toString("UTF-8");
		} catch (UnsupportedEncodingException uee) {
			throw new VisaTrackingServiceException(uee);
		}
	}

	/**
	 * This method prepares response header.
	 * 
	 * @param responseHeaderDTO
	 * @param e
	 * 
	 * @return
	 */
	public static ResponseHeaderDTO prepareErrorResponseHeader(ResponseHeaderDTO responseHeaderDTO, VisaTrackingException e) {
		ResponseHeaderDTO responseHeader = null;
		if (null == responseHeaderDTO) {
			responseHeader = new ResponseHeaderDTO();
		} else {
			responseHeader = responseHeaderDTO;
		}

		//response.setStatus(ApplicationConstants.VALIDATION_ERROR_STATUS);
		responseHeader.setStatus(e.getError().getStatus());
		//responseHeader.setCode(e.getError().getCode());
		responseHeader.setMessage(e.getError().getMessage());
		//if(VisaTrackingUtil.isNotEmptyString(e.getError().getDeveloperMessage()) 
				//&& e.getError().getDeveloperMessage().contains("Duplicate") && e.getError().getDeveloperMessage().contains("PRIMARY")){
			responseHeader.setMessage("Duplicate record. Associate already present, check in deleted record");
		//}
		//responseHeader.setDeveloperMessage(e.getError().getDeveloperMessage());

		return responseHeader;
	}

	/**
	 * This method concatenates first name and last name.
	 * 
	 * @param responseHeaderDTO
	 * @param e
	 * 
	 * @return
	 */
	public static String getName(String firstName, String lastName) {
		StringBuilder sb = new StringBuilder(firstName);
		sb.append(ApplicationConstants.SPACE_DELIMITER);
		if(lastName != null && !"".equalsIgnoreCase(lastName))
		{
			sb.append(lastName);			
		}


		return sb.toString();
	}
	
	public static String getFullName(Map<String, String> supervisorMap,
			String ldapId) {
		String fullName = "";
				
		if(supervisorMap != null && !supervisorMap.isEmpty())
		{
			fullName = (String)supervisorMap.get(ldapId);
			
			if(fullName == null)
			{
				fullName="";
			}
		}
		
		return fullName;
		
	}
	
	public static String getBillableName(int billableType) {
		String billableStr = "";
		if(billableType == ApplicationConstants.BILLABLE_TYPE_BILLABLE)
		{
			billableStr = "Billable";
		}
		else if(billableType == ApplicationConstants.BILLABLE_TYPE_NONBILLABLE)
		{
			billableStr = "Non-Billable";
		}
		else if(billableType == ApplicationConstants.BILLABLE_TYPE_PARTIAL)
		{
			billableStr = "Partial";
		}

	
		return billableStr;
		
	}
}
