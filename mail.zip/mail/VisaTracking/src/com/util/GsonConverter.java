package com.util;

import com.exception.VisaTrackingServiceException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import java.lang.reflect.Type;
import java.util.Map;
import com.google.gson.reflect.TypeToken;

public class GsonConverter {
	static Gson gson;

	private static Gson getGson() {
		return gson == null ? new GsonBuilder().setDateFormat("yyyy-MM-dd").create() : gson;
	}

	public static String toJson(Object inputClass) {
		return getGson().toJson(inputClass);
	}

	public static Object fromJson(String jsonInput, Class<?> classType) throws VisaTrackingServiceException {
		Object object = null;
		try {
			object = getGson().fromJson(jsonInput, classType);
		} catch (JsonSyntaxException jse) {
			throw new VisaTrackingServiceException(jse);
		}

		return object;
	}
	
	public static String getValuefromSingleLengthJson(String json, String key){
		Type mapType = new TypeToken<Map<String, String>>() {}.getType();
	    Map<String, String> map = getGson().fromJson(json, mapType);
	    return map.get(key);
	}

}
