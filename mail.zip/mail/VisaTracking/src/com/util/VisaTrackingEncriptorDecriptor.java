package com.util;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.apache.log4j.Logger;

import com.sun.mail.util.BASE64DecoderStream;
import com.sun.mail.util.BASE64EncoderStream;

public class VisaTrackingEncriptorDecriptor {

	private static Cipher ecipher;
	private static Cipher dcipher;
	private static SecretKeySpec speckey;
	/** Singleton instance */
	private static volatile VisaTrackingEncriptorDecriptor encriptorDecriptor;
	/** Object used to synchronize constructor */
	private static final Object dSemaphore = new Object();
	// Logger instance
	private static final Logger logger = Logger.getLogger(VisaTrackingEncriptorDecriptor.class);

	private VisaTrackingEncriptorDecriptor() throws NoSuchProviderException {

		try {

			// generate secret key using DES algorithm

			//String newKey = "george12george12";
			String newKey =   "TMSSystemByStrss";
			// key = (SecretKey) KeyPairGenerator.getInstance("DES" ,
			// newKey);//.getInstance(newKey);
			speckey = new SecretKeySpec(newKey.getBytes(), "AES");
			ecipher = Cipher.getInstance("AES");
			dcipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			// initialize the ciphers with the given key
			ecipher.init(Cipher.ENCRYPT_MODE, speckey);
			dcipher.init(Cipher.DECRYPT_MODE, speckey);

			// String encrypted =
			// encrypt("MP_QueryString=orderNbr_225941ZZZstrNbr_6986ZZZflag_IandMZZZinstallLine_1ZZZpgmCd_3ZZZemailUrl_MYITESTING11@GMAIL.COM");
			// System.out.println("encrypted" + encrypted);
			// String decrypted = decrypt(encrypted);
			// System.out.println("Decrypted: " + decrypted);

		} catch (NoSuchAlgorithmException e) {
			logger.error("No Such Algorithm:" + e.getMessage());
			return;
		} catch (NoSuchPaddingException e) {
			logger.error("No Such Padding:" + e.getMessage());
			return;
		} catch (InvalidKeyException e) {
			logger.error("Invalid Key:" + e.getMessage());
			return;
		}

	}

	/**
	 * This method gets the instance of VisaTrackingEncriptorDecriptor class Returns singleton manager
	 * 
	 * @return VisaTrackingEncriptorDecriptor
	 * @throws NoSuchProviderException
	 */
	public static VisaTrackingEncriptorDecriptor getInstance() throws NoSuchProviderException {
		logger.debug("Getting VisaTrackingEncriptorDecriptor singleton instance");
		if (encriptorDecriptor == null) {
			logger.debug("VisaTrackingEncriptorDecriptor singleton instance has not been synchronized yet, entering synchronized block");
			synchronized (dSemaphore) {
				logger.debug("In synchronized block, performing check to see if singleton has been initialized");
				if (encriptorDecriptor == null) {
					logger.debug("Initializing singleton");
					encriptorDecriptor = new VisaTrackingEncriptorDecriptor();
					logger.debug("VisaTrackingEncriptorDecriptor singleton initialized successfully");
				}
			}
		}
		return encriptorDecriptor;
	}
	
	public static void main(String[] args) throws NoSuchProviderException
	{
		VisaTrackingEncriptorDecriptor encrypt = new VisaTrackingEncriptorDecriptor();
		System.out.println(encrypt.encrypt("tcs"));
		
		
	}

	public String encrypt(String str) {

		try {

			// encode the string into a sequence of bytes using the named
			// charset

			// storing the result into a new byte array.

			byte[] utf8 = str.getBytes("UTF8");

			byte[] enc = ecipher.doFinal(utf8);

			// encode to base64

			enc = BASE64EncoderStream.encode(enc);

			return new String(enc);

		}

		catch (Exception e) {

			logger.error("Exception Occured while Encryption" + e.getMessage());

		}

		return null;

	}

	public String decrypt(String str) {

		try {

			// decode with base64 to get bytes

			byte[] dec = BASE64DecoderStream.decode(str.getBytes());

			byte[] utf8 = dcipher.doFinal(dec);

			// create new string based on the specified charset

			return new String(utf8, "UTF8");

		}

		catch (Exception e) {

			logger.error("Exception Occured while Decryption" + e.getMessage());

		}

		return null;

	}

	public static byte[] fromHexString(String s) {
		int len = s.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
		}
		return data;
	}

}
