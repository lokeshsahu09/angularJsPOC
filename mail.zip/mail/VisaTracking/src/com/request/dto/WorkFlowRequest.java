package com.request.dto;

import com.dto.WorkflowDTO;

public class WorkFlowRequest {
	private WorkflowDTO workflowDTO;
	
	private int loggedInEmpNumber;

	/**
	 * @return the loggedInEmpNumber
	 */
	public int getLoggedInEmpNumber() {
		return loggedInEmpNumber;
	}

	/**
	 * @param loggedInEmpNumber
	 *            the loggedInEmpNumber to set
	 */
	public void setLoggedInEmpNumber(int loggedInEmpNumber) {
		this.loggedInEmpNumber = loggedInEmpNumber;
	}

	/**
	 * @return the associateDetails
	 */
	public WorkflowDTO getWorkflowDTO() {
		return workflowDTO;
	}

	/**
	 * @param associateDetails
	 *            the associateDetails to set
	 */
	public void setWorkflowDTO(WorkflowDTO workflowDTO) {
		this.workflowDTO = workflowDTO;
	}
}
