package com.request.dto;

import com.dto.EditDTO;

public class EditEmpVisaRequest {
	private EditDTO associateDetails;
	
	private int loggedInempNbr;

	public EditDTO getAssociateDetails() {
		return associateDetails;
	}

	public void setAssociateDetails(EditDTO associateDetails) {
		this.associateDetails = associateDetails;
	}

	/**
	 * @return the loggedInEmpNumber
	 */
	
	public int getLoggedInempNbr() {
		return loggedInempNbr;
	}

	/**
	 * @param loggedInEmpNumber
	 *            the loggedInEmpNumber to set
	 */
	public void setLoggedInempNbr(int loggedInempNbr) {
		this.loggedInempNbr = loggedInempNbr;
	}

	

	
	
}
