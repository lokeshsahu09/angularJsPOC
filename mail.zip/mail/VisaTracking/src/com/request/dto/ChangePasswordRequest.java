package com.request.dto;

public class ChangePasswordRequest {

	private int empNumber;

	private String password;

	private String newPassword;
	
	private int securityQuestionCd;
	
	private String securityAns;
	

	/**
	 * @return the empNumber
	 */
	public int getEmpNumber() {
		return empNumber;
	}

	/**
	 * @param empNumber
	 *            the empNumber to set
	 */
	public void setEmpNumber(int empNumber) {
		this.empNumber = empNumber;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the newPassword
	 */
	public String getNewPassword() {
		return newPassword;
	}

	/**
	 * @param newPassword
	 *            the newPassword to set
	 */
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public int getSecurityQuestionCd() {
		return securityQuestionCd;
	}

	public void setSecurityQuestionCd(int securityQuestionCd) {
		this.securityQuestionCd = securityQuestionCd;
	}

	public String getSecurityans() {
		return securityAns;
	}

	public void setSecurityans(String securityAns) {
		this.securityAns = securityAns;
	}

}
