package com.request.dto;

import com.dto.EmpVisaDTO;

public class AddEmpVisaRequest {
	private EmpVisaDTO associateDetails;
	
	private int loggedInempNbr;

	public EmpVisaDTO getAssociateDetails() {
		return associateDetails;
	}

	public void setAssociateDetails(EmpVisaDTO associateDetails) {
		this.associateDetails = associateDetails;
	}

	/**
	 * @return the loggedInEmpNumber
	 */
	
	public int getLoggedInempNbr() {
		return loggedInempNbr;
	}

	/**
	 * @param loggedInEmpNumber
	 *            the loggedInEmpNumber to set
	 */
	public void setLoggedInempNbr(int loggedInempNbr) {
		this.loggedInempNbr = loggedInempNbr;
	}

	

	
	
}
