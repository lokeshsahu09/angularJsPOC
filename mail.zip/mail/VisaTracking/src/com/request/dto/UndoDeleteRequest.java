package com.request.dto;

public class UndoDeleteRequest {
	
	private int loggedInempNbr;
	private int emp_nbr;
	private int visaType;
	public int getVisaType() {
		return visaType;
	}
	public void setVisaType(int visaType) {
		this.visaType = visaType;
	}
	public int getLoggedInempNbr() {
		return loggedInempNbr;
	}
	public void setLoggedInempNbr(int loggedInempNbr) {
		this.loggedInempNbr = loggedInempNbr;
	}
	public int getEmp_nbr() {
		return emp_nbr;
	}
	public void setEmp_nbr(int emp_nbr) {
		this.emp_nbr = emp_nbr;
	}
	

}
