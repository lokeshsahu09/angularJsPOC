package com.export;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import com.dto.ResponseHeaderDTO;
import com.dto.VisaTrackerDTO;
import com.exception.VisaTrackingClientException;
import com.exception.VisaTrackingException;
import com.manager.AssociateManager;
import com.request.dto.SearchRequest;
import com.response.dto.SearchResponse;
import com.sun.jmx.snmp.Timestamp;
import com.util.ApplicationConstants;
import com.util.GsonConverter;
import com.util.VisaTrackingUtil;
//import com.test.export.AssociateDetailsDTO;
//import com.response.dto.SearchAssociateResponse;

@Path("/spreadsheet")
public class ExportData {
	

	@GET
	//@Produces("application/vnd.ms-excel")
	@Consumes(MediaType.MULTIPART_FORM_DATA)  
	@Path("/associate")
	public Response generateAssociateSpreadSheet(@QueryParam("data") String data,  @QueryParam("version") @DefaultValue("1") int version)
			throws IOException, VisaTrackingException, ParseException

	{
// for accessing search data here 
		
		SearchResponse response1 = new SearchResponse();
		
		SearchRequest searchRequest = (SearchRequest) GsonConverter	.fromJson(data, SearchRequest.class);

		AssociateManager manager = AssociateManager.getInstance();
		ResponseHeaderDTO header = new ResponseHeaderDTO();
		response1= manager.searchAssociate(searchRequest);
		
		Calendar calendar = Calendar.getInstance();
		
		List<VisaTrackerDTO> associateDataBean1=response1.getVisaTracerList();
		
		
		
		 ServletOutputStream fileOut = null;
		
		
		File file = null;
		FileOutputStream out = null;
	    Workbook wb = null;
		 StreamingOutput stream = null;
		FileInputStream fileInputStream = null;
		
	
	    
	    wb = new HSSFWorkbook();
	   

		switch (version) {
		case 1:
			if (VisaTrackingUtil.isNotEmptyString(data)) {
				
				

				 Sheet sheet = wb.createSheet("Associate Details");
				

				Map<String, CellStyle> styles = createStyles(wb);

				

				// turn off gridlines
				sheet.setDisplayGridlines(false);
				sheet.setPrintGridlines(false);
				sheet.setFitToPage(true);
				sheet.setHorizontallyCenter(true);
				PrintSetup printSetup = sheet.getPrintSetup();
				printSetup.setLandscape(true);

				// the following three statements are required only for HSSF
				sheet.setAutobreaks(true);
				printSetup.setFitHeight((short) 1);
				printSetup.setFitWidth((short) 1);

				// the header row: centered text in 48pt font
				Row headerRow = sheet.createRow(0);
				// headerRow.setHeightInPoints(15.75f);

		

			
				for (int i = 0; i < ApplicationConstants.titles.length; i++)

				{
					headerRow.setHeightInPoints(25.75f);
					Cell cell = headerRow.createCell(i);
					cell.setCellValue(ApplicationConstants.titles[i]);
					cell.setCellStyle(styles.get("header"));
				}

				// freeze the first row
				sheet.createFreezePane(0, 1);

				Row row;
				Cell cell;
				int rownum = 1;
				int column = 0;
				VisaTrackerDTO associateDataBean;
				Calendar cal = Calendar.getInstance();
				 for (int i = 0; i < associateDataBean1.size(); i++, rownum++)
				 { 
					 String travelPeriod="";
					 associateDataBean = associateDataBean1.get(i);
				   String empname=associateDataBean.getFirstName()+" "+associateDataBean.getLastName();
					 int travelPerid=associateDataBean.getTravelPeriod();
					 if(travelPerid<=6)
					 {
						 travelPeriod ="Short Term";
					 }
					 else
					 {
						 travelPeriod ="Long Term";
						 
					 }
					 
					
					// String lastname=associateDataBean.getLastName();
					 // empname=empname.concat(lastname);
					 
					row = sheet.createRow(rownum);
					
					cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getEmpNbr());
					cell.setCellStyle(styles.get("cell_b"));
					
					cell = row.createCell(column++);
					cell.setCellValue(empname);
					cell.setCellStyle(styles.get("cell_b"));
					/*cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getLastName());
					cell.setCellStyle(styles.get("cell_b"));*/

					cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getVisaType());
					cell.setCellStyle(styles.get("cell_b"));
					cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getProjectType());
					cell.setCellStyle(styles.get("cell_b"));

					cell = row.createCell(column++);
					cell.setCellValue(travelPeriod);
					cell.setCellStyle(styles.get("cell_b"));
					cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getTravelTo());
					cell.setCellStyle(styles.get("cell_b"));

					cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getInitialStatus());
					cell.setCellStyle(styles.get("cell_b"));
					cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getBusinessCase());
					cell.setCellStyle(styles.get("cell_b"));
// for date
					cell = row.createCell(column++);
					if (null != associateDataBean.getStartDateRequirement()) {
						cal.setTime(associateDataBean.getStartDateRequirement());
						cell.setCellValue(cal);
					} else {
						cell.setCellValue("");
					}
					
					
					//till here
					cell.setCellStyle(styles.get("cell_normal_date"));
					
					cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getBillingRate());
					cell.setCellStyle(styles.get("cell_b"));
					cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getSkillSet());
					cell.setCellStyle(styles.get("cell_b"));
					/*cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getVisaType());
					cell.setCellStyle(styles.get("cell_b"));
					cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getStatus());
					cell.setCellStyle(styles.get("cell_b"));*/
					cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getPotentialLoss());
 					cell.setCellStyle(styles.get("cell_b"));
 					cell = row.createCell(column++);
					cell.setCellValue(associateDataBean.getPortfolio());
					cell.setCellStyle(styles.get("cell_b"));

					column = 0;
					
				}

				
				for (int columnPosition = 0; columnPosition < 30; columnPosition++) {
					sheet.autoSizeColumn((short) (columnPosition));
				}
				
				  
				 
				
			
			//	String url = FolderDeleter.create(FOLDER_PATH);
				java.util.Date date= new java.util.Date();
				
				calendar.setTime(date);

//				file = new File("Associate_Details"+calendar.getTimeInMillis()+".xls");
				file = new File("Visa_Details"+calendar.getTimeInMillis()+".xls");
				out = new FileOutputStream(file);
				out.flush();
				wb.write(out);
				
				out.close();
			}

			 else {
				throw new VisaTrackingClientException("Empty input.");
			}
		}
		
		return Response.ok((Object) file).header("Content-Disposition", "attachment; filename=Visa_Details"+calendar.getTimeInMillis()+".xls").build();
	}

	private static Map<String, CellStyle> createStyles(Workbook wb) {
		Map<String, CellStyle> styles = new HashMap<String, CellStyle>();
		DataFormat df = wb.createDataFormat();

		CellStyle style;
		Font headerFont = wb.createFont();
		headerFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		style.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setFont(headerFont);
		styles.put("header", style);

		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		style.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE
				.getIndex());
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setFont(headerFont);
		style.setDataFormat(df.getFormat("d-mmm"));
		styles.put("header_date", style);

		Font font1 = wb.createFont();
		//font1.setBoldweight(Font.BOLDWEIGHT_BOLD);
		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_LEFT);
		style.setFont(font1);
		styles.put("cell_b", style);

		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		style.setFont(font1);
		styles.put("cell_b_centered", style);

		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_RIGHT);
		style.setFont(font1);
		style.setDataFormat(df.getFormat("d-mmm"));
		styles.put("cell_b_date", style);

		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_RIGHT);
		style.setFont(font1);
		style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setDataFormat(df.getFormat("d-mmm"));
		styles.put("cell_g", style);

		Font font2 = wb.createFont();
		font2.setColor(IndexedColors.BLUE.getIndex());
		//font2.setBoldweight(Font.BOLDWEIGHT_BOLD);
		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_LEFT);
		style.setFont(font2);
		styles.put("cell_bb", style);

		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_RIGHT);
		style.setFont(font1);
		style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setDataFormat(df.getFormat("d-mmm"));
		styles.put("cell_bg", style);

		Font font3 = wb.createFont();
		font3.setFontHeightInPoints((short) 14);
		font3.setColor(IndexedColors.DARK_BLUE.getIndex());
		//font3.setBoldweight(Font.BOLDWEIGHT_BOLD);
		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_LEFT);
		style.setFont(font3);
		style.setWrapText(true);
		styles.put("cell_h", style);

		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_LEFT);
		style.setWrapText(true);
		styles.put("cell_normal", style);

		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		style.setWrapText(true);
		styles.put("cell_normal_centered", style);

		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_RIGHT);
		style.setWrapText(true);
		style.setDataFormat(df.getFormat("d-m-yyyy"));
		styles.put("cell_normal_date", style);

		style = createBorderedStyle(wb);
		style.setAlignment(CellStyle.ALIGN_LEFT);
		style.setIndention((short) 1);
		style.setWrapText(true);
		styles.put("cell_indented", style);

		style = createBorderedStyle(wb);
		style.setFillForegroundColor(IndexedColors.BLUE.getIndex());
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		styles.put("cell_blue", style);

		return styles;
	}

	private static CellStyle createBorderedStyle(Workbook wb) {
		CellStyle style = wb.createCellStyle();
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());
		return style;
	}

}
