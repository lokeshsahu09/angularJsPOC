package com.response.dto;

import com.dto.ResponseHeaderDTO;

public class AddEmpVisaResponse {

	private ResponseHeaderDTO header;

	/**
	 * @return the header
	 */
	public ResponseHeaderDTO getHeader() {
		return header;
	}

	/**
	 * @param header
	 *            the header to set
	 */
	public void setHeader(ResponseHeaderDTO header) {
		this.header = header;
	}
}
