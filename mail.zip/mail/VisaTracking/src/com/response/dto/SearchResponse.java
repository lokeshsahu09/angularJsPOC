package com.response.dto;

import java.util.List;

import com.dto.ResponseHeaderDTO;
import com.dto.VisaTrackerDTO;

public class SearchResponse {
     
	private List<VisaTrackerDTO> visaTracerList;
	
	public List<VisaTrackerDTO> getVisaTracerList() {
		return visaTracerList;
	}

	public void setVisaTracerList(List<VisaTrackerDTO> visaTracerList) {
		this.visaTracerList = visaTracerList;
	}

	public ResponseHeaderDTO getHeader() {
		return header;
	}

	public void setHeader(ResponseHeaderDTO header) {
		this.header = header;
	}

	private ResponseHeaderDTO header;
	
}
