package com.response.dto;

import com.dto.LoggedInUserDetailsDTO;
import com.dto.MasterDetailsDTO;
import com.dto.ResponseHeaderDTO;

public class AuthenticateResponse {

	private ResponseHeaderDTO header;

	private LoggedInUserDetailsDTO userDetails;
	
	private MasterDetailsDTO masterDetails;
	
	/**
	 * @return the masterDetails
	 */
	public MasterDetailsDTO getMasterDetails() {
		return masterDetails;
	}

	/**
	 * @param masterDetails the masterDetails to set
	 */
	public void setMasterDetails(MasterDetailsDTO masterDetails) {
		this.masterDetails = masterDetails;
	}

	/**
	 * @return the header
	 */
	public ResponseHeaderDTO getHeader() {
		return header;
	}

	/**
	 * @param header
	 *            the header to set
	 */
	public void setHeader(ResponseHeaderDTO header) {
		this.header = header;
	}

	/**
	 * @return the userDetails
	 */
	public LoggedInUserDetailsDTO getUserDetails() {
		return userDetails;
	}

	/**
	 * @param userDetails
	 *            the userDetails to set
	 */
	public void setUserDetails(LoggedInUserDetailsDTO userDetails) {
		this.userDetails = userDetails;
	}

}
