package com.response.dto;

import com.dto.ResponseHeaderDTO;

public class PrepopulateResponse {

	private String firstName;
	private ResponseHeaderDTO header;
	private String lastName;
	private String portfolioName;
	
	private int portfolio;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(int portfolio) {
		this.portfolio = portfolio;
	}

	public ResponseHeaderDTO getHeader() {
		return header;
	}

	public void setHeader(ResponseHeaderDTO header) {
		this.header = header;
	}
	public String getPortfolioName() {
		return portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

}
