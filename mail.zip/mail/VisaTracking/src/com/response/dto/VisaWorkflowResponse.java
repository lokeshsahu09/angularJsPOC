package com.response.dto;

import com.dto.ResponseHeaderDTO;
import com.dto.WorkflowDTO;

public class VisaWorkflowResponse {

	private ResponseHeaderDTO header;

	private WorkflowDTO visa_tracker;

	/**
	 * @return the header
	 */
	public ResponseHeaderDTO getHeader() {
		return header;
	}

	/**
	 * @param header
	 *            the header to set
	 */
	public void setHeader(ResponseHeaderDTO header) {
		this.header = header;
	}

	public WorkflowDTO getVisa_tracker() {
		return visa_tracker;
	}

	public void setVisa_tracker(WorkflowDTO visa_tracker) {
		this.visa_tracker = visa_tracker;
	}

	

}
