package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.dao.util.DAOFactory;
import com.dto.AssociateDTO;
import com.dto.THDAssociateDTO;
import com.dto.THDFiscalMonthDTO;
import com.dto.TypeDTO;
import com.exception.VisaTrackingServiceException;

public class CacheDAO {

	private static String RETRIEVE_LOCATIONS = "SELECT LOCATION_CD, LOCATION_DESC FROM LOCATION";

	private static String RETRIEVE_VISA_TYPES = "SELECT VISA_TYP_CD, VISA_TYP_DESC FROM VISA_TYP";

	private static String RETRIEVE_VISA_STATUS = "SELECT VISA_STATS_CD, VISA_STATS_DESC FROM VISA_STATS";

	private static String RETRIEVE_PORTFOLIOS = "SELECT PORTFOLIO_CD, PORTFOLIO_DESC, ADDITIONAL_FUNCTION FROM PORTFOLIO";

	private static String RETRIEVE_ROLES = "SELECT ROLE_CD, ROLE_DESC FROM ROLE";
	
	private static String RETRIEVE_SEC_ROLES = "SELECT ROLE_CD, ROLE_DESC FROM SEC_ROLE";

	private static String RETRIEVE_DESIGNATIONS = "SELECT DESIGNATION_CD, DESIGNATION_DESC FROM DESIGNATION";

	private static String RETRIEVE_PROJECT_MANAGERS = "SELECT EMP_NBR, FIRST_NAME, LAST_NAME, PORTFOLIO_CD FROM ASSOCIATE WHERE ROLE_CD = 4 AND ACTIVE = 1";

	private static String RETRIEVE_DELIVERY_MANAGERS = "SELECT EMP_NBR, FIRST_NAME, LAST_NAME, PORTFOLIO_CD FROM ASSOCIATE WHERE ROLE_CD = 5 AND ACTIVE = 1";

	private static String RETRIEVE_GROUP_LEADS = "SELECT EMP_NBR, FIRST_NAME, LAST_NAME, PORTFOLIO_CD FROM ASSOCIATE WHERE ROLE_CD = 6 AND ACTIVE = 1";

	private static String RETRIEVE_CONTRACT_TYPES = "SELECT CONTRACT_TYP_CD, CONTRACT_TYP_DESC FROM CONTRACT_TYP";

	private static String RETRIEVE_PROJECT_LEADS = "SELECT EMP_NBR, FIRST_NAME, LAST_NAME, PORTFOLIO_CD FROM ASSOCIATE WHERE ROLE_CD = 3 AND ACTIVE = 1";

	private static String RETRIEVE_THD_MANAGERS = "SELECT LDAP_ID, FIRST_NAME, LAST_NAME, PORTFOLIO_CD FROM THD_ASSOCIATE WHERE THD_ROLE_CD = 1";

	private static String RETRIEVE_THD_SR_MANAGERS = "SELECT LDAP_ID, FIRST_NAME, LAST_NAME, PORTFOLIO_CD FROM THD_ASSOCIATE WHERE THD_ROLE_CD = 2";

	private static String RETRIEVE_THD_DIRECTORS = "SELECT LDAP_ID, FIRST_NAME, LAST_NAME, PORTFOLIO_CD FROM THD_ASSOCIATE WHERE THD_ROLE_CD = 3";

	private static String RETRIEVE_THD_SR_DIRECTORS = "SELECT LDAP_ID, FIRST_NAME, LAST_NAME, PORTFOLIO_CD FROM THD_ASSOCIATE WHERE THD_ROLE_CD = 4";

	private static String RETRIEVE_THD_VPS = "SELECT LDAP_ID, FIRST_NAME, LAST_NAME, PORTFOLIO_CD FROM THD_ASSOCIATE WHERE THD_ROLE_CD = 5";

	private static String RETRIEVE_THD_SR_VPS = "SELECT LDAP_ID, FIRST_NAME, LAST_NAME, PORTFOLIO_CD FROM THD_ASSOCIATE WHERE THD_ROLE_CD = 6";

	private static String RETRIEVE_TECHNOLOGIES = "SELECT TECHNOLOGY_TYP_CD, TECHNOLOGY_TYP_DESC FROM TECHNOLOGY";

	private static String RETRIEVE_PROJECTS = "SELECT PROJ_ID, PROJ_NAME, PORTFOLIO_CD FROM PROJECT";

	private static String RETRIEVE_THD_FISCAL_DETAILS = "SELECT START_DT, END_DT, MONTH_ID, MONTH_DESC, YEAR FROM THD_FISCAL_CAL WHERE YEAR = ?";

	private static String RETRIEVE_WO_STATUSES = "SELECT WO_STATUS_CD, WO_STATUS_DESC FROM WO_STATUS";
	
	private static String RETRIEVE_TECH_LVL_LIST = "SELECT TECH_LVL_CD, TECH_LVL_DESC FROM technology_level";
	
	private static String update  = "SELECT TECH_LVL_CD, TECH_LVL_DESC FROM technology_level";
	
	private static final String UPDATE_ASSOCIATE_ALLOCATION_TO_DEFAULT = "UPDATE ASSOCIATE SET ALLOCATED = 'N'";
	
	private static final String UPDATE_ASSOCIATE_CURRENT_ALLOCATION = "update tms_prod.associate set allocated = 'Y' where emp_nbr in (select b.emp_id from sams.current_allocation b)";

	private static String RETRIEVE_SERVICE_LINE_DESC = "SELECT SERVICE_LINE_CD, SERVICE_LINE_DESC FROM SERVICE_LINE";

	public static List<TypeDTO> retrieveLocations(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> locationList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_LOCATIONS);

			rs = preparedStatement.executeQuery();

			TypeDTO locationDetails = null;
			while (rs.next()) {
				locationDetails = new TypeDTO();

				locationDetails.setCd(rs.getInt("LOCATION_CD"));
				locationDetails.setDesc(rs.getString("LOCATION_DESC"));

				locationList.add(locationDetails);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return locationList;
	}

	public static List<TypeDTO> retrieveVisaTypes(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> visaTypeList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_VISA_TYPES);

			rs = preparedStatement.executeQuery();

			TypeDTO visaType = null;
			while (rs.next()) {
				visaType = new TypeDTO();

				visaType.setCd(rs.getInt("VISA_TYP_CD"));
				visaType.setDesc(rs.getString("VISA_TYP_DESC"));

				visaTypeList.add(visaType);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return visaTypeList;
	}

	public static List<TypeDTO> retrieveVisaStatuses(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> visaStatusList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_VISA_STATUS);

			rs = preparedStatement.executeQuery();

			TypeDTO visaStatus = null;
			while (rs.next()) {
				visaStatus = new TypeDTO();

				visaStatus.setCd(rs.getInt("VISA_STATS_CD"));
				visaStatus.setDesc(rs.getString("VISA_STATS_DESC"));

				visaStatusList.add(visaStatus);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return visaStatusList;
	}

	public static List<TypeDTO> retrievePortfolios(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> portfolioList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_PORTFOLIOS);

			rs = preparedStatement.executeQuery();

			TypeDTO portfolio = null;
			while (rs.next()) {
				portfolio = new TypeDTO();

				portfolio.setCd(rs.getInt("PORTFOLIO_CD"));
				portfolio.setDesc(rs.getString("PORTFOLIO_DESC"));
				portfolio.setAdditionalFunction(rs.getString("ADDITIONAL_FUNCTION"));

				portfolioList.add(portfolio);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return portfolioList;
	}

	public static List<TypeDTO> retrieveRoles(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> roleList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_ROLES);

			rs = preparedStatement.executeQuery();

			TypeDTO role = null;
			while (rs.next()) {
				role = new TypeDTO();

				role.setCd(rs.getInt("ROLE_CD"));
				role.setDesc(rs.getString("ROLE_DESC"));

				roleList.add(role);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return roleList;
	}
	
	
	public static List<TypeDTO> retrieveSecRoles(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> roleList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_SEC_ROLES);

			rs = preparedStatement.executeQuery();

			TypeDTO role = null;
			while (rs.next()) {
				role = new TypeDTO();

				role.setCd(rs.getInt("ROLE_CD"));
				role.setDesc(rs.getString("ROLE_DESC"));

				roleList.add(role);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return roleList;
	}

	public static List<TypeDTO> retrieveDesignations(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> designationList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_DESIGNATIONS);

			rs = preparedStatement.executeQuery();

			TypeDTO designation = null;
			while (rs.next()) {
				designation = new TypeDTO();

				designation.setCd(rs.getInt("DESIGNATION_CD"));
				designation.setDesc(rs.getString("DESIGNATION_DESC"));

				designationList.add(designation);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return designationList;
	}

	public static List<AssociateDTO> retrieveProjectManagers(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<AssociateDTO> projectManagerList = new ArrayList<AssociateDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_PROJECT_MANAGERS);

			rs = preparedStatement.executeQuery();

			AssociateDTO associate = null;
			while (rs.next()) {
				associate = new AssociateDTO();

				associate.setEmpNumber(rs.getInt("EMP_NBR"));
				associate.setFirstName(rs.getString("FIRST_NAME"));
				associate.setLastName(rs.getString("LAST_NAME"));
				associate.setPortfolioCd(rs.getInt("PORTFOLIO_CD"));

				projectManagerList.add(associate);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return projectManagerList;
	}

	public static List<AssociateDTO> retrieveDeliveryManagers(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<AssociateDTO> deliveryManagerList = new ArrayList<AssociateDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_DELIVERY_MANAGERS);

			rs = preparedStatement.executeQuery();

			AssociateDTO associate = null;
			while (rs.next()) {
				associate = new AssociateDTO();

				associate.setEmpNumber(rs.getInt("EMP_NBR"));
				associate.setFirstName(rs.getString("FIRST_NAME"));
				associate.setLastName(rs.getString("LAST_NAME"));
				associate.setPortfolioCd(rs.getInt("PORTFOLIO_CD"));

				deliveryManagerList.add(associate);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return deliveryManagerList;
	}

	public static List<AssociateDTO> retrieveGroupLeads(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<AssociateDTO> groupLeadList = new ArrayList<AssociateDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_GROUP_LEADS);

			rs = preparedStatement.executeQuery();

			AssociateDTO associate = null;
			while (rs.next()) {
				associate = new AssociateDTO();

				associate.setEmpNumber(rs.getInt("EMP_NBR"));
				associate.setFirstName(rs.getString("FIRST_NAME"));
				associate.setLastName(rs.getString("LAST_NAME"));
				associate.setPortfolioCd(rs.getInt("PORTFOLIO_CD"));

				groupLeadList.add(associate);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return groupLeadList;
	}

	public static List<TypeDTO> retrieveContractTypes(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> contractTypeList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_CONTRACT_TYPES);

			rs = preparedStatement.executeQuery();

			TypeDTO contractType = null;
			while (rs.next()) {
				contractType = new TypeDTO();

				contractType.setCd(rs.getInt("CONTRACT_TYP_CD"));
				contractType.setDesc(rs.getString("CONTRACT_TYP_DESC"));

				contractTypeList.add(contractType);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return contractTypeList;
	}

	public static List<AssociateDTO> retrieveProjectLeads(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<AssociateDTO> projectLeadList = new ArrayList<AssociateDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_PROJECT_LEADS);

			rs = preparedStatement.executeQuery();

			AssociateDTO associate = null;
			while (rs.next()) {
				associate = new AssociateDTO();

				associate.setEmpNumber(rs.getInt("EMP_NBR"));
				associate.setFirstName(rs.getString("FIRST_NAME"));
				associate.setLastName(rs.getString("LAST_NAME"));
				associate.setPortfolioCd(rs.getInt("PORTFOLIO_CD"));

				projectLeadList.add(associate);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return projectLeadList;
	}

	public static List<THDAssociateDTO> retrieveThdManagers(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<THDAssociateDTO> thdManagerList = new ArrayList<THDAssociateDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_THD_MANAGERS);

			rs = preparedStatement.executeQuery();

			THDAssociateDTO associate = null;
			while (rs.next()) {
				associate = new THDAssociateDTO();

				associate.setLdapId(rs.getString("LDAP_ID"));
				associate.setFirstName(rs.getString("FIRST_NAME"));
				associate.setLastName(rs.getString("LAST_NAME"));
				associate.setPortfolioCd(rs.getInt("PORTFOLIO_CD"));

				thdManagerList.add(associate);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return thdManagerList;
	}

	public static List<THDAssociateDTO> retrieveThdSrManagers(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<THDAssociateDTO> thdSrManagerList = new ArrayList<THDAssociateDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_THD_SR_MANAGERS);

			rs = preparedStatement.executeQuery();

			THDAssociateDTO associate = null;
			while (rs.next()) {
				associate = new THDAssociateDTO();

				associate.setLdapId(rs.getString("LDAP_ID"));
				associate.setFirstName(rs.getString("FIRST_NAME"));
				associate.setLastName(rs.getString("LAST_NAME"));
				associate.setPortfolioCd(rs.getInt("PORTFOLIO_CD"));

				thdSrManagerList.add(associate);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return thdSrManagerList;
	}

	public static List<THDAssociateDTO> retrieveThdDirectors(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<THDAssociateDTO> thdDirectorList = new ArrayList<THDAssociateDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_THD_DIRECTORS);

			rs = preparedStatement.executeQuery();

			THDAssociateDTO associate = null;
			while (rs.next()) {
				associate = new THDAssociateDTO();

				associate.setLdapId(rs.getString("LDAP_ID"));
				associate.setFirstName(rs.getString("FIRST_NAME"));
				associate.setLastName(rs.getString("LAST_NAME"));
				associate.setPortfolioCd(rs.getInt("PORTFOLIO_CD"));

				thdDirectorList.add(associate);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return thdDirectorList;
	}

	public static List<THDAssociateDTO> retrieveThdSrDirectors(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<THDAssociateDTO> thdSrDirectorList = new ArrayList<THDAssociateDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_THD_SR_DIRECTORS);

			rs = preparedStatement.executeQuery();

			THDAssociateDTO associate = null;
			while (rs.next()) {
				associate = new THDAssociateDTO();

				associate.setLdapId(rs.getString("LDAP_ID"));
				associate.setFirstName(rs.getString("FIRST_NAME"));
				associate.setLastName(rs.getString("LAST_NAME"));
				associate.setPortfolioCd(rs.getInt("PORTFOLIO_CD"));

				thdSrDirectorList.add(associate);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return thdSrDirectorList;
	}

	public static List<THDAssociateDTO> retrieveThdVPs(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<THDAssociateDTO> thdVPList = new ArrayList<THDAssociateDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_THD_VPS);

			rs = preparedStatement.executeQuery();

			THDAssociateDTO associate = null;
			while (rs.next()) {
				associate = new THDAssociateDTO();

				associate.setLdapId(rs.getString("LDAP_ID"));
				associate.setFirstName(rs.getString("FIRST_NAME"));
				associate.setLastName(rs.getString("LAST_NAME"));
				associate.setPortfolioCd(rs.getInt("PORTFOLIO_CD"));

				thdVPList.add(associate);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return thdVPList;
	}

	public static List<THDAssociateDTO> retrieveThdSrVPs(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<THDAssociateDTO> thdSrVPList = new ArrayList<THDAssociateDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_THD_SR_VPS);

			rs = preparedStatement.executeQuery();

			THDAssociateDTO associate = null;
			while (rs.next()) {
				associate = new THDAssociateDTO();
 
				associate.setLdapId(rs.getString("LDAP_ID"));
				associate.setFirstName(rs.getString("FIRST_NAME"));
				associate.setLastName(rs.getString("LAST_NAME"));
				associate.setPortfolioCd(rs.getInt("PORTFOLIO_CD"));

				thdSrVPList.add(associate);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return thdSrVPList;
	}

	public static List<TypeDTO> retrieveTechnologies(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> technologyList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_TECHNOLOGIES);

			rs = preparedStatement.executeQuery();

			TypeDTO technologyDetails = null;
			while (rs.next()) {
				technologyDetails = new TypeDTO();

				technologyDetails.setCd(rs.getInt("TECHNOLOGY_TYP_CD"));
				technologyDetails.setDesc(rs.getString("TECHNOLOGY_TYP_DESC"));

				technologyList.add(technologyDetails);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return technologyList;
	}

	public static List<TypeDTO> retrieveProjects(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> projectList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_PROJECTS);

			rs = preparedStatement.executeQuery();

			TypeDTO technologyDetails = null;
			while (rs.next()) {
				technologyDetails = new TypeDTO();

				technologyDetails.setCd(rs.getInt("PROJ_ID"));
				technologyDetails.setDesc(rs.getString("PROJ_NAME"));
				technologyDetails.setPortfolioCd(rs.getInt("PORTFOLIO_CD"));

				projectList.add(technologyDetails);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return projectList;
	}

	public static List<THDFiscalMonthDTO> retrieveThdFiscalDetails(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<THDFiscalMonthDTO> fiscalList = new ArrayList<THDFiscalMonthDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_THD_FISCAL_DETAILS);
			
			 Calendar cal = Calendar.getInstance();
			
			 DAOFactory.setValues(preparedStatement, cal.get(Calendar.YEAR));

			rs = preparedStatement.executeQuery();

			THDFiscalMonthDTO fiscalDetails = null;
			while (rs.next()) {
				fiscalDetails = new THDFiscalMonthDTO();

				fiscalDetails.setStartDate(rs.getDate("START_DT"));
				fiscalDetails.setEndDate(rs.getDate("END_DT"));
				fiscalDetails.setMonthId(rs.getInt("MONTH_ID"));
				fiscalDetails.setMonthDesc(rs.getString("MONTH_DESC"));
				fiscalDetails.setYear(rs.getInt("YEAR"));

				fiscalList.add(fiscalDetails);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return fiscalList;
	}

	public static List<TypeDTO> retrieveWOStatuses(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> woStatusList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_WO_STATUSES);

			rs = preparedStatement.executeQuery();

			TypeDTO workorderStatusDetails = null;
			while (rs.next()) {
				workorderStatusDetails = new TypeDTO();

				workorderStatusDetails.setCd(rs.getInt("WO_STATUS_CD"));
				workorderStatusDetails.setDesc(rs.getString("WO_STATUS_DESC"));

				woStatusList.add(workorderStatusDetails);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return woStatusList;
	}
	
	
	public static boolean updateAllocationData() throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> techLvlList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		Connection connection = null;
		try {
			
			connection = DAOFactory.getConnectionInManualCommitMode();
			preparedStatement = connection.prepareStatement(UPDATE_ASSOCIATE_ALLOCATION_TO_DEFAULT);
			
			int result = preparedStatement.executeUpdate();
			if (result != 0) {
				
				
				preparedStatement = connection.prepareStatement(UPDATE_ASSOCIATE_CURRENT_ALLOCATION);
				result = preparedStatement.executeUpdate();
				connection.commit();
				

			}
			
			
			//connection.setAutoCommit(false);
	
		}
		catch(Exception e)
		{
			DAOFactory.rollBackConnection(connection);
		}finally {

			
			DAOFactory.close(rs, preparedStatement, null);
		}

		return true;
	}
	
	
	
	public static List<TypeDTO> retrieveTechLvlList(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> techLvlList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_TECH_LVL_LIST);

			rs = preparedStatement.executeQuery();

			TypeDTO techLvlDetails = null;
			while (rs.next()) {
				techLvlDetails = new TypeDTO();

				techLvlDetails.setCd(rs.getInt("TECH_LVL_CD"));
				techLvlDetails.setDesc(rs.getString("TECH_LVL_DESC"));

				techLvlList.add(techLvlDetails);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return techLvlList;
	}

	public static List<TypeDTO> retrieveServiceLineDesc(Connection connection) throws SQLException, VisaTrackingServiceException {
		List<TypeDTO> serviceLineDescList = new ArrayList<TypeDTO>();

		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(RETRIEVE_SERVICE_LINE_DESC);

			rs = preparedStatement.executeQuery();

			TypeDTO serviceLineDesc = null;
			while (rs.next()) {
				serviceLineDesc = new TypeDTO();

				serviceLineDesc.setCd(rs.getInt("SERVICE_LINE_CD"));
				serviceLineDesc.setDesc(rs.getString("SERVICE_LINE_DESC"));

				serviceLineDescList.add(serviceLineDesc);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, null);
		}

		return serviceLineDescList;
	}
}
