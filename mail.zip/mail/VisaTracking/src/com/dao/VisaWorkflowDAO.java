package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import com.dao.util.DAOFactory;
import com.dto.WorkflowDTO;
import com.exception.VisaTrackingServiceException;
import com.util.ApplicationConstants;
import com.util.VisaTrackingUtil;


public class VisaWorkflowDAO {
	private static volatile VisaWorkflowDAO instance = null;

	public static VisaWorkflowDAO getInstance() {
		if (instance == null) {
			synchronized (VisaWorkflowDAO.class) {
				if (instance == null) {
					instance = new VisaWorkflowDAO();
				}
			}
		}
		return instance;
	}

	//insert into into workflow history and update into visa the status of the raised visa
	private static final String UPDATE_VISA_WF = 	"UPDATE VISA SET VISA_STATUS_CD= ?, REMARKS = ?, LAST_UPD_USER_ID = ?, LAST_UPD_TS = SYSDATE() where emp_nbr = ? ";
	
	private static final String INSERT_INTO_WORKFLOW_HISTORY_WF = "INSERT INTO workflow_history" +
																"(EMP_NBR,APPROVED_ID,APPROVED_DT,OLD_WORKFLOW_STATUS,NEW_WORKFLOW_STATUS,associates_tx_id)" +
																" VALUES(?, ?, ?, ?, ?, ?)";

	private static final String GET_LATEST_WORKFLOW_HISTORY_EMP_REC="select associates_tx_id,emp_nbr,approved_id, approved_dt, " +
													"old_workflow_status,new_workflow_status from workflow_history " +
													"where associates_tx_id=" +
													"(SELECT MAX(associates_tx_id) from workflow_history where emp_nbr=?)";

	/*private static final String SEARCH_TRACKER_WF =""; 
			
	// will run in loop for soft delete on the actual table
	private static final String SEARCH_HISTORY_WF = "select associates_tx_id, emp_nbr, approved_id, approved_dt, old_workflow_status, " +
													"new_workflow_status from workflow_history where emp_nbr=?" +
													"GROUP BY associates_tx_id, emp_nbr, approved_id, approved_dt, " +
													"old_workflow_status, new_workflow_status ORDER BY time associates_tx_id";

	private static final String DELETE_HISTORY_WF = "Delete from workflow_history where emp_nbr=?";

	// this will run in loop for entry on actual table
	private static final String ADD_ARCHIVE_WF = 	"INSERT INTO workflow_history_archive" +
													"(EMP_NBR,APPROVED_ID,APPROVED_DT,OLD_WORKFLOW_STATUS,NEW_WORKFLOW_STATUS,ASSOCIATES_TX_ID,DELETED_ON)" +
													" VALUES(?, ?, ?, ?, ?, ?, SYSDATE())"; */

	// This will udpate the status of visa using workflow management
	
	private static final String GET_ASSOCIATE_DETAILS_WF = "SELECT FIRST_NAME, LAST_NAME, LDAP_ID, ROLE_CD, SUPERVISOR_EMP_NBR, PORTFOLIO_CD FROM ASSOCIATE where emp_nbr = ?";

	public WorkflowDTO updateVisaStatusWorkflow(Connection connection,int emp_nbr, String comments,int approvalStatus, int loggedInEmpNumber) throws SQLException,
	VisaTrackingServiceException {
		WorkflowDTO workflowDTONew= new WorkflowDTO();
		PreparedStatement preparedStatement = null;
		boolean saveStatus= false;
		try {
			int associates_tx_id=0;
			//GET_LATEST_WORKFLOW_HISTORY_EMP_REC: for tracking the status
			preparedStatement = connection.prepareStatement(GET_LATEST_WORKFLOW_HISTORY_EMP_REC);
			//Query params: emp_nbr
			String old_workflow_status="";
			DAOFactory.setValues(preparedStatement, emp_nbr);
			ResultSet emp_visa_history= preparedStatement.executeQuery();
			
			//Result associates_tx_id,emp_nbr,approved_id, approved_dt, old_workflow_status,new_workflow_status
			while(emp_visa_history.next()){
				associates_tx_id=emp_visa_history.getInt(1)+1;
				old_workflow_status=emp_visa_history.getString(6);
			}
			String[] arr=old_workflow_status.split("`");
			if(approvalStatus<=Integer.parseInt(arr[0])){
				throw new VisaTrackingServiceException("Current status is same");
			}
			preparedStatement=null;
			// create a java calendar instance
			Calendar calendar = Calendar.getInstance();
			 
			// get a java date (java.util.Date) from the Calendar instance.
			// this java date will represent the current date, or "now".
			java.util.Date currentDate = calendar.getTime();
			 
			// now, create a java.sql.Date from the java.util.Date
			java.sql.Date date = new java.sql.Date(currentDate.getTime());
			
			String newStatus="";
			//insert into workflow_history table
			preparedStatement = connection.prepareStatement(INSERT_INTO_WORKFLOW_HISTORY_WF);
			int new_workflow_status=approvalStatus;
			newStatus=getNextPendingStatus((approvalStatus-1)+"`");
			
			//Query params: (EMP_NBR,APPROVED_ID,OLD_WORKFLOW_STATUS,NEW_WORKFLOW_STATUS,ASSOCIATES_TX_ID)
			DAOFactory.setValues(preparedStatement, emp_nbr, loggedInEmpNumber,date, old_workflow_status, 
					newStatus,associates_tx_id);

			int result = preparedStatement.executeUpdate();
			
			preparedStatement=null;
			//update VISA status
			preparedStatement = connection.prepareStatement(UPDATE_VISA_WF);
			//Query params: UPDATE VISA SET VISA_STATUS_CD= ?, REMARKS = ?, LAST_UPD_USER_ID = ?, LAST_UDP_TS = CURRENT_TIMESTAMP where emp_nbr = ? 
			DAOFactory.setValues(preparedStatement, new_workflow_status
					,comments, loggedInEmpNumber, emp_nbr);
			int rt = preparedStatement.executeUpdate();
			if (rt != 0 && result!=0) {
				saveStatus = true;
			}
			//workflowDTONew;
			if(saveStatus){
				workflowDTONew.setResultStatus(saveStatus);
				//based with the status of getApproverIdAndName
				String[] approverDetails=getApproverIdAndName(connection,loggedInEmpNumber).split("`");
				workflowDTONew.setNextPendingStatus(newStatus);
				workflowDTONew.setEmpNbr(emp_nbr);
				workflowDTONew.setApprovedId(loggedInEmpNumber);
				workflowDTONew.setApproverName(approverDetails[1]+approverDetails[2]);
				/*workflowDTONew.setApprovedDt(approvedDt);
				workflowDTONew.setApprovedId(loggedInEmpNumber);
				workflowDTONew.setApproverName(approverDetails[1]+approverDetails[2]);
				workflowDTONew.setApproverRole(approverDetails[3]);
				workflowDTONew.setCurrentStatus(currentStatus);*/
			}
			connection.commit();
		} catch(Exception ex){
			ex.printStackTrace();
		} finally {
			DAOFactory.close(null, preparedStatement, null);
		}
		return workflowDTONew;
	}
	

	public String getNextPendingStatus(String currentStatus){
		// call search query from DB
		if(currentStatus.contains("1`"))
			return (ApplicationConstants.MESSAGE_2);
		if(currentStatus.contains("2`"))
			return (ApplicationConstants.MESSAGE_3);
		if(currentStatus.contains("3`"))
			return (ApplicationConstants.MESSAGE_4);
		if(currentStatus.contains("4`"))
			return (ApplicationConstants.MESSAGE_5);
		if(currentStatus.contains("0`"))
			return (ApplicationConstants.MESSAGE_1);
		return ApplicationConstants.MESSAGE_0;
	}
	
	
	public String getApproverIdAndName(Connection connection,int emp_nbr) throws SQLException,
	VisaTrackingServiceException{
		PreparedStatement preparedStatement = null;
		try {
			//GET_ASSOCIATE_DETAILS_WF: for fetching FIRST_NAME, LAST_NAME, LDAP_ID, ROLE_CD, SUPERVISOR_EMP_NBR, PORTFOLIO_CD
			preparedStatement = connection.prepareStatement(GET_ASSOCIATE_DETAILS_WF);
			//Query params: emp_nbr
			DAOFactory.setValues(preparedStatement, emp_nbr);
			ResultSet empDetails = preparedStatement.executeQuery();
			while(empDetails.next()){
				return (emp_nbr+"`")+empDetails.getString(1)+"`"+empDetails.getString(2)+"`"+empDetails.getInt(4)+"`"+empDetails.getInt(5)+"`"+empDetails.getInt(6);
			}
			return emp_nbr+"`"+"null";
		}finally{
			DAOFactory.close(null, preparedStatement, null);
		}
	}
}
