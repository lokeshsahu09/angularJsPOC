package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dao.util.DAOFactory;
import com.dto.AssociateDetailsDTO;
import com.dto.CacheDTO;
import com.dto.LoggedInUserDetailsDTO;
import com.dto.TypeDTO;
import com.exception.VisaTrackingServiceException;
import com.manager.CacheManager;

public class AuthenticateDAO {

	private static volatile AuthenticateDAO instance = null;

	public static AuthenticateDAO getInstance() {
		if (instance == null) {
			synchronized (AuthenticateDAO.class) {
				if (instance == null) {
					instance = new AuthenticateDAO();
				}
			}
		}
		return instance;
	}

	private static final String AUTHENTICATE = "SELECT EMP_NBR, FIRST_NAME, LAST_NAME, PORTFOLIO_CD, ROLE_CD, FIRST_TIME FROM AUTH WHERE EMP_NBR = ? AND PWD = ? AND ACTIVE = 1";
	
	private static final String GET_SECURITY_QUESTIONS = "SELECT QUESTION_CD, QUESTION_DESC FROM SECURITY_QUESTIONS";

	private static final String UPDATE_PASSWORD = "UPDATE AUTH SET PWD = ? WHERE EMP_NBR = ?";
	
	private static final String UPDATE_USER_DETAILS = "UPDATE AUTH SET FIRST_NAME = ?, LAST_NAME = ?, PORTFOLIO_CD = ?, ROLE_CD = ? WHERE EMP_NBR = ?";
	
	private static final String UPDATE_PASSWORD_FIRST_TIME = "UPDATE AUTH SET PWD = ?, FIRST_TIME = ?, SECURITY_QUESTION_CD = ?, SECURITY_ANSWER = ? WHERE EMP_NBR = ?";

	private static final String CREATE_USER = "INSERT INTO AUTH(EMP_NBR, PWD, FIRST_NAME, LAST_NAME, PORTFOLIO_CD, ROLE_CD, ACTIVE, FIRST_TIME, SECURITY_QUESTION_CD, SECURITY_ANSWER) " +
												"VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	private static final String DELETE_USER = "DELETE FROM AUTH WHERE EMP_NBR = ?";
	
	private static final String IS_AUTH_USER_PRESENT = "SELECT * FROM AUTH WHERE EMP_NBR = ?";
	
	private static final String DELETE_USER_FOR_EMP_DELETE = "UPDATE AUTH SET ACTIVE = -1 WHERE EMP_NBR = ?";

	public LoggedInUserDetailsDTO authenticateAndGetDetials(int empNumber, String password) throws SQLException, VisaTrackingServiceException {

		LoggedInUserDetailsDTO loggedInUserDetails = null;

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = DAOFactory.getConnection();

			preparedStatement = connection.prepareStatement(AUTHENTICATE);

			DAOFactory.setValues(preparedStatement, empNumber, password);

			rs = preparedStatement.executeQuery();
			CacheManager cacheManager = CacheManager.getInsatance();

			CacheDTO cacheDTO = cacheManager.getCache();
			if (rs.next()) {
				loggedInUserDetails = new LoggedInUserDetailsDTO();
				loggedInUserDetails.setEmpNbr(rs.getInt("EMP_NBR"));
				loggedInUserDetails.setFirstName(rs.getString("FIRST_NAME"));
				loggedInUserDetails.setLastName(rs.getString("LAST_NAME"));
				loggedInUserDetails.setPortfolioCd(rs.getInt("PORTFOLIO_CD"));
				loggedInUserDetails.setPortfolioDesc(cacheDTO.getPorfolioMap().get(loggedInUserDetails.getPortfolioCd()));
				loggedInUserDetails.setRoleCd(rs.getInt("ROLE_CD"));
				loggedInUserDetails.setRoleDesc(cacheDTO.getRoleMap().get(loggedInUserDetails.getRoleCd()));
				loggedInUserDetails.setIsFirstTime(rs.getString("FIRST_TIME"));
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, connection);
		}
		return loggedInUserDetails;
	}
	
		
	public List<TypeDTO> getSecurityQuestions() throws SQLException, VisaTrackingServiceException {

		List<TypeDTO> securityquestionList = new ArrayList<TypeDTO>();

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = DAOFactory.getConnection();

			preparedStatement = connection.prepareStatement(GET_SECURITY_QUESTIONS);

			rs = preparedStatement.executeQuery();
			CacheManager cacheManager = CacheManager.getInsatance();

			CacheDTO cacheDTO = cacheManager.getCache();
			while(rs.next()) {
				TypeDTO question = new TypeDTO();
				question.setCd(rs.getInt("QUESTION_CD"));
				question.setDesc(rs.getString("QUESTION_DESC"));
				securityquestionList.add(question);
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, connection);
		}
		return securityquestionList;
	}
	
	public boolean authenticate(int empNumber, String password) throws SQLException, VisaTrackingServiceException {

		boolean status = false;

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = DAOFactory.getConnection();

			preparedStatement = connection.prepareStatement(AUTHENTICATE);

			DAOFactory.setValues(preparedStatement, empNumber, password);

			rs = preparedStatement.executeQuery();
			CacheManager cacheManager = CacheManager.getInsatance();

			CacheDTO cacheDTO = cacheManager.getCache();
			if (rs.next()) {
				status = true;
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, connection);
		}
		return status;
	}

	
	public boolean changePasswordFirstTime(int empNumber, String newPassword, int securityQuestinCd, String SecurityAns) throws SQLException, VisaTrackingServiceException {

		boolean saveStatus = false;

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = DAOFactory.getConnection();
			preparedStatement = connection.prepareStatement(UPDATE_PASSWORD_FIRST_TIME);

			DAOFactory.setValues(preparedStatement, newPassword, "N", securityQuestinCd, SecurityAns,  empNumber);

			int result = preparedStatement.executeUpdate();
			if (0 != result) {
				saveStatus = true;
			}
		} finally {
			DAOFactory.close(null, preparedStatement, connection);
		}
		return saveStatus;
	}
	
	
	public boolean changePassword(int empNumber, String newPassword) throws SQLException, VisaTrackingServiceException {

		boolean saveStatus = false;

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = DAOFactory.getConnection();

			preparedStatement = connection.prepareStatement(UPDATE_PASSWORD);

			DAOFactory.setValues(preparedStatement, newPassword, empNumber);

			int result = preparedStatement.executeUpdate();
			if (0 != result) {
				saveStatus = true;
			}
		} finally {
			DAOFactory.close(null, preparedStatement, connection);
		}
		return saveStatus;
	}
	
	public boolean updateUserDetails(Connection connection, AssociateDetailsDTO associate) throws SQLException, VisaTrackingServiceException {

		boolean saveStatus = false;

		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection.prepareStatement(UPDATE_USER_DETAILS);

			DAOFactory.setValues(preparedStatement, associate.getFirstName(), associate.getLastName(), associate.getPortfolioCd(), associate.getRoleCd(), associate.getEmpNumber());

			int result = preparedStatement.executeUpdate();
			if (0 != result) {
				saveStatus = true;
			}
		} finally {
			DAOFactory.close(null, preparedStatement, null);
		}
		return saveStatus;
	}

	public boolean createUser(int empNumber, String password) throws SQLException, VisaTrackingServiceException {

		boolean saveStatus = false;

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = DAOFactory.getConnection();

			preparedStatement = connection.prepareStatement(CREATE_USER);

			DAOFactory.setValues(preparedStatement, empNumber, password);

			int result = preparedStatement.executeUpdate();
			if (0 != result) {
				saveStatus = true;
			}
		} finally {
			DAOFactory.close(null, preparedStatement, connection);
		}
		return saveStatus;
	}
	
	public boolean createUser(AssociateDetailsDTO associateDetails, String password, Connection connection) throws SQLException, VisaTrackingServiceException {

		boolean saveStatus = false;
		boolean closeConnection = false;

		PreparedStatement preparedStatement = null;
		try {

			if(connection == null)
			{
				connection = DAOFactory.getConnection();
				closeConnection = true;
			}
			preparedStatement = connection.prepareStatement(CREATE_USER);

			DAOFactory.setValues(preparedStatement, associateDetails.getEmpNumber(), password, associateDetails.getFirstName(), associateDetails.getLastName(),
					associateDetails.getPortfolioCd(), associateDetails.getRoleCd(), 1,  "Y", null, null);

			int result = preparedStatement.executeUpdate();
			if (0 != result) {
				saveStatus = true;
			}
		} finally {
			if(closeConnection)
			{
				DAOFactory.close(null, preparedStatement, connection);
			}
			else
			{
				DAOFactory.close(null, preparedStatement, null);
			}
		}
		return saveStatus;
	}
	
	public boolean isUserAuthPresent(AssociateDetailsDTO associateDetails, Connection connection) throws SQLException, VisaTrackingServiceException {

		boolean isUserPresent = false;

		PreparedStatement preparedStatement = null;
		try {


			preparedStatement = connection.prepareStatement(IS_AUTH_USER_PRESENT);

			DAOFactory.setValues(preparedStatement, associateDetails.getEmpNumber());

			ResultSet result = preparedStatement.executeQuery();
			if (null != result) {
				isUserPresent = true;
			}
		} finally {
			DAOFactory.close(null, preparedStatement, null);
		}
		return isUserPresent;
	}

	public boolean deleteUser(int empNumber) throws SQLException, VisaTrackingServiceException {

		boolean saveStatus = false;

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = DAOFactory.getConnection();

			preparedStatement = connection.prepareStatement(DELETE_USER);

			DAOFactory.setValues(preparedStatement, empNumber);

			int result = preparedStatement.executeUpdate();
			if (0 != result) {
				saveStatus = true;
			}
		} finally {
			DAOFactory.close(null, preparedStatement, connection);
		}
		return saveStatus;
	}
	
	public boolean deleteUserUsingConnection(int empNumber) throws SQLException, VisaTrackingServiceException {

		boolean saveStatus = false;

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = DAOFactory.getConnection();

			preparedStatement = connection.prepareStatement(DELETE_USER);

			DAOFactory.setValues(preparedStatement, empNumber);

			int result = preparedStatement.executeUpdate();
			if (0 != result) {
				saveStatus = true;
			}
		} finally {
			DAOFactory.close(null, preparedStatement, connection);
		}
		return saveStatus;
	}
	
	
	public boolean deleteUserUsingConnection(Connection connection, int empNumber) throws SQLException, VisaTrackingServiceException {
		PreparedStatement preparedStatement = null;
		try {
			//preparedStatement = connection.prepareStatement(DELETE_USER);
			preparedStatement = connection.prepareStatement(DELETE_USER_FOR_EMP_DELETE);
			

			DAOFactory.setValues(preparedStatement, empNumber);

			preparedStatement.executeUpdate();
		} finally {
			DAOFactory.close(null, preparedStatement, null);
		}
		return true;
	}
	
}
