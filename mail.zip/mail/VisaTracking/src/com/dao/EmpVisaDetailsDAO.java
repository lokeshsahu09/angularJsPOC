package com.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import com.dao.util.DAOFactory;
import com.dto.EmpVisaDTO;
import com.dto.ResponseHeaderDTO;
import com.dto.WorkflowDTO;
import com.exception.VisaTrackingServiceException;

import java.sql.Statement;

import com.response.dto.AddEmpVisaResponse;
import com.util.ApplicationConstants;
import com.util.VisaTrackingUtil;


public class EmpVisaDetailsDAO {
	private static volatile EmpVisaDetailsDAO instance = null;

	public static EmpVisaDetailsDAO getInstance() {
		if (instance == null) {
			synchronized (EmpVisaDetailsDAO.class) {
				if (instance == null) {
					instance = new EmpVisaDetailsDAO();
				}
			}
		}
		return instance;
	}
	
	public static final String ADD_EMP_VISA_TRACKER="INSERT INTO visa_tracker "
			+ "(EMP_NBR, VISA_TYP_CD, TRAVEL_PERIOD, TRAVEL_TO,  "
			+ "NEW_Replacement, BUSINESS_CASE, START_DT_OF_REQ, "
			+ "BILLING_RATE_ONSITE, SKILL_SET, ROLE_POTENTIAL_LOSS, "
			+ "PROJECT_TYPE, PORTFOLIO_DESC,"
			+ "Deletion_status,LAST_UPDATED_DATE,LAST_UPDATED_BY,DELETED_ON,FIRST_NAME,LAST_NAME) "
			+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE(), ?, ?,?,?)";
	
	public static final String ADD_EMP_VISA_ADDITIONAL="INSERT INTO visa "
			+ "(EMP_NBR, VISA_TYP_CD, VISA_STATUS_CD,VTS_ID, "
			+ "submitted_user_id,submitted_TS) "
			+ "VALUES (?, ?, ?, ?, ?, ?)";
	private static final String GET_ASSOCIATE_DETAILS_WF = "SELECT FIRST_NAME, LAST_NAME, LDAP_ID, ROLE_CD, "
			+ "SUPERVISOR_EMP_NBR, PORTFOLIO_CD FROM ASSOCIATE where emp_nbr = ?";
	
	public static final String SOFT_DELETE_VISA = "UPDATE VISA_TRACKER SET DELETION_STATUS = 'Y', deleted_on = sysdate() where (emp_nbr,visa_typ_cd) IN "; 

	
	public ResponseHeaderDTO softDeleteEmpVisas(Connection connection, int[] empNbrsAndVisaTypes) throws SQLException,
	VisaTrackingServiceException {
		PreparedStatement preparedStatement = null;
		ResponseHeaderDTO responseHeader=new ResponseHeaderDTO();
		StringBuffer sb = new StringBuffer(SOFT_DELETE_VISA);
		try{
			
			if(empNbrsAndVisaTypes.length>0){
				sb.append("(");
				int empLength= empNbrsAndVisaTypes.length;
				
				for(int i=0; i<empLength;i++){
					sb.append("(");
					sb.append(empNbrsAndVisaTypes[i]+","+empNbrsAndVisaTypes[++i]);
					if(i==empLength-1){
						sb.append(")");
					}else{
						sb.append("),");
					}
					
				}
				sb.append(")");
				preparedStatement=connection.prepareStatement(sb.toString());
				int result=preparedStatement.executeUpdate();
				if(result!=0){
					responseHeader.setStatus(ApplicationConstants.OK_STATUS);
					responseHeader.setMessage(ApplicationConstants.SUCCESS);
				}
			}else {
				throw new VisaTrackingServiceException("Please select a row to delete");
			}
			
		}finally{
			DAOFactory.close(null, preparedStatement, null);
		}
		return responseHeader;
	}
	
	/**
	 * 
	 * @param connection
	 * @param empVisaDTO
	 * @param loggedInEmpNumber
	 * @return
	 * @throws SQLException
	 * @throws VisaTrackingServiceException
	 */
	public AddEmpVisaResponse addEmpVisaDetails(Connection connection,EmpVisaDTO empVisaDTO, int loggedInEmpNumber) throws SQLException,
	VisaTrackingServiceException {
		PreparedStatement preparedStatement = null;
		ResponseHeaderDTO responseHeader=new ResponseHeaderDTO();
		AddEmpVisaResponse addEmpVisaResp= new AddEmpVisaResponse();
		try {
			preparedStatement=connection.prepareStatement(ADD_EMP_VISA_TRACKER);
			//values of empVisa details into employee visa_tracker and visa
			/** EMP_NBR, VISA_TYP_CD, TRAVEL_PERIOD, TRAVEL_TO, "
			 * "NEW_Replacement, BUSINESS_CASE, START_DT_OF_REQ, "
			 * "BILLING_RATE_ONSITE, SKILL_SET, ROLE_POTENTIAL_LOSS, "
			 * "FIRST_NAME, LAST_NAME, PROJECT_TYPE, PORTFOLIO_DESC"
			 * "Deletion_status,LAST_UPDATED_DATE,LAST_UPDATED_BY,DELETED_ON"
			 */

			DAOFactory.setValues(preparedStatement, empVisaDTO.getEmpNbr(),empVisaDTO.getVisaType(),empVisaDTO.getTravelPeriod(),
					empVisaDTO.getTravelTo(),empVisaDTO.getInitialStatus(),empVisaDTO.getBusinessCase(),
					empVisaDTO.getStartDateRequirement(),empVisaDTO.getBillingRate(),
					empVisaDTO.getSkillSet(),empVisaDTO.getPotentialLoss(),
					empVisaDTO.getProjectType(),
					empVisaDTO.getPortfolio(),empVisaDTO.getDeletionStatus(),
					loggedInEmpNumber,empVisaDTO.getDeletedOn(),empVisaDTO.getFirstName(),empVisaDTO.getLastName());
			int result=preparedStatement.executeUpdate();
			if(result!=0){
				connection.commit();
			}
			if (result!=0 && addEmpVisaAdditionalDetails(connection,empVisaDTO,loggedInEmpNumber)!=0) {
				responseHeader.setStatus(ApplicationConstants.OK_STATUS);
				responseHeader.setMessage(ApplicationConstants.SUCCESS);
				
			}else{
				responseHeader.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
				responseHeader.setMessage(ApplicationConstants.FAILURE);
			}
			addEmpVisaResp.setHeader(responseHeader);
		}catch(Exception ex){
			throw ex;
		} finally {
			DAOFactory.close(null, preparedStatement, null);
		}
		return addEmpVisaResp;
	}
	
	public int addEmpVisaAdditionalDetails(Connection connection,EmpVisaDTO empVisaDTO, int loggedInEmpNumber) throws SQLException,
	VisaTrackingServiceException {
		PreparedStatement preparedStatement = null;
		int[] ret;
		try {
			//Add new values into
			/**
			 * EMP_NBR, VISA_TYP_CD, VISA_STATUS_CD,VTS_ID, "
			 * "submitted_user_id,submitted_TS"
			 */
			connection=DAOFactory.getConnectionInManualCommitMode();
			preparedStatement=connection.prepareStatement(ADD_EMP_VISA_ADDITIONAL);
			DAOFactory.setValues(preparedStatement, empVisaDTO.getEmpNbr(),empVisaDTO.getVisaType(),
					empVisaDTO.getVisaStatusCd(),0,empVisaDTO.getSubmittedUserId(),getCurrentSQLDate()+"");
			preparedStatement.addBatch();
			ret=preparedStatement.executeBatch();
			connection.commit();
		}catch(Exception ex){
			throw ex;
		} finally {
			DAOFactory.close(null, preparedStatement, null);
		}
		return ret[0];
	}

	/**
	 * 
	 * @return
	 */
	public Date getCurrentSQLDate(){
		// create a java calendar instance
		Calendar calendar = Calendar.getInstance();

		// get a java date (java.util.Date) from the Calendar instance.
		// this java date will represent the current date, or "now".
		java.util.Date currentDate = calendar.getTime();

		// now, create a java.sql.Date from the java.util.Date
		return new java.sql.Date(currentDate.getTime());
	}

	/**
	 * 
	 * @param connection
	 * @param emp_nbr
	 * @return
	 * @throws SQLException
	 * @throws VisaTrackingServiceException
	 */
	public String getApproverIdAndName(Connection connection,int emp_nbr) throws SQLException,
	VisaTrackingServiceException{
		PreparedStatement preparedStatement = null;
		try {
			//GET_ASSOCIATE_DETAILS_WF: for fetching FIRST_NAME, LAST_NAME, LDAP_ID, ROLE_CD, SUPERVISOR_EMP_NBR, PORTFOLIO_CD
			preparedStatement = connection.prepareStatement(GET_ASSOCIATE_DETAILS_WF);
			//Query params: emp_nbr
			DAOFactory.setValues(preparedStatement, emp_nbr);
			ResultSet empDetails = preparedStatement.executeQuery();
			while(empDetails.next()){
				return (emp_nbr+"`")+empDetails.getString(1)+"`"+empDetails.getString(2)+"`"+empDetails.getInt(4)+"`"+empDetails.getInt(5)+"`"+empDetails.getInt(6);
			}
			return emp_nbr+"`"+"null";
		}finally{
			DAOFactory.close(null, preparedStatement, null);
		}
	}
}
