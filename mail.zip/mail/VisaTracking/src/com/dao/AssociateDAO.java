package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.dao.util.DAOFactory;
import com.dto.EditDTO;
import com.dto.EditStatusDTO;
import com.dto.ResponseHeaderDTO;
import com.dto.VisaTrackerDTO;
import com.exception.VisaTrackingException;
import com.exception.VisaTrackingServiceException;
import com.request.dto.SearchRequest;
import com.request.dto.UndoDeleteRequest;
import com.response.dto.PrepopulateResponse;
import com.response.dto.SearchResponse;
import com.util.ApplicationConstants;

public class AssociateDAO {

	private static volatile AssociateDAO instance = null;

	public static AssociateDAO getInstance() {
		if (instance == null) {
			synchronized (AssociateDAO.class) {
				if (instance == null) {
					instance = new AssociateDAO();
				}
			}
		}
		return instance;
	}

	private static final String GET_DOB = "SELECT DOB FROM ASSOCIATE WHERE EMP_NBR = ?";

	private static final String UPDATE_INTO_VISATRACKER_TABLE = "UPDATE VISA_TRACKER SET TRAVEL_PERIOD=?, TRAVEL_TO=?, NEW_Replacement=?, BUSINESS_CASE=?, START_DT_OF_REQ=?, BILLING_RATE_ONSITE=?, SKILL_SET=?, ROLE_POTENTIAL_LOSS=?, PROJECT_TYPE=?, PORTFOLIO_DESC=?,LAST_UPDATED_DATE=SYSDATE(),LAST_UPDATED_BY=?,FIRST_NAME=?,LAST_NAME=? WHERE EMP_NBR=? AND VISA_TYP_CD=?";

	private static final String UPDATE_INTO_VISA_TABLE = "UPDATE VISA SET VISA_TYP_CD=? WHERE EMP_NBR=?";

	private static final String SEARCH_STRING = "SELECT * FROM((SELECT V.EMP_NBR,V.FIRST_NAME,V.LAST_NAME,V.PROJECT_TYPE AS PROJECT_TYPE,D.VISA_TYP_DESC,E.VISA_STATS_DESC,V.TRAVEL_PERIOD,v.TRAVEL_TO, v.NEW_REPLACEMENT,v.BUSINESS_CASE,v.START_DT_OF_REQ,v.BILLING_RATE_ONSITE, V.SKILL_SET,V.ROLE_POTENTIAL_LOSS,V.PORTFOLIO_DESC,B.VISA_TYP_CD,B.VISA_STATUS_CD ,B.SUBMITTED_TS,B.SUBMITTED_user_id, V.LAST_UPDATED_DATE,v.last_updated_by,V.DELETION_STATUS FROM VISA_TRACKER V JOIN VISA B JOIN VISA_TYP D JOIN VISA_STATS E ON (V.EMP_NBR=B.EMP_NBR AND B.VISA_TYP_CD=D.VISA_TYP_CD AND B.VISA_TYP_CD=V.VISA_TYP_CD AND B.VISA_STATUS_CD=E.VISA_STATS_CD)) AS TEMP)";
	private static final String UPDATE_VISA_STATUS = "UPDATE VISA SET VISA_STATUS_CD=? WHERE EMP_NBR=? AND VISA_TYP_CD=?";

	private static final String PREPOPULATE = "SELECT A.FIRST_NAME,A.LAST_NAME,A.PORTFOLIO_CD,B.PORTFOLIO_DESC FROM ASSOCIATE A JOIN PORTFOLIO B ON (A.PORTFOLIO_CD=B.PORTFOLIO_CD) WHERE EMP_NBR=?";
	private static final String UPDATE_DELETION_STATUS = "UPDATE VISA_TRACKER SET DELETION_STATUS='N', LAST_UPDATED_DATE=SYSDATE(), LAST_UPDATED_BY=? WHERE EMP_NBR=? AND VISA_TYP_CD=?";

	public Date getDOBOfAssociate(int empNumber) throws SQLException,
			VisaTrackingServiceException {
		Date dob = null;

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = DAOFactory.getConnection();

			preparedStatement = connection.prepareStatement(GET_DOB);

			DAOFactory.setValues(preparedStatement, empNumber);

			rs = preparedStatement.executeQuery();
			if (rs.next()) {
				dob = rs.getDate("DOB");
			}
		} finally {
			DAOFactory.close(rs, preparedStatement, connection);
		}

		return dob;
	}

	public SearchResponse searchAssociate(SearchRequest searchRequest)
			throws VisaTrackingException, SQLException, ParseException {

		SearchResponse searchAssociateResponse = new SearchResponse();

		List<VisaTrackerDTO> visaTracker = new ArrayList<VisaTrackerDTO>();

		VisaTrackerDTO visaTrackerDetails = null;

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = DAOFactory.getConnection();

			preparedStatement = connection
					.prepareStatement(buildQuery(searchRequest));

			rs = preparedStatement.executeQuery();

			while (rs.next()) {
				visaTrackerDetails = new VisaTrackerDTO();

				visaTrackerDetails.setEmpNbr(rs.getInt("EMP_NBR"));
				visaTrackerDetails.setFirstName(rs.getString("FIRST_NAME"));
				visaTrackerDetails.setLastName(rs.getString("LAST_NAME"));
				visaTrackerDetails.setVisaType(rs.getString("VISA_TYP_DESC"));
				visaTrackerDetails.setProjectType(rs.getString("PROJECT_TYPE"));
				visaTrackerDetails.setTravelPeriod(rs.getInt("TRAVEL_PERIOD"));
				if(rs.getInt("TRAVEL_PERIOD")==6){
					visaTrackerDetails.setTravelPeriodTerm("Short Term");
				}if(rs.getInt("TRAVEL_PERIOD")==12){
					visaTrackerDetails.setTravelPeriodTerm("Long Term");
				}
				visaTrackerDetails.setTravelTo(rs.getString("TRAVEL_TO"));
				visaTrackerDetails.setInitialStatus(rs
						.getString("NEW_REPLACEMENT"));
				visaTrackerDetails.setBusinessCase(rs
						.getString("BUSINESS_CASE"));
				visaTrackerDetails.setStartDateRequirement(rs
						.getDate("START_DT_OF_REQ"));
				visaTrackerDetails.setBillingRate(rs
						.getDouble("BILLING_RATE_ONSITE"));
				visaTrackerDetails.setSkillSet(rs.getString("SKILL_SET"));
				visaTrackerDetails.setPotentialLoss(rs
						.getString("ROLE_POTENTIAL_LOSS"));
				visaTrackerDetails.setPortfolio(rs.getString("PORTFOLIO_DESC"));
				visaTrackerDetails.setStatus(rs.getString("VISA_STATS_DESC"));
				// B.SUBMITTED_TS,B.SUBMITTED_user_id,
				// V.Last_updated_date,v.last_updated_by
				visaTrackerDetails.setSubmittedTS(rs.getString("SUBMITTED_TS"));
				visaTrackerDetails.setLastUpdatedDate(rs
						.getString("LAST_UPDATED_DATE"));
				visaTracker.add(visaTrackerDetails);

			}

		} finally {
			DAOFactory.close(rs, preparedStatement, connection);
		}
		searchAssociateResponse.setVisaTracerList(visaTracker);

		return searchAssociateResponse;

	}

	private String buildQuery(SearchRequest searchRequest)
			throws ParseException {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer("");

		sb.append(SEARCH_STRING).append(" WHERE ");

		boolean nextParam = false;

		if ((searchRequest.getEmpNbr() != 0)) {
			sb.append("EMP_NBR = " + searchRequest.getEmpNbr());
			nextParam = true;
		}

		if (searchRequest.getVisaType() != null
				&& !("".equalsIgnoreCase(searchRequest.getVisaType()))) {

			if (nextParam) {
				sb.append(ApplicationConstants.APPENDING_AND);

			}
			sb.append(" VISA_TYP_DESC LIKE '" + searchRequest.getVisaType()
					+ "%'");
			nextParam = true;
		}

		if (searchRequest.getVisaStatus() != null
				&& !("".equalsIgnoreCase(searchRequest.getVisaStatus()))) {
			if (nextParam) {
				sb.append(ApplicationConstants.APPENDING_AND);

			}
			sb.append(" VISA_STATS_DESC LIKE '%"
					+ searchRequest.getVisaStatus() + "%'");
			nextParam = true;
		}

		if (searchRequest.getPortfolio() != null
				&& !("".equalsIgnoreCase(searchRequest.getPortfolio()))) {

			if (nextParam) {
				sb.append(ApplicationConstants.APPENDING_AND);
			}

			sb.append(" PORTFOLIO_DESC LIKE '%" + searchRequest.getPortfolio()
					+ "%'");
			nextParam = true;
		}
		if (searchRequest.getProjectType() != null
				&& !("".equalsIgnoreCase(searchRequest.getProjectType()))) {

			if (nextParam) {
				sb.append(ApplicationConstants.APPENDING_AND);
			}

			sb.append(" PROJECT_TYPE LIKE '%" + searchRequest.getProjectType()
					+ "%'");
			nextParam = true;
		}

		if (searchRequest.getStartDate() != null
				&& searchRequest.getEndDate() != null) {

			if (nextParam) {
				sb.append(ApplicationConstants.APPENDING_AND);
			}
			String startDate = searchRequest.getStartDate().toString();
			DateFormat formatter = new SimpleDateFormat(
					ApplicationConstants.DATE_FORMAT_SQL);
			Date startdate = (Date) formatter.parse(startDate);

			Calendar cal = Calendar.getInstance();
			cal.setTime(startdate);
			String formatedStartDate = cal.get(Calendar.YEAR) + "-"
					+ (cal.get(Calendar.MONTH) + 1) + "-"
					+ cal.get(Calendar.DATE);
			String endDate = searchRequest.getEndDate().toString();
			Date enddate = (Date) formatter.parse(endDate);
			cal.setTime(enddate);
			String formatedEndDate = cal.get(Calendar.YEAR) + "-"
					+ (cal.get(Calendar.MONTH) + 1) + "-"
					+ cal.get(Calendar.DATE);

			sb.append(" START_DT_OF_REQ BETWEEN '" + formatedStartDate + "'"
					+ " AND '" + formatedEndDate + "'");
			nextParam = true;
		}
		if (searchRequest.getSkillSet() != null) {
			if (nextParam) {
				sb.append(ApplicationConstants.APPENDING_AND);
			}
			String[] skill = searchRequest.getSkillSet().split(",");
			sb.append(" ( SKILL_SET LIKE '%" + skill[0] + "%'");
			for (int i = 1; i < skill.length; i++) {
				sb.append((" OR SKILL_SET LIKE '%" + skill[i]) + "%' ");
			}
			sb.append(")");
			nextParam = true;
		}
		if (searchRequest.getIsDeleted() != null
				&& !("".equalsIgnoreCase(searchRequest.getIsDeleted()))) {
			if (nextParam) {
				sb.append(ApplicationConstants.APPENDING_AND);
			}
			if (searchRequest.getIsDeleted().equalsIgnoreCase("deleted")) {
				sb.append("  deletion_status='Y' ");
				nextParam = true;
			}
			if (searchRequest.getIsDeleted().equalsIgnoreCase("undeleted")) {
				sb.append("  deletion_status='N' ");
				nextParam = true;
			}

		}

		sb.append(" ORDER BY SUBMITTED_TS ASC");
		return sb.toString();
	}

	public boolean updateVisaTracker(Connection connection,
			EditDTO updateAssociateRequest, int loggedInEmp)
			throws SQLException, VisaTrackingServiceException, ParseException {
		boolean saveStatus = false;
		boolean closeConnection = false;
		PreparedStatement preparedStatement = null;
		try {

			if (connection == null) {
				connection = DAOFactory.getConnection();
				closeConnection = true;
			}
			String startDate = updateAssociateRequest.getStartDateRequirement()
					.toString();
			DateFormat formatter = new SimpleDateFormat(
					ApplicationConstants.DATE_FORMAT_SQL);
			Date startdate = (Date) formatter.parse(startDate);

			Calendar cal = Calendar.getInstance();
			cal.setTime(startdate);
			String formatedStartDate = cal.get(Calendar.YEAR) + "-"
					+ (cal.get(Calendar.MONTH) + 1) + "-"
					+ cal.get(Calendar.DATE);

			preparedStatement = connection
					.prepareStatement(UPDATE_INTO_VISATRACKER_TABLE);
			// LAST_UPDATED_BY=?
			DAOFactory.setValues(preparedStatement,
					updateAssociateRequest.getTravelPeriod(),
					updateAssociateRequest.getTravelTo(),
					updateAssociateRequest.getInitialStatus(),
					updateAssociateRequest.getBusinessCase(),
					formatedStartDate, updateAssociateRequest.getBillingRate(),
					updateAssociateRequest.getSkillSet(),
					updateAssociateRequest.getPotentialLoss(),
					updateAssociateRequest.getProjectType(),
					updateAssociateRequest.getPortfolio(), loggedInEmp,updateAssociateRequest.getFirstName(),updateAssociateRequest.getLastName(),
					updateAssociateRequest.getEmpNbr(),
					updateAssociateRequest.getVisaType());
			int result = preparedStatement.executeUpdate();
			if (result != 0) {
				saveStatus = true;
			}
			connection.commit();
		} finally {
			if (closeConnection) {
				DAOFactory.close(null, preparedStatement, connection);
			} else {
				DAOFactory.close(null, preparedStatement, null);
			}
		}
		return saveStatus;

	}

	/*
	 * public boolean updateVisaType(Connection connection, EditDTO
	 * updateAssociateRequest) throws SQLException, VisaTrackingServiceException
	 * { boolean saveStatus = false; boolean closeConnection = false;
	 * 
	 * PreparedStatement preparedStatement = null; try {
	 * 
	 * if (connection == null) { connection = DAOFactory.getConnection();
	 * closeConnection = true; }
	 * 
	 * preparedStatement = connection .prepareStatement(UPDATE_INTO_VISA_TABLE);
	 * 
	 * DAOFactory.setValues(preparedStatement,
	 * updateAssociateRequest.getVisaType(),
	 * updateAssociateRequest.getEmpNbr()); int result =
	 * preparedStatement.executeUpdate(); if (result != 0) { saveStatus = true;
	 * } } finally { if (closeConnection) { DAOFactory.close(null,
	 * preparedStatement, connection); } else { DAOFactory.close(null,
	 * preparedStatement, null); } } return saveStatus;
	 * 
	 * }
	 */

	public boolean updateStatus(Connection connection,
			EditStatusDTO updateAssociateRequest) throws SQLException,
			VisaTrackingServiceException {
		boolean saveStatus = false;
		boolean closeConnection = false;

		PreparedStatement preparedStatement = null;
		try {

			if (connection == null) {
				connection = DAOFactory.getConnection();
				closeConnection = true;
			}

			preparedStatement = connection.prepareStatement(UPDATE_VISA_STATUS);

			DAOFactory.setValues(preparedStatement,
					updateAssociateRequest.getNextPendingStatus(),
					updateAssociateRequest.getEmpNbr(),
					updateAssociateRequest.getVisaTypCd());
			int result = preparedStatement.executeUpdate();
			if (result != 0) {
				saveStatus = true;
			}
			connection.commit();
		} finally {
			if (closeConnection) {
				DAOFactory.close(null, preparedStatement, connection);
			} else {
				DAOFactory.close(null, preparedStatement, null);
			}
		}
		return saveStatus;

	}

	public PrepopulateResponse prepopulate(int empNbr) throws SQLException,
			VisaTrackingServiceException {
		PrepopulateResponse populateResponse = new PrepopulateResponse();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		ResponseHeaderDTO header = new ResponseHeaderDTO();
		boolean isEmpPresent = false;
		try {
			connection = DAOFactory.getConnection();

			preparedStatement = connection.prepareStatement(PREPOPULATE);
			DAOFactory.setValues(preparedStatement, empNbr);
			rs = preparedStatement.executeQuery();

			while (rs.next()) {

				populateResponse.setFirstName(rs.getString("FIRST_NAME"));
				populateResponse.setLastName(rs.getString("LAST_NAME"));
				populateResponse.setPortfolio(rs.getInt("PORTFOLIO_CD"));
				populateResponse.setPortfolioName(rs
						.getString("PORTFOLIO_DESC"));
				isEmpPresent = true;

			}
			if (isEmpPresent) {
				header.setStatus(ApplicationConstants.OK_STATUS);
			} else {
				header.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
			}
			populateResponse.setHeader(header);
		} finally {
			DAOFactory.close(rs, preparedStatement, connection);
		}
		return populateResponse;
	}

	public boolean undoDelete(Connection connection, UndoDeleteRequest undo)
			throws SQLException, VisaTrackingServiceException {
		boolean saveStatus = false;
		boolean closeConnection = false;

		PreparedStatement preparedStatement = null;
		try {

			if (connection == null) {
				connection = DAOFactory.getConnection();
				closeConnection = true;
			}

			preparedStatement = connection
					.prepareStatement(UPDATE_DELETION_STATUS);

			DAOFactory.setValues(preparedStatement, undo.getLoggedInempNbr(),
					undo.getEmp_nbr(), undo.getVisaType());
			int result = preparedStatement.executeUpdate();
			if (result != 0) {
				saveStatus = true;
			}
			connection.commit();
		} finally {
			if (closeConnection) {
				DAOFactory.close(null, preparedStatement, connection);
			} else {
				DAOFactory.close(null, preparedStatement, null);
			}
		}
		return saveStatus;

	}

}
