package com.dao.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

public class DAOProperties {
	private static final Properties PROPERTIES = new Properties();

	static {
		loadPropertiesFile();
	}

	private static void loadPropertiesFile() {
		FileInputStream fis = null;
		try {
			URL url = DAOProperties.class.getResource("DAO.properties");
			File file = new File(url.getFile());
			fis = new FileInputStream(file);
			PROPERTIES.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException ie) {
					ie.printStackTrace();
				}
			}
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public String getProperty(String key) {
		String property = PROPERTIES.getProperty(key);

		return property;
	}
}
