package com.dao.util;

public abstract interface DAOConstants
{
  public static final String TITLE = "title";
  public static final String FIRST_NAME = "first_name";
  public static final String LAST_NAME = "last_name";
  public static final String EMAIL_ADDR = "email_addr";
  public static final String PHONE_NBR = "phone_nbr";
  public static final String PHONE_EXTN = "phone_extn";
  public static final String ADDR_LINE_ONE = "addr_line_one";
  public static final String ADDR_LINE_TWO = "addr_line_two";
  public static final String CITY = "city";
  public static final String ZIP = "zip";
  public static final String USER_NAME = "user_name";
  public static final String BALANCE = "balance";
  public static final String AMOUNT = "amount";
  public static final String RECHARGE_ID = "recharge_id";
  public static final String TRANSACTION_ID = "transaction_id";
}