package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dao.util.DAOFactory;
import com.dto.MasterDetailsDTO;
import com.dto.MasterDetailsDTO.PortfolioDTO;
import com.dto.MasterDetailsDTO.ProjectTypeDTO;
import com.dto.MasterDetailsDTO.VisaStatusDTO;
import com.dto.MasterDetailsDTO.VisaTypeDTO;
import com.exception.VisaTrackingServiceException;

public class MasterDetailsDAO {
	private static volatile MasterDetailsDAO instance = null;
	
	public static final String GET_PORTFOLIO_DETAILS="SELECT PORTFOLIO_CD,PORTFOLIO_DESC FROM PORTFOLIO";
	public static final String GET_VISA_STATUS_DETAILS="SELECT VISA_STATS_CD,VISA_STATS_DESC FROM VISA_STATS";
	public static final String GET_VISA_TYPE_DETAILS="SELECT VISA_TYP_CD,VISA_TYP_DESC FROM VISA_TYP";

	public static MasterDetailsDAO getInstance() {
		if (instance == null) {
			synchronized (MasterDetailsDAO.class) {
				if (instance == null) {
					instance = new MasterDetailsDAO();
				}
			}
		}
		return instance;
	}
	
	public MasterDetailsDTO getMasterDetails(Connection connection)throws SQLException,
	VisaTrackingServiceException {
		PreparedStatement preparedStatement = null;
		MasterDetailsDTO masterDetails=new MasterDetailsDTO();
		ResultSet resultSet=null;
		try{
			List<PortfolioDTO> portfolioDetials=new ArrayList<PortfolioDTO>();
			List<VisaTypeDTO> visaTypeDetials=new ArrayList<VisaTypeDTO>();
			List<VisaStatusDTO> visaStatusDetials=new ArrayList<VisaStatusDTO>();
			List<ProjectTypeDTO> projectTypeDetials=new ArrayList<ProjectTypeDTO>();
			preparedStatement=connection.prepareStatement(GET_PORTFOLIO_DETAILS);
			
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				MasterDetailsDTO.PortfolioDTO portfolio= masterDetails.new PortfolioDTO();
				portfolio.setPortfolioCd(resultSet.getInt("PORTFOLIO_CD"));
				portfolio.setPortfolioDescription(resultSet.getString("PORTFOLIO_DESC"));
				portfolioDetials.add(portfolio);
			}
			DAOFactory.close(resultSet, preparedStatement, null);
			masterDetails.setPorfolioList(portfolioDetials);
			preparedStatement=connection.prepareStatement(GET_VISA_STATUS_DETAILS);
			
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				MasterDetailsDTO.VisaStatusDTO visaStatus= masterDetails.new VisaStatusDTO();
				visaStatus.setVisaStatsCd(resultSet.getInt("VISA_STATS_CD"));
				visaStatus.setVisaStatsDesc(resultSet.getString("VISA_STATS_DESC"));
				visaStatusDetials.add(visaStatus);
			}
			DAOFactory.close(resultSet, preparedStatement, null);
			masterDetails.setVisaStatusList(visaStatusDetials);
			preparedStatement=connection.prepareStatement(GET_VISA_TYPE_DETAILS);
			
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				MasterDetailsDTO.VisaTypeDTO visaType= masterDetails.new VisaTypeDTO();
				visaType.setVisaTypCd(resultSet.getInt("VISA_TYP_CD"));
				visaType.setVisaTypDesc(resultSet.getString("VISA_TYP_DESC"));
				visaTypeDetials.add(visaType);
			}
			DAOFactory.close(resultSet, preparedStatement, null);
			masterDetails.setVisaTypeList(visaTypeDetials);
		}finally{
			DAOFactory.close(resultSet, preparedStatement, connection);
		}
		return masterDetails;
	}
}
