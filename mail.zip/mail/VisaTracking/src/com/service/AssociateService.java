package com.service;

import java.text.ParseException;

import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import com.dto.EditStatusDTO;
import com.dto.ResponseHeaderDTO;
import com.exception.VisaTrackingClientException;
import com.exception.VisaTrackingException;
import com.exception.VisaTrackingServiceException;
import com.manager.AssociateManager;
import com.request.dto.EditEmpVisaRequest;
import com.request.dto.SearchRequest;
import com.request.dto.UndoDeleteRequest;
import com.response.dto.GenericResponse;
import com.response.dto.PrepopulateResponse;
import com.response.dto.SearchResponse;
import com.util.ApplicationConstants;
import com.util.GsonConverter;
import com.util.VisaTrackingUtil;

@Path("/associate")
public class AssociateService {
	@POST
	@Path("/search")
	public String search(@FormParam("data") String data,
			@FormParam("version") @DefaultValue("1") int version)
			throws VisaTrackingException, ParseException {
		SearchResponse response = new SearchResponse();
		switch (version) {
		case 1:
			try {
				if (VisaTrackingUtil.isNotEmptyString(data)) {
					SearchRequest searchRequest = (SearchRequest) GsonConverter
							.fromJson(data, SearchRequest.class);

					AssociateManager manager = AssociateManager.getInstance();
					ResponseHeaderDTO header = new ResponseHeaderDTO();
					response = manager.searchAssociate(searchRequest);

					if (response.getVisaTracerList().isEmpty()) {
						header.setMessage(ApplicationConstants.EMPTY_DATA);
					} else {

						header.setStatus(ApplicationConstants.OK_STATUS);
						response.setHeader(header);

					}

				} else {
					throw new VisaTrackingClientException("Empty input.");
				}
			} catch (VisaTrackingClientException ce) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(
						response.getHeader(), ce));
			} catch (VisaTrackingServiceException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(
						response.getHeader(), se));
			}
		}
		return GsonConverter.toJson(response);
	}

	@DELETE
	@Path("/delete")
	public String softDelete(@FormParam("empNbr") String empNbrAndVisaTypes,
			@FormParam("version") @DefaultValue("1") int version)
			throws ParseException {
		GenericResponse response = new GenericResponse();
		ResponseHeaderDTO responseHeader = new ResponseHeaderDTO();
		switch (version) {
		case 1:
			try {
				if (VisaTrackingUtil.isNotEmptyString(empNbrAndVisaTypes)) {
					// String[]
					// empNbrs=GsonConverter.getValuefromSingleLengthJson(data,
					// "empNbrs").split(",");
					String[] empNbrsAndVisaType = empNbrAndVisaTypes.split(",");
					int[] empNbrsDel = new int[empNbrsAndVisaType.length];
					for (int i = 0; i < empNbrsAndVisaType.length; i++) {
						empNbrsDel[i] = Integer.parseInt(empNbrsAndVisaType[i]);
					}
					if (empNbrsAndVisaType.length == 0) {
						throw new VisaTrackingClientException("Empty input.");
					}
					AssociateManager manager = AssociateManager.getInstance();
					responseHeader = manager.softDelete(empNbrsDel);
					response.setHeader(responseHeader);
				} else {
					throw new VisaTrackingClientException("Empty input.");
				}
			} catch (VisaTrackingClientException ce) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(
						response.getHeader(), ce));
			} catch (VisaTrackingException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(
						response.getHeader(), se));
			}
		}
		return GsonConverter.toJson(response);
	}

	@POST
	@Path("/update")
	public String update(@FormParam("data") String data,
			@FormParam("version") @DefaultValue("1") int version)
			throws ParseException {
		GenericResponse response = new GenericResponse();
		switch (version) {
		case 1:
			try {
				if (VisaTrackingUtil.isNotEmptyString(data)) {
					EditEmpVisaRequest updateAssociateRequest = (EditEmpVisaRequest) GsonConverter
							.fromJson(data, EditEmpVisaRequest.class);
					AssociateManager manager = AssociateManager.getInstance();
					ResponseHeaderDTO header = manager.update(
							updateAssociateRequest.getAssociateDetails(),
							updateAssociateRequest.getLoggedInempNbr());
					response.setHeader(header);
				} else {
					throw new VisaTrackingClientException("Empty input.");
				}
			} catch (VisaTrackingClientException ce) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(
						response.getHeader(), ce));
			} catch (VisaTrackingException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(
						response.getHeader(), se));
			}
		}
		return GsonConverter.toJson(response);
	}

	@POST
	@Path("/updateStatus")
	public String updateStatus(@FormParam("data") String data,
			@FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		switch (version) {
		case 1:
			try {
				if (VisaTrackingUtil.isNotEmptyString(data)) {
					EditStatusDTO updateAssociateRequest = (EditStatusDTO) GsonConverter
							.fromJson(data, EditStatusDTO.class);

					AssociateManager manager = AssociateManager.getInstance();
					ResponseHeaderDTO header = manager
							.updateStatus(updateAssociateRequest);

					response.setHeader(header);
				} else {
					throw new VisaTrackingClientException("Empty input.");
				}
			} catch (VisaTrackingClientException ce) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(
						response.getHeader(), ce));
			} catch (VisaTrackingException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(
						response.getHeader(), se));
			}
		}
		return GsonConverter.toJson(response);
	}

	@POST
	@Path("/prepopulate")
	public String prepopulate(@FormParam("data") String data,
			@FormParam("version") @DefaultValue("1") int version)
			throws ParseException {
		PrepopulateResponse response = new PrepopulateResponse();
		switch (version) {
		case 1:
			try {
				if (VisaTrackingUtil.isNotEmptyString(data)) {
					SearchRequest empNumber = (SearchRequest) GsonConverter
							.fromJson(data, SearchRequest.class);
					AssociateManager manager = AssociateManager.getInstance();

					response = manager.prepopulate(empNumber.getEmpNbr());

				} else {
					throw new VisaTrackingClientException("Empty input.");
				}

			} catch (VisaTrackingClientException ce) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(
						response.getHeader(), ce));
			} catch (VisaTrackingException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(
						response.getHeader(), se));
			}
		}
		return GsonConverter.toJson(response);
	}
	@POST
	@Path("/undodelete")
	public String undoDelete(@FormParam("data") String data,
			@FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		switch (version) {
		case 1:
			try {
				if (VisaTrackingUtil.isNotEmptyString(data)) {
					UndoDeleteRequest undo = (UndoDeleteRequest) GsonConverter
							.fromJson(data, UndoDeleteRequest.class);

					AssociateManager manager = AssociateManager.getInstance();
					ResponseHeaderDTO header = manager
							.undoDelete(undo);

					response.setHeader(header);
				} else {
					throw new VisaTrackingClientException("Empty input.");
				}
			} catch (VisaTrackingClientException ce) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(
						response.getHeader(), ce));
			} catch (VisaTrackingException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(
						response.getHeader(), se));
			}
		}
		return GsonConverter.toJson(response);
	}

}
