package com.service;

import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import com.dao.EmpVisaDetailsDAO;
import com.dto.EmpVisaDTO;
import com.dto.ResponseHeaderDTO;
import com.dto.WorkflowDTO;
import com.exception.VisaTrackingServiceException;
import com.manager.AddEmpVisaDetailsManager;
import com.manager.VisaWorkflowManager;
import com.request.dto.AddEmpVisaRequest;
import com.response.dto.AddEmpVisaResponse;
import com.response.dto.GenericResponse;
import com.response.dto.VisaWorkflowResponse;
import com.util.GsonConverter;
import com.util.VisaTrackingUtil;

@Path("/visaAdd")
public class AddEmpVisaService {

	@POST
	@Path("/addEmpVisaDetails")
	public String update(@FormParam("data") String data,@FormParam("loggedInEmployee") int loggedInEmp) {
		AddEmpVisaResponse response= new AddEmpVisaResponse();
		AddEmpVisaRequest request= new AddEmpVisaRequest();
		EmpVisaDTO empVisaDTO=new EmpVisaDTO();
		String responseStatus="";
			try {
				request=(AddEmpVisaRequest)GsonConverter.fromJson(data, AddEmpVisaRequest.class);
				/*if (TMSUtil.isNotEmptyString(data)) {
					CreateAssociateRequest updateAssociateRequest = (CreateAssociateRequest) GsonConverter.fromJson(data,
							CreateAssociateRequest.class);
							{"associateDetails":{"empNbr":"994100"...,"firstName":"test1"...,"lastName":"user"...,
							"visaType":1...,"skillSet":"java"...,
							"projectType":"Support"...,"travelPeriod":"24"...,
							"travelTo":"atlanta-us"...,"initialStatus":"new"...,"businessCase":"ok"...,"startDateRequirement":"2015-07-02"...,"billingRate":"100"...,
							"potentialLoss":"NA"...,"portfolio":Stores"},"loggedInempNbr":500002} 
							*/
				int loggedInempNbr=request.getLoggedInempNbr();
				empVisaDTO=request.getAssociateDetails();
				empVisaDTO.setDeletionStatus("N");
				empVisaDTO.setVisaStatusCd(1);// condition that this should be 1
				empVisaDTO.setSubmittedUserId(loggedInempNbr);
					AddEmpVisaDetailsManager manager= AddEmpVisaDetailsManager.getInstance();
					//need to change this workflow request
					responseStatus = manager.addEmpVisaDetails(loggedInempNbr, empVisaDTO);
				/*} else {
					throw new TMSClientException("Empty input.");
				}*/
			} catch (VisaTrackingServiceException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(response.getHeader(), se));
				responseStatus=GsonConverter.toJson(response);
			}
		return responseStatus;
	}
	
	@POST
	@Path("/edit")
	public String edit(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		return GsonConverter.toJson(response);
	}
	
	@POST
	@Path("/approveRevert")
	public String approveRevert(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		return GsonConverter.toJson(response);
	}
	
	@POST
	@Path("/search")
	public String search(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		return GsonConverter.toJson(response);
	}
	
	@POST
	@Path("/reject")
	public String reject(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		return GsonConverter.toJson(response);
	}
	
	@POST
	@Path("/newStatus")
	public String changedStatus(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		return GsonConverter.toJson(response);
	}
	
	@DELETE
	@Path("/archiveOld")
	public String delete(@FormParam("empNumber") int empNumber, @FormParam("loggedIn") int loggedIn, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		return GsonConverter.toJson(response);
	}
}
