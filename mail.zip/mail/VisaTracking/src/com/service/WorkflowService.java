package com.service;

import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import com.dto.ResponseHeaderDTO;
import com.dto.WorkflowDTO;
import com.exception.VisaTrackingServiceException;
import com.manager.VisaWorkflowManager;
import com.response.dto.GenericResponse;
import com.response.dto.VisaWorkflowResponse;
import com.util.GsonConverter;
import com.util.VisaTrackingUtil;

@Path("/visa")
public class WorkflowService {

	@GET
	@Path("/updateApproval")
	public String update(/*@FormParam("empNumber") int empNumber, @FormParam("approvalStatus") String approvalStatus, @FormParam("comments") String comments,
			@FormParam("loggedInEmployee") int loggedInEmp,
			@FormParam("version") @DefaultValue("1") int version*/) {
		VisaWorkflowResponse response = new VisaWorkflowResponse();
		ResponseHeaderDTO header=new ResponseHeaderDTO();
		int version=1;
		int empNumber=123456;
		int approvalStatus= 2;
		int loggedInEmp=200002;
		String comments="Approved";
		switch (version) {
		case 1:
			try {
				/*if (TMSUtil.isNotEmptyString(data)) {
					CreateAssociateRequest updateAssociateRequest = (CreateAssociateRequest) GsonConverter.fromJson(data,
							CreateAssociateRequest.class);*/
					
					VisaWorkflowManager manager = VisaWorkflowManager.getInstance();
					//need to change this workflow request
					String workflow = manager.updateVisaStatus(empNumber, comments, approvalStatus,loggedInEmp);
					WorkflowDTO workflowDTO=(WorkflowDTO)GsonConverter.fromJson(workflow, WorkflowDTO.class);
					response.setVisa_tracker(workflowDTO);
					if(workflowDTO.isResultStatus()){
						header.setStatus(1);
					}else{
						header.setStatus(0);
					}
					
					response.setHeader(header);
				/*} else {
					throw new TMSClientException("Empty input.");
				}*/
			} catch (VisaTrackingServiceException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(response.getHeader(), se));
			}
		}
		return GsonConverter.toJson(response);
	}
	
	@POST
	@Path("/edit")
	public String edit(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		return GsonConverter.toJson(response);
	}
	
	@POST
	@Path("/approveRevert")
	public String approveRevert(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		return GsonConverter.toJson(response);
	}
	
	@POST
	@Path("/search")
	public String search(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		return GsonConverter.toJson(response);
	}
	
	@POST
	@Path("/reject")
	public String reject(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		return GsonConverter.toJson(response);
	}
	
	@POST
	@Path("/newStatus")
	public String changedStatus(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		return GsonConverter.toJson(response);
	}
	
	@DELETE
	@Path("/archiveOld")
	public String delete(@FormParam("empNumber") int empNumber, @FormParam("loggedIn") int loggedIn, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		return GsonConverter.toJson(response);
	}
}
