package com.service;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import com.dto.ResponseHeaderDTO;
import com.exception.VisaTrackingClientException;
import com.exception.VisaTrackingServiceException;
import com.manager.AuthenticateManager;
import com.manager.MasterDetailsManager;
import com.request.dto.AuthenticateRequest;
import com.request.dto.ChangePasswordRequest;
import com.response.dto.AuthenticateResponse;
import com.response.dto.GenericResponse;
import com.util.ApplicationConstants;
import com.util.GsonConverter;
import com.util.VisaTrackingUtil;
@Path("/auth")
public class AuthService {

	@POST
	@Path("/login")
	public String authenticate(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		AuthenticateResponse response = new AuthenticateResponse();
		switch (version) {
		case 1:
			try {
				if (VisaTrackingUtil.isNotEmptyString(data)) {
					AuthenticateRequest authenticateRequest = (AuthenticateRequest) GsonConverter.fromJson(data, AuthenticateRequest.class);

					AuthenticateManager manager = AuthenticateManager.getInstance();
					response = manager.authenticate(authenticateRequest);
					MasterDetailsManager masterManager= MasterDetailsManager.getInstance();
					response.setMasterDetails(masterManager.getMasterDetails());
					if(response.getUserDetails() != null)
					{
						if(response.getUserDetails().getRoleCd() == ApplicationConstants.EMP_ROLE_TM 
						|| response.getUserDetails().getRoleCd() == ApplicationConstants.EMP_ROLE_ML
						|| response.getUserDetails().getRoleCd() == ApplicationConstants.EMP_ROLE_PL
						|| response.getUserDetails().getRoleCd() == ApplicationConstants.EMP_ROLE_NA
						|| response.getUserDetails().getRoleCd() == ApplicationConstants.EMP_ROLE_PMO)
						{
							if((response.getUserDetails().getPortfolioCd() != 7))
							{
								response.getHeader().setStatus(ApplicationConstants.VALIDATION_ERROR_STATUS);
								response.getHeader().setMessage("You are not authorized to login to the Application.");
								response.setUserDetails(null);
							}
						}
					}

				} else {
					throw new VisaTrackingClientException("Empty input.");
				}
			} catch (VisaTrackingClientException ce) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(response.getHeader(), ce));
			} catch (VisaTrackingServiceException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(response.getHeader(), se));
			}
		}
		return GsonConverter.toJson(response);
	}
	
	
	@POST
	@Path("/externallogin")
	public String externalAuthenticate(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		AuthenticateResponse response = new AuthenticateResponse();
		switch (version) {
		case 1:
			try {
				if (VisaTrackingUtil.isNotEmptyString(data)) {
					AuthenticateRequest authenticateRequest = (AuthenticateRequest) GsonConverter.fromJson(data, AuthenticateRequest.class);

					AuthenticateManager manager = AuthenticateManager.getInstance();
					response = manager.authenticate(authenticateRequest);

				} else {
					throw new VisaTrackingClientException("Empty input.");
				}
			} catch (VisaTrackingClientException ce) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(response.getHeader(), ce));
			} catch (VisaTrackingServiceException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(response.getHeader(), se));
			}
		}

		return GsonConverter.toJson(response);
	}

	
	@POST
	@Path("/changePasswordFirstTime")
	public String changePasswordFirstTime(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		AuthenticateResponse response = new AuthenticateResponse();
		switch (version) {
		case 1:
			try {
				if (VisaTrackingUtil.isNotEmptyString(data)) {
					ChangePasswordRequest changePasswordRequest = (ChangePasswordRequest) GsonConverter.fromJson(data, ChangePasswordRequest.class);

					AuthenticateManager manager = AuthenticateManager.getInstance();
					response = manager.changePasswordFirstTime(changePasswordRequest);
 
					if(response.getUserDetails() != null)
					{
						if(response.getUserDetails().getRoleCd() != 4 && response.getUserDetails().getRoleCd() != 5)
						{
							response.getHeader().setStatus(ApplicationConstants.VALIDATION_ERROR_STATUS);
							response.getHeader().setMessage("Your Password has been Changed.");
							response.setUserDetails(null);
						}
					}
					
			 		
				} else {
					throw new VisaTrackingClientException("Empty input.");
				}
			} catch (VisaTrackingClientException ce) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(response.getHeader(), ce));
			} catch (VisaTrackingServiceException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(response.getHeader(), se));
			}
		}

		return GsonConverter.toJson(response);
	}
	
	@POST
	@Path("/changePassword")
	public String changePassword(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		switch (version) {
		case 1:
			try {
				if (VisaTrackingUtil.isNotEmptyString(data)) {
					ChangePasswordRequest changePasswordRequest = (ChangePasswordRequest) GsonConverter.fromJson(data, ChangePasswordRequest.class);

					AuthenticateManager manager = AuthenticateManager.getInstance();
					ResponseHeaderDTO responseHeader = manager.changePassword(changePasswordRequest);

					response.setHeader(responseHeader);
				} else {
					throw new VisaTrackingClientException("Empty input.");
				}
			} catch (VisaTrackingClientException ce) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(response.getHeader(), ce));
			} catch (VisaTrackingServiceException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(response.getHeader(), se));
			}
		}

		return GsonConverter.toJson(response);
	}

	@POST
	@Path("/resetPassword")
	public String resetPassword(@FormParam("data") String data, @FormParam("version") @DefaultValue("1") int version) {
		GenericResponse response = new GenericResponse();
		switch (version) {
		case 1:
			try {
				if (VisaTrackingUtil.isNotEmptyString(data)) {
					AuthenticateRequest resetPasswordRequest = (AuthenticateRequest) GsonConverter.fromJson(data, AuthenticateRequest.class);

					AuthenticateManager manager = AuthenticateManager.getInstance();
					ResponseHeaderDTO responseHeader = manager.resetPassword(resetPasswordRequest);

					response.setHeader(responseHeader);
				} else {
					throw new VisaTrackingClientException("Empty input.");
				}
			} catch (VisaTrackingClientException ce) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(response.getHeader(), ce));
			} catch (VisaTrackingServiceException se) {
				response.setHeader(VisaTrackingUtil.prepareErrorResponseHeader(response.getHeader(), se));
			}
		}

		return GsonConverter.toJson(response);
	}

}
