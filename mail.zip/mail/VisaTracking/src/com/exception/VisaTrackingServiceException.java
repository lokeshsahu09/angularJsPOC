/**
 * This program is proprietary to The Home Depot and is not to be reproduced,
 * used, or disclosed without permission of:
 * 
 *    The Home Depot
 *    2455 Paces Ferry Road, NW
 *    Atlanta, GA 30339-4024
 *
 *  FileName : ICONXServceException
 */
package com.exception;

/**
 * Custom exception class extending IconXException for servce exceptions.
 * 
 * @author TCS
 */
public class VisaTrackingServiceException extends VisaTrackingException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2644014650738643571L;

	/**
	 * Constructor for error code.
	 * 
	 * @param errorCode
	 */
	public VisaTrackingServiceException(int errorCode) {
		super(errorCode);
	}

	/**
	 * Constructor for error code and Throwable.
	 * 
	 * @param errorCode
	 */
	public VisaTrackingServiceException(int errorCode, Throwable cause) {
		super(errorCode, cause);
	}

	/**
	 * Constructor when technical error occurs.
	 * 
	 * @param developerMessage
	 */
	public VisaTrackingServiceException(String developerMessage) {
		super(developerMessage);
	}

	/**
	 * Constructor to convert other exceptions to IConXException.
	 * 
	 * @param cause
	 */
	public VisaTrackingServiceException(Throwable cause) {
		super(cause);
	}

	/**
	 * Constructor for error code and status code.
	 * 
	 * @param errorCode
	 * @param statusCode
	 */
	public VisaTrackingServiceException(int errorCode, int statusCode) {
		super(errorCode, statusCode);
	}

	/**
	 * Constructor for error code, status code and Throwable.
	 * 
	 * @param errorCode
	 * @param statusCode
	 */
	public VisaTrackingServiceException(int errorCode, int statusCode, Throwable cause) {
		super(errorCode, statusCode, cause);
	}

	/**
	 * Constructor when technical error occurs during COS call.
	 * 
	 * @param developerMessage
	 * @param cosDataToDebug
	 */
	public VisaTrackingServiceException(String developerMessage, String cosDataToDebug) {
		super(developerMessage, cosDataToDebug);
	}

	/**
	 * Constructor for developer message and Throwable.
	 * 
	 * @param developerMessage
	 * @param cause
	 */
	public VisaTrackingServiceException(String developerMessage, Throwable cause) {
		super(developerMessage, cause);
	}

	/**
	 * Constructor for error code, developer message and COS data.
	 * 
	 * @param errorCode
	 * @param developerMessage
	 * @param cosDataToDebug
	 */
	public VisaTrackingServiceException(int errorCode, String developerMessage, String cosDataToDebug) {
		super(errorCode, developerMessage, cosDataToDebug);
	}

	/**
	 * Constructor when technical error occurs during COS call.
	 * 
	 * @param developerMessage
	 * @param cosDataToDebug
	 */
	public VisaTrackingServiceException(String developerMessage, String cosDataToDebug, Throwable cause) {
		super(developerMessage, cosDataToDebug, cause);
	}
}
