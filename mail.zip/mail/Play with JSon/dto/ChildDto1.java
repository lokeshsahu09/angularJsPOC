package com.tcs.dto;

import java.util.List;

public class ChildDto1 {
	private String childdtodata;
	private String childdtodata2;
	private List<ChildDto2> childDto2;
	public String getChilddtodata() {
		return childdtodata;
	}
	/**
	 * @param childdtodata the childdtodata to set
	 */
	public void setChilddtodata(String childdtodata) {
		this.childdtodata = childdtodata;
	}
	/**
	 * @return the childDto2
	 */
	public List<ChildDto2> getChildDto2() {
		return childDto2;
	}
	/**
	 * @param childDto2 the childDto2 to set
	 */
	public void setChildDto2(List<ChildDto2> childDto2) {
		this.childDto2 = childDto2;
	}
	public String getChilddtodata2() {
		return childdtodata2;
	}
	public void setChilddtodata2(String childdtodata2) {
		this.childdtodata2 = childdtodata2;
	}
	

}
