package com.tcs.dto;

import java.util.List;

public class ChildDto2 {
	private String childDto2data;
	private List<ChildDto3> childDto3;
	public String getChildDto2data() {
		return childDto2data;
	}
	/**
	 * @param childDto2data the childDto2data to set
	 */
	public void setChildDto2data(String childDto2data) {
		this.childDto2data = childDto2data;
	}
	/**
	 * @return the childDto3
	 */
	public List<ChildDto3> getChildDto3() {
		return childDto3;
	}
	/**
	 * @param childDto3 the childDto3 to set
	 */
	public void setChildDto3(List<ChildDto3> childDto3) {
		this.childDto3 = childDto3;
	}
	

}
