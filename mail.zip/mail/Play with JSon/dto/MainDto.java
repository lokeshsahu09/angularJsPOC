package com.tcs.dto;

import java.util.List;

public class MainDto {
	private String parentData;
	private List<ChildDto1> childDto;
	
	public List<ChildDto1> getChildDto() {
		return childDto;
	}
	public void setChildDto(List<ChildDto1> childDto) {
		this.childDto = childDto;
	}
	public String getParentData() {
		return parentData;
	}
	public void setParentData(String parentData) {
		this.parentData = parentData;
	}

}
