package com.tcs.dao;

import java.util.ArrayList;

import java.util.List;

import com.tcs.dto.ChildDto1;
import com.tcs.dto.ChildDto2;
import com.tcs.dto.ChildDto3;
import com.tcs.dto.MainDto;
import com.tcs.util.GsonConverter;

public class JsonAddUpdateTest {
	public static void main(String[] args) {
		MainDto main = new MainDto();
		main.setParentData("father");
		List<ChildDto1> childDtoList = new ArrayList<ChildDto1>();
		ChildDto1 child1 = new ChildDto1();
		child1.setChilddtodata("child data1");
		child1.setChilddtodata2("child data2");
		childDtoList.add(child1);
		main.setChildDto(childDtoList);

		List<ChildDto2> childDto2List = new ArrayList<ChildDto2>();
		ChildDto2 childDto2 = new ChildDto2();
		childDto2.setChildDto2data("child data2");
		childDto2List.add(childDto2);
		child1.setChildDto2(childDto2List);

		List<ChildDto3> childDto3List = new ArrayList<ChildDto3>();
		ChildDto3 childDto3 = new ChildDto3();
		childDto3.setAge("25");
		childDto3.setName("lokesh sahu");
		childDto3List.add(childDto3);
		childDto2.setChildDto3(childDto3List);

		String str = GsonConverter.toJson(main);
		callingPrint(str);
		

	}

	public static void callingPrint(String str) {

		MainDto main = (MainDto) GsonConverter.fromJson(str, MainDto.class);
		List<ChildDto1> childDto1List = main.getChildDto();

		
		
		for (ChildDto1 childDto1 : childDto1List) {

			for (ChildDto2 childDto2 : childDto1.getChildDto2()) {

				for (ChildDto3 childDto3 : childDto2.getChildDto3())
				{
					List<ChildDto3> childDto3List=new ArrayList<ChildDto3>();
					//updating json object with exisitng json
					
					/*childDto3List.add(childDto3);
					childDto3.setAge("29");
					childDto3.setName("sahu1");
					childDto3List.add(childDto3);
					String str1=GsonConverter.toJson(main);
					System.out.println("str1...."+str1);*/
					
					
					
					// adding new json object in last
					
					childDto3List.add(childDto3);
					ChildDto3 addnewObj = new ChildDto3();
					addnewObj.setAge("29");
					addnewObj.setName("sahu1");
					childDto3List.add(addnewObj);
					childDto2.setChildDto3(childDto3List);
					String str1=GsonConverter.toJson(main);
					System.out.println("str1...."+str1);
				}
				

			}
		}

	}

}
