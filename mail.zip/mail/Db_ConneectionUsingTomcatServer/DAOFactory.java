/**
 * This program is proprietary to The Home Depot and is not to be reproduced,
 * used, or disclosed without permission of:
 *    The Home Depot
 *    2455 Paces Ferry Rd, N.W.
 *    Atlanta, GA, 30339-4024
 *
 * FileName : DAOFactory
 */

package com.dao.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.exception.NanoServiceException;

public class DAOFactory {
	// Name used to retrieve the application servers JNDI context.
		private static final String CONTAINER_JNDI_NAME = "java:comp/env";

		private static DAOFactory singleton;
		// Object cache.
		private static Map<String, DataSource> mObjectCache;
		// JNDI context used to retrieve objects.
		private static Context mJNDIContext;

		/**
		 * Private Constructor to avoid instantiating the class as all the methods in class are static.
		 * 
		 * @throws NamingException
		 */
		private DAOFactory() throws NamingException {
			// Get an instance of the application servers JNDI context.
			mJNDIContext = (Context) new InitialContext().lookup(CONTAINER_JNDI_NAME);

			// initialize the object cache
			mObjectCache = Collections.synchronizedMap(new HashMap<String, DataSource>());
		}

		/**
		 * This function is used to retrieve the ServceLocator singleton instance. If the singleton has not been initialized yet, this function
		 * enters a synchronized block to create it.
		 * 
		 * @return The ServceLocator singleton instance
		 * 
		 * @throws NamingException
		 *             Thrown if a NamingException occurs retrieving an instance of the Application Servers JNDI context.
		 */
		public static synchronized DAOFactory getInstance() throws NamingException {
			// check to see if the singleton has been initialized already
			if (singleton == null) {
				// the singleton has not been initialized yet, enter a synchronized block
				// Creating new instance.
				singleton = new DAOFactory();
			}

			return singleton;
		}

		/**
		 * This function retrieves the named DataSource. First check is to the object cache. If the datasource does not exist in the object
		 * cache, it will be retrieved from the Application Server JNDI context instance and put into the cache.
		 * 
		 * @param jndiName
		 *            JNDI name of the DataSource to retrieve
		 * 
		 * @return DataSource object that can be used to create database connections
		 * 
		 * @throws NamingException
		 *             Thrown if a NamingException occurs retrieving the named DataSource from the Application Servers JNDI context.
		 */
		public DataSource getDataSource(String jndiName) throws NamingException {
			DataSource dataSource = null;

			// Check the object cache for the named DataSource. If the DataSource is found in the object cache, return it
			// from there. Otherwse retrieve the DataSouce from the Application Servers JNDI context and add it to the
			// object cache.
			if (mObjectCache.containsKey(jndiName)) {
				dataSource = (DataSource) mObjectCache.get(jndiName);
			} else {
				// Lookup the DataSource.
				dataSource = (DataSource) mJNDIContext.lookup(jndiName);
				// Add the DataSource to the object cache.
				mObjectCache.put(jndiName, dataSource);
			}

			return dataSource;
		}

		/**
		 * This method gets connection for the data source given and returns the same.
		 * 
		 * @param dataSrc
		 * @return
		 * 
		 * @throws SQLException
		 * @throws NanoServiceException
		 */
		public static Connection getConnection(String dataSrc) throws SQLException, NanoServiceException {
			Connection connection;

			try {
				// Get the ServiceLocator singleton instance.
				DAOFactory svcLocator = DAOFactory.getInstance();
				// Use the ServiceLocator singleton to get the DataSource.
				DataSource dataSource = svcLocator.getDataSource(dataSrc);
				// Use the DataSource to create a Database Connection.
				connection = dataSource.getConnection();
			} catch (NamingException ne) {
				throw new NanoServiceException(ne);
			}

			return connection;
		}

		/**
		 * This method gets connection for the data source given and returns the same.
		 * 
		 * @return
		 * 
		 * @throws SQLException
		 * @throws NanoServiceException
		 */
		public static Connection getConnection() throws SQLException, NanoServiceException {
			Connection conn = getConnection("jdbc/NANO-SQL.001");

			return conn;
		}

		/**
		 * This method creates a connection in manual commit mode and returns the same.
		 * 
		 * @return
		 * 
		 * @throws NanoServiceException
		 * @throws SQLException
		 */
		public static Connection getConnectionInManualCommitMode() throws NanoServiceException, SQLException {
			// Getting connection for PR4.005
			Connection connection = null;
			connection = DAOFactory.getConnection();
			// Setting auto commit to false for manual control of commit.
			connection.setAutoCommit(false);

			return connection;
		}

	/**
	 * This method can be used to close ResultSet, PreparedStatement and Connection. SQL Exception which might occur while closing will be
	 * suppressed.
	 * 
	 * @param rs
	 * @param preparedStatement
	 * @param connection
	 */
	public static void close(ResultSet rs, PreparedStatement preparedStatement, Connection connection) {
		// If a ResultSet was passed in, close it suppressing any exceptions.
		if (null != rs) {
			try {
				rs.close();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		}

		// If a Statement was passed in, close it suppressing any exceptions.
		if (null != preparedStatement) {
			try {
				preparedStatement.close();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		}

		// If a Connection was passed in, release it suppressing any exceptions.
		if (null != connection) {
			try {
				connection.close();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		}
	}
	
	/**
	 * This method can be used to roll back Connection in case of failure. SQLException will be thrown when there is a problem rolling back.
	 * 
	 * @param connection
	 * 
	 * @throws SQLException
	 */
	public static void rollBackConnection(Connection connection) throws SQLException {
		if (null != connection) {
			try {
				// Rolling back connection.
				connection.rollback();
			} catch (SQLException sqe) {
				sqe.printStackTrace();
			}

		}
	}

	/**
	 * This method can be used to set values to prepared statement.
	 * 
	 * @param preparedStatement
	 * @param values
	 * 
	 * @throws SQLException
	 */
	public static void setValues(PreparedStatement preparedStatement, Object... values) throws SQLException {
		// Setting values to prepared statement.
		for (int i = 0; i < values.length; i++) {
			preparedStatement.setObject(i + 1, values[i]);
		}
	}
}
