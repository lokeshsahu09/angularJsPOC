package com.sample.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("success")
public class SuccessDTO {
	int code;
	String message;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
