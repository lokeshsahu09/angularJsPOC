package com.sample.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;


@XStreamAlias("employee")
public class Employee {
	int employeeId=1;
	String employeeName;

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

}
