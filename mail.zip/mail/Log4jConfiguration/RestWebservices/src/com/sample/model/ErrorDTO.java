package com.sample.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("error")
public class ErrorDTO {
	int errorCode;
	String errorMessage;

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
