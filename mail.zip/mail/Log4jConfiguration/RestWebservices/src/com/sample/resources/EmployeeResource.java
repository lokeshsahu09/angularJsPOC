package com.sample.resources;

import javax.ws.rs.*;

import com.sample.model.Employee;
import com.xml.XMLGenerator;

@Path("employee")
public class EmployeeResource {
/*
 * this class is for get and post employee detals by using
 * REST Full web services
 */
	
	/*
	 * This method is for getting employee details by using employee details
	 * and employeeName
	 * @return String
	 */
	@GET
	@Path("search")
	@Produces("application/xml")
	public String getEmployeeDetails(
			@DefaultValue("1") @QueryParam("version") int version,
			@QueryParam("employeeId") int employeeId,
			@QueryParam("employeeName") String employeeName){
		String result = null;
		System.out.println("reached");
		try {
			switch (version) {
			case 1:
				if (employeeName == null && employeeId == 0) {
					throw new Exception("Invalid parameters");
				} else {
					Employee emp = new Employee();
					emp.setEmployeeId(employeeId);
					emp.setEmployeeName(employeeName);
					result = XMLGenerator.generateXML(emp);
				}
				break;
			default:
				throw new Exception("Invalid version number");
			}
		} catch (Exception e) {
			result = XMLGenerator.generateErrorXML(e);
		}
		return result;
	}

	/*
	 * This method is for maintain employee details by using employee details
	 * and employeeName
	 * @return String
	 */
	@POST
	@Path("maintain")
	@Produces("application/xml")
	public String maintainEmployeeDetails(
			@DefaultValue("1") @QueryParam("version") int version,
			@FormParam("inputData") String inputData) {
		String result = null;
		try {
			switch (version) {
			case 1:
				if (inputData == null || inputData.length() <1) {
					throw new Exception("Invalid data");
				} else {
					Employee emp = (Employee)XMLGenerator.generateTOfromXML(inputData);
					result=XMLGenerator.generateSuccessXML(emp.getEmployeeName()+" parsed successfully");
				}
				break;
			default:
				throw new Exception("Invalid version number");
			}
		} catch (Exception e) {
			result = XMLGenerator.generateErrorXML(e);
		}
		System.out.println("maintain "+result);
		return result;
	}
}
