package com.sample.client;


import java.net.URI;
import javax.ws.rs.core.UriBuilder;
import com.sample.model.Employee;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.representation.Form;
import com.xml.XMLGenerator;


public class Tester {
  public static void main(String[] args) {
    ClientConfig config = new DefaultClientConfig();
    Client client = Client.create(config);
    WebResource service = client.resource(getBaseURI());
    Employee employee = new Employee();
    employee.setEmployeeId(3);
    employee.setEmployeeName("srinivas");
    
    String response = service.path("rest").path("employee").path("search")
        .queryParam("employeeId", "1").get(String.class);
    // Return code should be 201 == created resource
    System.out.println(response);

    response = service.path("rest").path("employee").path("search")
    .queryParam("employeeName", "ram").get(String.class);
    // Return code should be 201 == created resource
    System.out.println(response);

    Form form = new Form();
    form.add("inputData", XMLGenerator.generateXML(employee));
    service.path("rest").path("employee").path("maintain")
        .post(form);
  }

  private static URI getBaseURI() {
    return UriBuilder.fromUri("http://localhost:9999/CaseStudyREST").build();
  }
} 