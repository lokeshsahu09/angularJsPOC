package com.xml;

import com.sample.model.Employee;
import com.sample.model.ErrorDTO;
import com.sample.model.SuccessDTO;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

public final class XMLGenerator {
/*
 * this class is for generating XML	
 */
	
	/*
	 * initialization of XStream class 
	 */
	private static XStream xstream = new XStream(new DomDriver())
	{{
		processAnnotations(Employee.class);
		processAnnotations(ErrorDTO.class);
		processAnnotations(SuccessDTO.class);
	}};
	
	/*
	 * This class is for generating XML from MODEL class
	 * @param Object
	 * @return String 
	 */
	public static String generateXML(Object to) {
		return null == to ? "" : xstream.toXML(to);
	}

	/*
	 * Generates the transfer object from the given XML using XStream.
	 * 
	 * @param String
	 * @return transfer object
	 */
	public static Object generateTOfromXML(String xml) {
		return xstream.fromXML(xml);
	}
	
	/*
	 * this method is for generating error xml
	 * @param exception - Exception
	 * @return String
	 */
	public static String generateErrorXML(Exception exception) {
		
		ErrorDTO errorTO = new ErrorDTO();
		errorTO.setErrorCode(-1);
		errorTO.setErrorMessage(exception.getMessage());
        return generateXML(errorTO);
	}

	/*
	 * Sets the error details to the ResponseDTO from the given Exception using XStream.
	 * @param String
	 * @return String
	 */
	public static String generateSuccessXML(String message) {
		SuccessDTO successTO = new SuccessDTO();
		successTO.setCode(0);
		successTO.setMessage(message);
        return generateXML(successTO);
	}
}
