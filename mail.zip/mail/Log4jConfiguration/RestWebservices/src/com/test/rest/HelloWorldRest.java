package com.test.rest;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.apache.log4j.Logger;

@Path("/test")
public class HelloWorldRest {
	
	Logger log = Logger.getLogger(HelloWorldRest.class);
	
	
	@GET
	@Path("/hello")
	public String hello()
	{
		//Logger LOGGER = Logger.getLogger(HelloWorldRest.class);
		log.info("This is a logging statement from log4j");
		String hello="Welcome To Restfull web services";
		System.out.println(hello);
		
		return hello;
	}

}
