package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.log4j.Logger;

import com.dao.util.DAOFactory;
import com.dao.util.NanoLearningSQLBuilder;
import com.dto.OptionsDTO;
import com.dto.QAOptionDetailsDTO;
import com.exception.NanoServiceException;
import com.request.dto.ChapterDetailsDTO;
import com.request.dto.GameDetailsRequestDTO;
import com.request.dto.GameScoreDetailsDTO;
import com.response.dto.ChapterDetailsResponseDTO;
import com.response.dto.GameDetailsResponseDTO;
import com.response.dto.GameDetailsTO;
import com.util.LoggerUtil;
import com.util.NanoUtil;

public class GameDetailsDAO
{
	private static final Logger LOGGER = Logger.getLogger(GameDetailsDAO.class);
	
	private static String CLASS_NAME = "GameDetailsDAO";
	
	private static volatile GameDetailsDAO gameDetailsDAO = null;
	
	public static GameDetailsDAO getInstance() 
	{
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getInstance", null);
		
		if(gameDetailsDAO == null) {
			
			LoggerUtil.info(LOGGER, "Singleton instance has not been initialized, entering synchronized block");
			
			gameDetailsDAO = new GameDetailsDAO();
			
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getInstance");
		
		return gameDetailsDAO;
		
	}
	/** 
	 * Description : Execute the SEARCH_GAME_DETAILS Query to retrieve Chapter Information
	 * 
	 * @return detailsRequestDTO
	 * 
	 * @throws SQLException 
	 * 
	 * @throws NanoServiceException 
	 */
	public GameDetailsResponseDTO searchGameDetails(GameDetailsRequestDTO detailsRequestDTO) throws SQLException, NanoServiceException
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "searchGameDetails", null);
		
		GameDetailsResponseDTO gameDetailsResponseDTO = new GameDetailsResponseDTO();
		
		List<QAOptionDetailsDTO> qaOptionDetailsDTOList = new ArrayList<QAOptionDetailsDTO>();
		
		QAOptionDetailsDTO qaOptionDetailsDTO = null;
		
		List<OptionsDTO> optionsDTOList = new ArrayList<OptionsDTO>();
		
		OptionsDTO optionsDTO = null;
		
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		
		Connection connection = null;
		
		PreparedStatement preparedStatement = null;
		
		ResultSet resultSet = null;
		
		
		try 
		{
			connection = DAOFactory.getConnection();
			
			preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.SEARCH_GAME_DETAILS);
			
			DAOFactory.setValues(preparedStatement, detailsRequestDTO.getGameId(), detailsRequestDTO.getChapterId());

			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) 
			{
				
				if(!map.containsKey(resultSet.getInt("question_id")))
				{
					if (!optionsDTOList.isEmpty()) {
						qaOptionDetailsDTO.setOptionsList(optionsDTOList);
						qaOptionDetailsDTOList.add(qaOptionDetailsDTO);
						optionsDTOList = new ArrayList<OptionsDTO>();
					}
					int questionId = resultSet.getInt("question_id");
					map.put(questionId, questionId);
					qaOptionDetailsDTO = new QAOptionDetailsDTO();
					qaOptionDetailsDTO.setQuestionId(questionId);
					qaOptionDetailsDTO.setQuestionFormat(resultSet.getString("question_format"));
					qaOptionDetailsDTO.setQuestion(resultSet.getString("question"));
					qaOptionDetailsDTO.setQuestionOrder(resultSet.getInt("question_order"));
					qaOptionDetailsDTO.setQuestion_tip(resultSet.getString("question_tip"));
					qaOptionDetailsDTO.setClueDescription(resultSet.getString("clue_description"));
					qaOptionDetailsDTO.setQuestionCategory(resultSet.getString("question_category"));
					qaOptionDetailsDTO.setQuestionSubCategory(resultSet.getString("question_subcategory"));
					qaOptionDetailsDTO.setQuestionCorrectScore(resultSet.getInt("question_correctscore"));
					qaOptionDetailsDTO.setQuestionInCorrectScore(resultSet.getInt("question_incorrectscore"));
				}
				optionsDTO = new OptionsDTO();
				
				String optionFormat = resultSet.getString("option_format");
				String option = resultSet.getString("options");
				String isOptionCorrect = resultSet.getString("isoptionCorrect");
				
				optionsDTO.setOptionId(resultSet.getInt("option_id"));
				optionsDTO.setOptionFormat(optionFormat == null ? "" : optionFormat);
				optionsDTO.setOptions(option == null ? "" : option);
				optionsDTO.setIsOptionCorrect(isOptionCorrect == null ? "" : isOptionCorrect);
				optionsDTOList.add(optionsDTO);
			}
			if (!optionsDTOList.isEmpty()) {
				qaOptionDetailsDTO.setOptionsList(optionsDTOList);
				qaOptionDetailsDTOList.add(qaOptionDetailsDTO);
			}
			preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.GET_LEARNING_DETAILS);
			DAOFactory.setValues(preparedStatement, detailsRequestDTO.getChapterId(), detailsRequestDTO.getGameId());
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) 
			{
				gameDetailsResponseDTO.setGameId(resultSet.getInt("game_id"));
				gameDetailsResponseDTO.setChapterId(resultSet.getInt("chapter_id"));
				gameDetailsResponseDTO.setTemplateId(resultSet.getInt("template_id"));
				gameDetailsResponseDTO.setChapterOrderNbr(resultSet.getInt("chapter_orderno"));
				gameDetailsResponseDTO.setChapterTitle(resultSet.getString("chapter_title"));
				gameDetailsResponseDTO.setLearning_format(resultSet.getString("learning_format"));
				gameDetailsResponseDTO.setLearning(resultSet.getString("learning"));
				gameDetailsResponseDTO.setMinScoreCompletion(resultSet.getInt("min_score_completion"));
			}
			gameDetailsResponseDTO.setQuestionOptionsList(qaOptionDetailsDTOList);
		}
		catch(SQLException e)
		{
			throw new NanoServiceException(e);
		}
		finally 
		{
			DAOFactory.close(resultSet, preparedStatement, connection);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "searchGameDetails");
		
		return gameDetailsResponseDTO;
	}
	/** 
	 * Description : Execute the All_GAME_LIST Query to retrieve All game
	 * @param gameKeySearch 
	 * 
	 * @return allGameList
	 * 
	 * @throws SQLException 
	 * 
	 * @throws NanoServiceException 
	 */
	public List<GameDetailsTO> getAllGame(String gameKeySearch) throws SQLException, NanoServiceException{		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getAllGame", null);
		
		Connection connection = null;		
		PreparedStatement preparedStatement = null;		
		ResultSet resultSet = null;
		
		final String All_GAME_LIST = new String("select * from NANO_GAMES where game_title like '%" +gameKeySearch+ "%'"); 
		
		List<GameDetailsTO> allGameList = new ArrayList<GameDetailsTO>();
		GameDetailsTO allGames = null;
		try{
			connection = DAOFactory.getConnection();			
			preparedStatement = connection.prepareStatement(All_GAME_LIST);			
			DAOFactory.setValues(preparedStatement);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) 
			{
				if(resultSet != null){
					allGames = new GameDetailsTO();
					allGames.setGameTitle(resultSet.getString("game_title"));
					allGames.setGameDescription(resultSet.getString("game_description"));
					allGames.setGameID(resultSet.getString("game_ID"));
					allGameList.add(allGames);
				}
				LOGGER.debug("All Game List : "+ allGameList);
			}
			
		}
		finally 
		{
			DAOFactory.close(resultSet, preparedStatement, connection);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getAllGame");
		return allGameList;		
	}
	/** 
	 * Description : Execute the POPULAR_GAME_DTLS_LIST Query to retrieve Popular game Details
	 * 
	 * @return popularGamesList
	 * 
	 * @throws SQLException 
	 * 
	 * @throws NanoServiceException 
	 */
	public List<GameDetailsTO> getPopularGames() throws SQLException, NanoServiceException{		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getPopularGames", null);
		
		Connection connection = null;		
		PreparedStatement preparedStatement = null;		
		ResultSet resultSet = null;
		
		List<GameDetailsTO> popularGamesList = new ArrayList<GameDetailsTO>();
		GameDetailsTO popularGames = null;
		try{
			connection = DAOFactory.getConnection();			
			preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.POPULAR_GAME_DTLS_LIST);			
			DAOFactory.setValues(preparedStatement);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) 
			{
				if(resultSet != null){
					popularGames = new GameDetailsTO();
					popularGames.setGameTitle(resultSet.getString("game_title"));
					popularGames.setGameDescription(resultSet.getString("game_description"));
					popularGamesList.add(popularGames);
				}
				LOGGER.debug("Popular Games List : "+ popularGamesList);
			}
			
		}
		finally 
		{
			DAOFactory.close(resultSet, preparedStatement, connection);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getPopularGames");
		return popularGamesList;		
	}
	/** 
	 * Description :  Execute the ASSIGNED_GAME_DTLS_LIST Query to retrieve Assigned game Details 
	 * 
	 * @return popularGamesList
	 * 
	 * @throws SQLException 
	 * 
	 * @throws NanoServiceException 
	 */
	public List<GameDetailsTO> getAssignedGames(int employeeId) throws SQLException, NanoServiceException{		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getAssignedGames", null);
		
		Connection connection = null;		
		PreparedStatement preparedStatement = null;		
		ResultSet resultSet = null;
		
		List<GameDetailsTO> assignedGamesList = new ArrayList<GameDetailsTO>();
		GameDetailsTO assignedGames = null;
		try{
			connection = DAOFactory.getConnection();			
			preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.ASSIGNED_GAME_DTLS_LIST);			
			DAOFactory.setValues(preparedStatement, employeeId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) 
			{
				if(resultSet != null){
					assignedGames = new GameDetailsTO();
					assignedGames.setGameTitle(resultSet.getString("game_title"));
					assignedGames.setGameDescription(resultSet.getString("game_description"));
					assignedGamesList.add(assignedGames);
				}
				LOGGER.debug("Assigned Games List : "+ assignedGamesList);
			}
			
		}
		finally 
		{
			DAOFactory.close(resultSet, preparedStatement, connection);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getAssignedGames");
		return assignedGamesList;		
	}
	/** 
	 * Description : Execute the NEWFEED_GAME_DTLS_LIST Query to retrieve Assigned game Details 
	 * 
	 * @return popularGamesList
	 * 
	 * @throws SQLException 
	 * 
	 * @throws NanoServiceException 
	 */
	public List<GameDetailsTO> getNewFeedGames() throws SQLException, NanoServiceException{		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getNewFeedGames", null);
		
		Connection connection = null;		
		PreparedStatement preparedStatement = null;		
		ResultSet resultSet = null;
		
		List<GameDetailsTO> newFeedGamesList = new ArrayList<GameDetailsTO>();
		GameDetailsTO newFeedGames = null;
		try{
			connection = DAOFactory.getConnection();			
			preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.NEWFEED_GAME_DTLS_LIST);			
			DAOFactory.setValues(preparedStatement);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) 
			{
				if(resultSet != null){
					newFeedGames = new GameDetailsTO();
					newFeedGames.setGameTitle(resultSet.getString("game_title"));
					newFeedGames.setGameDescription(resultSet.getString("game_description"));
					newFeedGamesList.add(newFeedGames);
				}
				LOGGER.debug("NewFeed Games List : "+ newFeedGamesList);
			}
			
		}
		finally 
		{
			DAOFactory.close(resultSet, preparedStatement, connection);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getNewFeedGames");
		return newFeedGamesList;		
	}
	/** 
	 * Description : Execute the NEWFEED_GAME_DTLS_LIST Query to retrieve Assigned game Details 
	 * 
	 * @return popularGamesList
	 * 
	 * @throws SQLException 
	 * 
	 * @throws NanoServiceException 
	 * @throws ParseException 
	 */
	public boolean updateGameScore(GameScoreDetailsDTO scoreDetailsDTO) throws NanoServiceException, ParseException
	{
		Connection connection = null;		
		PreparedStatement preparedStatement = null;		
		ResultSet resultSet = null;
		int updateStatus = 0;
		try
		{
			connection = DAOFactory.getConnection();	
			
			Time gameTimeSpent = NanoUtil.getTimeFromString(scoreDetailsDTO.getGameTimeSpent());
			
			preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.GET_NO_OF_GAME_ATTEMPTS);			
			DAOFactory.setValues(preparedStatement, scoreDetailsDTO.getEmployeeId(), scoreDetailsDTO.getGameId());
			resultSet = preparedStatement.executeQuery();
			int attemptNbr = 0;
			
			//Do update operations if the player record is present else insert a new record for the player
			
			if (resultSet.next()) 
			{
				attemptNbr = resultSet.getInt("game_noofattempts");
				
				if(attemptNbr == 0)
				{
					preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.UPDATE_FIRST_ATEMPT_GAME_SCORE);			
					DAOFactory.setValues(preparedStatement, scoreDetailsDTO.getGameScore(), scoreDetailsDTO.getGameScore(), gameTimeSpent, scoreDetailsDTO.getEmployeeId(), scoreDetailsDTO.getGameId());
					updateStatus = preparedStatement.executeUpdate();
				}
				else if(attemptNbr > 0)
				{
					preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.GET_CURRENT_TIME_SPENT);		
					DAOFactory.setValues(preparedStatement, scoreDetailsDTO.getEmployeeId(), scoreDetailsDTO.getGameId());
					resultSet = preparedStatement.executeQuery();
					Time gameTime = null;
					while (resultSet.next()) 
					{
						gameTime = resultSet.getTime("game_timespent");
					}
					
					gameTimeSpent = NanoUtil.add2TimeValues(gameTimeSpent,gameTime);
					
					preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.GET_HIGHEST_GAME_SCORE);		
					DAOFactory.setValues(preparedStatement, scoreDetailsDTO.getEmployeeId(), scoreDetailsDTO.getGameId());
					resultSet = preparedStatement.executeQuery();
					int highestScore = 0;
					while (resultSet.next()) 
					{
						highestScore = resultSet.getInt("game_highestscore");
					}
					if(scoreDetailsDTO.getGameScore() > highestScore)
					{
						preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.UPDATE_HIGHEST_GAME_SCORE);			
						DAOFactory.setValues(preparedStatement, ++attemptNbr, scoreDetailsDTO.getGameScore(), gameTimeSpent, scoreDetailsDTO.getEmployeeId(), scoreDetailsDTO.getGameId());
						updateStatus = preparedStatement.executeUpdate();
					}
					else
					{
						preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.UPDATE_ATTEMPTS);			
						DAOFactory.setValues(preparedStatement, ++attemptNbr, gameTimeSpent, scoreDetailsDTO.getEmployeeId(), scoreDetailsDTO.getGameId());
						updateStatus = preparedStatement.executeUpdate();
					}
				}
			}
			else {
				preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.INSERT_NEW_PLAYER);			
				DAOFactory.setValues(preparedStatement, scoreDetailsDTO.getEmployeeId(), scoreDetailsDTO.getGameId(), scoreDetailsDTO.getGameScore(), scoreDetailsDTO.getGameScore(), gameTimeSpent);
				updateStatus = preparedStatement.executeUpdate();
			}
			
			preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.CHECK_HISTORY_DATA);			
			DAOFactory.setValues(preparedStatement,  scoreDetailsDTO.getGameId(), scoreDetailsDTO.getEmployeeId());
			resultSet = preparedStatement.executeQuery();
			int currentScore = 0;
			boolean isRecordPresent = false;
			while (resultSet.next()) 
			{
				currentScore = resultSet.getInt("game_highestscore");
				isRecordPresent = true;
			}
			if(!isRecordPresent)
			{
				preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.INSERT_HIGHEST_GAME_SCORE_HISTORY);			
				DAOFactory.setValues(preparedStatement, (Calendar.getInstance().get(Calendar.MONTH) + 1), Calendar.getInstance().get(Calendar.YEAR), scoreDetailsDTO.getEmployeeId(), scoreDetailsDTO.getGameId(), scoreDetailsDTO.getGameScore());
				updateStatus = preparedStatement.executeUpdate();
			}
			else if((scoreDetailsDTO.getGameScore() > currentScore) && isRecordPresent)
			{
				preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.UPDATE_HIGHEST_GAME_SCORE_HISTORY);			
				DAOFactory.setValues(preparedStatement, scoreDetailsDTO.getGameScore(), scoreDetailsDTO.getEmployeeId(), scoreDetailsDTO.getGameId());
				updateStatus = preparedStatement.executeUpdate();
			}
		}
		catch(SQLException e)
		{
			throw new NanoServiceException(e);
		}
		finally 
		{
			DAOFactory.close(resultSet, preparedStatement, connection);
		}
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getNewFeedGames");
		return updateStatus != 0 ? true : false;	
	}
	
	public ChapterDetailsResponseDTO getGameChaptersOrder(int gameId) throws NanoServiceException
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getGameChaptersOrder", null);
		
		ChapterDetailsResponseDTO gameDetailsResponseDTO = new ChapterDetailsResponseDTO();
		List<ChapterDetailsDTO> chapterDetailsList = new ArrayList<ChapterDetailsDTO>();
		ChapterDetailsDTO detailsDTO = null;
		Connection connection = null;
		
		PreparedStatement preparedStatement = null;
		
		ResultSet resultSet = null;
		
		
		try 
		{
			connection = DAOFactory.getConnection();
			
			preparedStatement = connection.prepareStatement(NanoLearningSQLBuilder.GET_CHAPTER_DETAILS);
			DAOFactory.setValues(preparedStatement, gameId);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) 
			{
				detailsDTO = new ChapterDetailsDTO();
				detailsDTO.setGameId(resultSet.getInt("game_id"));
				detailsDTO.setChapterId(resultSet.getInt("chapter_id"));
				detailsDTO.setTemplateId(resultSet.getInt("template_id"));
				detailsDTO.setChapterOrderNbr(resultSet.getInt("chapter_orderno"));
				detailsDTO.setChapterTitle(resultSet.getString("chapter_title"));
				detailsDTO.setLearning_format(resultSet.getString("learning_format"));
				detailsDTO.setLearning(resultSet.getString("learning"));
				detailsDTO.setMinScoreCompletion(resultSet.getInt("min_score_completion"));
				chapterDetailsList.add(detailsDTO);
			}
			gameDetailsResponseDTO.setChapterDetails(chapterDetailsList);
		}
		catch(SQLException e)
		{
			throw new NanoServiceException(e);
		}
		finally 
		{
			DAOFactory.close(resultSet, preparedStatement, connection);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getGameChaptersOrder");
		
		return gameDetailsResponseDTO;
	}
}
