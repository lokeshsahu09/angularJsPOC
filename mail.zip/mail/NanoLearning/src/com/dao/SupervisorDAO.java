/**
 * 
 */
package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.dao.util.DAOFactory;
import com.dto.EmployeeDTO;
import com.dto.ResponseHeaderDTO;
import com.exception.NanoServiceException;
import com.request.dto.AssignGameToEmployeeRequestDTO;
import com.request.dto.GetNanoEmployeesRequestDTO;
import com.response.dto.GetNanoEmployeesResponseDTO;
import com.util.LoggerUtil;
import com.util.ApplicationConstants;

/**
 * @author 758645
 *
 */
public class SupervisorDAO {
	
	private static final Logger LOGGER = Logger.getLogger(SupervisorDAO.class);
	
	private static String CLASS_NAME = "SupervisorDAO";
	
	private static volatile SupervisorDAO supervisorDAO = null;
	
	private static final String GET_EMPLOYEES = "SELECT DISTINCT a.emp_nbr, a.first_name, " +
													  "a.last_name " + 
													  "FROM tms_prod.ASSOCIATE a, NANO_PLAYERS b " +
													  "WHERE a.supervisor_emp_nbr = ? AND " + 
													  "b.Game_Id = ? AND " +
													  "b.Employee_Id != a.emp_nbr";
	
	private static final String ASSIGN_GAME = "INSERT into Nano_Players " +
											  "(Employee_Id,Game_Id,Game_FirstScore,Game_HighestScore,Game_noofattempts,Game_AssignedBy,Game_AssignedTS,Game_LastPlayedTS) " +
											  "VALUES (?,?,0,0,0,?,CURRENT_TIMESTAMP,NULL)";
	
	private static final String UPDATE_ASSIGNED_DETAILS = "UPDATE Nano_Players " +
			  "SET game_assignedby = ?, game_assignedTS = CURRENT_TIMESTAMP " +
			  "WHERE employee_id = ?";
	
	private static final String CHECK_EMPLOYEE = "SELECT Employee_Id FROM Nano_Players WHERE Employee_Id = ?";
	
	public static SupervisorDAO getInstance() 
	{
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getInstance", null);
		
		if(supervisorDAO == null) {
			
			LoggerUtil.info(LOGGER, "Singleton instance has not been initialized, entering synchronized block");
			
			supervisorDAO = new SupervisorDAO();
			
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getInstance");
		
		return supervisorDAO;
		
	}
	
	public GetNanoEmployeesResponseDTO getEmployees(GetNanoEmployeesRequestDTO getNanoEmployeesRequestDTO) throws SQLException, NanoServiceException {
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getEmployees", null);
		
		GetNanoEmployeesResponseDTO getNanoEmployeesResponseDTO = new GetNanoEmployeesResponseDTO();
		
		List<EmployeeDTO> employeeDTOList = new ArrayList<EmployeeDTO>();
		
		EmployeeDTO employeeDTO = null;
		
		Connection connection = null;
		
		PreparedStatement preparedStatement = null;
		
		ResultSet resultSet = null;
		
		try {
			connection = DAOFactory.getConnection();
			
			preparedStatement = connection.prepareStatement(GET_EMPLOYEES);
			
			DAOFactory.setValues(preparedStatement, getNanoEmployeesRequestDTO.getSupervisorId(), getNanoEmployeesRequestDTO.getNanoGameId());

			resultSet = preparedStatement.executeQuery();
			
			while (resultSet.next()) {
				
				employeeDTO = new EmployeeDTO();
				
				employeeDTO.setEmployeeId(resultSet.getInt("EMP_NBR"));
				employeeDTO.setEmployeeFirstName(resultSet.getString("FIRST_NAME"));
				employeeDTO.setEmployeeLastName(resultSet.getString("LAST_NAME"));
				
				employeeDTOList.add(employeeDTO);
			}
			
			getNanoEmployeesResponseDTO.setEmployeesList(employeeDTOList);
		}
		
		finally 
		{
			DAOFactory.close(resultSet, preparedStatement, connection);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getEmployees");
		
		return getNanoEmployeesResponseDTO;
		
	}
	
	public ResponseHeaderDTO assignToEmployees(AssignGameToEmployeeRequestDTO assignGameToEmployeeRequestDTO) throws SQLException, NanoServiceException {
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "assignToEmployees", null);
		
		ResponseHeaderDTO responseHeaderDTO = new ResponseHeaderDTO();
		
		Connection connection = null;
		
		PreparedStatement preparedStatement = null;
		
		PreparedStatement pstmt = null;
		
		PreparedStatement prepStatementForUpdate = null;

		ResultSet resultSet = null;
		
		int empId;
		
		int [] rowsInserted;
		
		int [] rowsUpdated;

		try {
			connection = DAOFactory.getConnection();
			
			preparedStatement = connection.prepareStatement(ASSIGN_GAME);
			pstmt = connection.prepareStatement(CHECK_EMPLOYEE);
			prepStatementForUpdate = connection.prepareStatement(UPDATE_ASSIGNED_DETAILS);
			
			//Insert a record if Supervisor assigns the game only if the game is not played by the associate earlier
			//Update the Game Assigned details if game is played before the Supervisor assigns
			
			for(Object employeeId : assignGameToEmployeeRequestDTO.getEmployeeIds()) {
				empId = (Integer) employeeId;
				DAOFactory.setValues(pstmt, empId);
				resultSet = pstmt.executeQuery();
				
				if (!resultSet.next()) {
					
					preparedStatement.setInt(1, empId);
					preparedStatement.setInt(2, assignGameToEmployeeRequestDTO.getGameId());
					preparedStatement.setInt(3, assignGameToEmployeeRequestDTO.getSupervisorId());
					
					preparedStatement.addBatch();
				}
				else {
					prepStatementForUpdate.setInt(1, assignGameToEmployeeRequestDTO.getSupervisorId());
					prepStatementForUpdate.setInt(2, empId);
					prepStatementForUpdate.addBatch();
				}
			}

			rowsInserted = preparedStatement.executeBatch();
			
			rowsUpdated = prepStatementForUpdate.executeBatch();
			
			if(rowsInserted.length > 0) {
				for (int i=0;i<rowsInserted.length;i++) {
					if (0 == rowsInserted[i]) {
						responseHeaderDTO.setCode(ApplicationConstants.VALIDATION_ERROR_STATUS);
						responseHeaderDTO.setStatus(ApplicationConstants.VALIDATION_ERROR_STATUS);
						responseHeaderDTO.setMessage("Error ocurred while inserting records");
						responseHeaderDTO.setDeveloperMessage("Error ocurred while performing query 'ASSIGN_GAME'");
					} else {
						responseHeaderDTO.setCode(ApplicationConstants.OK_STATUS);
						responseHeaderDTO.setStatus(ApplicationConstants.OK_STATUS);
						responseHeaderDTO.setMessage("Employees added");
						responseHeaderDTO.setDeveloperMessage("Records inserted");
					}
				}
			} else if (rowsUpdated.length > 0) {
				
				for (int i=0;i<rowsUpdated.length;i++) {
					if (0 == rowsUpdated[i]) {
						responseHeaderDTO.setCode(ApplicationConstants.VALIDATION_ERROR_STATUS);
						responseHeaderDTO.setStatus(ApplicationConstants.VALIDATION_ERROR_STATUS);
						responseHeaderDTO.setMessage("Error ocurred while updating records");
						responseHeaderDTO.setDeveloperMessage("Error ocurred while performing query 'UPDATE_ASSIGNED_DETAILS'");
					} else {
						responseHeaderDTO.setCode(ApplicationConstants.OK_STATUS);
						responseHeaderDTO.setStatus(ApplicationConstants.OK_STATUS);
						responseHeaderDTO.setMessage("Employees already played the game.Assigned details Updated");
						responseHeaderDTO.setDeveloperMessage("Assigned details Updated");
					}
				}
			}
		}
		
		finally 
		{
			DAOFactory.close(resultSet, preparedStatement, connection);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "assignToEmployees");
		
		return responseHeaderDTO;
		
	}

}
