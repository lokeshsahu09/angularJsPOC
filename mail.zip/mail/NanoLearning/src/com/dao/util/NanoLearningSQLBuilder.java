package com.dao.util;

public class NanoLearningSQLBuilder {
	/** Query constants for getHomeScrnGameDtls service (Popular , Assigned, and New Feed Game Details) --- STARTS) **/
	public static final String POPULAR_GAME_DTLS_LIST = new String(
			"SELECT"
			+ " nanoGames.game_title, nanoGames.game_description "
			+"FROM"
			+ "	nano_games nanoGames,"
			+ "	nano_players nanoPlayers "
			+"WHERE "
			+ "	nanoGames.game_id = nanoPlayers.game_id HAVING max(game_noofattempts)"
			+ "	LIMIT 5");			
	
	public static final String ASSIGNED_GAME_DTLS_LIST = new String(
			"SELECT"
			+ " nanoGames.game_title, nanoGames.game_description "
			+ "FROM"
			+ " nano_games nanoGames, nano_players nanoPlayers "
			+ "WHERE"
			+ " nanoGames.game_id = nanoPlayers.game_id AND"
			+ " nanoPlayers.employee_id= ? AND"
			+ " nanoPlayers.game_assignedby != 'NULL'"
			+ " LIMIT 5");
	
	public static final String NEWFEED_GAME_DTLS_LIST = new String(
			"SELECT"
			+ " game_title,game_description "
			+ "FROM "
			+ " nano_games"
			+ " ORDER BY created_ts DESC "
			+ " LIMIT 5");
	/** Query constants for getHomeScrnGameDtls service (Popular , Assigned, and New Feed Game Details) --- ENDS) **/
	public static final String SEARCH_GAME_DETAILS = new String(
			"select "
					+ "a.game_id, "
					+ "a.chapter_id, "
					+ "a.question_id, "
					+ "a.question_format, "
					+ "a.question, "
					+ "a.clue_description, "
					+ "a.question_tip, "
					+ "a.question_category, "
					+ "a.question_subcategory, "
					+ "a.question_order, "
					+ "a.question_correctscore, "
					+ "a.question_incorrectscore, "
					+ "b.option_id, "
					+ "b.option_format, "
					+ "b.options, "
					+ "b.isoptionCorrect "
			+ "from "
				+ "nano_questions a left join nano_options b "
				+ "on a.question_id = b.question_id "
				+ "and a.game_id = b.game_id "
				+ "and a.chapter_id = b.chapter_id "
			+ "where "
				+ "a.game_id = ? and a.chapter_id = ? "
				+ "order by "
				+ "a.question_id asc");

	public static final String GET_LEARNING_DETAILS = new String(
			"select "
					+ "chapter_id,"
					+ "game_id,"
					+ "template_id,"
					+ "chapter_title,"
					+ "chapter_orderno,"
					+ "learning_format,"
					+ "learning,"
					+ "min_score_completion "
				+ "from "
					+ "nano_chapters "
				+ "where "
					+ "chapter_id = ? "
					+ "and game_id = ?"
			);
	public static final String GET_NO_OF_GAME_ATTEMPTS = new String(
			"select "
					+ "game_noofattempts "
				+ "from "
					+ "nano_players "
				+ "where "
					+ "employee_id = ? "
					+ "and game_id = ?");
	
	public static final String GET_HIGHEST_GAME_SCORE = new String(
			"select "
					+ "game_highestscore "
				+ "from "
					+ "nano_players "
				+ "where "
					+ "employee_id = ? "
					+ "and game_id = ?");
	public static final String UPDATE_FIRST_ATEMPT_GAME_SCORE = new String(
			"update nano_players "
					+ "set "
						+ "game_noofattempts = 1 , game_highestscore = ? , game_firstscore = ? , game_lastplayedTS = CURRENT_TIMESTAMP , game_timespent = ? "
						+ "where "
						+ "employee_id = ? "
						+ "and game_id = ?");
	public static final String UPDATE_HIGHEST_GAME_SCORE = new String(
			"update nano_players "
					+ "set "
						+ "game_noofattempts = ? , game_highestscore = ? , game_lastplayedTS = CURRENT_TIMESTAMP , game_timespent = ? "
						+ "where "
						+ "employee_id = ? "
						+ "and game_id = ?");

	public static final String UPDATE_ATTEMPTS = new String(
			"update nano_players "
					+ "set "
						+ "game_noofattempts = ? ,  game_lastplayedTS = CURRENT_TIMESTAMP , game_timespent = ? "
						+ "where "
						+ "employee_id = ? "
						+ "and game_id = ?");

	public static final String GET_CURRENT_TIME_SPENT = new String(
			"select "
					+ "game_timespent "
				+ "from "
					+ "nano_players "
				+ "where "
					+ "employee_id = ? "
					+ "and game_id = ?");

	public static final String CHECK_HISTORY_DATA = new String(
			"select month, "
			+ "year, "
			+ "employee_id, "
			+ "game_id, "
			+ "game_highestscore "
			+ "from "
			+ "nano_player_gameshistory "
			+ "where game_id = ? and employee_id = ? "
			+ "and month = MONTH(CURRENT_DATE()) "
			+ "and year = YEAR(CURRENT_DATE()) ");

	public static final String UPDATE_HIGHEST_GAME_SCORE_HISTORY = new String(
			"update nano_player_gameshistory "
					+ "set "
						+ "game_highestscore = ? , last_updatedTS = CURRENT_TIMESTAMP "
						+ "where "
						+ "employee_id = ? "
						+ "and game_id = ?");
	public static final String INSERT_HIGHEST_GAME_SCORE_HISTORY = new String(
			"insert into nano_player_gameshistory (month, year, employee_id, game_id, game_highestscore, last_updatedTS) "
			+ "values (?, ?, ?, ?, ?, CURRENT_TIMESTAMP) ");

	public static final String INSERT_NEW_PLAYER = new String(
			"INSERT into Nano_Players " +
			"(Employee_Id,Game_Id,Game_FirstScore,Game_HighestScore,Game_noofattempts,Game_AssignedBy,Game_AssignedTS,Game_LastPlayedTS,Game_timespent) " +
			"VALUES (?,?,?,?,1,NULL,NULL,CURRENT_TIMESTAMP,?)");

	public static final String GET_CHAPTER_DETAILS = new String(
			"select "
					+ "chapter_id,"
					+ "game_id,"
					+ "template_id,"
					+ "chapter_title,"
					+ "chapter_orderno,"
					+ "learning_format,"
					+ "learning,"
					+ "min_score_completion "
				+ "from "
					+ "nano_chapters "
				+ "where "
					+ " game_id = ? order by chapter_orderno asc "
			);

}
