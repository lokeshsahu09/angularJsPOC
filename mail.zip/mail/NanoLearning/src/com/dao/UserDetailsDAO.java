package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.dao.util.DAOFactory;
import com.exception.NanoServiceException;
import com.request.dto.UserRequestDTO;
import com.response.dto.BadgeDTO;
import com.response.dto.CompletedGameDTO;
import com.response.dto.DashboardResponseDTO;
import com.response.dto.PlayerDetails;
import com.response.dto.SupervisorDTO;
import com.response.dto.UserResponseDTO;
import com.util.LoggerUtil;

public class UserDetailsDAO {
	
private static final Logger LOGGER = Logger.getLogger(UserDetailsDAO.class);
	
	private static String CLASS_NAME = "UserDetailsDAO";
	
	private static volatile UserDetailsDAO userDetailsDAO = null;
	
	//private static final String GET_USER_DETAILS = "select a.game_id, a.game_highestscore, b.game_description, b.game_title, c.FIRST_NAME, c.LAST_NAME from nano_players a left join nano_games b on a.game_id = b.game_id left join tms_associate c on c.EMP_NBR = a.employee_id where a.employee_id = ? order by a.game_highestscore desc";
	
	private static final String GET_SUPERVISOR_NAME = "select a.FIRST_NAME, a.LAST_NAME, a.EMP_NBR from tms_associate a where a.EMP_NBR = ?";
	
	private static final String GET_USER_DETAILS = "select a.game_id, a.game_highestscore, b.game_description, b.game_title, a.game_timespent, c.FIRST_NAME, c.LAST_NAME from nano_players a left join nano_games b on a.game_id = b.game_id right join tms_associate c on c.EMP_NBR = a.employee_id where c.emp_nbr = ? order by a.game_highestscore desc";
	
	private static final String GET_BADGES = "select a.badge_id, a.badge_description, a.badge_image, a.badge_minscore from nano_badge_master a order by a.badge_minscore desc";
	
	private static final String GET_DASHBOARD_DETAILS_PM = "(select a.employee_id, a.game_id, a.game_highestscore, a.game_timespent, b.game_title, b.game_description, c.FIRST_NAME, c.LAST_NAME, c.SUPERVISOR_EMP_NBR, c.ROLE_CD, d.PM_EMP_NBR, d.DM_EMP_NBR, d.GL_EMP_NBR, d.PORTFOLIO_CD from nano_players a left join nano_games b on a.game_id = b.game_id join tms_associate c on a.employee_id = c.EMP_NBR join tms_associateshierachy d on c.EMP_NBR = d.EMP_NBR and d.pm_emp_nbr = ?) order by c.ROLE_CD desc";
	
	private static final String GET_DASHBOARD_DETAILS_DM = "(select a.employee_id, a.game_id, a.game_highestscore, a.game_timespent, b.game_title, b.game_description, c.FIRST_NAME, c.LAST_NAME, c.SUPERVISOR_EMP_NBR, c.ROLE_CD, d.PM_EMP_NBR, d.DM_EMP_NBR, d.GL_EMP_NBR, d.PORTFOLIO_CD from nano_players a left join nano_games b on a.game_id = b.game_id join tms_associate c on a.employee_id = c.EMP_NBR join tms_associateshierachy d on c.EMP_NBR = d.EMP_NBR and d.dm_emp_nbr = ?) order by c.ROLE_CD desc";
	
	private static final String GET_DASHBOARD_DETAILS_GL = "(select a.employee_id, a.game_id, a.game_highestscore, a.game_timespent, b.game_title, b.game_description, c.FIRST_NAME, c.LAST_NAME, c.SUPERVISOR_EMP_NBR, c.ROLE_CD, d.PM_EMP_NBR, d.DM_EMP_NBR, d.GL_EMP_NBR, d.PORTFOLIO_CD from nano_players a left join nano_games b on a.game_id = b.game_id join tms_associate c on a.employee_id = c.EMP_NBR join tms_associateshierachy d on c.EMP_NBR = d.EMP_NBR and d.gl_emp_nbr = ?) order by c.ROLE_CD desc";
	
	private static final String GET_DASHBOARD_HISTORY_PM = "select a.employee_id, a.month, a.year, a.game_id, a.game_highestscore, b.PM_EMP_NBR, b.DM_EMP_NBR, b.GL_EMP_NBR, b.PORTFOLIO_CD from nano_player_gameshistory a left join tms_associateshierachy b on a.employee_id = b.EMP_NBR where b.PM_EMP_NBR = ? and( a.year = ? or a.year = ? )";
	
	private static final String GET_DASHBOARD_HISTORY_DM = "select a.employee_id, a.month, a.year, a.game_id, a.game_highestscore, b.PM_EMP_NBR, b.DM_EMP_NBR, b.GL_EMP_NBR, b.PORTFOLIO_CD from nano_player_gameshistory a left join tms_associateshierachy b on a.employee_id = b.EMP_NBR where b.DM_EMP_NBR = ? and( a.year = ? or a.year = ? )";
	
	private static final String GET_DASHBOARD_HISTORY_GL = "select a.employee_id, a.month, a.year, a.game_id, a.game_highestscore, b.PM_EMP_NBR, b.DM_EMP_NBR, b.GL_EMP_NBR, b.PORTFOLIO_CD from nano_player_gameshistory a left join tms_associateshierachy b on a.employee_id = b.EMP_NBR where b.GL_EMP_NBR = ? and( a.year = ? or a.year = ? )";
	
	public static UserDetailsDAO getInstance() 
	{
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getInstance", null);
		
		if(userDetailsDAO == null) {
			
			LoggerUtil.info(LOGGER, "Singleton instance has not been initialized, entering synchronized block");
			
			userDetailsDAO = new UserDetailsDAO();
			
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getInstance");
		
		return userDetailsDAO;
		
	}

	public UserResponseDTO getUserDetails(UserRequestDTO detailsRequestDTO) throws SQLException, NanoServiceException
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getUserDetails", null);
		
		UserResponseDTO userDetailsResponseDTO = new UserResponseDTO();
		
		List<CompletedGameDTO> completedGames = new ArrayList<CompletedGameDTO>();
		
		CompletedGameDTO completedGame = null;
		
		Connection connection = null;
		
		Calendar zeroTime = Calendar.getInstance();	
		zeroTime.set(Calendar.HOUR, 0);
		zeroTime.set(Calendar.MINUTE, 0);
		zeroTime.set(Calendar.SECOND, 0);
		
		PreparedStatement preparedStatement = null;
		
		ResultSet resultSet = null;
		int totalPoints = 0;
		
		try {
			connection = DAOFactory.getConnection();
			
			List<BadgeDTO> badgeList = new ArrayList<BadgeDTO>();
			BadgeDTO badge = null;
			
			preparedStatement = connection.prepareStatement(GET_BADGES);
			DAOFactory.setValues(preparedStatement);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) 
			{
				badge = new BadgeDTO();
				badge.setBadgeId(resultSet.getInt("badge_id"));
				badge.setBadgeDescription(resultSet.getString("badge_description"));
				badge.setBadgeImage(resultSet.getString("badge_image"));
				badge.setBadgeMinscore(resultSet.getInt("badge_minscore"));
				badgeList.add(badge);
			}
			if (null != resultSet) {
				resultSet.close();
			}
			
			preparedStatement = connection.prepareStatement(GET_USER_DETAILS);
			
			DAOFactory.setValues(preparedStatement, detailsRequestDTO.getEmployeeId());

			resultSet = preparedStatement.executeQuery();
			int count = 0;
			while (resultSet.next()) 
			{
				if(count == 0){
					userDetailsResponseDTO.setFirstName(resultSet.getString("FIRST_NAME"));
					userDetailsResponseDTO.setLastName(resultSet.getString("LAST_NAME"));
					count++;
				}
				if(resultSet.getInt("game_id") != 0){
					completedGame = new CompletedGameDTO();
					completedGame.setGameId(resultSet.getInt("game_id"));
					completedGame.setGameTitle(resultSet.getString("game_title"));
					completedGame.setGameDescription(resultSet.getString("game_description"));
					completedGame.setPointsEarned(resultSet.getInt("game_highestscore"));
					if(null != resultSet.getTime("game_timespent")){
						completedGame.setTimeSpent(resultSet.getTime("game_timespent").toString());
						completedGame.setTimeSpentLong(resultSet.getTime("game_timespent").getTime());
						long time = userDetailsResponseDTO.getTotalTimeLong();
						time += resultSet.getTime("game_timespent").getTime();
						userDetailsResponseDTO.setTotalTimeLong(time);
					}else{
						completedGame.setTimeSpent("00:00:00");
						completedGame.setTimeSpentLong(zeroTime.getTime().getTime());
					}
					completedGames.add(completedGame);
					totalPoints += completedGame.getPointsEarned();
				}
			}
			
			Time totalTime = new Time(userDetailsResponseDTO.getTotalTimeLong());
			userDetailsResponseDTO.setTotalTimeSpent(totalTime.toString());
			userDetailsResponseDTO.setEmployeeId(detailsRequestDTO.getEmployeeId());
			userDetailsResponseDTO.setRole(detailsRequestDTO.getRole());
			userDetailsResponseDTO.setRoleCd(detailsRequestDTO.getRoleCd());
			userDetailsResponseDTO.setCompletedGameList(completedGames);
			userDetailsResponseDTO.setTotalPoints(totalPoints);
			setBadge(userDetailsResponseDTO, badgeList);
			
		}
		finally 
		{
			DAOFactory.close(resultSet, preparedStatement, connection);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getUserDetails");
		
		return userDetailsResponseDTO;
	}
	
	public DashboardResponseDTO getDashBoardDetails(UserRequestDTO detailsRequestDTO) throws SQLException, NanoServiceException
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getDashBoardDetails", null);
		
		DashboardResponseDTO dashboardResponseDTO = new DashboardResponseDTO();
		
		Connection connection = null;
		
		PreparedStatement preparedStatement = null;
		
		ResultSet resultSet = null;
		
		try {
			connection = DAOFactory.getConnection();
			
			List<BadgeDTO> badgeList = new ArrayList<BadgeDTO>();
			BadgeDTO badge = null;
			
			preparedStatement = connection.prepareStatement(GET_BADGES);
			DAOFactory.setValues(preparedStatement);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) 
			{
				badge = new BadgeDTO();
				badge.setBadgeId(resultSet.getInt("badge_id"));
				badge.setBadgeDescription(resultSet.getString("badge_description"));
				badge.setBadgeImage(resultSet.getString("badge_image"));
				badge.setBadgeMinscore(resultSet.getInt("badge_minscore"));
				badgeList.add(badge);
			}
			if (null != resultSet) {
				resultSet.close();
			}
			
			switch(detailsRequestDTO.getRoleCd()) {
				
				// role cd is 4 for pm
				case 4 : 
				{
					preparedStatement = connection.prepareStatement(GET_DASHBOARD_DETAILS_PM);
					dashboardResponseDTO = reponseLogic(connection, preparedStatement, detailsRequestDTO, badgeList, "PL_EMP_NBR");
					getQuarterDetails(connection, preparedStatement, dashboardResponseDTO, detailsRequestDTO, "PL_EMP_NBR");
					break;
				}
				// role cd is 5 for dm
				case 5 : 
				{
					preparedStatement = connection.prepareStatement(GET_DASHBOARD_DETAILS_DM);
					dashboardResponseDTO = reponseLogic(connection, preparedStatement, detailsRequestDTO, badgeList, "PM_EMP_NBR");
					getQuarterDetails(connection, preparedStatement, dashboardResponseDTO, detailsRequestDTO, "PM_EMP_NBR");
					break;
				}
				// role cd is 6 for gl
				case 6 : 
				{
					preparedStatement = connection.prepareStatement(GET_DASHBOARD_DETAILS_GL);
					dashboardResponseDTO = reponseLogic(connection, preparedStatement, detailsRequestDTO, badgeList, "DM_EMP_NBR");
					getQuarterDetails(connection, preparedStatement, dashboardResponseDTO, detailsRequestDTO, "DM_EMP_NBR");
					break;
				}
				
				default:
				{
					preparedStatement = connection.prepareStatement(GET_DASHBOARD_DETAILS_PM);
					break;
				}
			}
		}
		finally 
		{
			DAOFactory.close(resultSet, preparedStatement, connection);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getDashBoardDetails");
		
		return dashboardResponseDTO;
	}
	
	public void getQuarterDetails(Connection conn, PreparedStatement preparedStatement, DashboardResponseDTO dashboardResponse, UserRequestDTO detailsRequestDTO, String lowerLevel) throws SQLException{
		switch(detailsRequestDTO.getRoleCd()) {
			case 4 : { 
				preparedStatement = conn.prepareStatement(GET_DASHBOARD_HISTORY_PM);
				break;
			}
			case 5 : { 
				preparedStatement = conn.prepareStatement(GET_DASHBOARD_HISTORY_DM);
				break;
			}
			case 6 : { 
				preparedStatement = conn.prepareStatement(GET_DASHBOARD_HISTORY_GL);
				break;
			}
		}
		Calendar cal = Calendar.getInstance();
		List<Integer> lastQuarter = new ArrayList<Integer>();
		List<Integer> currentQuarter = new ArrayList<Integer>();
		List<Integer> q4 = new ArrayList<Integer>();
		q4.add(1);
		q4.add(2);
		q4.add(3);
		List<Integer> q1 = new ArrayList<Integer>();
		q1.add(4);
		q1.add(5);
		q1.add(6);
		List<Integer> q2 = new ArrayList<Integer>();
		q2.add(7);
		q2.add(8);
		q2.add(9);
		List<Integer> q3 = new ArrayList<Integer>();
		q3.add(10);
		q3.add(11);
		q3.add(12);
		int currentYear = cal.get(Calendar.YEAR);
		int currentMonth = cal.get(Calendar.MONTH);
		if(currentMonth < 3){
			currentQuarter = q4;
			lastQuarter = q1;
			DAOFactory.setValues(preparedStatement, detailsRequestDTO.getEmployeeId(), currentYear, currentYear-1);
		}else if(currentMonth >= 3 && currentMonth < 6){
			currentQuarter = q1;
			lastQuarter = q4;
			DAOFactory.setValues(preparedStatement, detailsRequestDTO.getEmployeeId(), currentYear, currentYear);
		}else if(currentMonth >= 6 && currentMonth < 9){
			currentQuarter = q2;
			lastQuarter = q1;
			DAOFactory.setValues(preparedStatement, detailsRequestDTO.getEmployeeId(), currentYear, currentYear);
		}else{
			currentQuarter = q3;
			lastQuarter = q2;
			DAOFactory.setValues(preparedStatement, detailsRequestDTO.getEmployeeId(), currentYear, currentYear);
		}
		
		Map<Integer, SupervisorDTO> quaterMap = new HashMap<Integer, SupervisorDTO>();
		ResultSet resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) 
		{
			int employeeId = resultSet.getInt(lowerLevel);
			int month = resultSet.getInt("MONTH");
			int year =  resultSet.getInt("YEAR");
			if(currentMonth < 3){
				if(year == currentYear && currentQuarter.contains(month)){
					addToQuarterMap(quaterMap, employeeId, resultSet.getInt("game_highestscore"), true, conn);
				}
				else if(year == currentYear-1 && lastQuarter.contains(month)){
					addToQuarterMap(quaterMap, employeeId, resultSet.getInt("game_highestscore"), false, conn);
				}
			}
			else{
				if(currentQuarter.contains(month)){
					addToQuarterMap(quaterMap, employeeId, resultSet.getInt("game_highestscore"), true, conn);
				}
				else if(lastQuarter.contains(month)){
					addToQuarterMap(quaterMap, employeeId, resultSet.getInt("game_highestscore"), false, conn);
				}
			}
		}
		
		List<SupervisorDTO> quaterList = new ArrayList<SupervisorDTO>();
		Iterator<Map.Entry<Integer, SupervisorDTO>> entries = quaterMap.entrySet().iterator();
		while (entries.hasNext()) {
			  Map.Entry<Integer, SupervisorDTO> entry = entries.next();
			  quaterList.add(entry.getValue());
		}
		dashboardResponse.setQuarterDetails(quaterList);
	}
	
	public void addToQuarterMap(Map<Integer, SupervisorDTO> quaterMap, int empId, int score, boolean isCurrentQuarter, Connection conn) throws SQLException{
		if(quaterMap.containsKey(empId)){
			if(isCurrentQuarter){
				int total = quaterMap.get(empId).getCurrentQuarter();
				total += score;
				quaterMap.get(empId).setCurrentQuarter(total);
			}
			else{
				int total = quaterMap.get(empId).getLastQuarter();
				total += score;
				quaterMap.get(empId).setLastQuarter(total);
			}
		}
		else{
			SupervisorDTO details = new SupervisorDTO();
			details.setSupervisorEmpId(empId);
			if(empId != 0){
				PreparedStatement preparedStatement = conn.prepareStatement(GET_SUPERVISOR_NAME);
				DAOFactory.setValues(preparedStatement, empId);
				ResultSet resultSet = preparedStatement.executeQuery();
				while (resultSet.next()) 
				{
					details.setFirstName(resultSet.getString("FIRST_NAME"));
					details.setLastName(resultSet.getString("LAST_NAME"));
				}
			}
			if(isCurrentQuarter){
				details.setCurrentQuarter(score);
			}
			else{
				details.setLastQuarter(score);
			}
			quaterMap.put(empId, details);
		}
	}
	
	public DashboardResponseDTO reponseLogic(Connection conn, PreparedStatement preparedStatement,UserRequestDTO detailsRequestDTO, List<BadgeDTO> badgeList, String lowerRole) throws SQLException{
		Calendar zeroTime = Calendar.getInstance();	
		zeroTime.set(Calendar.HOUR, 0);
		zeroTime.set(Calendar.MINUTE, 0);
		zeroTime.set(Calendar.SECOND, 0);
		DashboardResponseDTO dashboardResponseDTO = new DashboardResponseDTO();
		List<CompletedGameDTO> completedGames = null;
		CompletedGameDTO completedGame = null;
		Map<Integer, PlayerDetails> playerMapByEmpId = new HashMap<Integer, PlayerDetails>();
		
		DAOFactory.setValues(preparedStatement, detailsRequestDTO.getEmployeeId());
		ResultSet resultSet = preparedStatement.executeQuery();
		
		dashboardResponseDTO.setEmployeeId(detailsRequestDTO.getEmployeeId());
		dashboardResponseDTO.setRole(detailsRequestDTO.getRole());
		dashboardResponseDTO.setRoleCd(detailsRequestDTO.getRoleCd());
		
		while (resultSet.next()) 
		{
			completedGame = new CompletedGameDTO();
			completedGame.setGameId(resultSet.getInt("game_id"));
			completedGame.setGameDescription(resultSet.getString("game_description"));
			completedGame.setGameTitle(resultSet.getString("game_title"));
			completedGame.setPointsEarned(resultSet.getInt("game_highestscore"));
			if(null != resultSet.getTime("game_timespent")){
				completedGame.setTimeSpent(resultSet.getTime("game_timespent").toString());
				completedGame.setTimeSpentLong(resultSet.getTime("game_timespent").getTime());
				long time = dashboardResponseDTO.getTotalPlayerTimeLong();
				time += resultSet.getTime("game_timespent").getTime();
				dashboardResponseDTO.setTotalPlayerTimeLong(time);
			}else{
				completedGame.setTimeSpent("00:00:00");
				completedGame.setTimeSpentLong(zeroTime.getTime().getTime());
			}
			
			if(detailsRequestDTO.getEmployeeId() != resultSet.getInt("employee_id")){
				int EmpId = resultSet.getInt("employee_id");
				if(playerMapByEmpId.containsKey(EmpId)){
					int totalPoints = playerMapByEmpId.get(EmpId).getTotalPoints();
					totalPoints += resultSet.getInt("game_highestscore");
					playerMapByEmpId.get(EmpId).setTotalPoints(totalPoints);
					playerMapByEmpId.get(EmpId).getCompletedGameList().add(completedGame);
				}
				else{
					PlayerDetails player = new PlayerDetails();
					player.setEmployeeId(EmpId);
					player.setRoleCd(resultSet.getInt("ROLE_CD"));
					player.setFirstName(resultSet.getString("FIRST_NAME"));
					player.setLastName(resultSet.getString("LAST_NAME"));
					player.setSuperEmployeeId(resultSet.getInt("SUPERVISOR_EMP_NBR"));
					player.setTotalPoints(resultSet.getInt("game_highestscore"));
					
					completedGames = new ArrayList<CompletedGameDTO>();
					completedGames.add(completedGame);
					player.setCompletedGameList(completedGames);
					playerMapByEmpId.put(EmpId, player);
				}
			}
		}
		
		int totalPlayerScore = 0;
		Iterator<Map.Entry<Integer, PlayerDetails>> entries = playerMapByEmpId.entrySet().iterator();
		Map<Integer, Integer> supervisorMap = new HashMap<Integer, Integer>();
		List<PlayerDetails> playerList = new ArrayList<PlayerDetails>();
		
		while (entries.hasNext()) {
		  Map.Entry<Integer, PlayerDetails> entry = entries.next();
		  PlayerDetails player = entry.getValue();
		  setBadge(player, badgeList);
		  int superEmpId = player.getSuperEmployeeId();
		  totalPlayerScore += player.getTotalPoints();
		  playerList.add(player);
		  if(supervisorMap.containsKey(superEmpId)){
			  int supervisorPoints = supervisorMap.get(superEmpId).intValue();
			  supervisorPoints += player.getTotalPoints();
			  supervisorMap.put(superEmpId, supervisorPoints);
		  }
		  else{
			  supervisorMap.put(superEmpId, player.getTotalPoints());
		  }
		}
		
		List<SupervisorDTO> supervisorList = new ArrayList<SupervisorDTO>();
		SupervisorDTO supervisorDetails = null;
		Iterator<Map.Entry<Integer, Integer>> supervisorEntries = supervisorMap.entrySet().iterator();
		while (supervisorEntries.hasNext()) {
			Map.Entry<Integer, Integer> entry = supervisorEntries.next();
			supervisorDetails = new SupervisorDTO();
			supervisorDetails.setSupervisorEmpId(entry.getKey());
			supervisorDetails.setTotalPoints(entry.getValue());
			supervisorList.add(supervisorDetails);
		}
		
		for(PlayerDetails player : playerList){
			double result = player.getTotalPoints()*100*100/supervisorMap.get(player.getSuperEmployeeId());
			double percentile =  Math.round(result);
			percentile = percentile/100;
			player.setPercentile(percentile);
		}
		
		dashboardResponseDTO.setSupervisorList(supervisorList);
		dashboardResponseDTO.setTotalPlayerPoints(totalPlayerScore);
		dashboardResponseDTO.setPlayerList(playerList);
		
		if (null != resultSet) {
			resultSet.close();
		}
		preparedStatement = conn.prepareStatement(GET_USER_DETAILS);
		DAOFactory.setValues(preparedStatement, detailsRequestDTO.getEmployeeId());
		resultSet = preparedStatement.executeQuery();
		
		int count = 0;
		int ownPoints = 0;
		List<CompletedGameDTO> ownCompletedGames = new ArrayList<CompletedGameDTO>();
		while (resultSet.next()) 
		{
			if(count == 0){
				dashboardResponseDTO.setFirstName(resultSet.getString("FIRST_NAME"));
				dashboardResponseDTO.setLastName(resultSet.getString("LAST_NAME"));
				count++;
			}
			if(resultSet.getInt("game_id") != 0){
				completedGame = new CompletedGameDTO();
				completedGame.setGameId(resultSet.getInt("game_id"));
				completedGame.setGameTitle(resultSet.getString("game_title"));
				completedGame.setGameDescription(resultSet.getString("game_description"));
				completedGame.setPointsEarned(resultSet.getInt("game_highestscore"));
				if(null != resultSet.getTime("game_timespent")){
					completedGame.setTimeSpent(resultSet.getTime("game_timespent").toString());
					completedGame.setTimeSpentLong(resultSet.getTime("game_timespent").getTime());
					long time = dashboardResponseDTO.getTotalPlayerTimeLong();
					time += resultSet.getTime("game_timespent").getTime();
					dashboardResponseDTO.setTotalPlayerTimeLong(time);;
				}else{
					completedGame.setTimeSpent("00:00:00");
					completedGame.setTimeSpentLong(zeroTime.getTime().getTime());
				}
				ownCompletedGames.add(completedGame);
				ownPoints += completedGame.getPointsEarned();
			}
		}
		
		Time totalTime = new Time(dashboardResponseDTO.getTotalPlayerTimeLong());
		dashboardResponseDTO.setTotalPlayerTimeSpent(totalTime.toString());
		dashboardResponseDTO.setCompletedGameList(ownCompletedGames);
		dashboardResponseDTO.setTotalPoints(ownPoints);
		setBadge(dashboardResponseDTO, badgeList);
		
		return dashboardResponseDTO;
	}
	
	public void setBadge(UserResponseDTO userDetailsResponseDTO, List<BadgeDTO> badgeList){
		for(int i=0; i<badgeList.size(); i++){
			if(userDetailsResponseDTO.getTotalPoints() >= badgeList.get(i).getBadgeMinscore()){
				userDetailsResponseDTO.setBadgeId(badgeList.get(i).getBadgeId());
				userDetailsResponseDTO.setBadgeDescription(badgeList.get(i).getBadgeDescription());
				userDetailsResponseDTO.setBadgeUrl(badgeList.get(i).getBadgeImage());
				break;
			}
		}
	}
	
	public void setBadge(DashboardResponseDTO dashboardResponseDTO, List<BadgeDTO> badgeList){
		for(int i=0; i<badgeList.size(); i++){
			if(dashboardResponseDTO.getTotalPoints() >= badgeList.get(i).getBadgeMinscore()){
				dashboardResponseDTO.setBadgeId(badgeList.get(i).getBadgeId());
				dashboardResponseDTO.setBadgeDescription(badgeList.get(i).getBadgeDescription());
				dashboardResponseDTO.setBadgeUrl(badgeList.get(i).getBadgeImage());
				break;
			}
		}
	}
	
	public void setBadge(PlayerDetails playerDTO, List<BadgeDTO> badgeList){
		for(int i=0; i<badgeList.size(); i++){
			if(playerDTO.getTotalPoints() >= badgeList.get(i).getBadgeMinscore()){
				playerDTO.setBadgeId(badgeList.get(i).getBadgeId());
				playerDTO.setBadgeDescription(badgeList.get(i).getBadgeDescription());
				playerDTO.setBadgeUrl(badgeList.get(i).getBadgeImage());
				break;
			}
		}
	}
}
