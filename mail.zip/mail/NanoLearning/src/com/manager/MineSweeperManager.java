package com.manager;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import org.apache.log4j.Logger;

import com.dao.GameDetailsDAO;
import com.dto.Bomb;
import com.dto.MineSweeperResponse;
import com.dto.Options;
import com.dto.OptionsDTO;
import com.dto.QAOptionDetailsDTO;
import com.dto.Treasure;
import com.exception.NanoServiceException;
import com.request.dto.GameDetailsRequestDTO;
import com.response.dto.GameDetailsResponseDTO;
import com.dto.ResponseHeaderDTO;
import com.util.ApplicationConstants;
import com.util.LoggerUtil;

public class MineSweeperManager {
	
	private static String CLASS_NAME = "MineSweeperManager";
	
	private static MineSweeperManager mineSweeperManager = null;
	
	private static final Logger LOGGER = Logger.getLogger(MineSweeperManager.class);

	private MineSweeperManager() {
		// TODO Auto-generated constructor stub
		
	}
	
	public static synchronized MineSweeperManager getInstance(){
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getInstance", null);
				
		if(mineSweeperManager == null){
			
			LoggerUtil.info(LOGGER, "Singleton instance has not been initialized, entering synchronized block");
			
			mineSweeperManager = new MineSweeperManager();
		}
		return mineSweeperManager;
	}

	public MineSweeperResponse getMineSweeperData(String gameId, String levelId) throws NanoServiceException, SQLException{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getMineSweeperData", null);
		String matrix[][] = new String[9][9];
		ResponseHeaderDTO responseHeaderDTO = new ResponseHeaderDTO();
		MineSweeperResponse response = new MineSweeperResponse(matrix, new ArrayList<Bomb>(), new ArrayList<Treasure>());
		/*response.setBombList(MineSweeperDAO.getInstance().getBomb(gameId,levelId));
		response.setTreasureList(MineSweeperDAO.getInstance().getTreasure(gameId,levelId));*/
		try {
			getTreasuresAndBombs(gameId, levelId, response);
			matrix = setMatrix(response.getBombList().size(), response.getTreasureList().size(), matrix);
			if (response.getMatrix().length > 0) {
				responseHeaderDTO.setCode(ApplicationConstants.OK_STATUS);
				responseHeaderDTO.setStatus(ApplicationConstants.OK_STATUS);
				responseHeaderDTO.setMessage("Data received");
				responseHeaderDTO.setDeveloperMessage("Data received for Knowledge Hunt");
			} else {
				responseHeaderDTO.setCode(ApplicationConstants.NO_RECORDS_FOUND);
				responseHeaderDTO.setStatus(ApplicationConstants.NO_RECORDS_FOUND);
				responseHeaderDTO.setMessage("No data found");
				responseHeaderDTO.setDeveloperMessage("No data received for Knowledge Hunt");
			}
			
			response.setHeader(responseHeaderDTO);
		}
		catch (SQLException se) {
			throw new NanoServiceException(se);
		}
		return response;
		
	}
	
	private void  getTreasuresAndBombs(String gameID, String levelID, MineSweeperResponse response) throws NanoServiceException, SQLException{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getTreasuresAndBombs", null);
		GameDetailsRequestDTO requestDTO = new GameDetailsRequestDTO();
		Boolean isMultiple = false;
		requestDTO.setChapterId(new Integer(levelID));
		requestDTO.setGameId(new Integer(gameID));
		GameDetailsResponseDTO detailsResponseDTO = GameDetailsDAO.getInstance().searchGameDetails(requestDTO);
		if(detailsResponseDTO != null){
			for (QAOptionDetailsDTO qaOptionDTO : detailsResponseDTO.getQuestionOptionsList()){
				if(qaOptionDTO.getQuestionCategory() != null && qaOptionDTO.getQuestionCategory().equalsIgnoreCase("INFORMATION")){
					Treasure t = new Treasure(qaOptionDTO.getQuestion(), qaOptionDTO.getClueDescription());
					response.getTreasureList().add(t);
				}else if(qaOptionDTO.getQuestionCategory() != null && qaOptionDTO.getQuestionCategory().equalsIgnoreCase("BOMB")){
					Bomb b = new Bomb();
					b.setChoices(new ArrayList<Options>());
					b.setBombDescription(qaOptionDTO.getQuestion());
					b.setAnswerDescription(qaOptionDTO.getClueDescription());
					response.getBombList().add(b);
					isMultiple = false;
					for( OptionsDTO optionsDTO : qaOptionDTO.getOptionsList()){
						Options option = new Options();
						option.setOptionDesc(optionsDTO.getOptions());
						option.setIsCorrect("N");
						if(optionsDTO.getIsOptionCorrect() != null && optionsDTO.getIsOptionCorrect().equalsIgnoreCase("YES")){
							option.setIsCorrect("Y");
							if(isMultiple){
								b.setBombType("M");
							}
							isMultiple = true;
						}
						b.getChoices().add(option);
					}
				}
			}
		}
	}
	
	
	private  String[][] setMatrix(int bCount, int tCount, String[][] matrix){
		int i,j,k, indexs[];
		for(i=0; i <tCount;i++){
			indexs = getNextIndexs("T", matrix);
			j = indexs[0];
			k = indexs[1];
			matrix[j][k] = "T";
		}
		for(i=0; i <bCount * 2;i++){
			indexs = getNextBombIndexs("B", matrix);
			j = indexs[0];
			k = indexs[1];
			matrix[j][k] = "B";
		}
		for (i=0;i<9;i++){
			for(j=0;j<9;j++){
				if(matrix[i][j] == null || matrix[i][j].equals("")){
					if(getClue(i,j,"T",matrix) == 0)
						matrix[i][j] = "L";
					else
						matrix[i][j] = "" + getClue(i,j,"T",matrix); 
				}
			}
		}
	
		return matrix;
	}
	
	private  int randInt(int min, int max) {

	    // NOTE: Usually this should be a field rather than a method
	    // variable so that it is not re-seeded every call.
	    Random rand = new Random();

	    // nextInt is normally exclusive of the top value,
	    // so add 1 to make it inclusive
	    int randomNum = rand.nextInt((max - min) + 1) + min;

	    return randomNum;
	}
	
	private  int[] getNextIndexs(String type, String [][] matrix){
		int indexs[], j = 0, k = 0, count = 0; 
		boolean tryAgain = true;
		while (tryAgain){
			tryAgain = false;
			j = randInt(0, 8);
			k = randInt(0, 8);
			if (matrix[j][k] != null ){
				tryAgain = true;
			}else {
				count = getClue(j,k, type, matrix);
				if(count > 1){
					tryAgain = true;
				}
			}
		}
		indexs = new int[2];
		indexs[0] = j;
		indexs[1] = k;
		return indexs;
	}
	
	private  int[] getNextBombIndexs(String type, String[][]matrix){
		int indexs[], j = 0, k = 0, count = 0; 
		boolean tryAgain = true;
		while (tryAgain){
			tryAgain = false;
			j = randInt(0, 8);
			k = randInt(0, 8);
			if (matrix[j][k] != null ){
				tryAgain = true;
			}else {
				count = getClue(j,k, type,matrix);
				if(count > 2){
					tryAgain = true;
				}
				count = getClue(j,k, "T", matrix);
				if(count == 0){
					tryAgain = true;
				}
			}
		}
		indexs = new int[2];
		indexs[0] = j;
		indexs[1] = k;
		return indexs;
	}

	
	
	private  int getClue( int j, int k, String type, String[][]matrix){
		int clue = 0;
		
		if(k+1 < 9){
			if( matrix[j][k+1] != null && matrix[j][k+1].equals(type)){
				clue++;
			}
		}
		if(j+1 < 9){
			if( matrix[j+1][k] != null && matrix[j+1][k].equals(type)){
				clue++;
			}
		}
		if(k+1 < 9 && j+1 < 9){
			if( matrix[j+1][k+1] != null && matrix[j+1][k+1].equals(type)){
				clue++;
			}
		}
		if(j -1 >=0){
			if( matrix[j-1][k] != null && matrix[j-1][k].equals(type)){
				clue++;
			}
			if(k+1 < 9){
				if( matrix[j-1][k+1] != null && matrix[j-1][k+1].equals(type)){
					clue++;
				}
			}
		}
		if(k -1 >=0){
			if( matrix[j][k-1] != null && matrix[j][k-1].equals(type)){
				clue++;
			}
			if(j+1 < 9){
				if( matrix[j+1][k-1] != null && matrix[j+1][k-1].equals(type)){
					clue++;
				}
			}
		}
		if(k-1 >= 0 && j-1 >= 0){
			if( matrix[j-1][k-1] != null && matrix[j-1][k-1].equals(type)){
				clue++;
			}
		}
		
		return clue;
	}

}
