package com.manager;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.dao.GameDetailsDAO;
import com.exception.NanoServiceException;
import com.request.dto.GameDetailsRequestDTO;
import com.request.dto.GameScoreDetailsDTO;
import com.response.dto.ChapterDetailsResponseDTO;
import com.response.dto.GameDetailsResponseDTO;
import com.response.dto.GameDetailsTO;
import com.response.dto.HomeScreenGameDtlsDTO;
import com.util.LoggerUtil;

public class GameDetailsManager
{
private static final Logger LOGGER = Logger.getLogger(GameDetailsManager.class);
	
	private static String CLASS_NAME = "GameDetailsManager";
	
	private static volatile GameDetailsManager gameDetailsManager = null;
	
	
	public static synchronized  GameDetailsManager getInstance() throws NanoServiceException 
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getInstance", null);
		
		if(gameDetailsManager == null) 
		{
			
			LoggerUtil.info(LOGGER, "Singleton instance has not been initialized, entering synchronized block");
			
			gameDetailsManager = new GameDetailsManager();
			
			
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getInstance");
		
		return gameDetailsManager;
		
	}
	/**
	 * Description : This method will invoke,
	 * 					- question Details from nano_chapter table
	 * 					- multiple choice options Details from nano_options table
	 * 
	 * @param GameDetailsRequestDTO detailsRequestDTO
	 * 
	 * @return GameDetailsResponseDTO
	 * 
	 * @throws NanoServiceException
	 */
	public GameDetailsResponseDTO searchGameDetails(GameDetailsRequestDTO detailsRequestDTO) throws NanoServiceException
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "searchGameDetails", null);
		
		GameDetailsResponseDTO gameDetailsResponseDTO = null;
		
		GameDetailsDAO gameDetailsDAO = GameDetailsDAO.getInstance();

		try 
		{
			gameDetailsResponseDTO = gameDetailsDAO.searchGameDetails(detailsRequestDTO);
			
		} 
		catch (SQLException se) 
		{
			throw new NanoServiceException(se);
		}

		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "searchGameDetails");
		
		return gameDetailsResponseDTO;
	}
	/**
	 * Description: This method will retrieve list of all games based on key search.
	 * 
	 * @return GameDetailsTO
	 * 			- contains All game Details
	 * 
	 * @throws NanoServiceException
	 */
	public List<GameDetailsTO> getAllGameDtls(String gameKeySearch) throws NanoServiceException{
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getAllGameDtls", null);
		GameDetailsDAO gameDetailsDAO = GameDetailsDAO.getInstance();
		List<GameDetailsTO> allGameList = new ArrayList<GameDetailsTO>();
		
		try 
		{
			/** Invoke DAO to retrieve All game List **/
			allGameList = gameDetailsDAO.getAllGame(gameKeySearch);			
		} 
		catch (SQLException se)
		{
			throw new NanoServiceException(se);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getallGameDtls");
		
		return allGameList;
		
	}
	/**
	 * Description : This method will invoke the below methods.
	 * 					- setPopularGamesList
	 * 					- setAssignedGamesList
	 * 					- setNewFeedGamesList
	 * 
	 * @param employeeId
	 * 
	 * @return HomeScreenGameDtlsDTO
	 * 
	 * @throws NanoServiceException
	 */
	public HomeScreenGameDtlsDTO getHomeScrGameDtls(int employeeId) throws NanoServiceException, SQLException{
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getHomeScrGameDtls", null);
		HomeScreenGameDtlsDTO homescrnGameDtlsDTO = new HomeScreenGameDtlsDTO();
		List<GameDetailsTO> gameDtlsDTO = new ArrayList<GameDetailsTO>();
		
		/** 1. Get Popular Games Details **/
		gameDtlsDTO = getPopularGamesDtls();
		homescrnGameDtlsDTO.setPopularGamesList(gameDtlsDTO);
		
		/** 2. Get Assigned Games Details for the particular Player**/
		gameDtlsDTO = getAssignedGamesDtls(employeeId);
		homescrnGameDtlsDTO.setAssignedGamesList(gameDtlsDTO);
		
		/** 3. Get NewFeed Games Details **/
		gameDtlsDTO = getNewFeedGameDtls();
		homescrnGameDtlsDTO.setNewFeedGamesList(gameDtlsDTO);
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getHomeScrGameDtls");
		
		return homescrnGameDtlsDTO;
		
	}
	/**
	 * Description: This method will retrieve list of popular games commonly played by all players.
	 * 
	 * @return GameDetailsTO
	 * 			- contains Popular games Details
	 * 
	 * @throws NanoServiceException
	 */
	public List<GameDetailsTO> getPopularGamesDtls() throws NanoServiceException{
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getPopularGamesDtls", null);
		GameDetailsDAO gameDetailsDAO = GameDetailsDAO.getInstance();
		List<GameDetailsTO> popularGamesList = new ArrayList<GameDetailsTO>();
		
		try 
		{
			/** Invoke DAO to retrieve Popular game List **/
			popularGamesList = gameDetailsDAO.getPopularGames();			
		} 
		catch (SQLException se)
		{
			throw new NanoServiceException(se);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getPopularGamesDtls");
		
		return popularGamesList;
		
	}
	/**
	 * Description: This method will retrieve list of Assigned games to a particular player.
	 * 
	 * @return GameDetailsTO
	 * 			- contains Assigned games Details
	 * 
	 * @throws NanoServiceException
	 */
	public List<GameDetailsTO> getAssignedGamesDtls(int employeeId) throws NanoServiceException{
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getAssignedGamesDtls", null);
		GameDetailsDAO gameDetailsDAO = GameDetailsDAO.getInstance();
		List<GameDetailsTO> AssignedGamesList = new ArrayList<GameDetailsTO>();
		
		try
		{
			/** Invoke DAO to retrieve Assigned game List for the Particular Player **/
			AssignedGamesList = gameDetailsDAO.getAssignedGames(employeeId);
		} 
		catch (SQLException se) 
		{
			throw new NanoServiceException(se);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getAssignedGamesDtls");
		
		return AssignedGamesList;
		
	}
	/**
	 * Description: This method will retrieve list of first five Newly added games in the application. 
	 * 
	 * @return GameDetailsTO
	 * 			- contains New Feed games Details
	 * 
	 * @throws NanoServiceException
	 */
	public List<GameDetailsTO> getNewFeedGameDtls() throws NanoServiceException{
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getNewFeedGameDtls", null);
		GameDetailsDAO gameDetailsDAO = GameDetailsDAO.getInstance();
		List<GameDetailsTO> newFeedGamesList = new ArrayList<GameDetailsTO>();
		
		try 
		{
			/** Invoke DAO to retrieve New Feed game List **/
			newFeedGamesList = gameDetailsDAO.getNewFeedGames();
		} 
		catch (SQLException se) 
		{
			throw new NanoServiceException(se);
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getNewFeedGameDtls");
		
		return newFeedGamesList;
		
	}
	/**
	 * Description : This method will update the first score and calculate the highest score at the successful completion of game.
	 * 					- question Details from nano_chapter table
	 * 					- multiple choice options Details from nano_options table
	 * 
	 * @param GameDetailsRequestDTO detailsRequestDTO
	 * 
	 * @return GameScoreDetailsDTO
	 * 
	 * @throws NanoServiceException
	 * @throws ParseException 
	 */
	public boolean updateGameScore(GameScoreDetailsDTO scoreDetailsDTO) throws NanoServiceException, SQLException, ParseException
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "updateGameScore", null);
		boolean updateStaus = false;
		GameDetailsDAO gameDetailsDAO = GameDetailsDAO.getInstance();
		
		updateStaus = gameDetailsDAO.updateGameScore(scoreDetailsDTO);
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "updateGameScore");
		
		return updateStaus;
	}
	
	public ChapterDetailsResponseDTO getGameChaptersOrder(int gameId) throws NanoServiceException, SQLException
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getGameChaptersOrder", null);
		
		ChapterDetailsResponseDTO gameDetailsResponseDTO = null;
		
		GameDetailsDAO gameDetailsDAO = GameDetailsDAO.getInstance();

		gameDetailsResponseDTO = gameDetailsDAO.getGameChaptersOrder(gameId);

		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getGameChaptersOrder");
		
		return gameDetailsResponseDTO;
	}
}
