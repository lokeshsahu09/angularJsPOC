package com.manager;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.dao.UserDetailsDAO;
import com.exception.NanoServiceException;
import com.request.dto.UserRequestDTO;
import com.response.dto.DashboardResponseDTO;
import com.response.dto.UserResponseDTO;
import com.util.LoggerUtil;

public class NanoManager {

	
private static final Logger LOGGER = Logger.getLogger(NanoManager.class);
	
	private static String CLASS_NAME = "NanoManager";
	
	private static volatile NanoManager nanoManager = null;
	
	
	public static synchronized  NanoManager getInstance() throws NanoServiceException 
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getInstance", null);
		
		if(nanoManager == null) 
		{
			
			LoggerUtil.info(LOGGER, "Singleton instance has not been initialized, entering synchronized block");
			
			nanoManager = new NanoManager();
			
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getInstance");
		
		return nanoManager;
		
	}


	public UserResponseDTO getUserDetails(UserRequestDTO detailsRequestDTO) throws NanoServiceException
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getUserDetails", null);
		
		UserResponseDTO userDetailsResponseDTO = null;
		
		UserDetailsDAO userDetailsDAO = UserDetailsDAO.getInstance();

		try 
		{
			userDetailsResponseDTO = userDetailsDAO.getUserDetails(detailsRequestDTO);
		} 
		catch (SQLException se) 
		{
			throw new NanoServiceException(se);
		}

		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getUserDetails");
		
		return userDetailsResponseDTO;
	}
	
	public DashboardResponseDTO getDashBoardDetails(UserRequestDTO detailsRequestDTO) throws NanoServiceException
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getDashBoardDetails", null);
		
		DashboardResponseDTO dashboardResponseDTO = null;
		
		UserDetailsDAO userDetailsDAO = UserDetailsDAO.getInstance();

		try 
		{
			dashboardResponseDTO = userDetailsDAO.getDashBoardDetails(detailsRequestDTO);
		} 
		catch (SQLException se) 
		{
			throw new NanoServiceException(se);
		}

		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getDashBoardDetails");
		
		return dashboardResponseDTO;
	}
	
}
