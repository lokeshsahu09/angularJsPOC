/**
 * 
 */
package com.manager;

import java.sql.SQLException;

import com.dao.SupervisorDAO;
import com.dto.ResponseHeaderDTO;
import com.exception.NanoServiceException;
import com.request.dto.AssignGameToEmployeeRequestDTO;
import com.request.dto.GetNanoEmployeesRequestDTO;
import com.response.dto.GetNanoEmployeesResponseDTO;
import com.util.LoggerUtil;
import org.apache.log4j.Logger;
/**
 * @author 758645
 *
 */
public class SupervisorManager {
	
	private static final Logger LOGGER = Logger.getLogger(GameDetailsManager.class);
	
	private static String CLASS_NAME = "SupervisorManager";
	
	private static volatile SupervisorManager supervisorManager = null;
	
	public static synchronized  SupervisorManager getInstance() throws NanoServiceException 
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getInstance", null);
		
		if(supervisorManager == null) 
		{
			
			LoggerUtil.info(LOGGER, "Singleton instance has not been initialized, entering synchronized block");
			
			supervisorManager = new SupervisorManager();
			
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getInstance");
		
		return supervisorManager;
		
	}
	
	public GetNanoEmployeesResponseDTO getEmployees(GetNanoEmployeesRequestDTO getNanoEmployeesRequestDTO) throws NanoServiceException
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getEmployees", null);
		
		GetNanoEmployeesResponseDTO getNanoEmployeesResponseDTO = null;
		
		SupervisorDAO supervisorDAO = SupervisorDAO.getInstance();

		try 
		{
			getNanoEmployeesResponseDTO = supervisorDAO.getEmployees(getNanoEmployeesRequestDTO);
			
		} 
		catch (SQLException se) 
		{
			throw new NanoServiceException(se);
		}

		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getEmployees");
		
		return getNanoEmployeesResponseDTO;
	}
	
	public ResponseHeaderDTO assignToEmployees(AssignGameToEmployeeRequestDTO assignGameToEmployeeRequestDTO) throws NanoServiceException
	{
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "assignToEmployees", null);
		
		ResponseHeaderDTO responseHeaderDTO = null;
		
		SupervisorDAO supervisorDAO = SupervisorDAO.getInstance();

		try 
		{
			responseHeaderDTO = supervisorDAO.assignToEmployees(assignGameToEmployeeRequestDTO);
			
		} 
		catch (SQLException se) 
		{
			throw new NanoServiceException(se);
		}

		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "assignToEmployees");
		
		return responseHeaderDTO;
	}

}
