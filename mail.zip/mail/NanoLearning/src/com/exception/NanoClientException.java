/**
 * This program is proprietary to The Home Depot and is not to be reproduced,
 * used, or disclosed without permission of:
 * 
 *    The Home Depot
 *    2455 Paces Ferry Road, NW
 *    Atlanta, GA 30339-4024
 *
 *  FileName : PBTClientException
 */

package com.exception;

import com.util.ApplicationConstants;

/**
 * Custom exception class extending PBTException for client exceptions.
 * 
 * @author TCS
 */

public class NanoClientException extends NanoException {
	
	private static final long serialVersionUID = 5752344850677388639L;
	
	/**
	 * Constructor for error code.
	 * 
	 * @param errorCode
	 */
	public NanoClientException(int errorCode) {
		super(errorCode, ApplicationConstants.VALIDATION_ERROR_STATUS);
	}
	
	/**
	 * Constructor for error code and Throwable.
	 * 
	 * @param errorCode
	 */
	public NanoClientException(int errorCode, Throwable cause) {
		super(errorCode, cause);
	}

	/**
	 * Constructor when technical error occurs.
	 * 
	 * @param developerMessage
	 */
	public NanoClientException(String developerMessage) {
		super(developerMessage);
	}

	/**
	 * Constructor to convert other exceptions to IConXException.
	 * 
	 * @param cause
	 */
	public NanoClientException(Throwable cause) {
		super(cause);
	}

	/**
	 * Constructor for error code and status code.
	 * 
	 * @param errorCode
	 * @param statusCode
	 */
	public NanoClientException(int errorCode, int statusCode) {
		super(errorCode, statusCode);
	}

	/**
	 * Constructor for error code, status code and Throwable.
	 * 
	 * @param errorCode
	 * @param statusCode
	 */
	public NanoClientException(int errorCode, int statusCode, Throwable cause) {
		super(errorCode, statusCode, cause);
	}

	/**
	 * Constructor when technical error occurs during COS call.
	 * 
	 * @param developerMessage
	 * @param cosDataToDebug
	 */
	public NanoClientException(String developerMessage, String cosDataToDebug) {
		super(developerMessage, cosDataToDebug);
	}

	/**
	 * Constructor for developer message and Throwable.
	 * 
	 * @param developerMessage
	 * @param cause
	 */
	public NanoClientException(String developerMessage, Throwable cause) {
		super(developerMessage, cause);
	}

	/**
	 * Constructor for error code, developer message and COS data.
	 * 
	 * @param errorCode
	 * @param developerMessage
	 * @param cosDataToDebug
	 */
	public NanoClientException(int errorCode, String developerMessage, String cosDataToDebug) {
		super(errorCode, developerMessage, cosDataToDebug);
	}

	/**
	 * Constructor when technical error occurs during COS call.
	 * 
	 * @param developerMessage
	 * @param cosDataToDebug
	 */
	public NanoClientException(String developerMessage, String cosDataToDebug, Throwable cause) {
		super(developerMessage, cosDataToDebug, cause);
	}

}
