/**
 * This program is proprietary to The Home Depot and is not to be reproduced,
 * used, or disclosed without permission of:
 * 
 *    The Home Depot
 *    2455 Paces Ferry Road, NW
 *    Atlanta, GA 30339-4024
 *
 *  FileName : PBTException
 */

package com.exception;

import java.sql.SQLException;
import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.dto.ErrorDTO;
import com.sun.jersey.api.client.ClientHandlerException;
import com.util.ApplicationConstants;
import com.util.ErrorDetailsPropReader;
import com.util.NanoUtil;

/**
 * Custom exception class which can be used to set errors using different parameters and log errors in a formatted way.
 * 
 * @author TCS
 */

public class NanoException extends Exception {
	
	private static final long serialVersionUID = -5126047272617773015L;
	
	private static final Logger LOGGER = Logger.getLogger(NanoException.class);
	
	private String className;

	private String methodName;

	private int lineNumber;

	private Timestamp timeStamp;
	
	private ErrorDTO error;

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public int getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}

	public Timestamp getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Timestamp timeStamp) {
		this.timeStamp = timeStamp;
	}

	public ErrorDTO getError() {
		return error;
	}

	public void setError(ErrorDTO error) {
		this.error = error;
	}
	
	/**
	 * Constructor for error code.
	 * 
	 * @param errorCode
	 */
	public NanoException(int errorCode) {
		super(getProperty(errorCode));

		this.error = new ErrorDTO();
		this.error.setCode(errorCode);

		this.error.setMessage(getProperty(errorCode));
		this.error.setDeveloperMessage(getProperty(NanoUtil.getDevCode(errorCode)));

		setParams();
		logError(this);
	}

	/**
	 * Constructor for error code and Throwable.
	 * 
	 * @param errorCode
	 */
	public NanoException(int errorCode, Throwable cause) {
		super(getProperty(errorCode), cause);

		this.error = new ErrorDTO();
		this.error.setCode(errorCode);

		this.error.setMessage(getProperty(errorCode));
		this.error.setDeveloperMessage(getProperty(NanoUtil.getDevCode(errorCode)));

		setParams();
		logError(this, cause);
	}

	/**
	 * Constructor when technical error occurs.
	 * 
	 * @param developerMessage
	 */
	public NanoException(String developerMessage) {
		super(developerMessage);

		this.error = new ErrorDTO();
		this.error.setCode(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
		this.error.setMessage(ApplicationConstants.APPL_ERROR);
		this.error.setDeveloperMessage(developerMessage);

		setParams();
		logError(this);
	}

	/**
	 * Constructor to convert other exceptions to IConXException.
	 * 
	 * @param cause
	 */
	public NanoException(Throwable cause) {
		super(cause);

		this.error = new ErrorDTO();
		this.error.setCode(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);

		if (cause instanceof ClientHandlerException) {
			this.error.setMessage(ApplicationConstants.APPL_RETRY_ERROR);
		} else if (cause instanceof SQLException) {
			this.error.setMessage(ApplicationConstants.APPL_RETRY_ERROR);
		} else {
			this.error.setMessage(ApplicationConstants.APPL_ERROR);
		}

		this.error.setDeveloperMessage(cause.getClass() + ": " + cause.getMessage());

		setParams();
		logError(this, cause);
	}

	/**
	 * Constructor for error code and status code.
	 * 
	 * @param errorCode
	 * @param status
	 */
	public NanoException(int errorCode, int status) {
		super(getProperty(errorCode));

		this.error = new ErrorDTO();
		this.error.setCode(errorCode);
		this.error.setStatus(status);

		this.error.setMessage(getProperty(errorCode));
		this.error.setDeveloperMessage(getProperty(NanoUtil.getDevCode(errorCode)));

		setParams();
		logError(this);
	}

	/**
	 * Constructor for error code, status code and Throwable.
	 * 
	 * @param errorCode
	 * @param statusCode
	 * @param cause
	 */
	public NanoException(int errorCode, int status, Throwable cause) {
		super(getProperty(errorCode), cause);

		this.error = new ErrorDTO();
		this.error.setCode(errorCode);
		this.error.setStatus(status);

		this.error.setMessage(getProperty(errorCode));
		this.error.setDeveloperMessage(getProperty(NanoUtil.getDevCode(errorCode)).concat(ApplicationConstants.NEW_LINE).concat(
				cause.getClass() + ": " + cause.getMessage()));

		setParams();
		logError(this);
	}

	/**
	 * Constructor when technical error occurs during COS call.
	 * 
	 * @param developerMessage
	 * @param cosDataToDebug
	 */
	public NanoException(String developerMessage, String cosDataToDebug) {
		super(developerMessage);

		this.error = new ErrorDTO();
		this.error.setCode(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
		this.error.setMessage(ApplicationConstants.APPL_ERROR);
		this.error.setDeveloperMessage(developerMessage);

		setParams();
		logError(this);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.error(ApplicationConstants.NEW_LINE + cosDataToDebug);
		}
	}

	/**
	 * Constructor for developer message and Throwable.
	 * 
	 * @param developerMessage
	 * @param cause
	 */
	public NanoException(String developerMessage, Throwable cause) {
		super(developerMessage, cause);

		this.error = new ErrorDTO();
		this.error.setCode(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);

		if (cause instanceof ClientHandlerException) {
			this.error.setMessage(ApplicationConstants.APPL_RETRY_ERROR);
		} else if (cause instanceof SQLException) {
			this.error.setMessage(ApplicationConstants.APPL_RETRY_ERROR);
		} else {
			this.error.setMessage(ApplicationConstants.APPL_ERROR);
		}

		this.error.setDeveloperMessage(developerMessage.concat(ApplicationConstants.NEW_LINE).concat(cause.getClass() + ": " + cause.getMessage()));

		setParams();
		logError(this, cause);
	}

	/**
	 * Constructor for error code, developer message and COS data.
	 * 
	 * @param errorCode
	 * @param developerMessage
	 * @param cosDataToDebug
	 */
	public NanoException(int errorCode, String developerMessage, String cosDataToDebug) {
		super(developerMessage);

		this.error = new ErrorDTO();
		this.error.setCode(errorCode);

		this.error.setMessage(getProperty(errorCode));
		this.error.setDeveloperMessage(developerMessage);

		setParams();
		logError(this);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.error(ApplicationConstants.NEW_LINE + cosDataToDebug);
		}
	}

	/**
	 * Constructor when technical error occurs during COS call.
	 * 
	 * @param developerMessage
	 * @param cosDataToDebug
	 */
	public NanoException(String developerMessage, String cosDataToDebug, Throwable cause) {
		super(developerMessage, cause);

		this.error = new ErrorDTO();
		this.error.setCode(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);

		if (cause instanceof ClientHandlerException) {
			this.error.setMessage(ApplicationConstants.APPL_RETRY_ERROR);
		} else if (cause instanceof SQLException) {
			this.error.setMessage(ApplicationConstants.APPL_RETRY_ERROR);
		} else {
			this.error.setMessage(ApplicationConstants.APPL_ERROR);
		}

		this.error.setDeveloperMessage(developerMessage);

		setParams();
		logError(this, cause);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.error(ApplicationConstants.NEW_LINE + cosDataToDebug);
		}
	}

	/**
	 * This method sets class name, method name and line at which exception has occurred. Useful while debugging.
	 * 
	 */
	private void setParams() {
		this.className = this.getStackTrace()[0].getClassName();
		this.methodName = this.getStackTrace()[0].getMethodName();
		this.lineNumber = this.getStackTrace()[0].getLineNumber();
		this.timeStamp = new Timestamp(System.currentTimeMillis());
	}

	/**
	 * This method return the error message by invoking properties reader for a given error code.
	 * 
	 * @param errorCode
	 * 
	 * @return
	 */
	private static String getProperty(int errorCode) {
		ErrorDetailsPropReader errorDetailsPropReader = ErrorDetailsPropReader.getInsatance();
		return errorDetailsPropReader.getProperty(errorCode);
	}

	/**
	 * This method return the developer message by invoking properties reader for a given error code.
	 * 
	 * @param errorCode
	 * 
	 * @return
	 */
	private String getProperty(String errorCode) {
		ErrorDetailsPropReader errorDetailsPropReader = ErrorDetailsPropReader.getInsatance();
		return errorDetailsPropReader.getProperty(errorCode);
	}

	/**
	 * This method logs the error in a formatted manner.
	 * 
	 * @param PBTExp
	 */
	private void logError(NanoException PBTExp) {
		// Log the error.
		LOGGER.error(buildErrorMsg(PBTExp));
	}

	/**
	 * This method logs the error in a formatted manner.
	 * 
	 * @param PBTExp
	 */
	private void logError(NanoException PBTExp, Throwable cause) {
		// Log the error.
		LOGGER.error(buildErrorMsg(PBTExp), cause);
	}

	/**
	 * This method prepares error message from PBTException.
	 * 
	 * @param PBTExp
	 * 
	 * @return
	 */
	private String buildErrorMsg(NanoException PBTExp) {
		StringBuilder errorMsg = new StringBuilder();

		// Checking for null.
		if (PBTExp != null) {
			errorMsg.append(ApplicationConstants.NEW_LINE);
			errorMsg.append("There was an exception at time :: ");
			errorMsg.append(PBTExp.getTimeStamp());
			errorMsg.append(ApplicationConstants.NEW_LINE);
			errorMsg.append("Class name :: ");
			errorMsg.append(PBTExp.getClassName());
			errorMsg.append(ApplicationConstants.NEW_LINE);
			errorMsg.append("Method name :: ");
			errorMsg.append(PBTExp.getMethodName());
			errorMsg.append(ApplicationConstants.NEW_LINE);
			errorMsg.append("Line number :: ");
			errorMsg.append(PBTExp.getLineNumber());
			errorMsg.append(ApplicationConstants.NEW_LINE);
			errorMsg.append("Error Code :: ");
			errorMsg.append(PBTExp.getError().getCode());
			errorMsg.append(ApplicationConstants.NEW_LINE);
			errorMsg.append("End User Error Details :: ");
			errorMsg.append(PBTExp.getError().getMessage());
			errorMsg.append(ApplicationConstants.NEW_LINE);
			errorMsg.append("Technical Error Details :: ");
			errorMsg.append(PBTExp.getError().getDeveloperMessage());
		}

		return errorMsg.toString();
	}

	/**
	 * Generates a String representation of the PBTException Object.
	 * 
	 * @return String value of the object
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder(this.getClass().getSimpleName());
		builder.append(" Object {");
		builder.append(ApplicationConstants.NEW_LINE);
		builder.append("timeStamp: ").append(timeStamp).append(ApplicationConstants.NEW_LINE);
		builder.append("lineNumber: ").append(lineNumber).append(ApplicationConstants.NEW_LINE);
		builder.append("methodName: ").append(methodName).append(ApplicationConstants.NEW_LINE);
		builder.append("className: ").append(className).append(ApplicationConstants.NEW_LINE);
		builder.append("error: ").append(error).append(ApplicationConstants.NEW_LINE);
		builder.append("}");

		return builder.toString();
	}
	
}
