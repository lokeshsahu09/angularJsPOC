/**
 * 
 */
package com.dto;

/**
 * @author 758645
 *
 */
public class NanoGamesDTO {
	
	private int gameId;
	
	private String gameName;
	
	private String gameDesc;
	
	private String minimumScore;

	/**
	 * @return the gameId
	 */
	public int getGameId() {
		return gameId;
	}

	/**
	 * @param gameId the gameId to set
	 */
	public void setGameId(int gameId) {
		this.gameId = gameId;
	}

	/**
	 * @return the gameName
	 */
	public String getGameName() {
		return gameName;
	}

	/**
	 * @param gameName the gameName to set
	 */
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	/**
	 * @return the gameDesc
	 */
	public String getGameDesc() {
		return gameDesc;
	}

	/**
	 * @param gameDesc the gameDesc to set
	 */
	public void setGameDesc(String gameDesc) {
		this.gameDesc = gameDesc;
	}

	/**
	 * @return the minimumScore
	 */
	public String getMinimumScore() {
		return minimumScore;
	}

	/**
	 * @param minimumScore the minimumScore to set
	 */
	public void setMinimumScore(String minimumScore) {
		this.minimumScore = minimumScore;
	}

}
