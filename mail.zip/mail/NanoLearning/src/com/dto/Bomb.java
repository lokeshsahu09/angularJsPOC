package com.dto;

import java.util.ArrayList;
import java.util.List;

public class Bomb {
	
	private String bombDescription;
	private List<Options> choices;
	private String answer;
	private String answerDescription;
	private String bombId;
	private String bombType = "S";
	
	public Bomb() {
		super();
	}
	public Bomb(String bombDescription, ArrayList<Options> choice1, String answer,
			String answerDescription, String bombType) {
		super();
		this.bombDescription = bombDescription;
		this.choices = choice1;
		this.answer = answer;
		this.answerDescription = answerDescription;
		this.bombType = bombType;
	}
	public String getBombDescription() {
		return bombDescription;
	}
	public void setBombDescription(String bombDescription) {
		this.bombDescription = bombDescription;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getAnswerDescription() {
		return answerDescription;
	}
	public void setAnswerDescription(String answerDescription) {
		this.answerDescription = answerDescription;
	}
	public String getBombId() {
		return bombId;
	}
	public void setBombId(String bombId) {
		this.bombId = bombId;
	}
	public List<Options> getChoices() {
		return choices;
	}
	public void setChoices(ArrayList<Options> choice1) {
		this.choices = choice1;
	}
	public String getBombType() {
		return bombType;
	}
	public void setBombType(String bombType) {
		this.bombType = bombType;
	}

}
