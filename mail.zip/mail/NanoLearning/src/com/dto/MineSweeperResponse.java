package com.dto;

import java.util.ArrayList;
import java.util.List;
import com.dto.ResponseHeaderDTO;

public class MineSweeperResponse {

	private ResponseHeaderDTO header;
	private String[][] matrix;
	private List<Bomb> bombList;
	private List<Treasure> treasureList;
	
	public MineSweeperResponse(String[][] matrix, List<Bomb> bombList,
			ArrayList<Treasure> arrayList) {
		super();
		this.matrix = matrix;
		this.bombList = bombList;
		this.treasureList = arrayList;
	}

	public String[][] getMatrix() {
		return matrix;
	}

	public void setMatrix(String[][] matrix) {
		this.matrix = matrix;
	}

	public List<Bomb> getBombList() {
		return bombList;
	}

	public void setBombList(List<Bomb> bombList) {
		this.bombList = bombList;
	}

	public List<Treasure> getTreasureList() {
		return treasureList;
	}

	public void setTreasureList(List<Treasure> treasureList) {
		this.treasureList = treasureList;
	}
	
	/**
	 * @return the header
	 */
	public ResponseHeaderDTO getHeader() {
		return header;
	}

	/**
	 * @param header the header to set
	 */
	public void setHeader(ResponseHeaderDTO header) {
		this.header = header;
	}
	
	
}
