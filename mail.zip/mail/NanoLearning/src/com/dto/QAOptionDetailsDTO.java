package com.dto;

import java.util.List;

public class QAOptionDetailsDTO
{
	private int questionId;
	
	private String questionFormat;
	
	private String question;
	
	private int questionOrder;
   
	private String question_tip;
   
	private String clueDescription;
   
	private String questionCategory;
   
	private String questionSubCategory;
   
	private int questionCorrectScore;
   
	private int questionInCorrectScore;
   
	private List<OptionsDTO> optionsList;

	public int getQuestionId()
	{
		return questionId;
	}
	
	public void setQuestionId(int questionId)
	{
		this.questionId = questionId;
	}
	
	public String getQuestionFormat()
	{
		return questionFormat;
	}
	
	public void setQuestionFormat(String questionFormat)
	{
		this.questionFormat = questionFormat;
	}
	
	public String getQuestion()
	{
		return question;
	}
	
	public void setQuestion(String question)
	{
		this.question = question;
	}
	
	public int getQuestionOrder()
	{
		return questionOrder;
	}
	
	public void setQuestionOrder(int questionOrder)
	{
		this.questionOrder = questionOrder;
	}
	
	public String getQuestion_tip()
	{
		return question_tip;
	}
	
	public void setQuestion_tip(String question_tip)
	{
		this.question_tip = question_tip;
	}
	
	public String getClueDescription()
	{
		return clueDescription;
	}
	
	public void setClueDescription(String clueDescription)
	{
		this.clueDescription = clueDescription;
	}
	
	public String getQuestionCategory()
	{
		return questionCategory;
	}
	
	public void setQuestionCategory(String questionCategory)
	{
		this.questionCategory = questionCategory;
	}
	
	public String getQuestionSubCategory()
	{
		return questionSubCategory;
	}
	
	public void setQuestionSubCategory(String questionSubCategory)
	{
		this.questionSubCategory = questionSubCategory;
	}
	
	public int getQuestionCorrectScore()
	{
		return questionCorrectScore;
	}
	
	public void setQuestionCorrectScore(int questionCorrectScore)
	{
		this.questionCorrectScore = questionCorrectScore;
	}
	
	public int getQuestionInCorrectScore()
	{
		return questionInCorrectScore;
	}
	
	public void setQuestionInCorrectScore(int questionInCorrectScore)
	{
		this.questionInCorrectScore = questionInCorrectScore;
	}
	
	public List<OptionsDTO> getOptionsList()
	{
		return optionsList;
	}
	
	public void setOptionsList(List<OptionsDTO> optionsList)
	{
		this.optionsList = optionsList;
	}
	   
}
