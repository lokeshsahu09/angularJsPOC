package com.dto;

public class Treasure {

	private String treasureTitle;
	private String treasureDescription;
	public Treasure(){
		
	}
	public Treasure(String treasureTitle, String treasureDescription) {
		super();
		this.treasureTitle = treasureTitle;
		this.treasureDescription = treasureDescription;
	}
	public String getTreasureTitle() {
		return treasureTitle;
	}
	public void setTreasureTitle(String treasureTitle) {
		this.treasureTitle = treasureTitle;
	}
	public String getTreasureDescription() {
		return treasureDescription;
	}
	public void setTreasureDescription(String treasureDescription) {
		this.treasureDescription = treasureDescription;
	}
	
	
}
