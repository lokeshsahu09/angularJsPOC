package com.dto;

public class OptionsDTO
{
	private int optionId;
	
	private String optionFormat;
	
	private String options;
	
	private String isOptionCorrect;

	public int getOptionId()
	{
		return optionId;
	}

	public void setOptionId(int optionId)
	{
		this.optionId = optionId;
	}

	public String getOptionFormat()
	{
		return optionFormat;
	}

	public void setOptionFormat(String optionFormat)
	{
		this.optionFormat = optionFormat;
	}

	public String getOptions()
	{
		return options;
	}

	public void setOptions(String options)
	{
		this.options = options;
	}

	public String getIsOptionCorrect()
	{
		return isOptionCorrect;
	}

	public void setIsOptionCorrect(String isOptionCorrect)
	{
		this.isOptionCorrect = isOptionCorrect;
	}
}
