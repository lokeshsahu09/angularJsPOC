package com.response.dto;

import java.util.List;

import com.dto.ResponseHeaderDTO;
import com.request.dto.ChapterDetailsDTO;

public class ChapterDetailsResponseDTO
{
	private ResponseHeaderDTO header;
	
	private List<ChapterDetailsDTO> chapterDetails;

	public ResponseHeaderDTO getHeader()
	{
		return header;
	}

	public void setHeader(ResponseHeaderDTO header)
	{
		this.header = header;
	}

	public List<ChapterDetailsDTO> getChapterDetails()
	{
		return chapterDetails;
	}

	public void setChapterDetails(List<ChapterDetailsDTO> chapterDetails)
	{
		this.chapterDetails = chapterDetails;
	}
}
