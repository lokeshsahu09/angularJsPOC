package com.response.dto;

public class SupervisorDTO {

	private int supervisorEmpId;
	private int totalPoints;
	private int currentQuarter;
	private int lastQuarter;
	private String firstName;
	private String lastName;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getCurrentQuarter() {
		return currentQuarter;
	}
	public void setCurrentQuarter(int currentQuarter) {
		this.currentQuarter = currentQuarter;
	}
	public int getLastQuarter() {
		return lastQuarter;
	}
	public void setLastQuarter(int lastQuarter) {
		this.lastQuarter = lastQuarter;
	}
	public int getSupervisorEmpId() {
		return supervisorEmpId;
	}
	public void setSupervisorEmpId(int supervisorEmpId) {
		this.supervisorEmpId = supervisorEmpId;
	}
	public int getTotalPoints() {
		return totalPoints;
	}
	public void setTotalPoints(int totalPoints) {
		this.totalPoints = totalPoints;
	}
}
