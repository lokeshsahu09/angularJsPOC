package com.response.dto;

import java.sql.Time;

public class CompletedGameDTO {

	private int gameId;
	private String gameTitle;
	private String gameDescription;
	private int pointsEarned;
	private String completionDate;
	private String timeSpent;
	private long timeSpentLong;

	public long getTimeSpentLong() {
		return timeSpentLong;
	}
	public void setTimeSpentLong(long timeSpentLong) {
		this.timeSpentLong = timeSpentLong;
	}
	public String getTimeSpent() {
		return timeSpent;
	}
	public void setTimeSpent(String timeSpent) {
		this.timeSpent = timeSpent;
	}
	public String getGameTitle() {
		return gameTitle;
	}
	public void setGameTitle(String gameTitle) {
		this.gameTitle = gameTitle;
	}
	public int getGameId() {
		return gameId;
	}
	public void setGameId(int gameId) {
		this.gameId = gameId;
	}
	public String getGameDescription() {
		return gameDescription;
	}
	public void setGameDescription(String gameDescription) {
		this.gameDescription = gameDescription;
	}
	public int getPointsEarned() {
		return pointsEarned;
	}
	public void setPointsEarned(int pointsEarned) {
		this.pointsEarned = pointsEarned;
	}
	public String getCompletionDate() {
		return completionDate;
	}
	public void setCompletionDate(String completionDate) {
		this.completionDate = completionDate;
	}
	
}
