package com.response.dto;

public class GameDetailsTO {
	private String gameTitle;
	private String gameDescription;
	private String gameID;
	
	/**
	 * @return the gameTitle
	 */
	public String getGameTitle() {
		return gameTitle;
	}
	/**
	 * @param gameTitle the gameTitle to set
	 */
	public void setGameTitle(String gameTitle) {
		this.gameTitle = gameTitle;
	}
	/**
	 * @return the gameDescription
	 */
	public String getGameDescription() {
		return gameDescription;
	}
	/**
	 * @param gameDescription the gameDescription to set
	 */
	public void setGameDescription(String gameDescription) {
		this.gameDescription = gameDescription;
	}
	/**
	 * @return the gameID
	 */
	public String getGameID() {
		return gameID;
	}
	/**
	 * @param gameTitle the gameIDto set
	 */
	public void setGameID(String gameID) {
		this.gameID = gameID;
	}
}
