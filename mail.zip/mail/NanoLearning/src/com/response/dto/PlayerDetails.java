package com.response.dto;

import java.util.List;

public class PlayerDetails {

	private int employeeId;
	private int roleCd;
	private int SuperEmployeeId;
	private String firstName;
	private String lastName;
	private List<CompletedGameDTO> completedGameList;
	private int totalPoints;
	private int badgeId;
	private String badgeDescription;
	private String badgeUrl;
	private String totalTimeSpent;
	private long totalTimeLong;
	private double percentile;
	
	public double getPercentile() {
		return percentile;
	}
	public void setPercentile(double percentile) {
		this.percentile = percentile;
	}
	public String getTotalTimeSpent() {
		return totalTimeSpent;
	}
	public void setTotalTimeSpent(String totalTimeSpent) {
		this.totalTimeSpent = totalTimeSpent;
	}
	public long getTotalTimeLong() {
		return totalTimeLong;
	}
	public void setTotalTimeLong(long totalTimeLong) {
		this.totalTimeLong = totalTimeLong;
	}
	
	public int getBadgeId() {
		return badgeId;
	}
	public void setBadgeId(int badgeId) {
		this.badgeId = badgeId;
	}
	public String getBadgeDescription() {
		return badgeDescription;
	}
	public void setBadgeDescription(String badgeDescription) {
		this.badgeDescription = badgeDescription;
	}
	public String getBadgeUrl() {
		return badgeUrl;
	}
	public void setBadgeUrl(String badgeUrl) {
		this.badgeUrl = badgeUrl;
	}
	public List<CompletedGameDTO> getCompletedGameList() {
		return completedGameList;
	}
	public void setCompletedGameList(List<CompletedGameDTO> completedGameList) {
		this.completedGameList = completedGameList;
	}
	public int getTotalPoints() {
		return totalPoints;
	}
	public void setTotalPoints(int totalPoints) {
		this.totalPoints = totalPoints;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getRoleCd() {
		return roleCd;
	}
	public void setRoleCd(int roleCd) {
		this.roleCd = roleCd;
	}
	public int getSuperEmployeeId() {
		return SuperEmployeeId;
	}
	public void setSuperEmployeeId(int superEmployeeId) {
		SuperEmployeeId = superEmployeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
}
