package com.response.dto;

import java.util.List;

import com.dto.ResponseHeaderDTO;

public class GameSearchDtlsDTO {
	
	private ResponseHeaderDTO header;
	
	private List<GameDetailsTO> allGameList;
	
	/**
	 * @return the header
	 */
	public ResponseHeaderDTO getHeader() {
		return header;
	}
	/**
	 * @param header the header to set
	 */
	public void setHeader(ResponseHeaderDTO header) {
		this.header = header;
	}	
	
	/**
	* @return the allGameList
	*/
	public List<GameDetailsTO> getallGameList() {
		return allGameList;
	}

	/**
	 * @param allGameList the allGameList to set
	 */
	public void allGameList(List<GameDetailsTO> allGameList) {
		this.allGameList = allGameList;
	}

}
