package com.response.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import com.dto.ResponseHeaderDTO;

@XmlRootElement
public class UserResponseDTO {

	public UserResponseDTO() {}
	private ResponseHeaderDTO header;
    private int employeeId;
    private String role;
    private int roleCd;
	private String firstName;
	private String lastName;
	private List<CompletedGameDTO> completedGameList;
    private int totalPoints;
	private int badgeId;
    private String badgeDescription;
	private String badgeUrl;
	private String totalTimeSpent;
	private long totalTimeLong;
	
	public long getTotalTimeLong() {
		return totalTimeLong;
	}
	public void setTotalTimeLong(long totalTimeLong) {
		this.totalTimeLong = totalTimeLong;
	}
	public String getTotalTimeSpent() {
		return totalTimeSpent;
	}
	public void setTotalTimeSpent(String totalTimeSpent) {
		this.totalTimeSpent = totalTimeSpent;
	}
	public int getRoleCd() {
		return roleCd;
	}
	public void setRoleCd(int roleCd) {
		this.roleCd = roleCd;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public int getBadgeId() {
		return badgeId;
	}
	public void setBadgeId(int badgeId) {
		this.badgeId = badgeId;
	}
	public String getBadgeDescription() {
		return badgeDescription;
	}
	public void setBadgeDescription(String badgeDescription) {
		this.badgeDescription = badgeDescription;
	}
	public ResponseHeaderDTO getHeader(){
		return header;
	}
	public void setHeader(ResponseHeaderDTO header){
		this.header = header;
	}
	public int getTotalPoints() {
		return totalPoints;
	}
	public void setTotalPoints(int totalPoints) {
		this.totalPoints = totalPoints;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public List<CompletedGameDTO> getCompletedGameList() {
		return completedGameList;
	}
	public void setCompletedGameList(List<CompletedGameDTO> completedGameList) {
		this.completedGameList = completedGameList;
	}
	public String getBadgeUrl() {
		return badgeUrl;
	}
	public void setBadgeUrl(String badgeUrl) {
		this.badgeUrl = badgeUrl;
	}
	
}
