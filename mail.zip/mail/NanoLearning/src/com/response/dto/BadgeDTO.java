package com.response.dto;

public class BadgeDTO {

	private int badgeId;
	private String badgeDescription;
	private String badgeImage;
	private int badgeMinscore;
	
	public int getBadgeId() {
		return badgeId;
	}
	public void setBadgeId(int badgeId) {
		this.badgeId = badgeId;
	}
	public String getBadgeDescription() {
		return badgeDescription;
	}
	public void setBadgeDescription(String badgeDescription) {
		this.badgeDescription = badgeDescription;
	}
	public String getBadgeImage() {
		return badgeImage;
	}
	public void setBadgeImage(String badgeImage) {
		this.badgeImage = badgeImage;
	}
	public int getBadgeMinscore() {
		return badgeMinscore;
	}
	public void setBadgeMinscore(int badgeMinscore) {
		this.badgeMinscore = badgeMinscore;
	}
	
}
