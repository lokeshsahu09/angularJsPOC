/**
 * 
 */
package com.response.dto;

import java.util.List;

import com.dto.ResponseHeaderDTO;
import com.dto.EmployeeDTO;

/**
 * @author 758645
 *
 */
public class GetNanoEmployeesResponseDTO {
	
	private ResponseHeaderDTO header;
	
	private List<EmployeeDTO> employeesList;

	/**
	 * @return the header
	 */
	public ResponseHeaderDTO getHeader() {
		return header;
	}

	/**
	 * @param header the header to set
	 */
	public void setHeader(ResponseHeaderDTO header) {
		this.header = header;
	}

	/**
	 * @return the employeesList
	 */
	public List<EmployeeDTO> getEmployeesList() {
		return employeesList;
	}

	/**
	 * @param employeesList the employeesList to set
	 */
	public void setEmployeesList(List<EmployeeDTO> employeesList) {
		this.employeesList = employeesList;
	}
}
