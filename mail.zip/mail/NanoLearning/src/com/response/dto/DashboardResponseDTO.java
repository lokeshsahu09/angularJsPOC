package com.response.dto;

import java.util.List;
import java.util.Map;

import com.dto.ResponseHeaderDTO;

public class DashboardResponseDTO {

	public DashboardResponseDTO() {}
	private ResponseHeaderDTO header;
    private int employeeId;
    private String role;
    private int roleCd;
	private String firstName;
	private String lastName;
    private List<CompletedGameDTO> completedGameList;
	private int totalPoints;
    private int totalPlayerPoints;
	private int badgeId;
    private String badgeDescription;
	private String badgeUrl;
    private List<PlayerDetails> playerList;
	private List<SupervisorDTO> supervisorList;
	private String totalPlayerTimeSpent;
	private long totalPlayerTimeLong;
	private List<SupervisorDTO> quarterDetails;
    
	public List<SupervisorDTO> getQuarterDetails() {
		return quarterDetails;
	}
	public void setQuarterDetails(List<SupervisorDTO> quarterDetails) {
		this.quarterDetails = quarterDetails;
	}
	public String getTotalPlayerTimeSpent() {
		return totalPlayerTimeSpent;
	}
	public void setTotalPlayerTimeSpent(String totalPlayerTimeSpent) {
		this.totalPlayerTimeSpent = totalPlayerTimeSpent;
	}
	public long getTotalPlayerTimeLong() {
		return totalPlayerTimeLong;
	}
	public void setTotalPlayerTimeLong(long totalPlayerTimeLong) {
		this.totalPlayerTimeLong = totalPlayerTimeLong;
	}
	public List<SupervisorDTO> getSupervisorList() {
		return supervisorList;
	}
	public void setSupervisorList(List<SupervisorDTO> supervisorList) {
		this.supervisorList = supervisorList;
	}
	public int getRoleCd() {
		return roleCd;
	}
	public void setRoleCd(int roleCd) {
		this.roleCd = roleCd;
	}
	public List<PlayerDetails> getPlayerList() {
		return playerList;
	}
	public void setPlayerList(List<PlayerDetails> playerList) {
		this.playerList = playerList;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public List<CompletedGameDTO> getCompletedGameList() {
		return completedGameList;
	}
	public void setCompletedGameList(List<CompletedGameDTO> completedGameList) {
		this.completedGameList = completedGameList;
	}
	public int getTotalPoints() {
		return totalPoints;
	}
	public void setTotalPoints(int totalPoints) {
		this.totalPoints = totalPoints;
	}
	public int getTotalPlayerPoints() {
		return totalPlayerPoints;
	}
	public void setTotalPlayerPoints(int totalPlayerPoints) {
		this.totalPlayerPoints = totalPlayerPoints;
	}
	public int getBadgeId() {
		return badgeId;
	}
	public void setBadgeId(int badgeId) {
		this.badgeId = badgeId;
	}
	public String getBadgeDescription() {
		return badgeDescription;
	}
	public void setBadgeDescription(String badgeDescription) {
		this.badgeDescription = badgeDescription;
	}
	public String getBadgeUrl() {
		return badgeUrl;
	}
	public void setBadgeUrl(String badgeUrl) {
		this.badgeUrl = badgeUrl;
	}
    public ResponseHeaderDTO getHeader(){
		return header;
	}
	public void setHeader(ResponseHeaderDTO header){
		this.header = header;
	}
    public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
}
