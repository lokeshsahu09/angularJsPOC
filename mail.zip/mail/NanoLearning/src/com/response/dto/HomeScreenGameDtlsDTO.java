package com.response.dto;

import java.util.List;

import com.dto.ResponseHeaderDTO;

public class HomeScreenGameDtlsDTO {

	private ResponseHeaderDTO header;
	
	private List<GameDetailsTO> popularGamesList;
	
	private List<GameDetailsTO> assignedGamesList;
	
	private List<GameDetailsTO> newFeedGamesList;

	/**
	 * @return the popularGamesList
	 */
	public List<GameDetailsTO> getPopularGamesList() {
		return popularGamesList;
	}

	/**
	 * @param popularGamesList the popularGamesList to set
	 */
	public void setPopularGamesList(List<GameDetailsTO> popularGamesList) {
		this.popularGamesList = popularGamesList;
	}

	/**
	 * @return the assignedGamesList
	 */
	public List<GameDetailsTO> getAssignedGamesList() {
		return assignedGamesList;
	}

	/**
	 * @param assignedGamesList the assignedGamesList to set
	 */
	public void setAssignedGamesList(List<GameDetailsTO> assignedGamesList) {
		this.assignedGamesList = assignedGamesList;
	}

	/**
	 * @return the newFeedGamesList
	 */
	public List<GameDetailsTO> getNewFeedGamesList() {
		return newFeedGamesList;
	}

	/**
	 * @param newFeedGamesList the newFeedGamesList to set
	 */
	public void setNewFeedGamesList(List<GameDetailsTO> newFeedGamesList) {
		this.newFeedGamesList = newFeedGamesList;
	}

	/**
	 * @return the header
	 */
	public ResponseHeaderDTO getHeader() {
		return header;
	}

	/**
	 * @param header the header to set
	 */
	public void setHeader(ResponseHeaderDTO header) {
		this.header = header;
	}
	
	
}
