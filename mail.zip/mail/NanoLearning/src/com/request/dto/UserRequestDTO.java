package com.request.dto;

public class UserRequestDTO {

	private int employeeId;
	private String role;
	private int roleCd;
	
	public int getRoleCd() {
		return roleCd;
	}
	public void setRoleCd(int roleCd) {
		this.roleCd = roleCd;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
}
