package com.request.dto;

public class GameDetailsRequestDTO
{

	private int gameId;
	
	private int chapterId;

	public int getGameId()
	{
		return gameId;
	}

	public void setGameId(int gameId)
	{
		this.gameId = gameId;
	}

	public int getChapterId()
	{
		return chapterId;
	}

	public void setChapterId(int chapterId)
	{
		this.chapterId = chapterId;
	}

}
