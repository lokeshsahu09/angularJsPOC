package com.request.dto;

public class ChapterDetailsDTO
{
	private int gameId;
	
	private int chapterId;
	
	private int templateId;
	
	private String chapterTitle;
	
	private int chapterOrderNbr;
	 
	private String learning_format;
	
	private String learning;
	
	private int minScoreCompletion;

	public int getGameId()
	{
		return gameId;
	}

	public void setGameId(int gameId)
	{
		this.gameId = gameId;
	}

	public int getChapterId()
	{
		return chapterId;
	}

	public void setChapterId(int chapterId)
	{
		this.chapterId = chapterId;
	}

	public int getTemplateId()
	{
		return templateId;
	}

	public void setTemplateId(int templateId)
	{
		this.templateId = templateId;
	}

	public String getChapterTitle()
	{
		return chapterTitle;
	}

	public void setChapterTitle(String chapterTitle)
	{
		this.chapterTitle = chapterTitle;
	}

	public int getChapterOrderNbr()
	{
		return chapterOrderNbr;
	}

	public void setChapterOrderNbr(int chapterOrderNbr)
	{
		this.chapterOrderNbr = chapterOrderNbr;
	}

	public String getLearning_format()
	{
		return learning_format;
	}

	public void setLearning_format(String learning_format)
	{
		this.learning_format = learning_format;
	}

	public String getLearning()
	{
		return learning;
	}

	public void setLearning(String learning)
	{
		this.learning = learning;
	}

	public int getMinScoreCompletion()
	{
		return minScoreCompletion;
	}

	public void setMinScoreCompletion(int minScoreCompletion)
	{
		this.minScoreCompletion = minScoreCompletion;
	}
}
