/**
 * 
 */
package com.request.dto;

/**
 * @author 758645
 *
 */
public class GetNanoEmployeesRequestDTO {

	private int supervisorId;
	
	private int nanoGameId;

	/**
	 * @return the supervisorId
	 */
	public int getSupervisorId() {
		return supervisorId;
	}

	/**
	 * @param supervisorId the supervisorId to set
	 */
	public void setSupervisorId(int supervisorId) {
		this.supervisorId = supervisorId;
	}

	/**
	 * @return the nanoGameId
	 */
	public int getNanoGameId() {
		return nanoGameId;
	}

	/**
	 * @param nanoGameId the nanoGameId to set
	 */
	public void setNanoGameId(int nanoGameId) {
		this.nanoGameId = nanoGameId;
	}
}
