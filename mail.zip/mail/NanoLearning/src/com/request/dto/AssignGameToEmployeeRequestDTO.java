/**
 * 
 */
package com.request.dto;

import java.util.ArrayList;

/**
 * @author 758645
 *
 */
public class AssignGameToEmployeeRequestDTO {
	
	private ArrayList<Integer> employeeIds;
	
	private int gameId;
	
	private int supervisorId;

	/**
	 * @return the employeeIds
	 */
	public ArrayList<Integer> getEmployeeIds() {
		return employeeIds;
	}

	/**
	 * @param employeeIds the employeeIds to set
	 */
	public void setEmployeeIds(ArrayList<Integer> employeeIds) {
		this.employeeIds = employeeIds;
	}

	/**
	 * @return the gameId
	 */
	public int getGameId() {
		return gameId;
	}

	/**
	 * @param gameId the gameId to set
	 */
	public void setGameId(int gameId) {
		this.gameId = gameId;
	}

	/**
	 * @return the supervisorId
	 */
	public int getSupervisorId() {
		return supervisorId;
	}

	/**
	 * @param supervisorId the supervisorId to set
	 */
	public void setSupervisorId(int supervisorId) {
		this.supervisorId = supervisorId;
	}

}
