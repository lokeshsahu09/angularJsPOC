package com.request.dto;

import java.sql.Time;

public class GameScoreDetailsDTO
{
	private int employeeId;
	
	private int gameId;
	
	private int gameScore;
	
	private String gameTimeSpent;

	public int getEmployeeId()
	{
		return employeeId;
	}

	public void setEmployeeId(int employeeId)
	{
		this.employeeId = employeeId;
	}

	public int getGameId()
	{
		return gameId;
	}

	public void setGameId(int gameId)
	{
		this.gameId = gameId;
	}

	public int getGameScore()
	{
		return gameScore;
	}

	public void setGameScore(int gameScore)
	{
		this.gameScore = gameScore;
	}

	public String getGameTimeSpent()
	{
		return gameTimeSpent;
	}

	public void setGameTimeSpent(String gameTimeSpent)
	{
		this.gameTimeSpent = gameTimeSpent;
	}
}
