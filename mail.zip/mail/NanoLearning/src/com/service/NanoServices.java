package com.service;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import org.apache.log4j.Logger;

import com.dto.ResponseHeaderDTO;
import com.exception.NanoClientException;
import com.exception.NanoServiceException;
import com.manager.NanoManager;
import com.request.dto.UserRequestDTO;
import com.response.dto.DashboardResponseDTO;
import com.response.dto.UserResponseDTO;
import com.util.ApplicationConstants;
import com.util.GsonConverter;
import com.util.LoggerUtil;
import com.util.NanoUtil;

@Path("/nano")
public class NanoServices {
	
	private final Logger LOGGER = Logger.getLogger(NanoServices.class);
	
	private final String CLASS_NAME = "NanoServices";

	@POST
	@Path("/home")
	public String getHomeContent(@FormParam("data") String inputData,  @FormParam("version") @DefaultValue("1") int version) throws NanoServiceException {
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getHomeContent", null);
		
		UserResponseDTO userResponseDTO = new UserResponseDTO();
		
		ResponseHeaderDTO responseHeaderDTO = new ResponseHeaderDTO();
		
		switch(version) {
		
			case 1 : 
				try 
				{
					if(NanoUtil.isNotEmptyString(inputData)) 
					{
						UserRequestDTO detailsRequestDTO = (UserRequestDTO) GsonConverter.fromJson(inputData, UserRequestDTO.class);
						
						NanoManager nanoManager = NanoManager.getInstance();
						
						if(NanoUtil.validateUserRequest(detailsRequestDTO)){
							userResponseDTO = nanoManager.getUserDetails(detailsRequestDTO);
						}else{
							throw new NanoClientException("Invalid Request");
						}
						
						if(userResponseDTO != null) {
							
							responseHeaderDTO.setStatus(ApplicationConstants.OK_STATUS);
							
							userResponseDTO.setHeader(responseHeaderDTO);
						}
					} 
					else 
					{
						throw new NanoClientException("Empty Request");
					}
				}
				catch(NanoClientException ce) {
					userResponseDTO.setHeader(NanoUtil.prepareErrorResponseHeader(userResponseDTO.getHeader(), ce));
				}
				catch(NanoServiceException se) {
					userResponseDTO.setHeader(NanoUtil.prepareErrorResponseHeader(userResponseDTO.getHeader(), se));
				}
		
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getHomeContent");
		
		String resultJson = "{\"HomeResponse\": "+ GsonConverter.toJson(userResponseDTO) + "}";
		
		return resultJson;
	}
	
	@POST
	@Path("/dashboard")
	public String getDashBoardContent(@FormParam("data") String inputData,  @FormParam("version") @DefaultValue("1") int version) throws NanoServiceException {
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getDashBoardContent", null);
		
		DashboardResponseDTO userResponseDTO = new DashboardResponseDTO();
		
		ResponseHeaderDTO responseHeaderDTO = new ResponseHeaderDTO();
		
		switch(version) {
		
			case 1 : 
				try 
				{
					if(NanoUtil.isNotEmptyString(inputData)) 
					{
						UserRequestDTO detailsRequestDTO = (UserRequestDTO) GsonConverter.fromJson(inputData, UserRequestDTO.class);
						
						NanoManager nanoManager = NanoManager.getInstance();
						
						if(NanoUtil.validateUserRequest(detailsRequestDTO)){
							userResponseDTO = nanoManager.getDashBoardDetails(detailsRequestDTO);
						}else{
							throw new NanoClientException("Invalid Request");
						}
						
						if(userResponseDTO != null) {
							
							responseHeaderDTO.setStatus(ApplicationConstants.OK_STATUS);
							
							userResponseDTO.setHeader(responseHeaderDTO);
						}
					} 
					else 
					{
						throw new NanoClientException("Empty Request");
					}
				}
				catch(NanoClientException ce) {
					userResponseDTO.setHeader(NanoUtil.prepareErrorResponseHeader(userResponseDTO.getHeader(), ce));
				}
				catch(NanoServiceException se) {
					userResponseDTO.setHeader(NanoUtil.prepareErrorResponseHeader(userResponseDTO.getHeader(), se));
				}
		
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getDashBoardContent");
		
		String resultJson = "{\"DashBoardResponse\": "+ GsonConverter.toJson(userResponseDTO) + "}";
		
		return resultJson;
	}
	
}
