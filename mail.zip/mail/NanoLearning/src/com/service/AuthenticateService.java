package com.service;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import java.net.URLEncoder;

@Path("/authenticate")
public class AuthenticateService {
		
	@POST
	@Path("/login")
	public static String authenicate(@FormParam("data") String inputData) throws Exception
	{

		Client client = null;
		String responsejson = null;
		String data = null;
		WebResource webResource = null;
		ClientResponse response = null;
		
		try
		{
			
			client = Client.create();
			
			webResource = client.resource("http://inchnsirthdapp.india.tcs.com/TMS/rs/auth/externallogin");
			
			data = URLEncoder.encode(inputData, "UTF-8");

			response = webResource.accept("application/json").post(ClientResponse.class, "data=" + data);
			
			responsejson = response.getEntity(String.class);
		}
		
	    finally
	    {
        	if (client != null)
        	{
        		client.destroy();
        	}
	    }
		
		return responsejson;
	}
	 
}