package com.service;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import org.apache.log4j.Logger;

import com.dto.ResponseHeaderDTO;
import com.exception.NanoClientException;
import com.exception.NanoServiceException;
import com.manager.GameDetailsManager;
import com.request.dto.GameDetailsRequestDTO;
import com.request.dto.GameScoreDetailsDTO;
import com.response.dto.ChapterDetailsResponseDTO;
import com.response.dto.GameDetailsResponseDTO;
import com.response.dto.GameDetailsTO;
import com.response.dto.GameSearchDtlsDTO;
import com.response.dto.HomeScreenGameDtlsDTO;
import com.util.ApplicationConstants;
import com.util.GsonConverter;
import com.util.LoggerUtil;
import com.util.NanoUtil;

@Path("/gameDetailsService")
public class GameDetailsService
{
	private final Logger LOGGER = Logger.getLogger(GameDetailsService.class);
	
	private final String CLASS_NAME = "GameDetailsService";
	/**
	 * Description: This method will retrieve the Chapter Information for the provided game_id and level_id
	 * @param inputData
	 * 
	 * @param version
	 * 
	 * @return String
	 * 
	 * @throws NanoServiceException
	 * 
	 */
	@POST
	@Path("/searchGameDetails") 
		
	public String searchGameDetails(@FormParam("data") String inputData, @FormParam("version") @DefaultValue("1") int version) throws NanoServiceException {
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "searchGameDetails", null);
		
		GameDetailsResponseDTO gameDetailsResponseDTO = new GameDetailsResponseDTO();
		
		ResponseHeaderDTO responseHeaderDTO = new ResponseHeaderDTO();
		
		switch(version) {
		
			case 1 : 
				try 
				{
					if(NanoUtil.isNotEmptyString(inputData)) 
					{
						GameDetailsRequestDTO detailsRequestDTO = (GameDetailsRequestDTO) GsonConverter.fromJson(inputData, GameDetailsRequestDTO.class);
						
						GameDetailsManager manageWONManager = GameDetailsManager.getInstance();
						
						gameDetailsResponseDTO = manageWONManager.searchGameDetails(detailsRequestDTO);
						
						if(gameDetailsResponseDTO != null) {
							
							responseHeaderDTO.setStatus(ApplicationConstants.OK_STATUS);
							
							gameDetailsResponseDTO.setHeader(responseHeaderDTO);
						}
					} 
					else 
					{
						throw new NanoClientException("Empty Request");
					}
				}
				catch(NanoClientException ce) {
					gameDetailsResponseDTO.setHeader(NanoUtil.prepareErrorResponseHeader(gameDetailsResponseDTO.getHeader(), ce));
				}
				catch(NanoServiceException se) {
					gameDetailsResponseDTO.setHeader(NanoUtil.prepareErrorResponseHeader(gameDetailsResponseDTO.getHeader(), se));
				}
		
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "searchGameDetails");
		
		return GsonConverter.toJson(gameDetailsResponseDTO);
	}
	/**
	 * Description: This method will retrieve the All Game List
	 * @param gameKeySearch
	 * 
	 * @return String
	 * 
	 * @throws NanoServiceException
	 * 
	 * @throws SQLException 
	 */
	@POST
	@Path("/getSearchGameDtls") 
	public String getSearchGameDtls(@QueryParam("gameKeySearch") String gameKeySearch) throws NanoServiceException, SQLException {
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getSearchGameDtls", null);
		
		GameSearchDtlsDTO gameSearchDtlsDTO = new GameSearchDtlsDTO(); 
		ResponseHeaderDTO responseHeaderDTO = new ResponseHeaderDTO();

		try 
		{
			if(gameKeySearch != null) 
			{	
				//GameSearchRequestDTO searchRequestDTO = (GameSearchRequestDTO) GsonConverter.fromJson(gameKeySearch, GameSearchRequestDTO.class);
				/**Invoke gameDetailsManager **/
				GameDetailsManager gameDtlsManager = GameDetailsManager.getInstance();						
				List<GameDetailsTO> gamesList = gameDtlsManager.getAllGameDtls(gameKeySearch);
						
				if(gamesList != null) {							
					responseHeaderDTO.setStatus(ApplicationConstants.OK_STATUS);							
					gameSearchDtlsDTO.allGameList(gamesList);
				}
			} 
			else 
			{
				throw new NanoClientException("Game Search is Empty");
			}
		}
		catch(NanoClientException ce) {
			gameSearchDtlsDTO.setHeader(NanoUtil.prepareErrorResponseHeader(gameSearchDtlsDTO.getHeader(), ce));
			responseHeaderDTO.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
		}
		catch(NanoServiceException se) {
			gameSearchDtlsDTO.setHeader(NanoUtil.prepareErrorResponseHeader(gameSearchDtlsDTO.getHeader(), se));
			responseHeaderDTO.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
		}
		
		gameSearchDtlsDTO.setHeader(responseHeaderDTO);
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getSearchGameDtls");
		
		return GsonConverter.toJson(gameSearchDtlsDTO); 
	}
	/**
	 * Description: This method will retrieve the List Popular Games, 
	 * 					Assigned Games for the particular Player and Newly added games in the application
	 * @param employeeId
	 * 
	 * @param version
	 * 
	 * @return String
	 * 
	 * @throws NanoServiceException
	 * 
	 * @throws SQLException 
	 */
	@POST
	@Path("/getHomeScrnGameDtls") 
	public String getHomeScrGameDtls(@QueryParam("employeeId") int employeeId , @FormParam("version") @DefaultValue("1") int version) throws NanoServiceException, SQLException {
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getHomeScrGameDtls", null);
		
		HomeScreenGameDtlsDTO homeScrGameDtlsDTO = new HomeScreenGameDtlsDTO(); 
		ResponseHeaderDTO responseHeaderDTO = new ResponseHeaderDTO();
		
		switch(version) {
			
			case 1 : 
				try 
				{
					if(employeeId != 0 ) 
					{	
						/**Invoke gameDetailsManager **/
						GameDetailsManager gameDtlsManager = GameDetailsManager.getInstance();						
						homeScrGameDtlsDTO = gameDtlsManager.getHomeScrGameDtls(employeeId);
						
						if(homeScrGameDtlsDTO != null) {							
							responseHeaderDTO.setStatus(ApplicationConstants.OK_STATUS);							
							homeScrGameDtlsDTO.setHeader(responseHeaderDTO);
						}
					} 
					else 
					{
						throw new NanoClientException("Employee Id is Empty");
					}
				}
				catch(NanoClientException ce) {
					homeScrGameDtlsDTO.setHeader(NanoUtil.prepareErrorResponseHeader(homeScrGameDtlsDTO.getHeader(), ce));
				}
				catch(NanoServiceException se) {
					homeScrGameDtlsDTO.setHeader(NanoUtil.prepareErrorResponseHeader(homeScrGameDtlsDTO.getHeader(), se));
				}
			LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getHomeScrGameDtls");
			
		}
		return GsonConverter.toJson(homeScrGameDtlsDTO); 
	}
	/**
	 * Description: This method will update the score details at the successfully completion of game.
	 * @param inputData
	 * 
	 * @param version
	 * 
	 * @return String
	 * 
	 * @throws NanoServiceException
	 * @throws SQLException 
	 * @throws ParseException 
	 * 
	 */
	@POST
	@Path("/updateGameScore") 
		
	public String updateGameScore(@FormParam("data") String inputData, @FormParam("version") @DefaultValue("1") int version) throws NanoServiceException, SQLException, ParseException {
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "updateGameScore", null);
		
		ResponseHeaderDTO responseHeaderDTO = new ResponseHeaderDTO();
		
		switch(version) {
		
			case 1 : 
				try 
				{
					if(NanoUtil.isNotEmptyString(inputData)) 
					{
						GameScoreDetailsDTO scoreDetailsDTO = (GameScoreDetailsDTO) GsonConverter.fromJson(inputData, GameScoreDetailsDTO.class);
						
						GameDetailsManager manageWONManager = GameDetailsManager.getInstance();
						
						boolean updateStatus = manageWONManager.updateGameScore(scoreDetailsDTO);
						
						if(updateStatus) {
							
							responseHeaderDTO.setStatus(ApplicationConstants.OK_STATUS);
							
							responseHeaderDTO.setMessage("Game Score has been updated successfully.");
						}
					} 
					else 
					{
						throw new NanoClientException("Empty Request");
					}
				}
				catch(NanoClientException e) {
					responseHeaderDTO.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
					
					responseHeaderDTO.setMessage("Error occured in updating the score.");
				}
				catch(NanoServiceException e) {
					responseHeaderDTO.setStatus(ApplicationConstants.INTERNAL_SERVER_ERROR_STATUS);
					
					responseHeaderDTO.setMessage("Error occured in updating the score.");
				}
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "updateGameScore");
		
		return GsonConverter.toJson(responseHeaderDTO);
	}
	/**
	 * Description: This method will retrieve the List Popular Games, 
	 * 					Assigned Games for the particular Player and Newly added games in the application
	 * @param employeeId
	 * 
	 * @param version
	 * 
	 * @return String
	 * 
	 * @throws NanoServiceException
	 * 
	 * @throws SQLException 
	 */
	@POST
	@Path("/getGameChapters") 
	public String getGameChaptersOrder(@FormParam("gameId") int gameId , @FormParam("version") @DefaultValue("1") int version) throws NanoServiceException, SQLException, NanoClientException {
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getGameChapters", null);
		
		ChapterDetailsResponseDTO gameDetailsResponseDTO = new ChapterDetailsResponseDTO();
		
		ResponseHeaderDTO responseHeaderDTO = new ResponseHeaderDTO();
		
		switch(version) {
		
			case 1 : 
				try 
				{
					GameDetailsManager manageWONManager = GameDetailsManager.getInstance();
					
					gameDetailsResponseDTO = manageWONManager.getGameChaptersOrder(gameId);
					
					if(gameDetailsResponseDTO != null) {
						
						responseHeaderDTO.setStatus(ApplicationConstants.OK_STATUS);
						
						gameDetailsResponseDTO.setHeader(responseHeaderDTO);
					}
				}
				catch(NanoServiceException se) {
					gameDetailsResponseDTO.setHeader(NanoUtil.prepareErrorResponseHeader(gameDetailsResponseDTO.getHeader(), se));
				}
		
		}
		
		LoggerUtil.methodExitInfo(LOGGER, CLASS_NAME, "getGameChapters");
		
		return GsonConverter.toJson(gameDetailsResponseDTO);
	}
}
