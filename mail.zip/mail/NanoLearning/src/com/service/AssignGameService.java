/**
 * 
 */
package com.service;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import org.apache.log4j.Logger;

import com.dto.ResponseHeaderDTO;
import com.exception.NanoClientException;
import com.exception.NanoServiceException;
import com.manager.SupervisorManager;
import com.request.dto.AssignGameToEmployeeRequestDTO;
import com.request.dto.GetNanoEmployeesRequestDTO;
import com.response.dto.GetNanoEmployeesResponseDTO;
import com.util.ApplicationConstants;
import com.util.GsonConverter;
import com.util.LoggerUtil;
import com.util.NanoUtil;

/**
 * @author 758645
 *
 */
@Path("/assignGame")
public class AssignGameService {
	
	private final Logger LOGGER = Logger.getLogger(GameDetailsService.class);
	
	private final String CLASS_NAME = "AssignGameService";
	
	@POST
	@Path("/getEmployees")
	
	public String getEmployees(@FormParam("data") String inputData, @FormParam("version") @DefaultValue("1") int version) throws NanoServiceException {
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getEmployees", null);
		
		GetNanoEmployeesResponseDTO getNanoEmployeesResponseDTO = new GetNanoEmployeesResponseDTO();
		
		ResponseHeaderDTO responseHeaderDTO = new ResponseHeaderDTO();
		
		switch(version) {
		
		case 1 : 
			try 
			{
				if(NanoUtil.isNotEmptyString(inputData)) 
				{
					GetNanoEmployeesRequestDTO getNanoEmployeesRequestDTO = (GetNanoEmployeesRequestDTO) GsonConverter.fromJson(inputData, GetNanoEmployeesRequestDTO.class);
					
					SupervisorManager supervisorManager = SupervisorManager.getInstance();
					
					getNanoEmployeesResponseDTO = supervisorManager.getEmployees(getNanoEmployeesRequestDTO);
					
					if(!(getNanoEmployeesResponseDTO.getEmployeesList()).isEmpty()) {
						responseHeaderDTO.setStatus(ApplicationConstants.OK_STATUS);
						responseHeaderDTO.setCode(ApplicationConstants.OK_STATUS);
						getNanoEmployeesResponseDTO.setHeader(responseHeaderDTO);
					} else {
						responseHeaderDTO.setCode(ApplicationConstants.NO_RECORDS_FOUND);
						responseHeaderDTO.setStatus(ApplicationConstants.NO_RECORDS_FOUND);
						responseHeaderDTO.setMessage("No Employees found for the Supervisor");
						getNanoEmployeesResponseDTO.setHeader(responseHeaderDTO);
					}
				} 
				else 
				{
					throw new NanoClientException("Empty Request");
				}
			}
			catch(NanoClientException ce) {
				getNanoEmployeesResponseDTO.setHeader(NanoUtil.prepareErrorResponseHeader(getNanoEmployeesResponseDTO.getHeader(), ce));
			}
			catch(NanoServiceException se) {
				getNanoEmployeesResponseDTO.setHeader(NanoUtil.prepareErrorResponseHeader(getNanoEmployeesResponseDTO.getHeader(), se));
			}
	
	}
		
		return GsonConverter.toJson(getNanoEmployeesResponseDTO);
	}
	
	@POST
	@Path("/assignToEmployees")
	
	public String assignToEmployees(@FormParam("data") String inputData, @FormParam("version") @DefaultValue("1") int version) throws NanoServiceException {
		
		LoggerUtil.methodEntryInfo(LOGGER, CLASS_NAME, "getEmployees", null);
		
		ResponseHeaderDTO responseHeaderDTO = new ResponseHeaderDTO();
		
		switch(version) {
		
		case 1 : 
			try 
			{
				if(NanoUtil.isNotEmptyString(inputData)) 
				{
					AssignGameToEmployeeRequestDTO assignGameToEmployeeRequestDTO = (AssignGameToEmployeeRequestDTO) GsonConverter.fromJson(inputData, AssignGameToEmployeeRequestDTO.class);
					
					SupervisorManager supervisorManager = SupervisorManager.getInstance();
					
					responseHeaderDTO = supervisorManager.assignToEmployees(assignGameToEmployeeRequestDTO);
				} 
				else 
				{
					throw new NanoClientException("Empty Request");
				}
			}
			catch(NanoClientException ce) {
				responseHeaderDTO = NanoUtil.prepareErrorResponseHeader(responseHeaderDTO, ce);
			}
			catch(NanoServiceException se) {
				responseHeaderDTO = NanoUtil.prepareErrorResponseHeader(responseHeaderDTO, se);
			}
	
	}
		
		return GsonConverter.toJson(responseHeaderDTO);
	}

}
