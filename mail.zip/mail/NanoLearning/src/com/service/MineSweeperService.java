package com.service;

import java.sql.SQLException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import org.apache.log4j.Logger;
import com.dto.MineSweeperResponse;
import com.exception.NanoServiceException;
import com.manager.MineSweeperManager;
import com.util.GsonConverter;
import com.util.LoggerUtil;


//TODO: add the path value for your service here
@Path("/minesweeper")
public class MineSweeperService
{

    // Logger instance
    private static final Logger logger = Logger.getLogger(MineSweeperService.class);
    
    //TODO: update these values based on your needs
    @GET
    @Produces("application/json")
    @Path("/getmatrix")
	
    //TODO: modify this to include the inputs you need and change the method name
    public String getMatrix(@QueryParam("gameId") String gameId,@QueryParam("levelId") String levelId )
    {
    	MineSweeperResponse response = null;
    	try{
    		
    		response = MineSweeperManager.getInstance().getMineSweeperData(gameId, levelId);
    		
    	}	catch(SQLException se) {
			LoggerUtil.info(logger, se.getMessage());
		}
		catch(NanoServiceException se) {
			LoggerUtil.info(logger, se.getMessage());
		}
				
		return GsonConverter.toJson(response);
    }  
	
    //TODO: add as many additional methods as needed using the above format

    

}

