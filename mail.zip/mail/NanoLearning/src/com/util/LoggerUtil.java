package com.util;

import org.apache.log4j.Logger;

/**
 * Contains required methods for logging at different levels.
 * 
 * @author TCS
 */
public class LoggerUtil {


	/**
	 * Private Constructor to avoid instantiating the class as all the methods in class are static.
	 */
	private LoggerUtil() {
	}

	/**
	 * This method can be used to log a message at info level.
	 * 
	 * @param logger
	 * @param message
	 */
	public static void info(Logger logger, String message) {
		logger.info(message);
	}

	public static void methodEntryInfo(Logger logger, String className, String methodName, Object inputOfMethod) {
		if (null != inputOfMethod) {
			logger.info("Entering into " + methodName + "  method of " + className + " with data: " + inputOfMethod.toString());
		} else {
			logger.info("Entering into " + methodName + "  method of " + className);
		}
	}

	/**
	 * This method can be used to log a method exit statement at info level.
	 * 
	 * @param logger
	 * @param className
	 * @param methodName
	 */
	public static void methodExitInfo(Logger logger, String className, String methodName) {
		logger.info("Exiting from " + methodName + " method of " + className);
	}
}
