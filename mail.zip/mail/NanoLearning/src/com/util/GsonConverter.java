package com.util;

import com.exception.NanoServiceException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

public class GsonConverter {
	static Gson gson;

	private static Gson getGson() {
		return gson == null ? new GsonBuilder().setDateFormat("yyyy-MM-dd").create() : gson;
	}

	public static String toJson(Object inputClass) {
		return getGson().toJson(inputClass);
	}

	public static Object fromJson(String jsonInput, Class<?> classType) throws NanoServiceException {
		Object object = null;
		try {
			object = getGson().fromJson(jsonInput, classType);
		} catch (JsonSyntaxException jse) {
			throw new NanoServiceException(jse);
		}

		return object;
	}

}
