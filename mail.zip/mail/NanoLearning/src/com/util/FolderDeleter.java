package com.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class FolderDeleter {

	public static String create(String folder) throws IOException {

		String currDate = new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime());
		boolean noOldDir = false;
		//System.out.println(currDate);
		int count = -1;
		do {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, count);
			String yestrday = new SimpleDateFormat("yyyyMMdd").format(cal.getTime());
			//System.out.println(yestrday);
			File oldDir = new File(folder + "/" + yestrday);
			if (!oldDir.exists()) {
				noOldDir = true;
			} else {
				delete(oldDir);
			}
			count--;
		} while (!noOldDir);

		File newDir = new File(folder + "/" + currDate);

		newDir.mkdirs();

		//System.out.println(newDir.getAbsolutePath());
		return newDir.getAbsolutePath();

	}

	public static void delete(File file) throws IOException {

		if (file.isDirectory()) {

			if (file.list().length == 0) {

				file.delete();
				//System.out.println("Directory is deleted : " + file.getAbsolutePath());

			} else {

				// list all the directory contents
				String files[] = file.list();

				for (String temp : files) {
					// construct the file structure
					File fileDelete = new File(file, temp);

					// recursive delete
					delete(fileDelete);
				}

				// check the directory again, if empty then delete it
				if (file.list().length == 0) {
					file.delete();
					//System.out.println("Directory is deleted : " + file.getAbsolutePath());
				}
			}

		} else {
			// if file, then delete it
			file.delete();
			//System.out.println("File is deleted : " + file.getAbsolutePath());
		}
	}
}
