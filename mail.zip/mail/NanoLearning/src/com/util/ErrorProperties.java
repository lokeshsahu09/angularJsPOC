package com.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ErrorProperties {
	private static final Properties PROPERTIES = new Properties();
	private static ErrorProperties instance = null;

	private ErrorProperties() {
		loadPropertiesFile();
	}

	public static synchronized ErrorProperties getInstance() {
		if (instance == null) {
			instance = new ErrorProperties();
		}

		return instance;
	}

	private static void loadPropertiesFile() {
		FileInputStream fis = null;
		try {
			PROPERTIES.load(ErrorProperties.class.getResourceAsStream("ErrorDetails.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public String getProperty(String key) {
		String property = PROPERTIES.getProperty(key);
		return property;
	}

	public String getProperty(int key) {
		String property = PROPERTIES.getProperty(Integer.toString(key));
		return property;
	}
}
