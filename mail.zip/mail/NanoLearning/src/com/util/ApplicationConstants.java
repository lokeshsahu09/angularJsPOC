package com.util;

import java.util.regex.Pattern;

public class ApplicationConstants {

	public static final String SUCCESS = "SUCCESS";

	public static final String FAILURE = "FALIURE";

	public static final String NEW_LINE = System.getProperty("line.separator");

	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";

	public static final String DATE_WITH_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

	public static final String DEFAULT_TIME_FORMAT = "HH:mm:ss";

	public static final String COMMA_DELIMITER = ", ";
	
	public static final String SPACE_DELIMITER = " ";

	public static final String SINGLE_QUOTE = "'";

	private static final String ONLY_DATE_REGEX = "^[0-9]{4}-(((0[13578]|(10|12))-(0[1-9]|[1-2][0-9]|3[0-1]))|(02-(0[1-9]|[1-2][0-9]))|((0[469]|11)-(0[1-9]|[1-2][0-9]|30)))$";

	private static final String ONLY_NUMBERS_REGEX = "^?\\d+$";

	private static final String NO_SPECIAL_CHARS_REGEX = "^[ ,.a-zA-Z0-9]*$";

	private static final String NUMBERS_COMMA_SPERATED_REGEX = "^[ ,0-9]*$";

	private static final String EMAIL_REGEX = ".+@.+\\.[a-z0-9]+";

	public static final Pattern ONLY_DATE_REGEX_PATTERN = Pattern.compile(ONLY_DATE_REGEX);

	public static final Pattern ONLY_NUMBERS_REGEX_PATTERN = Pattern.compile(ONLY_NUMBERS_REGEX);

	public static final Pattern NO_SPECIAL_CHARS_REGEX_PATTERN = Pattern.compile(NO_SPECIAL_CHARS_REGEX);

	public static final Pattern NUMBERS_COMMA_SPERATED_REGEX_PATTERN = Pattern.compile(NUMBERS_COMMA_SPERATED_REGEX);

	public static final Pattern EMAIL_REGEX_PATTERN = Pattern.compile(EMAIL_REGEX);

	public static final String APPL_ERROR = "Application encountered fatal error.";

	public static final String APPL_RETRY_ERROR = "Application encountered fatal error. Please retry after some time.";

	public static final String ROLL_BACK_ERROR = "Error while rolling back after a failure in middle of the flow. ";
	
	public static final int OK_STATUS = 200;
	
	public static final int VALIDATION_ERROR_STATUS = 400;

	public static final int INTERNAL_SERVER_ERROR_STATUS = 500;
	
	public static final int NO_RECORDS_FOUND = 100;
	
}
