package com.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import com.dto.ResponseHeaderDTO;
import com.exception.NanoException;
import com.exception.NanoServiceException;
import com.request.dto.UserRequestDTO;

/**
 * This class contains following utility methods which can be accessed in a static way: - semptyString - trimString
 * 
 * @author TCS
 */
public class NanoUtil {
	
	/**
	 * Private Constructor to avoid instantiating the class as all the methods in class are static.
	 */
	private NanoUtil() {
	}
	
	/**
	 * This method can be used to check if a String is null or empty.
	 * 
	 * @param input
	 * 
	 * @return
	 */
	public static boolean isemptyString(String input) {
		return (input == null || trimString(input).length() == 0) ? true : false;
	}

	/**
	 * This method can be used to check if a String is null or empty.
	 * 
	 * @param input
	 * 
	 * @return
	 */
	public static boolean isNotEmptyString(String input) {
		return (input == null || trimString(input).length() == 0) ? false : true;
	}

	/**
	 * This method can be used to trim white spaces in a String. Returns null if input is null.
	 * 
	 * @param input
	 * 
	 * @return
	 */
	public static String trimString(String input) {
		if (input != null) {
			return input.trim();
		}
		return input;
	}

	/**
	 * This method returns a String with _dev attached to the error code. This is used to retrieve developer message.
	 * 
	 * @param errorCode
	 * 
	 * @return
	 */
	public static String getDevCode(int errorCode) {
		return Integer.toString(errorCode) + "_dev";
	}

	/**
	 * This method returns a new Date object if input is not null.
	 * 
	 * @param date
	 * 
	 * @return
	 */
	public static Date copyDate(Date date) {
		return date == null ? null : new Date(date.getTime());
	}

	/**
	 * This method can be used to get non null value from mixture of null and non null Timestamp values.
	 * 
	 * @param values
	 * 
	 * @return
	 */
	public static Date getNonNullDate(Timestamp... values) {
		for (int i = 0; i < values.length; i++) {
			if (null != values[i]) {
				return new Date(values[i].getTime());
			}
		}

		return null;
	}

	/**
	 * This method can be used to get String value of date.
	 * 
	 * @param values
	 * 
	 * @return
	 */
	public static String getDateStr(Date date) {
		if (null != date) {
			DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DEFAULT_DATE_FORMAT);
			sdFormat.setLenient(false);

			return sdFormat.format(date.getTime());
		}

		return null;
	}

	/**
	 * This method can be used to get String value of time.
	 * 
	 * @param values
	 * 
	 * @return
	 */
	public static String getTimeStr(Time time) {
		if (null != time) {
			DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DEFAULT_TIME_FORMAT);
			sdFormat.setLenient(false);

			return sdFormat.format(time.getTime());
		}

		return null;
	}

	/**
	 * This method can be used to get String time value of date.
	 * 
	 * @param values
	 * 
	 * @return
	 */
	public static String getTimeStr(Date date) {
		if (null != date) {
			DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DEFAULT_TIME_FORMAT);
			sdFormat.setLenient(false);

			return sdFormat.format(date.getTime());
		}

		return null;
	}

	/**
	 * This method can be used to get String value of date along with time.
	 * 
	 * @param values
	 * 
	 * @return
	 */
	public static String getDateStrWithTime(Date date) {
		if (null != date) {
			DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DATE_WITH_TIME_FORMAT);
			sdFormat.setLenient(false);

			return sdFormat.format(date.getTime());
		}

		return null;
	}

	/**
	 * This methods returns today's date with time set to 0.
	 * 
	 * @return
	 * 
	 * @throws ParseException
	 */
	public static Date getTodaysDate() throws ParseException {
		Calendar calendar = new GregorianCalendar();
		DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DEFAULT_DATE_FORMAT);
		sdFormat.setLenient(false);

		Date returnDate = sdFormat.parse(sdFormat.format(calendar.getTime()));

		return returnDate;
	}

	/**
	 * This method returns current Timestamp.
	 * 
	 * @return
	 */
	public static Timestamp getCurrentTimestamp() {
		return new Timestamp(System.currentTimeMillis());
	}

	/**
	 * This methods returns date from string with format yyyy-MM-dd.
	 * 
	 * @return
	 * 
	 * @throws ParseException
	 */
	public static Date getDateFromString(String dateStr) throws ParseException {
		DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DEFAULT_DATE_FORMAT);
		sdFormat.setLenient(false);

		Date returnDate = sdFormat.parse(dateStr);

		return returnDate;
	}

	/**
	 * This methods returns date from string with format yyyy-MM-dd.
	 * 
	 * @return
	 * 
	 * @throws ParseException
	 */
	public static Date getDateFromStringTime(String dateStr) throws ParseException {
		DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DATE_WITH_TIME_FORMAT);
		sdFormat.setLenient(false);
 
		Date returnDate = sdFormat.parse(dateStr);

		return returnDate;
	}

	/**
	 * This methods returns date from string with format yyyy-MM-dd.
	 * 
	 * @return
	 * 
	 * @throws ParseException
	 */
	public static java.sql.Date getSQLDateFromString(String dateStr) throws ParseException {
		DateFormat sdFormat = new SimpleDateFormat(ApplicationConstants.DEFAULT_DATE_FORMAT);
		sdFormat.setLenient(false);

		java.sql.Date returnDate = new java.sql.Date(sdFormat.parse(dateStr).getTime());

		return returnDate;
	}

	/**
	 * This methods pads input String with given String.
	 * 
	 * @param inputStr
	 *            Input String
	 * @param padStr
	 *            Pad String
	 * @return returnStr Result String
	 */
	public static String padString(String inputStr, String padStr) {
		String returnStr = inputStr;

		if (NanoUtil.isNotEmptyString(inputStr) && NanoUtil.isNotEmptyString(padStr)) {
			returnStr = padStr.substring(0, padStr.length() - returnStr.length()) + NanoUtil.trimString(inputStr);
		}

		return returnStr;
	}
	
	/**
	 * This method converts ByteArrayOutputStream to String.
	 * 
	 * @param input
	 * 
	 * @return
	 * 
	 * @throws TMSServiceException
	 */
	
	public static String convertToStringWithEncoding(ByteArrayOutputStream input) throws NanoServiceException {
		try {
			return input.toString("UTF-8");
		} catch (UnsupportedEncodingException uee) {
			throw new NanoServiceException(uee);
		}
	}

	/**
	 * This method prepares response header.
	 * 
	 * @param responseHeaderDTO
	 * @param e
	 * 
	 * @return
	 */
	
	public static ResponseHeaderDTO prepareErrorResponseHeader(ResponseHeaderDTO responseHeaderDTO, NanoException e) {
		ResponseHeaderDTO responseHeader = null;
		if (null == responseHeaderDTO) {
			responseHeader = new ResponseHeaderDTO();
		} else {
			responseHeader = responseHeaderDTO;
		}

		responseHeader.setStatus(e.getError().getStatus());
		responseHeader.setMessage(e.getError().getMessage());

		return responseHeader;
	}
	
	/**
     * This method is used to check whether the string is null or not.
     * @param string
     * @return boolean
     */
    public static boolean isNullString(String string) {
        boolean isNullString = true;
        if (string != null && !"".equals(string.trim())) {
            isNullString = false;
        }
        return isNullString;
    }
    
    /**
     * This method is used to check whether a list is null or not.
     * @param list
     * @return boolean
     */
    @SuppressWarnings("unchecked")
    public static boolean isNullList(Object obj) {
        boolean isNullList = true;
        if (obj instanceof List) {
            List<Object> list = (List<Object>) obj;
            if (!list.isEmpty() && list.size() != 0) {
                isNullList = false;
            }
        }
        return isNullList;
    }
    
    /**
     * This method is used to check whether an object is null or not.
     * @param obj
     * @return boolean
     */
    public static boolean isNull(Object obj) {
        return null == obj ? true : false;
    }
    
    public static int getCurrentYear()
    {
        return Calendar.getInstance().get(Calendar.YEAR);
    }
    
    public static int getCurrentMonth()
    {
        return Calendar.getInstance().get(Calendar.MONTH)+1;
    }
    
    
    public static int getServiceMonth(String serviceMonth)
    {
        int month = 0;
        try
        {
            DateFormat inputDF  = new SimpleDateFormat("dd-MMM-yy");
            Date date1 = inputDF.parse(serviceMonth);

            Calendar cal = Calendar.getInstance();
            cal.setTime(date1);

            month = cal.get(Calendar.MONTH)+1;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
       
        return month;
    }
    
    public static int getServiceYear(String serviceMonth)
    {
        int year = 0;
        try
        {
            DateFormat inputDF  = new SimpleDateFormat("dd-MMM-yy");
            Date date1 = inputDF.parse(serviceMonth);

            Calendar cal = Calendar.getInstance();
            cal.setTime(date1);

            year = cal.get(Calendar.YEAR);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
       
        return year;
    }
    
    
    /**
     * This method is used to convert the list of comma separated string to ArrayList
     * @param str
     * @return
     */
    public static String getCommaSepratedStringFromList(List<Integer> valueList)
    {
       StringBuffer csvString = new StringBuffer();
       String finalValue = null;
        if(!isNullList(valueList))
        {
            int count =0;
            for(Integer value: valueList)
            {
             csvString.append(value);
             csvString.append(",");
            }
            
            finalValue = csvString.toString();
            
            if(!isNullString(finalValue))
            {
                finalValue = finalValue.substring(0,finalValue.length()-1);
            }
        }
        return finalValue;
    }

	public static int getMilestoneYear(String mileStoneDate) {
		int year = 0;
        try
        {
            DateFormat inputDF  = new SimpleDateFormat("MMM-yy");
            Date date1 = inputDF.parse(mileStoneDate);

            Calendar cal = Calendar.getInstance();
            cal.setTime(date1);

            year = cal.get(Calendar.YEAR);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
       
        return year;
	}

	public static int getMilestoneMonth(String mileStoneDate) {
		int month = 0;
        try
        {
        	DateFormat inputDF  = new SimpleDateFormat("MMM-yy");
            Date date1 = inputDF.parse(mileStoneDate);

            Calendar cal = Calendar.getInstance();
            cal.setTime(date1);

            month = cal.get(Calendar.MONTH)+1;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
       
        return month;
	}
	
    /**
     * Returns the current date
     * 
     * @return int
     */
    public static java.sql.Date getCurrentDate()
    {

        return new java.sql.Date(System.currentTimeMillis());
    }
    
    public static int getMonthFromDateTime(String serviceMonth)
    {
        int month = 0;
        try
        {
            DateFormat inputDF  = new SimpleDateFormat(ApplicationConstants.DATE_WITH_TIME_FORMAT);
            Date date1 = inputDF.parse(serviceMonth);

            Calendar cal = Calendar.getInstance();
            cal.setTime(date1);

            month = cal.get(Calendar.MONTH)+1;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
       
        return month;
    }
    
    public static String getMonthName(int monthNbr)
    {
        Map<Integer, String> monthMap = new HashMap<Integer, String>();
        monthMap.put(1, "JAN");
        monthMap.put(2, "FEB");
        monthMap.put(3, "MAR");
        monthMap.put(4, "APR");
        monthMap.put(5, "MAY");
        monthMap.put(6, "JUN");
        monthMap.put(7, "JUL");
        monthMap.put(8, "AUG");
        monthMap.put(9, "SEP");
        monthMap.put(10, "OCT");
        monthMap.put(11, "NOV");
        monthMap.put(12, "DEC");
        
        if(monthNbr > 0)
        {
        	return monthMap.get(monthNbr);
        }
        else
        {
        	return "DEC";
        }
        
    }
    
    public static int getMonthNbr(String month)
    {
    	Map<String, Integer> monthMap = new HashMap<String, Integer>();
        monthMap.put("JAN", 1);
        monthMap.put("FEB", 2);
        monthMap.put("MAR", 3);
        monthMap.put("APR", 4);
        monthMap.put("MAY", 5);
        monthMap.put("JUN", 6);
        monthMap.put("JUL", 7);
        monthMap.put("AUG", 8);
        monthMap.put("SEP", 9);
        monthMap.put("OCT", 10);
        monthMap.put("NOV", 11);
        monthMap.put("DEC", 12);
        
        return monthMap.get(month);
    }
    
    public static void deleteFile(String fileName)
    {
    	File fileTemp = new File(fileName);
        if (fileTemp.exists())
        {
          fileTemp.delete();
        } 
    }

	public static String getWONFromString(String stringVal)
	{
		return stringVal.substring(0, 7);
	}

	public static int getMonthVal(String startDate)
	{
		String[] date = startDate.split("-");
		return getMonthNbr(date[0]);
	}
	
	public static int getYearVal(String startDate)
	{
		String[] date = startDate.split("-");
		return Integer.valueOf(date[1]);
	}
	
	public static Time getTimeFromString(String TimeStringValue) throws ParseException
	{
		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
		java.util.Date d1 =(java.util.Date)format.parse(TimeStringValue);
		java.sql.Time TimeValue = new java.sql.Time(d1.getTime());
		return TimeValue;
	}
	
	public static Time add2TimeValues(Time TimeValue1, Time TimeValue2) throws ParseException 
	{
		String time1=TimeValue1.toString();
		String time2=TimeValue2.toString();

		SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
		timeFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

		java.util.Date date1 = timeFormat.parse(time1);
		java.util.Date date2 = timeFormat.parse(time2);

		long sum = date1.getTime() + date2.getTime();

		String sumTimeString = timeFormat.format(new java.util.Date(sum));
		Time sumTime = getTimeFromString(sumTimeString);
		
		return sumTime;
	}
	
	public static boolean validateUserRequest(UserRequestDTO request){
		boolean valid = false;
		if(request != null && request.getEmployeeId() != 0 && request.getRoleCd() != 0){
			valid = true;
		}
		return valid;
	}
	
}
