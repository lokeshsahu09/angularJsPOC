﻿'use strict';
define([], function () {
	console.log('Project App JS called');
    var app = angular.module('ProjectApp', ['ngRoute', 'ngAnimate', 'ngCookies', 
                                            'routeResolverServices', 'ui.bootstrap', 'ngDragDrop', 'nvd3']);
    app.config(['$routeProvider', 'routeResolverProvider', '$controllerProvider', '$compileProvider', '$filterProvider', '$provide', '$httpProvider',
        function ($routeProvider, routeResolverProvider, $controllerProvider, $compileProvider, $filterProvider, $provide, $httpProvider) {
            app.register = {
                controller: $controllerProvider.register,
                directive: $compileProvider.directive,
                filter: $filterProvider.register,
                factory: $provide.factory,
                service: $provide.service,
                constant : $provide.constant
            };
            var route = routeResolverProvider.route;
            $routeProvider
                .when('/login', route.resolve('Login', ''))
                .when('/home', route.resolve('Home', ''))
                .when('/viewGames', route.resolve('ViewGames', ''))
                .when('/dashBoard', route.resolve('DashBoard', ''))
                .when('/knowledgeHunt',route.resolve('KnowledgeHunt', ''))
                .when('/learningCartMain',route.resolve('LearningCartMain', ''))
                .when('/QACards',route.resolve('QACards', 'qaCards/'))
                .when('/buzzWordContent', route.resolve('BuzzWordWelcomeContent', ''))
                .when('/buzzWordGameStart', route.resolve('BuzzWordGameStart', ''))
                .when('/', route.resolve('Dummy', ''))
                 .when('/Presentation', route.resolve('Presentation', ''))
                .otherwise({
                    redirectTo: '/'
                });
        }
    ]);
    
    app.run(['$q', '$rootScope', '$location', 
        function ($q, $rootScope, $location) {
        //Init Run
    	require(['business/controllers/AppController',
    	         'business/factory/dataService',
    	         'business/factory/DialogFactory',
		         'business/factory/GlobalConstants',
		         'business/factory/GlobalVariables'
		         ], function(){
			console.log("Project App Loaded ");
		});
    		console.log("Init Run");
    	}
    ]);
    return app;
});