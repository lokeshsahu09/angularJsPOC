﻿"use strict";
require.config({
    baseUrl: 'app',
    paths: {
        app: 'app',
        appBoot: 'bootstrap',
        angUi: 'assets/libs/angular1.2.18/angular-ui-bootstrap',
        angRoute: 'assets/libs/angular1.2.18/angular-route.min',
        angAnimate: 'assets/libs/angular1.2.18/angular-animate.min',
        angCookies: 'assets/libs/angular1.2.18/angular-cookies.min',
        jquery: 'assets/libs/jquery2.1.1/jquery-2.1.1.min',
        jqueryui: 'assets/libs/others/jquery-ui-1.10.4.custom.min',
        jqgrid : 'assets/libs/jqgrid/jquery.jqGrid.min',
        jqgridLocal : 'assets/libs/jqgrid/i18n/grid.locale-en',
        underscore: 'assets/libs/underscore/underscore-min',
        blockui : 'assets/libs/others/jquery.blockUI',
        bootStrap : 'assets/libs/others/bootstrap.min',
        md5 : 'assets/libs/others/md5',
        FlipClock : 'assets/libs/qaCards/flipclock.min',
        lodash : 'assets/libs/qaCards/lodash',
        jrumble : 'assets/libs/qaCards/jrumble',
        liquidFillGauge : 'liquidFillGauge',
        howl : 'assets/libs/qaCards/howler.min',
        touchPunch : 'assets/libs/jQuery 1.6.2/jquery.ui.touch-punch.min',
      	jQueryPlugin : 'assets/libs/jQuery 1.6.2/jquery.plugin',
      	countdownTimer : 'assets/libs/jQuery 1.6.2/jquery.countdown',
        typed : 'assets/libs/typed',
        flightOfPhrase : 'assets/libs/jquery.fop-1.0.2.min',
        flapper:'assets/libs/qaCards/jquery.flapper'
    },
    //urlArgs: "ts=" + (new Date()).getTime(),
    waitSeconds : 0,
    shim: {
        "underscore": {
            exports: "_"
        },
        "jqueryui": {
            deps: ["jquery"],
            exports: "jqueryui"
        },
        "jqgrid": {
        	deps: ["jquery", "jqgridLocal"],
        	exports: "jqgrid"
        },
        "jrumble": {
        	deps: ["jquery"],
        	exports: "jrumble"
        },
        "howl": {
        	deps: ["jquery"],
        	exports: "howl"
        },
        "jQueryPlugin":{
        	deps: ["jquery"],
        	exports: "jQueryPlugin"
        },
        "touchPunch":{
        	deps: ["jquery"],
        	exports: "touchPunch"
        },
        "countdownTimer":{
        	deps: ["jquery", "jQueryPlugin"],
        	exports: "countdownTimer"
        },
        "typed":{
            deps: ["jquery"],
            exports: "typed"
        },
        "flightOfPhrase":{
            deps: ["jquery"],
            exports: "flightOfPhrase"
        },
        "bootStrap":{
            deps: ["jquery"],
            exports: "bootStrap"
        },
        "flapper":{
        	deps: ["jquery"],
        	exports: "flapper"
        }
    },
    deps: ['app'],
    callback : function(){
    	require(['appBoot'], function(){
			console.log("app boot Loaded ");
		});
    	console.log("Deps Loaded");
    }
});