require(['app', 'angUi', 'angRoute', 'angAnimate', 'angCookies', 'jquery',  'jqueryui', 'jqgrid', 
         'blockui',
         'typed',
         'flightOfPhrase',
         'bootStrap',
         'business/services/routeResolver', 
         'business/controllers/AppController',
         'business/services/manageSessionService', 
         'business/factory/DialogFactory'
         ], function () {
    'use strict';
    jQuery.noConflict();
    angular.bootstrap(document, ['ProjectApp']);
});