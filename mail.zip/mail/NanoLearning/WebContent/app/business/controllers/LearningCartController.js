"use strict";
define(['app', 'jquery', 'business/utils/utils', 'jqgrid'], function (app, $, util, jqgrid) {
	
    var learningCartController = function ($scope, $rootScope, $location, DialogFactory, GlobalConstants, dataService) {
    	//-----------------------------------------------------------------------------------------------------------------
		$scope.render = function(){
			util.log(" :::::::::::[ TAB CONTROLLER CALLED ]:::::::::: ");
			
					
			//dataService.Get(GlobalConstants.GET_HEAD_COUNT, $scope.success, $scope.failed);
			dataService.Get('app/stub/getLearningCart.json', $scope.success, $scope.failed);

			$(window).load(function(){
                $('#myModal').modal('show');
            });

			$scope.clickedGame = false;
			if (!$scope.$$phase) {
                $scope.$apply();
            }			
		};

		$scope.success = function(result){
			if(result && result.header.status === 200) {
				$rootScope.dataReceived = result;
				$rootScope.instructions = result.instructions;
			} else {
				//throw error pop.up
			}
			
		};

		$scope.startGame = function(){
			$location.path('/learningCartMain');			
		};

		$scope.failed = function(result){
			//show a error pop-up
		};

		$scope.closeModal = function(){
			$('#modalMain').addClass('hide');
			$('.modal-backdrop').css({'display':'none'});
		};
	
		//-----------------------------------------------------------------------------------------------------------------
		
		$scope.render();
	};
	app.register.controller('LearningCartController', ['$scope', '$rootScope', '$location', 'DialogFactory', 'GlobalConstants', 'dataService', learningCartController]);
});


	
    


