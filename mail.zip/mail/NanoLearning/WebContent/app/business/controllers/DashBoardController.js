  "use strict";
define(['app', 'jquery', 'business/utils/utils', 'liquidFillGauge'], function (app, $, util ,liqidFill) {
	    var DashBoardController = function ($scope, $rootScope,dataService, $location, $http, $timeout, orderByFilter) {
	    	$scope.testing = false;
	    	$scope.referenceValue = 0;
	    	$scope.playerData=[];
	    	$scope.totalScore = 0;
	    	$scope.totalPlayer = 0;
        	$scope.myTotalPoints = 0;
        	$scope.userName = "";
	    	$scope.totalPlayerTimeSpent = "0";
	    	$scope.showChart = true;
	    	$scope.isProjectManager = false;
	    	$rootScope.currentPage = 0;
	    	$rootScope.pageNumberStart = ($rootScope.currentPage/2)*2;
	    	$rootScope.pageNumberEnd = $rootScope.pageNumberStart + 2;
	    	//$scope.options = {};
	    	//$scope.data_bar = [];
	    	var data11 = [];
	    	var data22 = [];
	    	
	    	if($rootScope.roleCd == 4)
	    	{
	    		$scope.showChart = false;
	    		$scope.isProjectManager = true;
	    	}
	    	 $scope.rowsPerPage =2;
        	
        	$scope.success = function(result){
        		var dashboardContent = result.DashBoardResponse;
    			if(dashboardContent.header.status == 200 && dashboardContent.header.code == 0)
    			{
    				$scope.totalScore = dashboardContent.totalPlayerPoints;
    				$scope.totalPlayer = dashboardContent.playerList.length;
    				$scope.myTotalPoints = dashboardContent.totalPoints;
    				$scope.playerData=dashboardContent.playerList;
    				if(dashboardContent.playerList != null && dashboardContent.playerList.length > 0){
    					$scope.playerData = orderByFilter(dashboardContent.playerList, '-totalPoints');
    				}    				
    				$scope.userName = dashboardContent.firstName+" "+dashboardContent.lastName;
    				$scope.totalPlayerTimeSpent = dashboardContent.totalPlayerTimeSpent;
    				
    				$timeout(function(){
    					$scope.callSvg();
    				}, 1000);
    				var quarterDetails = dashboardContent.quarterDetails;
    				if(quarterDetails != null && quarterDetails.length > 0 && !$scope.isProjectManager){
    					var lastQuarter = [];
        				var currentQuarter = [];
    					/*angular.forEach(quarterDetails, function(value, key) {
    						var obj1 = {};
    						var obj2 = {};
    						obj1.pmId = value.supervisorEmpId;
    						obj1.pm = value.supervisorEmpId;
    						obj1.points = value.lastQuarter;
    						lastQuarter.push(obj1);
    						obj2.pmId = value.supervisorEmpId;
    						obj2.pm = value.supervisorEmpId;
    						obj2.points = value.currentQuarter;
    						currentQuarter.push(obj2);
    					});*/
    					//.........
    					$scope.graph(quarterDetails);
    					
    		            util.Wait(false);
    				}else{
    					$scope.showChart = false;
    				}
    				
    			  // rowData = result.data;
    			}
    			else {
    				//throw error pop.up
    			}
    		};
    		$scope.failed = function(result){
    			//show a error pop-up
    			util.Wait(false);
    		};
    	
    	$scope.goToHomePage1 = function(){
         	$location.path('/home');
         	
         	
         };
         function radialProgress(parent) {
        	    var _data=null,
        	        _duration= 500,
        	        _selection,
        	        _margin = {top:0, right:0, bottom:30, left:0},
        	        _width = 300,
        	        _height = 300,
        	        _diameter = 150,
        	        _label="",
        	        _fontSize=10;


        	    var _mouseClick;

        	    var _value= 0,
        	        _minValue = 0,
        	        _maxValue = 100;

        	    var  _currentArc= 0, _currentArc2= 0, _currentValue=0;

        	    var _arc = d3.svg.arc()
        	        .startAngle(0 * (Math.PI/180)); //just radians

        	    var _arc2 = d3.svg.arc()
        	        .startAngle(0 * (Math.PI/180))
        	        .endAngle(0); //just radians


        	    _selection=d3.select(parent);


        	    function component() {

        	        _selection.each(function (data) {

        	            // Select the svg element, if it exists.
        	            var svg = d3.select(this).selectAll("svg").data([data]);

        	            var enter = svg.enter().append("svg").attr("class","radial-svg").append("g");

        	            measure();

        	            svg.attr("width", _width)
        	                .attr("height", _height);


        	            var background = enter.append("g").attr("class","component")
        	                .attr("cursor","pointer")
        	                .on("click",onMouseClick);


        	            _arc.endAngle(360 * (Math.PI/180))

        	            background.append("rect")
        	                .attr("class","background")
        	                .attr("width", _width)
        	                .attr("height", _height);

        	            background.append("path")
        	                .attr("transform", "translate(" + _width/2 + "," + _width/2 + ")")
        	                .attr("d", _arc);

        	            background.append("text")
        	                .attr("class", "label")
        	                .attr("transform", "translate(" + _width/2 + "," + (_width + _fontSize) + ")")
        	                .text(_label);
        	           var g = svg.select("g")
        	                .attr("transform", "translate(" + _margin.left + "," + _margin.top + ")");


        	            _arc.endAngle(_currentArc);
        	            enter.append("g").attr("class", "arcs");
        	            var path = svg.select(".arcs").selectAll(".arc").data(data);
        	            path.enter().append("path")
        	                .attr("class","arc")
        	                .attr("transform", "translate(" + _width/2 + "," + _width/2 + ")")
        	                .attr("d", _arc);

        	            //Another path in case we exceed 100%
        	            var path2 = svg.select(".arcs").selectAll(".arc2").data(data);
        	            path2.enter().append("path")
        	                .attr("class","arc2")
        	                .attr("transform", "translate(" + _width/2 + "," + _width/2 + ")")
        	                .attr("d", _arc2);


        	            enter.append("g").attr("class", "labels");
        	            var label = svg.select(".labels").selectAll(".label").data(data);
        	            label.enter().append("text")
        	                .attr("class","label")
        	                .attr("y",_width/2+_fontSize/3)
        	                .attr("x",_width/2)
        	                .attr("cursor","pointer")
        	                .attr("width",_width)
        	                // .attr("x",(3*_fontSize/2))
        	                .text(function (d) { return Math.round((_value-_minValue)/(_maxValue-_minValue)*100) + "%" })
        	                .style("font-size",_fontSize+"px")
        	                .on("click",onMouseClick);

        	            path.exit().transition().duration(500).attr("x",1000).remove();


        	            layout(svg);

        	            function layout(svg) {

        	                var ratio=(_value-_minValue)/(_maxValue-_minValue);
        	                var endAngle=Math.min(360*ratio,360);
        	                endAngle=endAngle * Math.PI/180;

        	                path.datum(endAngle);
        	                path.transition().duration(_duration)
        	                    .attrTween("d", arcTween);

        	                if (ratio > 1) {
        	                    path2.datum(Math.min(360*(ratio-1),360) * Math.PI/180);
        	                    path2.transition().delay(_duration).duration(_duration)
        	                        .attrTween("d", arcTween2);
        	                }

        	                label.datum(Math.round(ratio*100));
        	                label.transition().duration(_duration)
        	                    .tween("text",labelTween);

        	            }

        	        });

        	        function onMouseClick(d) {
        	            if (typeof _mouseClick == "function") {
        	                _mouseClick.call();
        	            }
        	        }
        	    }

        	    function labelTween(a) {
        	        var i = d3.interpolate(_currentValue, a);
        	        _currentValue = i(0);

        	        return function(t) {
        	            _currentValue = i(t);
        	            this.textContent = Math.round(i(t)) + "%";
        	        }
        	    }

        	    function arcTween(a) {
        	        var i = d3.interpolate(_currentArc, a);

        	        return function(t) {
        	            _currentArc=i(t);
        	            return _arc.endAngle(i(t))();
        	        };
        	    }

        	    function arcTween2(a) {
        	        var i = d3.interpolate(_currentArc2, a);

        	        return function(t) {
        	            return _arc2.endAngle(i(t))();
        	        };
        	    }


        	    function measure() {
        	        _width=_diameter - _margin.right - _margin.left - _margin.top - _margin.bottom;
        	        _height=_width;
        	        _fontSize=_width*.2;
        	        _arc.outerRadius(_width/2);
        	        _arc.innerRadius(_width/2 * .85);
        	        _arc2.outerRadius(_width/2 * .85);
        	        _arc2.innerRadius(_width/2 * .85 - (_width/2 * .15));
        	    }


        	    component.render = function() {
        	        measure();
        	        component();
        	        return component;
        	    }

        	    component.value = function (_) {
        	        if (!arguments.length) return _value;
        	        _value = [_];
        	        _selection.datum([_value]);
        	        return component;
        	    }


        	    component.margin = function(_) {
        	        if (!arguments.length) return _margin;
        	        _margin = _;
        	        return component;
        	    };

        	    component.diameter = function(_) {
        	        if (!arguments.length) return _diameter
        	        _diameter =  _;
        	        return component;
        	    };

        	    component.minValue = function(_) {
        	        if (!arguments.length) return _minValue;
        	        _minValue = _;
        	        return component;
        	    };

        	    component.maxValue = function(_) {
        	        if (!arguments.length) return _maxValue;
        	        _maxValue = _;
        	        return component;
        	    };

        	    component.label = function(_) {
        	        if (!arguments.length) return _label;
        	        _label = _;
        	        return component;
        	    };

        	    component._duration = function(_) {
        	        if (!arguments.length) return _duration;
        	        _duration = _;
        	        return component;
        	    };

        	    component.onClick = function (_) {
        	        if (!arguments.length) return _mouseClick;
        	        _mouseClick=_;
        	        return component;
        	    }

        	    return component;

        	};
         $scope.callSvg = function(){
			if($scope.playerData != null && $scope.playerData.length > 0){
				var start = $rootScope.currentPage * 2;
				var end = ($rootScope.currentPage + 1) * 2;
				if(end > $scope.playerData.length) {
					end=$scope.playerData.length;
				}
				for(var i=start; i < end; i++){
					 var rp1 = radialProgress(document.getElementById('fillgauge'+$scope.playerData[i].employeeId))
			            
			            
			            .diameter(100)
			            .value($scope.playerData[i].percentile)
			            .render();
					/*//var gaugeFinder = d3.select("fillgauge"+$scope.playerData[i].employeeId);
					//if(gaugeFinder != null && gaugeFinder != undefined){
						var config4 = liquidFillGaugeDefaultSettings();
			        	config4.circleThickness = 0.15;
			        	config4.circleColor = "#808015";
			        	config4.textColor = "#555500";
			        	config4.waveTextColor = "#FFFFAA";
			        	config4.waveColor = "#AAAA39";
			        	config4.textVertPosition = 0.8;
			        	config4.waveAnimateTime = 1000;
			        	config4.waveHeight = 0.05;
			        	config4.waveAnimate = true;
			        	config4.waveRise = false;
			        	config4.waveHeightScaling = false;
			        	config4.waveOffset = 0.25;
			        	config4.textSize = 0.75;
			        	config4.waveCount = 3;
			        	
			        	//var gauge = loadLiquidFillGauge("fillgauge"+$scope.playerData[i].employeeId, 35.9,config4);
			        	var gauge = loadLiquidFillGauge("fillgauge"+$scope.playerData[i].employeeId, $scope.playerData[i].percentile, config4);
					//}
*/				}
			}
        	 
         };
	    	//-----------------------------------------------------------------------------------------------------------------
	        $scope.render = function () {
	        	$scope.percentile=50;
	        	if($scope.testing){
	        		dataService.Get('app/stub/dashBoard.json', $scope.success, $scope.failed);
	    		}else{
	    			var request = {};
	    			request.employeeId = $rootScope.employeeId;
	    			request.role = $rootScope.role;
	    			request.roleCd = $rootScope.roleCd;
	    			var inputData = {
	    	            	data : JSON.stringify(request)
	    	            };
	    			util.Wait(true);
	    			dataService.Post('/NanoLearning/rs/nano/dashboard', inputData, $scope.success, $scope.failed);
	    		}
	        		
	            if (!$scope.$$phase) {
	                $scope.$apply();
	            }
	        		
	        };
	        //-----------------------------------------------------------------------------------------------------------------
	        $scope.safeApply = function (fn) {
	            var phase = this.$root.$$phase;
	            if (phase == '$apply' || phase == '$digest') {
	                if (fn && (typeof (fn) === 'function')) {
	                    fn();
	                }
	            } else {
	                this.$apply(fn);
	            }
	        };
	        $scope.render();
	        // chart code from here
	        
	        $scope.graph=function(quarterDetails)
	        {
	        	if($rootScope.roleCd == 5){
					$scope.xLabel = "Project Manager";
				}
				else if($rootScope.roleCd == 6){
					$scope.xLabel = "Delevery Manager";
				} 
	        	data11 = [];
	        	data22 = [];
	        	angular.forEach(quarterDetails, function(value, key) {
					var obj1 = {};
					var obj2 = {};
					if(value.supervisorEmpId !=0)
						{
						
						obj1.year = value.firstName;
						obj1.number = value.supervisorEmpId;
						obj1.name = value.firstName;
						obj1.money = value.lastQuarter;
						data11.push(obj1);
						obj2.year = value.firstName;
						obj2.number = value.supervisorEmpId;
						obj2.money = value.currentQuarter;
						obj2.name = value.firstName;
						data22.push(obj2);
						}
					
				});
	        
	        var margin = {top: 80, right: 80, bottom: 80, left: 261},
	        width = 900 - margin.left - margin.right,
	        height = 400 - margin.top - margin.bottom;

	    	var x = d3.scale.ordinal().rangeRoundBands([ 0, width ], .1);

	    	var y0 = d3.scale.linear().domain([ 400, 3500 ]).range([ height, 0 ]),
	    	   y1 = d3.scale.linear().domain([ 20, 80 ]).range([ height, 0 ]);

	    	var xAxis = d3.svg.axis().scale(x).orient("bottom");

	    	// create left yAxis
	    	var yAxisLeft = d3.svg.axis().scale(y0).ticks(4).orient("left");
	    	// create right yAxis
	    	var yAxisRight = d3.svg.axis().scale(y1).ticks(6).orient("right");

	    	var svg = d3.select("#statusChart").append("svg").attr("width",width + margin.left + margin.right)
	    	/* .attr("float","left").attr("margin-left","301px").attr("margin-top","-773px") */
	    .attr("style","padding: 2%; float: left; margin-left: 126px; margin-top: -417px;padding-bottom: 0;")
	    	.attr("height",	height + margin.top + margin.bottom).append("g").attr("class", "graph").attr("transform","translate(" + margin.left + "," + margin.top + ")");

	    	/* for(var i=0; i< data11.length;i++) {
	    	
	    	 } */
	    	//d3.tsv(data11, type, function(error, data) {

	    	//d3.tsv("data.tsv", type, function(error, data) {
	    	x.domain(data11.map(function(d) {
	    		return d.year;
	    	}));
	    	y0.domain([ 0, d3.max(data11, function(d) {
	    		return d.money;
	    	}) ]);
	    	y1.domain([ 0, d3.max(data22, function(d) {
	    		return d.money;
	    	}) ]);

	    	svg.append("g").attr("class", "x axis").attr("transform",
	    			"translate(0," + height + ")").call(xAxis);

	    	svg.append("g").attr("class", "y axis axisLeft").attr("transform",
	    			"translate(0,0)").call(yAxisLeft).append("text").attr("y", 6).attr(
	    			"dy", "-4em").style("text-anchor", "end").style("text-anchor",
	    			"end");

	    	svg.append("g").attr("class", "y axis axisRight").attr("transform",
	    			"translate(" + (width) + ",0)").call(yAxisRight).append("text")
	    			.attr("y", 6).attr("dy", "-4em").attr("dx", "1em").style(
	    					"text-anchor", "end");

	    	 var bars = svg.selectAll(".bar").data(data11).enter();
	    	var bars22 = svg.selectAll(".bar").data(data22).enter();

	    	bars.append("rect").attr("class", "bar1")/*.attr("style","width :10px;")*/.attr("x", function(d)
	    			{
	    		return x(d.year)+20;
	    	}).attr("width", 10 ).attr("y", function(d) {
	    		return y0(d.money);
	    		
	    	}).attr("height", function(d, i, j) {
	    		return height - y0(d.money);
	    	});

	    	bars22.append("rect").attr("class", "bar2")/*.attr("style","width :10px;")*/.attr("x", function(d) {
	    		return x(d.year) + 20 + 10 / 2;
	    	}).attr("width", 10).attr("y", function(d) {
	    		return y1(d.money);
	    	}).attr("height", function(d, i, j) {
	    		return height - y1(d.money);
	    	});

	    	//});

	    	function type(d) {
	    		d.money = +d.money;
	    		return d;
	    	}
	    }
	    };
	    // till here
	    app.register.filter('paginate', function(Paginator) {
	        return function(input, rowsPerPage) {
	            if (!input) {
	                return input;
	            }

	            if (rowsPerPage) {
	                Paginator.rowsPerPage = rowsPerPage;
	            }
	            
	            Paginator.itemCount = input.length;

	            return input.slice(parseInt(Paginator.page * Paginator.rowsPerPage), parseInt((Paginator.page + 1) * Paginator.rowsPerPage + 1) - 1);
	        }
	    });

	    app.register.filter('forLoop', function() {
	        return function(input, start, end) {
	            input = new Array(end - start);
	            for (var i = 0; start < end; start++, i++) {
	                input[i] = start;
	            }

	            return input;
	        }
	    });

	    app.register.service('Paginator', function ($rootScope, $timeout) {
	        this.page = 0;
	        this.rowsPerPage = 2;
	        this.itemCount = 0;

	        this.setPage = function (page) {
	            if (page > this.pageCount()) {
	                return;
	            }
	            this.page = page;
	            $rootScope.currentPage = this.page;
	            this.showSvg();
	        };
	        
	        this.showSvg = function(){
	        	var scope = angular.element(document.getElementById("dashboardDiv")).scope();
	            $timeout(function(){
	            	scope.callSvg();
	            },250);
	        };
	        
	        this.paginationLogic = function(page){
	        	$rootScope.currentPage = this.page;
	        	$rootScope.pageNumberStart = ($rootScope.currentPage/this.rowsPerPage)*this.rowsPerPage;
		    	$rootScope.pageNumberEnd = $rootScope.pageNumberStart + this.rowsPerPage;
		    	this.showSvg();
	        };

	        this.nextPage = function () {
	            if (this.isLastPageSet()) {
	                return;
	            }
	            var set = Math.ceil(($rootScope.currentPage + 1)  / parseInt(this.rowsPerPage));
	            this.page = set * this.rowsPerPage;
	            this.paginationLogic(this.page);
	        };

	        this.perviousPage = function () {
	            if (this.isFirstPageSet()) {
	                return;
	            }
	            var set = Math.ceil(($rootScope.currentPage + 1)  / parseInt(this.rowsPerPage));
	            this.page = (set-2) * this.rowsPerPage;
	            this.paginationLogic(this.page);
	        };

	        this.firstPage = function () {
	            this.page = 0;
	            this.paginationLogic(this.page);
	        };

	        this.lastPage = function () {
	        	var set = Math.ceil(this.pageCount() / this.rowsPerPage);
	            this.page = (set-1) * this.rowsPerPage;
	            this.paginationLogic(this.page);
	        };
	        
	        this.isFirstPageSet = function () {
	        	var setNumber = Math.ceil(($rootScope.currentPage + 1) / parseInt(this.rowsPerPage));
	            return setNumber == 1 ;
	        };

	        this.isLastPageSet = function () {
	        	var setNumber = Math.ceil(($rootScope.currentPage + 1) / parseInt(this.rowsPerPage));
	        	var lastSet = Math.ceil(this.pageCount() / this.rowsPerPage);
	            return setNumber == lastSet ;
	        };

	        this.isFirstPage = function () {
	            return this.page == 0;
	        };

	        this.isLastPage = function () {
	            return this.page == this.pageCount() - 1;
	        };

	        this.pageCount = function () {
	            return Math.ceil(parseInt(this.itemCount) / parseInt(this.rowsPerPage));
	        };
	    });

	    app.register.directive('paginator', function factory() {
	        return {
	            restrict:'E',
	            controller: function ($scope, Paginator) {
	                $scope.paginator = Paginator;
	            },
	            templateUrl: 'paginationControl.html'
	        };
	    });
	    
	    app.register.controller('DashBoardController', ['$scope', '$rootScope','dataService', '$location', '$http', '$timeout', 'orderByFilter', DashBoardController]);
	});

	
	


