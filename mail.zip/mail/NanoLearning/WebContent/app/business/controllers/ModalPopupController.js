"use strict";
define(['app'], function (app) {
	var _ctrlrName = "ModalPopupController";
	
    var ModalPopup = function ($scope, $sce, dialog, scopeOptions) {
    	
    	$scope.showModalFooter = scopeOptions.isOK;
		$scope.showModalOK = scopeOptions.isOK;
		$scope.showModalCancel = scopeOptions.isCancel;
		//-----------------------------------------------------------------------------------------------------------------
		$scope.render = function() {
			$scope.popupContent = $sce.trustAsHtml(scopeOptions.modalMsg);
			if (!$scope.$$phase) {
				$scope.$apply();
			}
		};
		//-----------------------------------------------------------------------------------------------------------------
		$scope.closeModal = function(result) {
			dialog.close(result);
		};
		//-----------------------------------------------------------------------------------------------------------------
		$scope.render();
    };
    
    app.register.controller('ModalPopupController', ['$scope', '$sce', 'dialog', 'scopeOptions', ModalPopup]);
    
    return {
		getName : function() {
			return _ctrlrName;
		}
	};
});
