var projectView = angular.module('ProjectApp');
projectView.factory('$exceptionHandler', function ($injector) {
    return function errorCatcherHandler(exception, cause) {
        var $location = $injector.get("$location");
        exception.message += ' (caused by "' + cause + '")';
        console.log("Exception Message ::: " + exception.message);
        $("#ng-view").remove();
        $location.path("/");
        throw exception;
        return false;
    };
});
//-----------------------------------------------------------------------------------------------------------------
projectView.controller('AppController', function ($rootScope, $scope, $http, $filter, $location, $cookieStore, $timeout, $modal, manageSession) {
    
	$scope.appName = "My Project";
    console.log("App Controller Called");
    
    $rootScope.$on('$routeChangeSuccess', function(event, toRoute, fromRoute) {
    	if(toRoute != undefined)
    	{
    		if (toRoute.$$route != undefined) {
    			var path = toRoute.$$route.originalPath;
    			path = path.substring(1, path.length);
    			console.log("Current Path ::::"+path);
    			if(path != "login" && path != "")
    			{
    				manageSession.resetWatch();
    			}
    		}
    	}
    	
    	if(fromRoute != undefined)
    	{
    		if (fromRoute.$$route != undefined) {
    			var path = fromRoute.$$route.originalPath;
    			path = path.substring(1, path.length);
    			console.log("Previous Path ::::"+path);
    			if(path == "QACards")
    			{
    				$rootScope.stopQACardsSound();
    			}
    		}
    	}
	});
    
    $scope.logOut = function() {
    	$rootScope.loginStatus = false;
    	manageSession.destroyWatch();
    	$rootScope.ngIncludeUrl = {'userDashBoard' : '','gameDetails' : ''};
    	$location.path('/login');
        $rootScope.gameLaunched = false;
    };
    //-----------------------------------------------------------------------------------------------------------------
    $scope.render = function () {
        $rootScope.gameLaunched = false;
    	$rootScope.loginStatus = false;
    	$rootScope.ngIncludeUrl = {'userDashBoard' : '','gameDetails' : ''};
    };
    //-----------------------------------------------------------------------------------------------------------------
    $scope.render();
    
});

