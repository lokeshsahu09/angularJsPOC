"use strict";
define(['app', 'jquery', 'business/utils/utils', 'jqgrid', 'howl'], function (app, $, util, howl, jqgrid) {
	
    var learningCartMainController = function ($scope, $rootScope, $location, DialogFactory, GlobalConstants, dataService) {
    	//-----------------------------------------------------------------------------------------------------------------
		$scope.render = function(){
			util.log(" :::::::::::[ TAB CONTROLLER CALLED ]:::::::::: ");
			console.log("$rootScope.chapterScore in LearCrdt - "+$rootScope.chapterScore);
            console.log("$rootScope.gameScore in LearCrdt - "+$rootScope.gameScore);
			
			$scope.list1 = [];
  			$scope.list2 = [];
  			$scope.walletCost = 100;
  			$rootScope.infoMsg = '';
  			$rootScope.btnText = "Ok";
  	        if(!$scope.cartCleared) {
  	        	$scope.bookOpenSound = undefined;
  	        	$scope.bookDropSound = undefined;
  	        	$scope.learningCartBGM = undefined;
  	        	$scope.soundInit();
  	        } 	        

  			$("#nextChapter").text("");
        	$("#nextChapter").text("Next Chapter");
        	
  			if($scope.cartCleared) {
  				$scope.cartCleared = false;
  				$scope.walletCost = $scope.remainingAmnt;
  			}

  			$scope.optionsList2 = {
		        accept: function(dragEl) {
		            if ($scope.list2.length >= 12) {
		              return false;
		            } else {
		              return true;
		            }
		        }
        	};

        	$rootScope.gameLaunched = 'true';
        	$rootScope.validateButton = 'Place Order';

            $.each($rootScope.PagesObject, function( key, value ) {
        		if(key == $location.path().replace('/', ""))
        		{
        			$rootScope.dataReceived = value;
                    $rootScope.instructions = value.instructions;
        		}
			});

            $("#nextChapter").on( "click", function() {
        		if($location.path().replace('/', "") == "learningCartMain")
        		{
        		  console.log( "Clicked Next Chapter Inside Learning Cart Controller" );
        		  $(this).unbind("click");
          			$("#nextChapter").unbind("click");
  	              $scope.applaudSound.stop();
  	              $rootScope.commonRouter($rootScope.chapterDetails, $rootScope.chapterOrderNbr);
        		}
            });

            if (! $rootScope.gameId) {
            	$rootScope.gameId = 3;
            	$rootScope.dataReceived.chapterId = 3;
            }
            
			var inputs = new Object();
			inputs.gameId = $rootScope.gameId;
			//inputs.gameId = $rootScope.gameId;
			inputs.chapterId = $rootScope.dataReceived.chapterId;
			var jsonInput = JSON.stringify(inputs);
			var dataToSend = {
				data:jsonInput
			};

			/*$(".endGame").Fop({ 
		        		"phrase_class" : "rain",
						"phrase" : "&#9733;",		//ASCII symbol code for STAR
						"animation_type" : "rain",
						"density" : 8,
						"duration" : 1000,
						"click_to_start" : false
		    });*/

			$(function(){
	        	$(".playInstructions").typed({
	                strings: ["<ul class='gameSteps'>" +
	                "<li class='tip'>Drag and drop the books into the cart in the correct order</li>" +
	                "<li class='tip'>Start with 100$. Be careful because you’ll lose 25$ for every wrong order</li>" +
	                "<li class='tip'>Play your game until you have money in the wallet</li>" +
	                "</ul>"],
	                typeSpeed: 2,
	                startDelay: 0,
	                loop: false,
	                contentType: 'html', // or text
	                loopCount: false,
	                callback: function() {
	                	$('.startChap').prop("disabled", false);
	                	$('.startChap').addClass('active');
	                }
	            });
          	});

        	dataService.Post('rs/gameDetailsService/searchGameDetails', dataToSend, $scope.success, $scope.failed);
        	//dataService.Get('app/stub/learningCartResponse.json', $scope.success, $scope.failed);

			if (!$scope.$$phase) {
                $scope.$apply();
            }			
		};
		
		$scope.success = function(result){
			if(result && result.header.status === 200) {
				$scope.getData(result);
			} else {
				//throw error pop.up
			}
		};
		
		$scope.failed = function(result){
			//show a error pop-up
		};
		
		 $scope.soundInit = function() {
			 	$scope.applaudSound = new Howl({
	              urls: ['app/assets/audio/qaCards/applaud.mp3'],
	              autoplay: false,
	              loop: false,
	              volume: 1,
	              onend: function() {
	                //alert('Finished!');
	              }
	            });
	            $scope.beepSound = new Howl({
	              urls: ['app/assets/audio/beep.mp3'],
	              autoplay: false,
	              loop: false,
	              volume: 3,
	              onend: function() {
	                //alert('Finished!');
	              }
	            });
	            $scope.retrySound = new Howl({
		          urls: ['app/assets/audio/birdWhistle.mp3'],
		          autoplay: false,
		          loop: true,
		          volume: 1,
		          onend: function() {
		            //alert('Finished!');
		          }
		        });
	            $scope.bookDropSound = new Howl({
	              urls: ['app/assets/audio/bookOpen.mp3'],
	              autoplay: false,
	              loop: false,
	              volume: 3,
	              onend: function() {
	                //alert('Finished!');
	              }
	            });
	            $scope.learningCartBGM = new Howl({
	              urls: ['app/assets/audio/summerAir.mp3'],
	              autoplay: false,
	              loop: true,
	              volume: 1,
	              onend: function() {
	                //alert('Finished!');
	              }
	            });
	        };

	    $scope.hoverIn = function(ev){
	    	//console.log("Mouse in");
	    	var bookId = '#' + ev.currentTarget.getAttribute('id');
	    	if(!($(bookId).hasClass('animated'))) {
	    		$(bookId).addClass('animated');
	    	}
	    	$(bookId).removeClass('bounceInUp');
	    	$(bookId).addClass('flip');
	    };

	    $scope.hoverOut = function(ev){
	    	//console.log("Mouse out");
	    	var bookId = '#' + ev.currentTarget.getAttribute('id');
	    	$(bookId).removeClass('flip');
	    };
		
		$scope.closeModal = function(ev){
			$scope.goToNextChap = false;
			$scope.retryChap = false;
			$('#modalMain').addClass('hide');
			$('.modal-backdrop').css({'display':'none'});
			if(ev.currentTarget.innerText === "Start") {
				$scope.learningCartBGM.play();
				$scope.animate();
			}
			if($scope.btnText === "Continue") {
				$scope.goToNextChap = true;
	            
			} else if ($scope.btnText === "Retry") {
				//$('#myModal').addClass('hide');
				$scope.retrySound.stop();
				$scope.render();
				$scope.learningCartBGM.play();
				$scope.animate();
			}
		};

		$scope.animate = function() {
			$('.book.image').addClass('animated bounceInUp');
			$('#scoreboard').addClass('animated fadeInRightBig');
		};

		$scope.getData = function(result) {
				$scope.game = result.chapterTitle;
				$scope.list1 = $scope.shuffleItems(result.questionOptionsList);
				var invalidProd = 0;
				var title = '';
				var matches = '';
				for (var i=0;i<$scope.list1.length;i++) {
					$scope.list1[i].bookNum = 'book' + $scope.list1[i].questionId;
					title =  $scope.list1[i].question;
					matches = title.match(/\b(\w)/g);
					$scope.list1[i].bookTitle = matches.join('');
					if($scope.list1[i].bookTitle.length == 1) {
						$scope.list1[i].bookTitle = $scope.list1[i].bookTitle + title.toUpperCase().split('')[1];
					}
					if($scope.list1[i].questionOrder == 0) {
						invalidProd ++;
						$scope.list1[i].questionOrder = "invalid" + invalidProd;
					}
				}
				$scope.validProductCount = 0;
				
				if($scope.list1 && $scope.list1.length > 0){
					for (var i = 0; i < $scope.list1.length; i++){
						var validProduct = $scope.list1[i].questionOrder;
						if(validProduct && typeof(validProduct) === "number") {
							$scope.validProductCount = $scope.validProductCount + 1;
						}
					};
				}
		};

		$scope.shuffleItems = function(items) {
			var currentIndex = items.length, temporaryValue, randomIndex ;
		  	while (0 !== currentIndex) {
		    	randomIndex = Math.floor(Math.random() * currentIndex);
		    	currentIndex -= 1;
		    	temporaryValue = items[currentIndex];
		    	items[currentIndex] = items[randomIndex];
		    	items[randomIndex] = temporaryValue;
		  	}
  			return items;
		};

		$scope.productClicked = function (index, ev) {
			$rootScope.btnText = "Ok";
			$("#myModal .modal-footer button").removeClass('nxtLevel');
			$scope.learn = true;
			$scope.ordPlaced = false;
			var msg = '';
			var prodTitle = '';
			for (var i = 0; i < $scope.list1.length; i++) {
				if($scope.list1[i].questionOrder && ev.currentTarget.id === $scope.list1[i].questionOrder.toString()) {
					msg = $scope.list1[i].clueDescription;
					prodTitle = $scope.list1[i].question;
					break;
				}
			};
			$scope.bookDropSound.play();
			$rootScope.infoMsg = msg;
			$rootScope.infoTitle = prodTitle;
		};

		$scope.instructionsClicked = function () {
			$rootScope.btnText = "Got it";
		};
		
		$scope.clearCart = function (ev) {
			$scope.cartCleared = true;
			$scope.remainingAmnt = $scope.walletCost;
			$scope.render();
		};

		$scope.onClickMenu = function () {
			$("#nav-icon1").toggleClass('open');
			if($("#nav-icon1").hasClass('open')) {
				$(".panelContainer").css('z-index','1');
			} else {
				$(".panelContainer").css('z-index','0');
			}

		};

		$scope.finish = function (ev) {
			$scope.learn = false;
			$scope.ordPlaced = true;
			$rootScope.btnText = "Ok";
			var msg = '';
			var prodTitle = '';
			var prodInSeqOrd = 0;
			var prodNotInSeqOrd = '';
			var prodNotInPrcss ='';
			var deductedAmt = 0;
			var fineAmt = 25;
			var initialAmnt = $scope.walletCost;
			$("#myModal .modal-footer button").removeClass('nxtLevel');

			if($('#scoreboard').hasClass('fadeInRightBig')) {
				$('#scoreboard').removeClass('fadeInRightBig');
			}
			
			if($scope.walletCost != 0){
				if($scope.list2.length > 0 && $scope.list2.length < $scope.validProductCount){
					deductedAmt = $scope.walletCost - fineAmt;
					$scope.walletCost = deductedAmt;
					if($scope.walletCost != 0){
						$scope.beepSound.play();
					}
					msg = "One or More product(s) required for " + $scope.game + " process and the selected product(s) may or may not belong to this process";
					prodTitle = 'OOPS !!';
				}
				else if($scope.list2.length > 0 && $scope.list2.length > $scope.validProductCount){
					deductedAmt = $scope.walletCost - fineAmt;
					$scope.walletCost = deductedAmt;
					$scope.beepSound.play();
					msg = "Selected more products for " + $scope.game + " process. Please select the required products alone";
					prodTitle = 'OOPS !!';
				}
				else if($scope.list2.length > 0 && $scope.list2.length === $scope.validProductCount){
					for (var i = 0; i < $scope.list2.length; i++) {
						var prodKey = $scope.list2[i].questionOrder;
						if (prodKey && typeof(prodKey) === "number") {
							if(i + 1 === prodKey) {
								prodInSeqOrd = prodInSeqOrd + 1;;
							} 
							else {
								prodNotInSeqOrd = true;
							}
						} else {
							prodNotInPrcss = true;
						}
										
					};
				}
				
				if(prodInSeqOrd > 0 && prodInSeqOrd === $scope.validProductCount){

					/** Calculate the Chapter Score & Game Total Score - STARTS **/ 
					util.log("$scope.walletCost :::"+$scope.walletCost);
					$rootScope.chapterScore = 0;
					$rootScope.chapterScore = $scope.walletCost;
		            $rootScope.gameScore = $rootScope.gameScore+$scope.walletCost;
		            /** Calculate the Chapter Score & Game Total Score - ENDS **/
		            
		            
					$scope.learningCartBGM.stop();
					$scope.applaudSound.play();
					msg = "Congrats !! You finished the level successfully.Your Score is " +$scope.walletCost;
					prodTitle = 'Awesome';
					$scope.goToNextChap = true;
					ev.currentTarget.setAttribute('data-target','#chapterEndModal');
					/*$('.endGame').Fop("start");*/
				}
				else if(prodNotInPrcss === true){
					deductedAmt = $scope.walletCost - fineAmt;
					$scope.walletCost = deductedAmt;
					$scope.beepSound.play();
					msg = "Sorry. Some of the product(s) you choose or doesn't belong to " + $scope.game + " Process";
					prodTitle = 'OOPS !!';
				}
				else if(prodNotInSeqOrd === true){
					deductedAmt = $scope.walletCost - fineAmt;
					$scope.walletCost = deductedAmt;
					$scope.beepSound.play();
					msg = "Please re-arrange the products for " + $scope.game + " process";
					prodTitle = 'OOPS !!';
				}
				else  if ($scope.list2.length === 0) {
					$scope.beepSound.play();
					msg = "Please select the products for " + $scope.game + " process";
					prodTitle = 'OOPS !!';
				}
				
				if($scope.walletCost === 0){
					$scope.learningCartBGM.stop();
					$scope.retrySound.play();
					msg = "Your Wallet doesn't have enough cash to play Learning Cart";
					prodTitle = "Game Over";
					$rootScope.btnText = 'Retry';
					$("#myModal .modal-footer button").addClass('nxtLevel');
				}
			}
			else {
				$scope.learningCartBGM.stop();
				$scope.retrySound.play();
				msg = "Your Wallet doesn't have enough cash to play Learning Cart";
				prodTitle = "Game Over";
				$rootScope.btnText = 'Retry';
				$("#myModal .modal-footer button").addClass('nxtLevel');
			}

			if(initialAmnt != $scope.walletCost) {				
				if($('#scoreboard').hasClass('shake')) {
					$('#scoreboard').removeClass('shake');
					$('#scoreboard').addClass('rubberBand');
				} else if($('#scoreboard').hasClass('rubberBand')) {
					$('#scoreboard').removeClass('rubberBand');
					$('#scoreboard').addClass('jello');
				}
				  else  {
					$('#scoreboard').addClass('shake');
				}
			}
			
			$rootScope.infoMsg = msg;
			$rootScope.infoTitle = prodTitle;
		};
	
		$scope.render();
	};
	app.register.controller('LearningCartMainController', ['$scope', '$rootScope', '$location', 'DialogFactory', 'GlobalConstants', 'dataService', learningCartMainController]);
});


	
    


