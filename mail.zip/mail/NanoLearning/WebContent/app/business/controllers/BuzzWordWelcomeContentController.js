"use strict";
define(['app', 'jquery', 'business/utils/utils'], function(app, $, util) {


    var BuzzWordWelcomeContentControllerFn = function($scope, $rootScope, $location, DialogFactory, GlobalConstants, dataService, $compile, $timeout, $interval, Pages ) {
    	
    	$scope.playBuzzWordsGame = function()
    	{
    		util.log("BuzzWords Game Starts...");
    		$location.path('/buzzWordGameStart');
    	};
    	
    	$scope.buzzContentSuccess = function(result)
    	{
    		if(result.header.status == 200){
    			var contentTitle = result.chapterTitle;
    			var contentLearning = result.learning;
    			$('#contentTitle').html(contentTitle);
    			$('#contentLearning').html(contentLearning);
    		}
    		else 
    		{
    			alert("Service is Temporially Down,Please try after sometimes.");
    		}
    	};
    	
    	$scope.buzzContentError = function(result)
    	{
    		alert("Error Occured Please try after sometimes.");
    	};
    	
    	$scope.render = function() {
             util.log(" :::::::::::[ Buzz Words Main Page CALLED ]:::::::::: ");
             console.log("$rootScope.chapterScore in Buzz Words - "+$rootScope.chapterScore);
             console.log("$rootScope.gameScore in Buzz Words - "+$rootScope.gameScore);
             
             console.log("Replaced Current route name :::"+$location.path().replace('/', ""));
             console.log("$rootScope.PagesObject :::"+$rootScope.PagesObject);
         	 /*$.each($rootScope.PagesObject, function( key, value ) {
         		if(key == $location.path().replace('/', ""))
         		{
         			
         		}
 			 });*/
         	
             var chapterRequest = new Object();
             chapterRequest.gameId = 3;
             chapterRequest.chapterId = 1;
  			 var jsonData = JSON.stringify(chapterRequest);
  			 var dataToSend = {
 			        data: jsonData,
  			 };

             $(function(){
                $(".playInstructions").typed({
                    strings: ["<ul class='gameSteps'>" +
                    "<li class='tip'>First Read the content displayed , understand the concept and Play the Game</li>" +
                    "<li class='tip'>Find and Select the appropriate answer in the Grid for the Listed Questions</li>" +
                    "<li class='tip'>Every Correct answer without clue will gain you 20 points else 10 points only</li>" +
                    "</ul>"],
                    typeSpeed: 2,
                    startDelay: 0,
                    loop: false,
                    contentType: 'html', // or text
                    loopCount: false,
                    callback: function() {
                        $('.startChap').prop("disabled", false);
                        $('.startChap').addClass('active');
                    }
                });
            });
             
  			 dataService.Post(GlobalConstants.CHAPTER_DETAILS, dataToSend, $scope.buzzContentSuccess, $scope.buzzContentError);
  			 // dataService.Post('app/stub/buzz.json', dataToSend, $scope.buzzGameSuccess, $scope.buzzGameError);
             if (!$scope.$$phase) {
                 $scope.$apply();
             }
        };
        $scope.closeModal = function(ev){
			$('#modalMain').addClass('hide');
			$('.modal-backdrop').css({'display':'none'});
		};
         //------------------------------------------------------------------------------
         $scope.render();
     };
     app.register.controller('BuzzWordWelcomeContentController', ['$scope', '$rootScope', '$location', 'DialogFactory', 'GlobalConstants', 'dataService', '$compile', '$timeout', BuzzWordWelcomeContentControllerFn]);
 });
    	
