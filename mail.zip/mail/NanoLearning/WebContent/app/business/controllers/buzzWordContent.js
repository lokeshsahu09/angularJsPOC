window.onload = function () {
	 var inputs= new Object();
     inputs.gameId = 3;
     inputs.chapterId = 1;
     var jsonInput = JSON.stringify(inputs);	
     var dataToSend = {
     	data:jsonInput
     }
	var getContentURL="/NanoLearning/rs/gameDetailsService/searchGameDetails";
		 jQuery.ajax({
		        type: "POST",
		        url: getContentURL,
		        data: dataToSend,
		        contentType: "application/json; charset=utf-8",
		        dataType: "json",
		        success: function (data, status, jqXHR) {

		        	if(data !=null){
		        		if(data.header.status == 200){
		        			var contentTitle = data.chapterTitle;
		        			var content = data.learning;
		        			$('#contentTitle').html(contentTitle);
		        			$('#content').html(content);
		        		}
		        	}
		        	else{
		        		alert("Service is Temporially Down,Please try after sometimes.");
		        	}

		        },

		        error: function (jqXHR, status) {
		        	alert("Error Occured Please try after sometimes.");
		        }

		}); 
}
