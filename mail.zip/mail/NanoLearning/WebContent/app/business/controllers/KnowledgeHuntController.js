"use strict";
define(
		[ 'app', 'jquery', 'business/utils/utils', 'jqgrid', 'howl', 'business/constants/config' ],
		function(app, $, util, jqgrid, howl) {

			var knowledgeHuntController = function($timeout, $interval,
					$location, $scope, $rootScope, DialogFactory,
					GlobalConstants, dataService, Pages) {
				
	            
				$scope.serviceSuccess = function(data) {
					if (data.header.status != 200) {
						$scope.serviceFailure(data);
						return false;
					}

					if (data.header.status == 200) {

						var bList = data.bombList.length;
						for ( var x = 0; x < bList; x++) {
							var ques = data.bombList[x].bombDescription;
							var ansdesc = data.bombList[x].answerDescription;
							var bombId = data.bombList[x].bombId;
							var bombType = data.bombList[x].bombType;
							var choiceList = data.bombList[x].choices;
							var choiceTemp = [];
							for ( var y = 0; y < choiceList.length; y++) {
								var choice = {
									id : y,
									choice : choiceList[y].optionDesc,
									isAnswer : choiceList[y].isCorrect
								};
								choiceTemp.push(choice);
							}
							var obj = {
								"count" : x,
								"ques" : ques,
								"ansdesc" : ansdesc,
								"choice" : choiceTemp,
								"bombId" : bombId,
								"bombType" : bombType
							};
							$scope.bombList.push(obj);
						}
						$scope.matrix = data.matrix;
						$scope.treasureList = data.treasureList;
						$scope.totalTeasureCountInitial = data.treasureList.length;
						$scope.totalTeasureCount = data.treasureList.length;
						$scope.initialBombCount = $scope.bombList.length;

						$scope.gameBoard = initGameBoard(data);
						$scope.userGameBoard = userBoard(data);
						$scope.treasGameBoard = treasGameBoard(data.treasureList.length + 1);
						
						$scope.bombSound = undefined;
						$scope.treasureSound = undefined;
						$scope.knowledgeHuntBGM = undefined;
						$scope.soundInit();
						$scope.treasureCount = 0;
					}
				};

				$scope.serviceFailure = function(data) {
					if (data.header.status != 200) {
						$scope.serviceFailure(data);
						return false;
					}

					if (data.header.status == 200) {

					}
				};

				$scope.initiateGame = function() {
					$scope.bombList = [];
					$scope.bombListC = [];
					$scope.resetAnswer();
					$rootScope.PagesObject = Pages;
					$.each($rootScope.PagesObject, function( key, value ) {
		        		if(key == $location.path().replace('/', ""))
		        		{
		        			$rootScope.dataReceived = value;
		                    $rootScope.instructions = value.instructions;
		        		}
					});

					$(function(){
	        			$(".playInstructions").typed({
			                strings: ["<ul class='gameSteps'>" +
			                "<li class='tip'>Click on each column. Column can give you a treasure – the learning, bomb – the riddle, or clue to treasure / hunt</li>" +
			                "<li class='tip'>Answer the riddle at first shot to earn 10 points or check it out later to earn just 5 points</li>" +
			                "<li class='tip'>Hunt all treasures and answer all bombs to complete</li>" +
			                "</ul>"],
			                typeSpeed: 2,
			                startDelay: 0,
			                loop: false,
			                contentType: 'html', // or text
			                loopCount: false,
			                callback: function() {
			                	$('.startChap').prop("disabled", false);
			                	$('.startChap').addClass('active');
			                }
	            		});
          			});

					//hardcoded as of now
					var gameId = 3;
					var chapterId = 2;
					var urlToSend = "rs/minesweeper/getmatrix" + "?" + "gameId=" + gameId + "&" +"levelId=" + chapterId;

					dataService.Get(urlToSend, $scope.serviceSuccess, $scope.serviceFailure);
					//dataService.Get('app/stub/hunt.json', $scope.serviceSuccess, $scope.serviceFailure);
	
				};
				
				$scope.hideStartModal = function(){
					$scope.goToNextChap = false;
					$scope.retryChap = false;
					$scope.knowledgeHuntBGM.play();
					$('#modalMain').addClass('hide');
					$('.modal-backdrop').css({'display':'none'});
					$scope.countdownTimer();
				};
				
				/* $("#nextChapter").on( "click", function() {
    		 		 console.log( "Clicked Next Chapter" );
    		 		 $scope.knowledgeHuntBGM.stop();
    		 		 $scope.$apply(function() {
    		 			$location.path('/learningCartMain');
    		 		 });
         		 });*/
				
				$("#nextChapter").on( "click", function() {
	        		if($location.path().replace('/', "") == "knowledgeHunt")
	        		{
	        		  console.log( "Clicked Next Chapter Inside Knowledge Hunt Controller" );
	        		  $(this).unbind("click");
	          		  $("#nextChapter").unbind("click");
	          		  $scope.knowledgeHuntBGM.stop();
	  	              $rootScope.commonRouter($rootScope.chapterDetails, $rootScope.chapterOrderNbr);
	        		}
	            });
				 
				 $scope.soundInit = function() {
					 	
			            $scope.treasureSound = new Howl({
			              urls: ['app/assets/audio/treasure.mp3'],
			              autoplay: false,
			              loop: false,
			              volume: 2,
			              onend: function() {
			                //alert('Finished!');
			              }
			            });
			            $scope.bombSound = new Howl({
				              urls: ['app/assets/audio/bigBomb.mp3'],
				              autoplay: false,
				              loop: false,
				              volume: 2,
				              onend: function() {
				                //alert('Finished!');
				              }
				            });
			            $scope.knowledgeHuntBGM = new Howl({
			              urls: ['app/assets/audio/tango.mp3'],
			              autoplay: false,
			              loop: true,
			              volume: 1,
			              onend: function() {
			                //alert('Finished!');
			              }
			            });
			        };

				$scope.resetAnswer = function() {
					$scope.counterMinutes = 300;
					$scope.seconds = "00";
					$scope.counterSeconds = 60;
					$scope.minutes = 5;

					$scope.TreasureOpendedCount = 0;
					$scope.score = 0;
					$scope.openedBombCount = 0;
					$scope.compBombCount = 0;

					$scope.gameStatusFail = false;
					$scope.isGameComplete = false;
					$scope.selectedAns = {};
					$scope.showPopUpQuesCheck = false;
					$scope.showPopUpQuesRadio = false;
					$scope.showPopUpBg = false;
					$scope.gameStatusComBPend = false;
					$scope.showPopUpInf = false;
					$('#infModal').modal('hide');

					$scope.showPopUpQuesWro = false;
					$scope.showPopUpQues = false;
					$('#riddleModal').modal('hide');
				};
				$scope.calScore = function() {
					if ( $scope.counterMinutes != 0 ) {
						$scope.score = $scope.score + ($scope.minutes * 10);
					}
					if ( $scope.score > 100 ) {
						$scope.score = 100;
					}
				};

				function treasGameBoard() {

					var boardSize = $scope.matrix.length;
					var maxMines = $scope.matrix.length;
					var treasGameBoard = {};

					treasGameBoard.resetBoard = function(boardSize) {
						this.size = boardSize;

						var boardTempSizeX;
						var boardTempSizeY;
						this.rows = [];
						boardTempSizeX = 3;
						boardTempSizeY = Math.floor(($scope.treasureList.length + 3) / 3);

						var temp = 0;
						for ( var y = 0; y < boardTempSizeY; y++) {
							var gameBoardRow = {};
							gameBoardRow.cells = [];
							for ( var x = 0; x < boardTempSizeX; x++) {
								var cell = {
									visited : 0,
									mine : 0,
									mineNum : 0,
									x : x,
									y : y,
									cellStyle : 'imgTeas',
									markVisited : function() {
										this.visited = 1;
									},
									visit : function() {
									}
								};
								gameBoardRow.cells.push(cell);
								temp = temp + 1;
								if ( temp == $scope.treasureList.length ) {
									break;
								}
							}
							this.rows.push(gameBoardRow);
						}
						$scope.teasureTotalVar = this;

					};

					treasGameBoard.start = function(boardSize, maxMines) {
						this.resetBoard(boardSize);
					};

					treasGameBoard.restart = function() {
					};

					treasGameBoard.start(boardSize, maxMines);

					return treasGameBoard;
				}
				;

				function userBoard() {

					var boardSize = $scope.matrix.length;
					var maxMines = $scope.matrix.length;
					var userGameBoard = {};

					userGameBoard.resetBoard = function(boardSize) {
						this.size = boardSize;

						var boardTempSizeX;
						var boardTempSizeY;
						this.rows = [];
						boardTempSizeX = 3;
						boardTempSizeY = Math.floor(($scope.treasureList.length + 3) / 3);

						var temp = 0;

						for ( var y = 0; y < boardTempSizeY; y++ ) {
							var gameBoardRow = {};
							gameBoardRow.cells = [];
							for ( var x = 0; x < boardTempSizeX; x++ ) {
								var cell = {
									visited : 0,
									mine : 0,
									mineNum : 0,
									x : x,
									y : y,
									cellStyle : 'default',
									markVisited : function() {
										this.visited = 1;
									},
									visit : function() {
									}
								};
								gameBoardRow.cells.push(cell);
								temp = temp + 1;
								if ( temp == $scope.treasureList.length ) {
									break;
								}
							}
							this.rows.push(gameBoardRow);
						}
						$scope.userTeasureTotalVar = this;
					};

					userGameBoard.start = function(boardSize, maxMines) {
						this.resetBoard(boardSize);
					};

					userGameBoard.restart = function() {
					};

					userGameBoard.start(boardSize, maxMines);

					return userGameBoard;
				};

				$scope.stopped;

				$scope.countdownTimer = function() {
					if ( $scope.counterSeconds == 0 ) {
						$scope.counterSeconds = 60;
					}
					if ( $scope.counterMinutes == 0 ) {
						$scope.counterSeconds = 60;
						$scope.showPopUpBg = true;
						$scope.gameStatusFail = true;
						$scope.stopTimer();
						return;
					}
					if ( $scope.isGameComplete == true ) {
						$scope.stopTimer();
						$scope.calScore();
					}

					$scope.stopped = $timeout(function() {
						$scope.counterMinutes--;
						$scope.counterSeconds--;
						if ($scope.counterSeconds == 60 || $scope.counterSeconds == 0) {
							$scope.seconds = "00";
						} else if ($scope.counterSeconds > 0 && $scope.counterSeconds <= 9) {
							$scope.seconds = "0" + $scope.counterSeconds.toString();
						} else {
							$scope.seconds = $scope.counterSeconds;
						}
						if ($scope.counterMinutes >= 300) {
							$scope.minutes = 1;
						} else {
							var calMin = ((300 - $scope.counterMinutes) / 60);
							if (calMin >= 0 && calMin <= 1) {
								$scope.minutes = 4;
							} else if (calMin > 1 && calMin <= 2) {
								$scope.minutes = 3;
							} else if (calMin > 2 && calMin <= 3) {
								$scope.minutes = 2;
							} else if (calMin > 3 && calMin <= 4) {
								$scope.minutes = 1;
							} else if (calMin > 4 && calMin <= 5) {
								$scope.minutes = 0;
							}
						}
						$scope.countdownTimer();
					}, 1000);
				};

				$scope.stopTimer = function() {
					$timeout.cancel($scope.stopped);
				};

				function initGameBoard() {

					var boardSize = $scope.matrix.length;
					var maxMines = $scope.matrix.length;
					var gameBoard = {}

					gameBoard.resetBoard = function(boardSize) {
						this.maxMines = 0;
						this.totalVisited = 0;
						this.size = boardSize;
						this.totalCells = boardSize * boardSize;

						this.rows = [];
						for ( var y = 0; y < this.size; y++) {
							var cellValueY = $scope.matrix[y];
							var gameBoardRow = {};
							var bombQuestion = {};
							var treasInform = {};
							gameBoardRow.cells = [];
							for ( var x = 0; x < this.size; x++) {
								var cellValueX = cellValueY[x];
								var cell = {
									visited : 0,
									mine : 0,
									mineNum : 0,
									x : x,
									y : y,
									bombQ : bombQuestion,
									treasInf : treasInform,
									cellValue : cellValueX,
									bomdAnswrd : false,
									bombType : '',
									cellStyle : 'default',
									markVisited : function() {
										this.visited = 1;
										gameBoard.totalVisited++;
									},
									visit : function() {
										if ($scope.showTeasAni == true) {
											return;
										}
										if (this.cellValue == "T") {
											this.markVisited();
											this.cellStyle = 'imgTeas';
											$scope.stopTimer();
											if (this.treasInf.treasureTitle === undefined
													&& $scope.treasureList.length != 0) {
												$scope.showTeasAni = true;
												$scope.treasureSound.play();
												var id = ++$scope.treasureCount;
												$("#treasure"+id).attr('src', 'app/assets/images/Treasure_Founded.png');
												var that = this;
												$timeout(
														function() {
															$scope.showTeasAni = false;
															if ($scope.score < 100) {
																$scope.score = $scope.score + 5;
															}
															that.treasInf = $scope.treasureList[0];
															$scope.treasInfTitle = $scope.treasureList[0].treasureTitle;
															$scope.treasInfDesc = $scope.treasureList[0].treasureDescription;
															var shiftTreasure = $scope.treasureList.shift();
															$scope.uncheckImage();
															$scope.showPopUpBg = true;
															$scope.showPopUpInf = true;
															$('#infModal').modal('show');
														}, 2000);
											} else {
												$scope.treasInfTitle = this.treasInf.treasureTitle;
												$scope.treasInfDesc = this.treasInf.treasureDescription;
												$scope.showPopUpBg = true;
												$scope.showPopUpInf = true;
												$('#infModal').modal('show');
											}
										} else if (this.cellValue == "B") {
											if ( $scope.showBombAni == true || this.bomdAnswrd == true ) {
												return false;
											}
											this.visited = 1;
											if (this.bombQ.ques === undefined && ($scope.bombList && $scope.bombList.length != 0) && this.bomdAnswrd == false) {
												this.cellStyle = 'imgBombN';
												$scope.openedBombCount++;
												this.bombQ = $scope.bombList[0];
												if (this.bombQ.bombType == 'S') {
													this.bombType = 'S';
													$scope.showPopUpQuesRadio = true;
													$scope.showPopUpQuesCheck = false;
												} else {
													this.bombType = 'M';
													$scope.showPopUpQuesCheck = true;
													$scope.showPopUpQuesRadio = false;
												}
												$scope.bchoice = $scope.bombList[0].choice;
												$scope.bQues = $scope.bombList[0].ques;
												$scope.bquesDesc = $scope.bombList[0].ansdesc;
												var bombTreasure = $scope.bombList.shift();
												$scope.openedBombList = [];
												$scope.openedBombList.push(bombTreasure);
												$scope.stopTimer();
												$scope.showBombAni = true;

												/* load audio url from local
												var url = $location.$$absUrl;
												var urlPath = url.split("index.html#");
												$scope.audio = urlPath[0]+ "/app/assets/audio/bigBomb.mp3";
												document.getElementById("bombAudio").src = $scope.audio;*/
												$scope.bombSound.play();

												$timeout(function() {
															//document.getElementById("bombAudio").src = "";
															$scope.showBombAni = false;
															$scope.showPopUpBg = true;
															$scope.showPopUpQues = true;
															//$scope.soundBomb.stop();
															//$scope.soundBomb.stop();
															$('#riddleModal').modal('show');
														}, 1800);
											} else {
												if (this.bomdAnswrd == false && (this.bombType == 'S' || this.bombType == 'M')) {
													if (this.bombType == 'S') {
														$scope.showPopUpQuesRadio = true;
														$scope.showPopUpQuesCheck = false;
													} else {
														$scope.showPopUpQuesCheck = true;
														$scope.showPopUpQuesRadio = false;
													}
													$scope.bchoice = this.bombQ.choice;
													$scope.bQues = this.bombQ.ques;
													$scope.bquesDesc = this.bombQ.ansdesc;
													$scope.showPopUpBg = true;
													$scope.showPopUpQues = true;
													$('#riddleModal').modal('show');
													$scope.stopTimer();
												} else {
													if (this.visited != 1) {
														this.cellValue = "L";
														this.cellStyle = 'visited';
													}
												}
											}
											$scope.saveBombAns = this;
										} else if (this.cellValue == "L"
												&& this.visited == 0) {
											this.markVisited();
											gameBoard.unCover(this);
											this.cellStyle = 'visited';
											gameBoard.unCover(this);
										} else {
											if ((this.cellValue != "L" || this.cellValue != "B" || this.cellValue != "T") && this.visited == 0) {
												this.cellStyle = 'visited';
												this.markVisited();
												this.mine = 1;
											}
										}
									}
								};
								gameBoardRow.cells.push(cell);
							}
							this.rows.push(gameBoardRow);
						}
						$scope.showPopUpQuesWro = false;
						$scope.showPopUpQuesCor = false;
					};

					$scope.uncheckImage = function() {
						var treasTotRows = $scope.teasureTotalVar.rows;
						var treasTotRowsObj = treasTotRows.cells;
						for ( var i = treasTotRows.length - 1; i >= 0; i--) {
							var test = treasTotRows[i];
							var isFound = false;
							for ( var p = test.cells.length - 1; p >= 0; p--) {
								var t = test.cells[p];
								if (t.cellStyle == 'imgTeas') {
									isFound = true;
									t.cellStyle = 'default';
									break;
								}
							}
							if (isFound == true) {
								break;
							}
						}
						$scope.treasureSound.stop();
						$scope.TreasureOpendedCount++;
						$scope.totalTeasureCountInitial = $scope.totalTeasureCount - $scope.TreasureOpendedCount;
						var userTreasTotRows = $scope.userTeasureTotalVar.rows;
						var userTreasTotRowsObj = userTreasTotRows.cells;
						for ( var i = 0; i < userTreasTotRows.length; i++) {
							var test = userTreasTotRows[i];
							var isFound = false;
							for ( var p = 0; p < test.cells.length; p++) {
								var t = test.cells[p];
								if (t.cellStyle == 'default') {
									isFound = true;
									t.cellStyle = 'imgTeas';
									break;
								}
							}
							if (isFound == true) {
								break;
							}
						}
					};

					gameBoard.unCover = function(startCell) {
						var arr = [];
						for ( var x = 0; x < 2; x++) {
							for ( var y = 0; y < 2; y++) {
								var xPos = startCell.x + x;
								var yPos = startCell.y + y;
								var xNeg = startCell.x - x;
								var yNeg = startCell.y - y;
								if ((xPos >= 0) && (yPos >= 0) && (xPos < this.size) && (yPos < this.size) && (xNeg >= 0) && (yNeg >= 0) && (xNeg < this.size) && (yNeg < this.size)) {
									var cell = this.getCell(xPos, yPos);
									var celll = this.getCell(xNeg, yNeg);
									arr.push(cell);
									arr.push(celll);
								}
							}
						}

						if (arr && arr.length != 0) {
							var length = arr.length;
							var myArray = [];
							var arrayMax = length;
							var limit = arrayMax + 1;
							for ( var i = 0; i < arrayMax; i++) {
								myArray.push(Math.floor(Math.random() * limit));
							}
							for ( var z = 0; z < 3; z++) {
								var temp = myArray[z];
								if (arr[temp] && arr[temp].visited == 0) {
									arr[temp].visited = 1;
									arr[temp].cellStyle = 'visited';
									gameBoard.totalVisited++;
								}
							}
						}
					};

					gameBoard.bombExp = function() {
						$scope.bombList;
					};

					gameBoard.hideBombImg = function() {
						$scope.showBombImg = false;
					};

					gameBoard.getCell = function(x, y) {
						return this.rows[y].cells[x];
					};

					$scope.closePopUpInf = function() {
						$scope.countdownTimer();
						$scope.showPopUpInf = false;
						$('#infModal').modal('hide');
						$scope.showPopUpBg = false;
						var isCompleteCheck = $scope.initialBombCount - ($scope.openedBombCount - $scope.compBombCount);
						if ($scope.treasureList
								&& $scope.treasureList.length == 0) {
							$scope.stopTimer();
							if (isCompleteCheck == $scope.initialBombCount) {
								$scope.showPopUpBg = true;
								$scope.isGameComplete = true;
								$scope.calScore();
							} else {
								$scope.gameStatusComBPend = true;
								$scope.showPopUpBg = true;
							}
						}
					};
					$scope.gamecont = function() {
						$scope.countdownTimer();
						$scope.gameStatusComBPend = false;
						$scope.showPopUpBg = false;
					};
					$scope.gameStatusComBtn = function() {
						$scope.isGameComplete = false;
						$scope.showPopUpBg = false;
						/** Calculate the Chapter Score & Game Total Score - STARTS **/ 
						util.log("$scope.score :::"+$scope.score);
						$rootScope.chapterScore = 0;
						$rootScope.chapterScore = $scope.score;
						$rootScope.gameScore = (($rootScope.gameScore)+($scope.score));
						/** Calculate the Chapter Score & Game Total Score - ENDS **/
					};

					$scope.gameStatusFailBtn = function() {
						$scope.gameStatusFail = false;
						$scope.showPopUpBg = false;
						$scope.initiateGame();
					};

					$scope.closePopUpQues = function(Answer, check, checkBox) {
						var selectCheckValue = selectcheck.elements[check];
						if (selectCheckValue.checked == true) {
							selectCheckValue.checked = false;
							$scope.showPopUpQues = false;
							$('#riddleModal').modal('hide');
							$scope.showPopUpBg = false;
							$scope.saveBombAns.bomdAnswrd = false;
							$scope.showPopUpQuesCheck = false;
							$scope.showPopUpQuesRadio = false;
							gameBoard.selectedAns = [];

							// Clearing Selected Values
							var selectValueCheck = selectCheck.elements[checkBox];
							var selectedAnsSelc = [];
							for ( var i = 0; i < selectValueCheck.length; i++) {
								var someRadio = selectValueCheck[i];
								if (someRadio.checked) {
									selectedAnsSel = someRadio.value - 1;
									selectValueCheck[i].checked = false;
									selectedAnsSelc.push(selectedAnsSel);
								}
							}

							var selectValueRadio = selectRadio.elements[Answer];
							var selectedAnsSel;
							for ( var i = 0; i < selectValueRadio.length; i++) {
								var someRadio = selectValueRadio[i];
								if (someRadio.checked) {
									selectedAnsSel = someRadio.value - 1;
									selectValueRadio[i].checked = false;
									break;
								}
							}
							$scope.countdownTimer();
						} else {
							gameBoard.selectedAns = [];
							if ($scope.showPopUpQuesCheck == true) {
								var selectValue = selectCheck.elements[checkBox];
								var selectedAnsSelc = [];
								for ( var i = 0; i < selectValue.length; i++) {
									var someRadio = selectValue[i];
									if (someRadio.checked) {
										selectedAnsSel = someRadio.value - 1;
										selectValue[i].checked = false;
										selectedAnsSelc.push(selectedAnsSel);
									}
								}
								if ( selectedAnsSelc.length != 0 ) {
									for ( var z = 0; z < selectedAnsSelc.length; z++) {
										if ($scope.bchoice[selectedAnsSelc[z]].isAnswer == "Y") {
											gameBoard.selectedAns.push($scope.bchoice[selectedAnsSelc[z]]);
										}
									}
									var correctAns = [];
									for ( var l = 0; l < $scope.bchoice.length; l++) {
										if ($scope.bchoice[l].isAnswer == "Y") {
											correctAns.push($scope.bchoice[l]);
								}
									}
									if ((gameBoard.selectedAns && selectedAnsSelc && correctAns) && selectedAnsSelc.length == gameBoard.selectedAns.length && correctAns.length == selectedAnsSelc.length ) {
									if (gameBoard.selectedAns.length != 0) {
										if ($scope.score < 100) {
											$scope.score = $scope.score + 5;
										}
										$scope.showPopUpQuesCor = true;
										$scope.showPopUpQues = false;
										$('#riddleModal').modal('hide');
										$scope.saveBombAns.bomdAnswrd = true;
										$scope.saveBombAns.cellStyle = 'imgBombC';
										$scope.compBombCount++;
									}
								} else {
									$scope.score = $scope.score - 5;
									$scope.showPopUpQues = false;
									$('#riddleModal').modal('hide');
									$scope.showPopUpQuesWro = true;
									gameBoard.selectedAns = [];
									}
								}
							}
							if ($scope.showPopUpQuesRadio == true) {
								var selectValue = selectRadio.elements[Answer];
								var selectedAnsSel;
								for ( var i = 0; i < selectValue.length; i++) {
									var someRadio = selectValue[i];
									if (someRadio.checked) {
										selectedAnsSel = someRadio.value - 1;
										selectValue[i].checked = false;
										break;
									}
								}
								if (selectedAnsSel == undefined) {

								} else {
									if ($scope.bchoice[selectedAnsSel].isAnswer == "Y") {
										gameBoard.selectedAns.push($scope.bchoice[selectedAnsSel]);
									} else {
										gameBoard.selectedAns = [];
									}
									if (gameBoard.selectedAns && gameBoard.selectedAns.length == 1) {
										if ($scope.score < 100) {
											$scope.score = $scope.score + 5;
										}
										$scope.showPopUpQuesCor = true;
										$scope.showPopUpQues = false;
										$('#riddleModal').modal('hide');
										$scope.saveBombAns.bomdAnswrd = true;
										$scope.saveBombAns.cellStyle = 'imgBombC';
										$scope.compBombCount++;
									} else {
										$scope.score = $scope.score - 5;
										$scope.showPopUpQues = false;
										$('#riddleModal').modal('hide');
										$scope.showPopUpQuesWro = true;
										gameBoard.selectedAns = [];
									}
								}
							}
						}
					};

					$scope.closePopUpQuesInfCor = function() {
						$scope.showPopUpBg = false;
						$scope.showPopUpQuesCor = false;
						$scope.showPopUpQues = false;
						$('#riddleModal').modal('hide');
						$scope.showPopUpQuesCheck = false;
						$scope.showPopUpQuesRadio = false;
						$scope.countdownTimer();
						var isCompleteCheck = $scope.initialBombCount - ($scope.openedBombCount - $scope.compBombCount);
						if ($scope.treasureList && $scope.treasureList.length == 0 && isCompleteCheck == $scope.initialBombCount) {
							$scope.showPopUpBg = true;
							$scope.isGameComplete = true;
							$scope.calScore();
							$scope.stopTimer();
						}
					};

					$scope.closePopUpQuesInfWro = function() {
						$scope.showPopUpQuesCheck = false;
						$scope.showPopUpQuesRadio = false;
						$scope.showPopUpBg = false;
						$scope.showPopUpQuesWro = false;
						$scope.showPopUpQues = false;
						$('#riddleModal').modal('hide');
						$scope.countdownTimer();
					};

					gameBoard.start = function(boardSize, maxMines) {
						this.resetBoard(boardSize);
					};

					gameBoard.restart = function() {
						$scope.resetAnswer();
						this.start(this.size, this.maxMines);
					};

					gameBoard.start(boardSize, maxMines);

					//$scope.countdownTimer();

					return gameBoard;
				}

				(function() {
					console.log("$rootScope.chapterScore in KnowHunt - "+$rootScope.chapterScore);
		            console.log("$rootScope.gameScore in KnnowHun - "+$rootScope.gameScore);
					$scope.initiateGame();

				})();
			};

			app.register.controller('KnowledgeHuntController', [ '$timeout','$interval','$location','$scope','$rootScope','DialogFactory','GlobalConstants','dataService', 'Config.Pages',knowledgeHuntController]);
});