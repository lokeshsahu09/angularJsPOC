"use strict";
define(['app', 'business/utils/utils'], function (app, util) {
    var PresentationControllerFn = function ($scope, $rootScope, $location, $timeout, GlobalConstants, 
    		GlobalVariable) {
    	//-----------------------------------------------------------------------------------------------------------------
    	/** Render Function **/
    	$scope.render = function () {
    		var vid = document.getElementById("myVideo"); 
    		vid.play(); 
			
    		
    		$("video").bind("ended", function() {
    			 $scope.$apply(function() {
    				 $location.path("/login");
    			 });
			});
    		
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        };
        //-----------------------------------------------------------------------------------------------------------------
        
		//-----------------------------------------------------------------------------------------------------------------
        $scope.render();
    };
    app.register.controller('PresentationController', ['$scope', '$rootScope', '$location', '$timeout','GlobalConstants', 
                                                'GlobalVariable', PresentationControllerFn]);
});