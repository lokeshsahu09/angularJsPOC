"use strict";
define(['app', 'business/utils/utils', 'jquery'], function (app, util, $) {
    var homeController = function ($scope, $rootScope, $location,  dataService, $timeout, GlobalConstants, 
    		GlobalVariable, DialogFactory, $filter) {
    	
    	/** Render Function **/
    	$scope.testing = false;
    	$scope.userName = "";
    	$rootScope.gameSearchText = "";
    	$scope.myInterval = 2000;
    	$scope.homeStub = {};
    	$scope.completedGamesList = [];
    	$scope.popularGames = [];
		$scope.assignedGames = [];
		$scope.newFeedGames = [];
		$scope.isManager = true;
		$scope.pendingGames = 0;
		$scope.pointsEarned = 0;
		$scope.completedGames = 0;
		$scope.gameSearch = "";
		$rootScope.searchClicked = false;
		$rootScope.selectedGameInHome = {};
		
		$scope.success = function(result){
			var homeContent = result.HomeResponse;
			if(homeContent.header.status == 200 && homeContent.header.code == 0){
				$scope.userName = homeContent.firstName+" "+homeContent.lastName;
				$scope.completedGamesList = homeContent.completedGameList;
				$scope.pointsEarned = homeContent.totalPoints;
				$scope.completedGames = homeContent.completedGameList.length;
				var data = {
						employeeId : $rootScope.employeeId
				};
				dataService.Post('/NanoLearning/rs/gameDetailsService/getHomeScrnGameDtls?employeeId='+$rootScope.employeeId, data, $scope.gameDetailsSuccess, $scope.gameDetailsFailed);
			}
		};
		$scope.failed = function(result){
			//show a error pop-up
			util.Wait(false);
		};
		
		$scope.gameDetailsSuccess = function(result){
			if(result.header.status == 200 && result.header.code == 0){
				if(result.popularGamesList != null && result.popularGamesList.length > 0){
					angular.forEach(result.popularGamesList, function(value, key){
						var obj = {};
						obj.title = value.gameTitle;
						obj.description = value.gameDescription;
						obj.id = value.gameID;
						$scope.popularGames.push(obj);
					});
				}
				if(result.assignedGamesList != null && result.assignedGamesList.length > 0){
					angular.forEach(result.assignedGamesList, function(value, key){
						var obj = {};
						obj.title = value.gameTitle;
						obj.description = value.gameDescription;
						obj.id = value.gameID;
						$scope.assignedGames.push(obj);
					});
				}
				if(result.newFeedGamesList != null && result.newFeedGamesList.length > 0){
					angular.forEach(result.newFeedGamesList, function(value, key){
						var obj = {};
						obj.title = value.gameTitle;
						obj.description = value.gameDescription;
						obj.id = value.gameID;
						$scope.newFeedGames.push(obj);
					});
				}
			}
			util.Wait(false);
		};
		$scope.gameDetailsFailed = function(result){
			//show a error pop-up
			util.Wait(false);
		};
		
		var request = {};
		request.employeeId = $rootScope.employeeId;
		request.role = $rootScope.role;
		request.roleCd = $rootScope.roleCd;
		var inputData = {
            	data : JSON.stringify(request)
            };
		if($scope.testing){
			dataService.Get('app/stub/homeContent.json', $scope.success, $scope.failed);
		}else{
			util.Wait(true);
			dataService.Post('/NanoLearning/rs/nano/home', inputData, $scope.success, $scope.failed);
			
		}
		
		
		$scope.showGameResults = false;
		$scope.gamesList = [];
		
    	$scope.render = function () {
    		$rootScope.ngIncludeUrl.gameDetails = '';
        };
        
        $scope.goToDashBoard = function(){
        	$location.path('/dashBoard');
        };
        
        $scope.goToViewGamesFromSearch = function(){
        	if($scope.gameSearch != null && $scope.gameSearch != ""){
        		$rootScope.gameSearchText = $scope.gameSearch;
        		//$rootScope.searchClicked = true;
        		$location.path('/viewGames');
        	}
        };
        
        $scope.goToViewGamesFromLink = function(game){
        	$rootScope.selectedGameInHome = game;
    		$rootScope.gameSearchText = game.title;
    		//$rootScope.searchClicked = false;
    		$location.path('/viewGames');
        };
        
        $scope.onSearchBoxKeyup = function($event){
        	if($event.keyCode == 13){
        		$scope.goToViewGamesFromSearch();
        	}
        };
        
		//-----------------------------------------------------------------------------------------------------------------
        /*var _SlideshowTransitions = [
                                     {$Duration:800,$Delay:200,$Cols:10,$Clip:2,$Formation:$JssorSlideshowFormations$.$FormationStraight}
                                     ];
         var options = {
             $AutoPlay: true,
             $SlideshowOptions: {
                     $Class: $JssorSlideshowRunner$,
                     $Transitions: _SlideshowTransitions,
                     $TransitionsOrder: 1,
                     $ShowLink: true
                 }
         };
         var jssor_slider1 = new $JssorSlider$('slider1_container', options);
         
         function changeBackground() {
        	    //    here i select the current one visible,
        	    //    then i check if there is another image after it, else i go back to the first
        	    var cur = $("#myBackground img:visible"),
        	        nxt = cur.next().length ? cur.next() : $("#myBackground img:first");
        	    cur.fadeOut("slow");
        	    nxt.fadeIn(1500);
        	}

         setInterval(changeBackground, 2250);*/    //    2 second timer
         
         $scope.render();
        
    };
    app.register.controller('HomeController', ['$scope', '$rootScope', '$location', 'dataService', '$timeout','GlobalConstants', 
                                                'GlobalVariable', 'DialogFactory', '$filter', homeController]);
});