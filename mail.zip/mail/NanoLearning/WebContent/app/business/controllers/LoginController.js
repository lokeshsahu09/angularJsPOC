"use strict";
define(['app', 'business/utils/utils', 'business/directives/onlyNumeric', 'business/constants/config'], function (app, util) {
    var loginController = function ($scope, $rootScope, $location,  dataService, $timeout, GlobalConstants, 
    		GlobalVariable, DialogFactory, manageSession, Pages) {
    	
    	var LOG_USERNAME = "logUserName";
    	var LOG_USERPWD = "logUserPwd";
    	$scope.loginUserNameError = false;
    	$scope.loginUserPwdError = false;
    	$rootScope.loginStatus = false;
    	$scope.imageUrl=true;
    	//-----------------------------------------------------------------------------------------------------------------
    	 $("input[type = text]").keydown(function(event) {
 	    	if(event.which == 13) {
 	    		$scope.authenticate();
 	    	}
     	});
    	 
    	 $("input[type = password]").keydown(function(event) {
  	    	if(event.which == 13) {
  	    		$scope.authenticate();
  	    	}
      	});
    	//-----------------------------------------------------------------------------------------------------------------
     	/** authenticate Function **/
     	$scope.authenticate = function() {
     		console.log("EvenT Triggered"); 
     		if($scope.validateLoginForm()) {
     			var loginRequest = new Object();
     			if (angular.isDefined($scope.logUserName) && $scope.logUserName != "" 
     				&& $scope.logUserName !=null){
     				
     				loginRequest.empNumber = $scope.logUserName;
     			}
     			if (angular.isDefined($scope.logUserPwd) && $scope.logUserPwd != "" 
     					&& $scope.logUserPwd != null){

     				loginRequest.password = $scope.logUserPwd;
     			}  
     			//util.Wait(true);
     			var jsonData = JSON.stringify(loginRequest);
     			var dataToSend = {
 			        data: jsonData,
     			};
     			//dataService.Post('rs/authenticate/login', dataToSend, $scope.onLoginSuccess, $scope.onLoginError);
     			dataService.Post('rs/authenticate/login', dataToSend, $scope.onLoginSuccess, $scope.onLoginError);
     		}
     		else {
     			console.log("Validation Fails");
     		}
     	};
     	//-----------------------------------------------------------------------------------------------------------------
     	/** onLoginSuccess Function **/
     	$scope.onLoginSuccess = function(result) {
     		util.log(result);
     		
     		if(result.header.status != 200) {
     			$scope.onLoginError(result);
     			return false;
     		}
     		
     		if(result.header.status == 200) {
                $rootScope.loginStatus = true;
                manageSession.startSession();
                if($rootScope.ngIncludeUrl.userDashBoard == ''){
                            $rootScope.ngIncludeUrl.userDashBoard = 'app/business/views/userDashBoard.html';   
                    }
     			$rootScope.userDetails = result.userDetails;
     			$rootScope.PagesObject = Pages;
     			console.log("$scope.Pages::::"+$scope.Pages);
     			/*$rootScope.employeeId = 555216;
     			$rootScope.role = "TM";
     			$rootScope.roleCd = 1;*/
     			$rootScope.employeeId = 118107;
     			$rootScope.role = "DM";
     			$rootScope.roleCd = 5;
     			
     		/*$rootScope.employeeId = result.userDetails.empNbr;
     			$rootScope.role = result.userDetails.roleDesc;
     			$rootScope.roleCd = result.userDetails.roleCd;
     			$rootScope.firstName = result.userDetails.firstName;
     			$rootScope.lastName = result.userDetails.lastName;*/
     			
     			
     			if($rootScope.roleCd == 4 || $rootScope.roleCd == 5 || $rootScope.roleCd == 6){
     				$rootScope.isDashboard = true;
     				$location.path('/dashBoard');
     			}else{
     				$rootScope.isDashboard = false;
     				$location.path('/home');
     				//$location.path('/learningCartMain');
     				//$location.path('/buzzWordContent');
     				//$location.path('/QACards');
     			}
     		}
     	};
     	//-----------------------------------------------------------------------------------------------------------------
     	/** onLoginError Function **/
     	$scope.onLoginError = function(result) {
     		util.Wait(false);
     		$rootScope.PagesObject = null;
     		util.log(result);
     		if(result)
     		{
     			$rootScope.showManageWONMsg(result.header.message);
     		}	
     	};
        
    	//-----------------------------------------------------------------------------------------------------------------
    	/** validateLoginForm Function **/
    	$scope.validateLoginForm = function() {
    		if($scope.logUserName && $scope.logUserName != null && $scope.logUserPwd && $scope.logUserPwd != null) {
    			$scope.loginUserNameError = false;
        		$scope.loginUserPwdError = false;
    			return true;
    		}
    		else
    		{
    			if($scope.logUserName && $scope.logUserName != null) {
    				$scope.loginUserNameError = false;
    				if(!$scope.logUserPwd || $scope.logUserPwd == null) {
    					util.setFocus([LOG_USERPWD]);
    					$scope.loginUserPwdError = true;
    				} else {
    					$scope.loginUserPwdError = false;
    				}
    			} else {
    				$scope.loginUserNameError = true;
    				$scope.loginUserPwdError = false;
    				util.setFocus([LOG_USERNAME]);
    			}
    			return false;
    		}
    	};
    	//-----------------------------------------------------------------------------------------------------------------
    	/** Render Function **/
    	$scope.render = function () {
        	util.log("Hi Im in Login Controller ---- " + $("#ng-view").length);
        	manageSession.destroyWatch();
        	$('.autoDisable').attr('autocomplete','off');
        	$rootScope.loginStatus = false;
			$timeout(function() {
				angular.element("#" + LOG_USERNAME).focus();
			}, 50);
        	
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        };
        //-----------------------------------------------------------------------------------------------------------------
        /** showManageWONMsg Function **/
        $rootScope.showManageWONMsg = function(_msg) {
        	var _scopeOptions = {
				'isOK' : true,
				'isCancel' : false,
				'modalMsg' : _msg
			};
			var _tmPath = "app/business/partials/modalPopupTemplate.html";
			var _ctrlPath = "business/controllers/ModalPopupController";
			
			DialogFactory.show(_tmPath, _ctrlPath, null, false, _scopeOptions);
        };
        $scope.changeImage=function()
        {
        	
        	$scope.imageUrl=!$scope.imageUrl;
        	
        	
        	
        };
        
		//-----------------------------------------------------------------------------------------------------------------
        $scope.render();
    };
    app.register.controller('LoginController', ['$scope', '$rootScope', '$location', 'dataService', '$timeout','GlobalConstants', 
                                                'GlobalVariable', 'DialogFactory', 'manageSession', 'Config.Pages', loginController]);
});