"use strict";
define(['app', 'business/utils/utils', 'jquery', 'lodash'], function (app, util, $, _) {
    var viewGamesController = function ($scope, $rootScope, $location,  dataService, $timeout, GlobalConstants, 
    		GlobalVariable, DialogFactory, $filter) {
    	
    	/** Render Function **/
    	$scope.assignedSuccess = false;
    	$scope.assignedError = false;
    	$scope.homeStub = {};
    	$scope.isManager = $rootScope.isDashboard;
		$scope.gameSearch = $rootScope.gameSearchText;
		$rootScope.gameSearchText = "";
		$scope.showAssignToTeam = false;
		$scope.employeeList = [];
		$scope.selectedGame = {};
		$scope.assignSuccessMessage = "";
		 //-----------------------------------------------------------------------------------------------------------------
		$scope.success = function(result){
			if(result.header.status == 200) {
				if(result.allGameList != null && result.allGameList.length > 0){
					angular.forEach(result.allGameList, function(value, key){
						var game = {};
						game.id = value.gameID;
						game.description = value.gameDescription;
						game.name = value.gameTitle;
						$scope.gamesList.push(game);
					});
					$scope.resetShowAssignToTeam();
				}
				else if(result.allGameList != null && result.allGameList.length == 0){
					$scope.assignSuccessMessage = "No Games Found.";
					$scope.assignedSuccess = true;
				}
				util.Wait(false);
			}
			else if(result.header.status == 100){
				// No results found
				util.Wait(false);
			}
			else {
				// throw error pop.up
				$scope.failed(result);
			}
		};
		 //-----------------------------------------------------------------------------------------------------------------
		$scope.failed = function(result){
			//show a error pop-up
			util.Wait(false);
		};
		 //-----------------------------------------------------------------------------------------------------------------
		//$scope.showGameResults = false;
		$scope.gamesList = [];
		
		$scope.searchGames = function(){
			$scope.assignedSuccess = false;
			$scope.gamesList = [];
			var data = {gameKeySearch:$scope.gameSearch};
			//dataService.Get('app/stub/homeContent.json', $scope.success, $scope.failed);
			util.Wait(true);
			dataService.Post('/NanoLearning/rs/gameDetailsService/getSearchGameDtls?gameKeySearch='+$scope.gameSearch, data, $scope.success, $scope.failed);
			//$scope.showGameResults = true;
		};
		 //-----------------------------------------------------------------------------------------------------------------
		$scope.onGameSearchKeyUp = function($event){
			if($event.keyCode == 13){
				$scope.searchGames();
			}
		};
		 //-----------------------------------------------------------------------------------------------------------------
		$scope.assignToTeam = function(game){
			$scope.resetShowAssignToTeam();
			$scope.selectedGame = game;
			$scope.showAssignToTeam = true;
			var obj = {};
			obj.supervisorId = $rootScope.employeeId;
			obj.nanoGameId = game.id;
			
			var inputData = {
					data : JSON.stringify(obj)
			};
			util.Wait(true);
			dataService.Post('/NanoLearning/rs/assignGame/getEmployees', inputData, $scope.getEmployeeSuccess, $scope.getEmployeeFailed);
		};
		 //-----------------------------------------------------------------------------------------------------------------
		$scope.getEmployeeSuccess =  function(result){
			$scope.employeeList = [];
			if(result.header.status == 200){
				if(result.employeesList != null && result.employeesList.length > 0){
					angular.forEach(result.employeesList, function(value, key){
						var employee = {};
						employee.state = false;
						employee.id = value.employeeId;
						employee.name = value.employeeFirstName+" "+value.employeeLastName;
						$scope.employeeList.push(employee);
					});
				}
				util.Wait(false);
			}
			else if(result.header.status == 100){
				// code to show message - no employee to assign
				util.Wait(false);
			}
			else{
				$scope.getEmployeeFailed(result);
			}
		};
		 //-----------------------------------------------------------------------------------------------------------------
		$scope.getEmployeeFailed =  function(result){
			util.Wait(false);
		};
		 //-----------------------------------------------------------------------------------------------------------------
		$scope.resetShowAssignToTeam = function(){
			$scope.employeeList = [];
			$scope.selectedGame = {};
			$scope.showAssignToTeam = false;
			$scope.assignedSuccess = false;
			$scope.assignedError = false;
		};
		$scope.selectedEmployees = [];
		$scope.assignGame = function(){
			var atleastOneSelected = false;
			for(var i=0; i<$scope.employeeList.length; i++){
				if($scope.employeeList[i].state){
					atleastOneSelected = true;
					$scope.selectedEmployees.push($scope.employeeList[i].id);
				}
			}
			if(atleastOneSelected){
				$scope.callAssignService();
			}else{
				$scope.assignedError = true;
			}
		};
		 //-----------------------------------------------------------------------------------------------------------------
		$scope.callAssignService = function(){
			var obj = {};
			obj.supervisorId = $rootScope.employeeId;
			obj.gameId = $scope.selectedGame.id;
			obj.employeeIds = $scope.selectedEmployees;
			
			var inputData = {
					data : JSON.stringify(obj)
			};
			util.Wait(true);
			dataService.Post('/NanoLearning/rs/assignGame/assignToEmployees', inputData, $scope.assignSuccess, $scope.assignFailure);
		};
		 //-----------------------------------------------------------------------------------------------------------------
		$scope.assignSuccess = function(result){
			if(result.status == 200){
				if(result.developerMessage == "Employees added"){
					$scope.assignSuccessMessage = "Game Assigned Successfully.";
				}else{
					$scope.assignSuccessMessage = "Game Already Assigned.";
				}
				$scope.assignedSuccess = true;
				$scope.showAssignToTeam = false;
				util.Wait(false);
			}
			else{
				$scope.assignFailure(result);
			}
		};
		 //-----------------------------------------------------------------------------------------------------------------
		$scope.assignFailure = function(result){
			util.Wait(false);
		};
		 //-----------------------------------------------------------------------------------------------------------------
    	$scope.render = function () {
    		$rootScope.ngIncludeUrl.gameDetails = '';
    		//if($rootScope.searchClicked){
    		if($scope.gameSearch != ""){
    			$scope.searchGames();
    		}
    		/*}else{
    			$scope.gamesList = [];
    			var game = {};
				game.id = $rootScope.selectedGameInHome.id;
				game.description = $rootScope.selectedGameInHome.description;
				game.name = $rootScope.selectedGameInHome.title;
    			$scope.gamesList.push(game);
    			$scope.resetShowAssignToTeam();
    		}*/
        };
        //-----------------------------------------------------------------------------------------------------------------
        $scope.goToHomePage = function(){
        	$location.path('/home');
        };
        //-----------------------------------------------------------------------------------------------------------------
        $scope.playGame = function(game){
        	$rootScope.chapterDetails  = null;
        	$rootScope.gameId = game.id;
 			var dataToSend = {
 					gameId : $rootScope.gameId
 					//game : $rootScope.gameId
 			};
 			dataService.Post(GlobalConstants.GET_CHAPTER_ORDER, dataToSend, $scope.onChapterSuccess, $scope.onChapterError);
        };
        //-----------------------------------------------------------------------------------------------------------------
        $scope.onChapterSuccess = function(result)
        {
        	if(result.header.status != 200)
        	{
        		$scope.onChapterError(result);
        		return false;
        	}
        	if(result.chapterDetails != undefined && result.chapterDetails.length > 0)
        	{
        		/** Reset the Chapter Score & Game Total Score At the Start of Game - STARTS **/ 
        		$rootScope.chapterDetails  = null;
        		$rootScope.chapterOrderNbr = 0;
            	$rootScope.chapterScore = 0;
            	$rootScope.gameScore = 0;
            	$rootScope.gameTS = 0;
            	$rootScope.gameTS = (new Date).getTime();
            	util.log("$rootScope.gameTS::"+$rootScope.gameTS);
            	$rootScope.chapterDetails = result.chapterDetails;
            	/** Reset the Chapter Score & Game Total Score At the Start of Game  - ENDS **/
        		$rootScope.commonRouter($rootScope.chapterDetails, $rootScope.chapterOrderNbr);
        	}
        };
      //-----------------------------------------------------------------------------------------------------------------
        $rootScope.commonRouter = function(resultData, chapterOrderNbr)
        {
        	$timeout(function() {
        		$rootScope.chapterOrderNbr = chapterOrderNbr+1;
        		util.log("chapterOrderNbr:::"+$rootScope.chapterOrderNbr);
     			var ChapterObject = _.where(resultData, {
     				chapterOrderNbr : $rootScope.chapterOrderNbr
                 });
     			util.log("ChapterObject.length :::"+ChapterObject.length);
     			if(ChapterObject[0] != undefined)
     			{
     				var RouteObject = _.where($rootScope.PagesObject, {
         				chapterId : ChapterObject[0].chapterId
                     });
     				util.log("RouteObject.length :::"+RouteObject.length);
         			if(RouteObject[0] != undefined)
         			{
     					util.log("RouteObject[0].path:::"+RouteObject[0].path);
         				$location.path('/'+RouteObject[0].path);
         				//$location.path('/learningCartMain');
                  		//$location.path('/knowledgeHunt');
                     	//$location.path('/QACards');
                     	//$location.path('/buzzWordContent');
         			}
         			else
         			{
         				$scope.moveToHome();
         			}
     			}
     			else
     			{
     				$scope.moveToHome();
     			}
        	}, 10);
        };
      //-----------------------------------------------------------------------------------------------------------------
        $scope.onChapterError = function(result)
        {
        	$rootScope.chapterDetails  = null;
        	return false;
        };
      //-----------------------------------------------------------------------------------------------------------------
        $scope.moveToHome = function(){
        	$rootScope.chapterDetails  = null;
    		$rootScope.chapterOrderNbr = 0;
        	$rootScope.chapterScore = 0;
        	$rootScope.gameScore = 0;
        	$rootScope.gameTS = 0;
        	$location.path('/home');	
        };
        //-----------------------------------------------------------------------------------------------------------------
        $scope.rowClicked = function(event, index){
        	 if (event.target.tagName != 'INPUT') {
                 $scope.employeeList[index].state = !$scope.employeeList[index].state;
             }
        };
        
		//-----------------------------------------------------------------------------------------------------------------
        $scope.render();
    };
    app.register.controller('ViewGamesController', ['$scope', '$rootScope', '$location', 'dataService', '$timeout','GlobalConstants', 
                                                'GlobalVariable', 'DialogFactory', '$filter', viewGamesController]);
});