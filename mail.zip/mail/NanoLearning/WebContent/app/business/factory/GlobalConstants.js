'use strict';
define(['app'], function (app) {
    var GlobalConstants = function () {
        var GlobalConstantObj = {};
        
        GlobalConstantObj.CHAPTER_DETAILS = 'rs/gameDetailsService/searchGameDetails';
        GlobalConstantObj.UPDATE_NANO_SCORE = 'rs/gameDetailsService/updateGameScore';
        GlobalConstantObj.GET_CHAPTER_ORDER = 'rs/gameDetailsService/getGameChapters';
        
        return GlobalConstantObj;
    };
    app.register.factory('GlobalConstants', [GlobalConstants]);
});