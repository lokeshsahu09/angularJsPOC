"use strict";
define(['jquery', 'underscore'], function ($, _) {
    var utilClass = {};
    //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
    utilClass.safeApply = function (scope, fn) {
        var phase = scope.$root.$$phase;
        if (phase == '$apply' || phase == '$digest') {
            if (fn && (typeof (fn) === 'function')) {
                fn();
            }
        } else {
            scope.$apply(fn);
        }
    };
    //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
    utilClass.getMaxZIndex = function () {
        var zIndexMax = 0;
        $('div').each(function () {
            var z = parseInt($(this).css('z-index'));
            if (z > zIndexMax) zIndexMax = z;
        });
        return zIndexMax + 10;
    };
    //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
    utilClass.Wait = function (wait) {
        if (wait) {
            if ($(".blockOverlay").length > 0)
                return false;
            $.blockUI({
               /* message: '<img src="app/assets/images/spinner.gif" /> ',*/
            	 message: '<img src="app/assets/images/loading_new.gif" /> ',
                baseZ: 10001,
                onUnblock: function () {},
                css: {
                    "backgroundColor": "none",
                    "border": "0px"
                }
            });
        } else {
           $.unblockUI();
        }
    };
    //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
    utilClass.setFocus = function (_elemId) {
        if (!_.isArray(_elemId)) {
            $("#" + _elemId).focus();
        } else {
            $("#" + _elemId[0]).focus();
        }
    };
   //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
    utilClass.log = function (_msg) {
    	try {
            console.log(result+'-->'+_msg);
        } catch (e) {

        }
    };
   //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
    utilClass.compileListToKeyValue = function(_poList, keey){
    	var poObj = {};
    	var poArr = _.pluck(_poList, keey);
    	_.each(poArr, function(key, value){
    		poObj[key] = _poList[value];
    	});
    	return poObj;
    };
  //-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
    utilClass.convertYYYYMMDDToMMDDYYYY = function(_dateVal){
    	var _date = _dateVal.split("-")[1]+"/"+_dateVal.split("-")[2]+"/"+_dateVal.split("-")[0];
    	return _date;
    };
    return utilClass;
    
});