(function() {
	var dependencies = [];

	define(dependencies, function() {
		var module = angular.module("ProjectApp");
		if (module.hasOwnProperty('register'))
			module = module.register;

		module.constant("Config.Pages", {
			buzzWordContent : {
				template : "Buzz Words",
				title: "Agile Basics",
				path : "buzzWordContent",
				chapterId : 1,
				description: "",
				instructions: [
	                  
			    ]
			},
			knowledgeHunt : {
				template : "Knowledge Hunt",
				title: "Agile Charecteristice, Values & Principles",
				path : "knowledgeHunt",
				chapterId : 2,
				description: "",
				instructions: [
	                  
			    ]
			},
			QACards : {
				template : "QA Cards",
				title: "Agile Process",
				path : "QACards",
				chapterId : 4,
				description: "This game provides a basic overview about the Agile process following in The Home Depot",
				instructions: [
	                  {
	                    key: "Playing Rule",
	                    description: [
	                      {
						    value: "Click a Question card, and then choose the correct answer within 60 seconds."
						  },
	                      {
	                        value: "And, can you reveal the hidden picture ?"
	                      }
	                    ]
	                  },
	                  {
	                    key: "Score Rule",
	                    description: [
	                      {
	                        value: "Score a point each time if your attempt is correct."
	                      }
	                    ]
	                  }
			    ]
			},
			learningCartMain : {
				template : "Learning Cart",
				path : "learningCartMain",
				chapterId : 3,
				description: "This game provides a basic overview about the Agile process following in The Home Depot",
				instructions: [
	                  {
	                    key: "Playing Rule",
	                    description: [
	                      {
	                        value: "You have to select the book which are applicable to the given title"
	                      },
	                      {
	                        value: "Click on each book to know its detail and relationship with other books"
	                      },
	                      {
	                        value: "After reading every book, Drag & Drop the required books sequentially in the cart for the mentioned process"
	                      },
	                      {
	                        value: "Click 'Place Order', once the books are added in the cart"
	                      }
	                    ]
	                  },
	                  {
	                    key: "Wallet Deduction Rule",
	                    description: [
	                      {
	                        value: "On start of game you will be provided $100"
	                      },
	                      {
	                        value:"Once the order is placed, if",
					        subValue:[
					            {
					              "text":"Cart books are selected in sequential for the respective process, we will not deduct the wallet amount"
					            },
					            {
					              "text":"Cart books are not selected in sequential, we will deduct $25 from wallet"
					            },
					            {
					              "text":"Cart contained the irrelevant books to the process, we will deduct $25 from wallet"
					            }
					          ]
	                      }
	                    ]
	                  }
			    ]
			}
		});

	});
})();