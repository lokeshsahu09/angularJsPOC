"use strict";
(function() {
	var dependencies = [ 'app', 'business/utils/utils' ];

	define(dependencies, function(app, util) {
		angular.module("ProjectApp").service('manageSession', ManageSession);

		ManageSession.$inject = [ '$timeout', '$document', '$location'];

		function ManageSession($timeout, $document, $location) {
			var selfInstance = this;
			var configuration = {
				expireTime : 1800000, // 30 minute
				events : 'click'
			};

			this.expireSessionIterval = null;

			/** Call this function when the customer logged in successfully * */
			this.startSession = function() {
				util.log("Start the session");
				$document.find('body').on(configuration.events, function() {
					selfInstance.resetWatch();
				});
				selfInstance.expireSessionIterval = $timeout(selfInstance.expireSession, configuration.expireTime);
			};

			this.expireSession = function() {
				util.log("Session is expired");
				selfInstance.destroyWatch(); // Destroy the intervals before
				// loading login page
				selfInstance.loadLoginPage();
			};

			this.resetWatch = function() {
				util.log("Reset the session");
				selfInstance.destroyWatch();
				selfInstance.startSession();
			};

			this.destroyWatch = function() {
				util.log("Destroy the Session");
				$timeout.cancel(selfInstance.expireSessionIterval);
				$document.find('body').off(configuration.events);
			};

			this.loadLoginPage = function() {
				util.log("Navigating to Login due to session expiry");
				/** Clear all cookie values and $rootscope values * */
				$location.path('/login');
			};
		}
	});
})();