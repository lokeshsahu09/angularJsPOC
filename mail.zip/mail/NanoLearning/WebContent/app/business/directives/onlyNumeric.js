'use strict';
(function() {
	var dependencies = [ 'app' ];
	define(dependencies, function(app) {
		angular.module("ProjectApp").register.directive('numbersOnly', OnlyNumeric);

		OnlyNumeric.$inject = [];

		function OnlyNumeric() {
			return {
		        require: 'ngModel',
		        link: function(scope, element, attrs, modelCtrl) {
		            modelCtrl.$parsers.push(function (inputValue) {
		                var transformedInput ;
		                if(inputValue != undefined)
		                {
		                	transformedInput= inputValue.replace(/[^\d]/g,'');

			                if (transformedInput!=inputValue) {
			                    modelCtrl.$setViewValue(transformedInput);
			                    modelCtrl.$render();
			                }
		                }
		                else
		                {
		                	transformedInput = "";
		                }	
		                return transformedInput;
		            });
		        }
		    };
		}
	});
})();