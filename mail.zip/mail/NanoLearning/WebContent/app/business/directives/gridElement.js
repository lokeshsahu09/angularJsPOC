'use strict';
(function() {
	var dependencies = [ 'app', 'jquery', 'jqgrid' ];

	define(dependencies, function(app, $, jqgrid) {
		angular.module("ProjectApp").register.directive('ngJqGrid', TableGrid);

		TableGrid.$inject = [];

		function TableGrid() {
		    return {
		        restrict: 'AE',
		        scope: {
		          config: '=',
		          gridId:'=',
		          clsName:'=',
		          data: '=?',
		          footerdata: '=?',
		        },
		        link: function (scope, element, attrs) {
		      	  var table, div;
		      	  var footerVal;
		      	  var id = attrs.gridId;
		      	  var className = attrs.clsName;
		          scope.$watch('config', function (newValue) {
		            element.children().empty();
		            console.log("New Grid ID----"+id);
		            table = angular.element('<table id="grid_'+id+'" class="'+className+'"></table>');
		            
		            div = angular.element('<div id="gridHeaderInfo"></div>');
		            element.append(div);
		            element.append(table);
		           $(table).jqGrid(newValue);
		          });
		          scope.$watch('data', function (value) {
		          	 $(table).jqGrid('clearGridData');
		          	 $(table).jqGrid('setGridParam', { data: value }).trigger('reloadGrid');
		          });
		          
		          
		          scope.$watch('footerdata', function (value) {
		          	/*if(angular.isDefined(value) && $rootScope.isAdditionalFeatureAllowed){
		  	        	footerVal="";
		  	        	
		  	        	if(value.hasOwnProperty('totalResults')){
		  	        		footerVal = footerVal+' <div class="grid-footer-element"><label class="searchLblCls">Total Results: </label><span style="width:2px;"></span>'+value.totalResults+'</div>';
		  	        	}
		  	       	 $(div).html(footerVal);
		          	}*/
		         });
		        }
		      };
		}
	});
})();

