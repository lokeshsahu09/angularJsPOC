package com.homedepot.ipcameracontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.homedepot.ipcameramanager.IPCameraManager;
import com.homedepot.ipcamerapojo.IPCameraList;
import com.homedepot.ipcamerautils.GSONConverter;


@Controller
@Scope("prototype")
public class StoreCameraDetailsController {

	@Autowired
	IPCameraManager ipCameraManager ;
	@Autowired
	IPCameraList ipCameraList ;

	@RequestMapping(value = "/storeCameraDetails", method = RequestMethod.GET)
	@ResponseBody
	public String storeCameraDetails() throws Exception {
		ipCameraList = ipCameraManager.getCameraInfo(ipCameraList);
		return GSONConverter.toJson(ipCameraList);

	}
	
	@RequestMapping(value = "/getImageOfIpCamera", method = RequestMethod.GET, produces = "image/jpg")
	public @ResponseBody byte[] getImage(@RequestParam("cameraIp") String cameraIp, @RequestParam("thumbnail") String isThumbnailImage) {
		byte[] imageData = null;
		try {
			imageData = ipCameraManager.getImage(cameraIp, isThumbnailImage);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return imageData;
	}
}
