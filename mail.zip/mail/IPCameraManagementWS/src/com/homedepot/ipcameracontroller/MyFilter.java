package com.homedepot.ipcameracontroller;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.filter.OncePerRequestFilter;

public class MyFilter extends OncePerRequestFilter {

	public static final String CREDENTIALS_NAME = "Access-Control-Allow-Credentials";
	public static final String ORIGIN_NAME = "Access-Control-Allow-Origin";
	public static final String METHODS_NAME = "Access-Control-Allow-Methods";
	public static final String HEADERS_NAME = "Access-Control-Allow-Headers";
	public static final String MAX_AGE_NAME = "Access-Control-Max-Age";


	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		response.setHeader(CREDENTIALS_NAME, "true");
		response.setHeader(ORIGIN_NAME, "*");
		response.setHeader(METHODS_NAME, "GET, OPTIONS, POST");
		response.setHeader(HEADERS_NAME, "Origin, X-Requested-With, Content-Type, Accept");
		response.setHeader(MAX_AGE_NAME, "3600");
		filterChain.doFilter(request, response);
	}

}
