package com.homedepot.ipcamerapojo;

import org.springframework.stereotype.Component;

@Component
public class IPCamera {
	private String model;

    private String MAC;

    private String ipAddress;
    
    private String firstDiscoverTS;
    private String url;
   
	/**
	 * @return the firstDiscoverTS
	 */
	public String getFirstDiscoverTS() {
		return firstDiscoverTS;
	}

	/**
	 * @param firstDiscoverTS the firstDiscoverTS to set
	 */
	public void setFirstDiscoverTS(String firstDiscoverTS) {
		this.firstDiscoverTS = firstDiscoverTS;
	}

	public String getModel ()
    {
        return model;
    }

    public void setModel (String model)
    {
        this.model = model;
    }

    public String getMAC ()
    {
        return MAC;
    }

    public void setMAC (String MAC)
    {
        this.MAC = MAC;
    }

    public String getIpAddress ()
    {
        return ipAddress;
    }

    public void setIpAddress (String ipAddress)
    {
        this.ipAddress = ipAddress;
    }

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
}
