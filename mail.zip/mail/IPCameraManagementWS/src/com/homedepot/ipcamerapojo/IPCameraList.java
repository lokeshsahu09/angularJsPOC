package com.homedepot.ipcamerapojo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class IPCameraList {
	

	@Autowired
	private ResponseHeader header;
	@Autowired
	private List<IPCamera> cameraList;

	public List<IPCamera> getCameraList () {
		return cameraList;
	}

	public void setCameraList (List<IPCamera> cameraList) {
		this.cameraList = cameraList;
	}
	
	
}
