package com.homedepot.ipcamerautils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@ComponentScan
@PropertySource("classpath:com/homedepot/ipcamerautils/ip_config.properties")
public class GetPropertiesValues {
	@Autowired
	private Environment env;
	public static GetPropertiesValues getPropertiesValues=null;
	
	public static GetPropertiesValues getInstance()
	{
		if(getPropertiesValues==null)
		{
			synchronized (GetPropertiesValues.class) {
				if(getPropertiesValues==null)
				{
					
					@SuppressWarnings("resource")
					ApplicationContext applicationContext = new AnnotationConfigApplicationContext(GetPropertiesValues.class);
				    getPropertiesValues=applicationContext.getBean(GetPropertiesValues.class);
					
					return getPropertiesValues;
				}
				
			}
		}
		
		return getPropertiesValues;
		
	}
	
	public String getValueFromProperty(String value) {
		String result = env.getProperty(value);
		return result;
	}
}
