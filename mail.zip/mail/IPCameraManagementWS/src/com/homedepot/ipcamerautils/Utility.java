package com.homedepot.ipcamerautils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Utility {
	public static String getProperty(String key) {
		String propertyFilePath = "com/homedepot/ipcamerautils/ip_config.properties";
		
        InputStream propertyFile = null;
        String value = null;
        try {

            propertyFile = Utility.class.getClassLoader().getResourceAsStream(propertyFilePath);
            Properties property =null;

            if (propertyFile != null && property==null)
            {
            	
            	property = new Properties();
            	property.load(propertyFile);
            	System.out.println("loaded..................");
            	
            	            }

            value = property.getProperty(key);

        } catch (IOException ex) {

            ex.printStackTrace();

        } finally {

            if (propertyFile != null) {
                try {
                    propertyFile.close();

                } catch (IOException ex) {
                	ex.printStackTrace();
                }
            }


        }
        return value;
    }

}
