package com.homedepot.ipcameramanager;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import javax.imageio.ImageIO;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.homedepot.ipcamerapojo.IPCamera;
import com.homedepot.ipcamerapojo.IPCameraList;
import com.homedepot.ipcamerautils.GetPropertiesValues;
import com.homedepot.ipcamerautils.NtlmAuthenticator;

@Service
public class IPCameraManager {

	String[] cameraIPs = {"10.4.81.218", "10.4.81.219"};//stubbed data to be replaced with values from DB/Command
	String urlForMacIp = null;
	String urlForModel = null;

	public IPCameraList getCameraInfo(IPCameraList ipCameraList) {
		String result = null;
		IPCamera ipCamera=null;
		List<IPCamera> ipCameras = new ArrayList<IPCamera>();
		GetPropertiesValues getPropertiesValues=GetPropertiesValues.getInstance();
		String forImageURLfirst =getPropertiesValues.getValueFromProperty("forImageURLfirst");
	    String forImageURLLast = getPropertiesValues.getValueFromProperty("forImageURLLast");

		try {
			for(int i = 0; i < cameraIPs.length; i++) {
				ipCamera=new IPCamera();
				urlForMacIp = "http://"+cameraIPs[i]+"/axis-cgi/param.cgi?action=list&group=Network.eth0&listformat=xmlschema";
				urlForModel = "http://"+cameraIPs[i]+"/axis-cgi/param.cgi?action=list&group=Brand.ProdNbr&listformat=xmlschema";
				NtlmAuthenticator authenticator = new NtlmAuthenticator("root", "pass");
				Authenticator.setDefault(authenticator);
				RestTemplate restTemplate = new RestTemplate();
				result = restTemplate.getForObject(urlForMacIp, String.class);
				Scanner scanner1 = new Scanner(result);
				while (scanner1.hasNextLine()) {
					String line = scanner1.nextLine();
					String[] values = line.split("=");
					if(values[0].equals("root.Network.eth0.MACAddress")) {
						ipCamera.setMAC(values[1]);
					} else if(values[0].equals("root.Network.eth0.IPAddress")) {
						ipCamera.setIpAddress(values[1]);
					}
				}
				scanner1.close();
				result = restTemplate.getForObject(urlForModel, String.class);
				Scanner scanner2 = new Scanner(result);
				while (scanner2.hasNextLine()) {
					String line = scanner2.nextLine();
					String[] values = line.split("=");
					if(values[0].equals("Brand.ProdNbr")) {
						ipCamera.setModel(values[1].substring(1, 5));
					}
				}
				scanner2.close();
				Date date=new Date();
				SimpleDateFormat dateFormat=new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
				ipCamera.setFirstDiscoverTS(dateFormat.format(date));
				ipCamera.setUrl(forImageURLfirst+cameraIPs[i]+forImageURLLast);
				ipCameras.add(ipCamera);
			}
			ipCameraList.setCameraList(ipCameras);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ipCameraList;
	}

	public byte[] getImage(String cameraIp, String isThumbnailImage)
	{
		byte[] imageData = null;
		URL url = null;
		try {
			Authenticator.setDefault (new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication ("root", "pass".toCharArray());
				}
			});
			if(isThumbnailImage.equals("true")) {
				url = new URL("http://"+cameraIp+"/axis-cgi/jpg/image.cgi?resolution=160x120");
			} else {
				url = new URL("http://"+cameraIp+"/axis-cgi/jpg/image.cgi?resolution=1280x720");
			}
			HttpURLConnection connection = (HttpURLConnection)url.openConnection(); 
			BufferedImage image = ImageIO.read(connection.getInputStream());
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(image, "jpg", baos);
			imageData = baos.toByteArray();
		} catch (IOException e) {
			e.printStackTrace();
		}		
		return imageData;
	}
}
