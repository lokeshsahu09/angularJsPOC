package com.tcs.beans;

public class StoreDto {
	private int id;
	private String strName;
	/**
	 * @return the strNumber
	 */
	
	/**
	 * @return the strName
	 */
	public StoreDto()
	{
		
	}
	
	public StoreDto(int id, String strName)
	{
		
		this.id=id;
		this.strName=strName;
	}
	public String getStrName() {
		return strName;
	}
	/**
	 * @param strName the strName to set
	 */
	public void setStrName(String strName) {
		this.strName = strName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

}
