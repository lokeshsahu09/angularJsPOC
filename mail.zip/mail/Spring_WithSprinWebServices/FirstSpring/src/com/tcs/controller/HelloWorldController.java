package com.tcs.controller;

import org.pojoxml.core.PojoXml;
import org.pojoxml.core.PojoXmlFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.tcs.beans.StoreDto;

@Controller
public class HelloWorldController {
	@Autowired
	private StoreDto st;

	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ModelAndView helloWorld() {
		st.setStrName("lokesh11");
		System.out.println("data...."+st.getStrName());

		String message = "HELLO SPRING MVC HOW R U?";
		return new ModelAndView("hellopage", "message", message);
	}

	
	@ResponseBody
	@RequestMapping(value = "/micro/data/{id1}",  method = RequestMethod.GET)
	public String getSingleParameter(@PathVariable("id1") String id) {

		StoreDto storeDto = new StoreDto();
		storeDto.setId(46);
		storeDto.setStrName("lokesh");
		String str = GsonConverter.toJson(storeDto);
		return str;

	}
	
	@RequestMapping(value = "/micro/data", method = RequestMethod.POST)
	@ResponseBody
	public String getMultipleParameter(@RequestBody String st) {
 	   
		StoreDto str = (StoreDto)GsonConverter.fromJson(st, StoreDto.class);
		System.out.println("data in services..."+str.getId()+".....name..."+str.getStrName());
		return "sucess";

	}
	
	 @ResponseBody
	 @RequestMapping(value = "/micro/empty",   method = RequestMethod.GET)
	 public String getValueWithParameter() {
			return "Hello World!";
	
	}
	 
	@ResponseBody
	@RequestMapping(value = "/micro/xml/{id}", method = RequestMethod.GET)
	public String getSingleParameterXML(@PathVariable("id") String id) {
		PojoXml pojoxml = PojoXmlFactory.createPojoXml();
		StoreDto storeDto = new StoreDto();
		storeDto.setId(46);
		storeDto.setStrName("lokesh");
		String xml = pojoxml.getXml(storeDto);
		return xml;

	}
	   
	
	

}
