package com.tcs.controller;


import java.util.HashMap;
import java.util.Map;

import org.pojoxml.core.PojoXml;
import org.pojoxml.core.PojoXmlFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.tcs.beans.StoreDto;

public class TestSpringRestExample {

	
	public static void main(String args[]) {
		
		withParameter();

	}
	
	
	//get call
    public static void withParameter()
	{
	    final String SERVER_URI = "http://localhost:8081/FirstSpring/micro/data/{id1}";
		RestTemplate restTemplate = new RestTemplate();
		Map<String, String> m=new HashMap<String, String>();
		m.put("id1", "6");
		StoreDto str = restTemplate.getForObject(SERVER_URI , StoreDto.class, m);
		System.out.println("User details Id:"+str.getId()+"..name....."+str.getStrName());
		
	}
	
	//post call
	public static void withMultipeParameter()
	{
	    final String SERVER_URI = "http://localhost:8081/FirstSpring/micro/data";
		RestTemplate restTemplate = new RestTemplate();
		StoreDto st=new StoreDto();

		st.setId(100);
		st.setStrName("sahu");
	
		ResponseEntity<String> str = restTemplate.postForEntity(SERVER_URI, GsonConverter.toJson(st), String.class);
		System.out.println("retruned :"+str.getBody().toString());
		
	}
	
	public static void withParameterXML()
	{
		PojoXml pojoxml = PojoXmlFactory.createPojoXml();
	    final String SERVER_URI = "http://localhost:8081/FirstSpring/micro/xml/{id}";
		RestTemplate restTemplate = new RestTemplate();
		Map<String, String> m=new HashMap<String, String>();
		m.put("id", "6");
		String str = restTemplate.getForObject(SERVER_URI , String.class, m);
		//StoreDto str1=(StoreDto)pojoxml.getPojo(str, StoreDto.class);
		
		
		System.out.println("User details Id:"+str);
		
	}
	public static void getString()
	{
		
		    final String SERVER_URI = "http://localhost:8081/FirstSpring/micro/empty";
			RestTemplate restTemplate = new RestTemplate();
			String str = restTemplate.getForObject(SERVER_URI , String.class);
			System.out.println("Output details :"+str);
		
	}

}
    
    
    

