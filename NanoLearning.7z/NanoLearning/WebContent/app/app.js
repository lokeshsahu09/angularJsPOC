﻿'use strict';
define([], function () {
	console.log('Project App JS called');
    var app = angular.module('ProjectApp', ['ngRoute', 'ngAnimate', 'ngCookies', 
                                            'routeResolverServices', 'ui.bootstrap', 'ngDragDrop']);
    app.config(['$routeProvider', 'routeResolverProvider', '$controllerProvider', '$compileProvider', '$filterProvider', '$provide', '$httpProvider',
        function ($routeProvider, routeResolverProvider, $controllerProvider, $compileProvider, $filterProvider, $provide, $httpProvider) {
            app.register = {
                controller: $controllerProvider.register,
                directive: $compileProvider.directive,
                filter: $filterProvider.register,
                factory: $provide.factory,
                service: $provide.service
            };
            var route = routeResolverProvider.route;
            $routeProvider
                .when('/login', route.resolve('Login', ''))
                .when('/learningCart',route.resolve('LearningCart', ''))
                .when('/learningCartMain',route.resolve('LearningCartMain', ''))
                .when('/flowChart',route.resolve('FlowChartGame', ''))
                .when('/', route.resolve('Dummy', ''))
                .otherwise({
                    redirectTo: '/'
                });
        }
    ]);
    
    app.run(['$q', '$rootScope', '$location', 
        function ($q, $rootScope, $location) {
        //Init Run
    	require(['business/controllers/AppController',
    	         'business/factory/dataService',
    	         'business/factory/DialogFactory',
		         'business/factory/GlobalConstants',
		         'business/factory/GlobalVariables'
		         ], function(){
			console.log("Project App Loaded ");
		});
    		console.log("Init Run");
    	}
    ]);
    return app;
});