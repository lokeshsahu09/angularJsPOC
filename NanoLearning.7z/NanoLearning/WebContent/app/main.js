﻿"use strict";
require.config({
    baseUrl: 'app',
    paths: {
        app: 'app',
        appBoot: 'bootstrap',
        angUi: 'assets/libs/angular1.2.18/angular-ui-bootstrap',
        angRoute: 'assets/libs/angular1.2.18/angular-route.min',
        angAnimate: 'assets/libs/angular1.2.18/angular-animate.min',
        angCookies: 'assets/libs/angular1.2.18/angular-cookies.min',
        jquery: 'assets/libs/jquery2.1.1/jquery-2.1.1.min',
        jqueryui: 'assets/libs/others/jquery-ui-1.10.4.custom.min',
        jqgrid : 'assets/libs/jqgrid/jquery.jqGrid.min',
        jqgridLocal : 'assets/libs/jqgrid/i18n/grid.locale-en',
        underscore: 'assets/libs/underscore/underscore-min',
        blockui : 'assets/libs/others/jquery.blockUI',
        bootStrap : 'assets/libs/uibootstrap/bootstrap.min',
        md5 : 'assets/libs/others/md5',
    },
    //urlArgs: "ts=" + (new Date()).getTime(),
    waitSeconds : 0,
    shim: {
        "underscore": {
            exports: "_"
        },
        "jqueryui": {
            deps: ["jquery"],
            exports: "jqueryui"
        },
        "jqgrid": {
        	deps: ["jquery", "jqgridLocal"],
        	exports: "jqgrid"
        }
    },
    deps: ['app'],
    callback : function(){
    	require(['appBoot'], function(){
			console.log("app boot Loaded ");
		});
    	console.log("Deps Loaded");
    }
});