'use strict';
define(['app'], function (app) {
    var GlobalVariable = function () {
        var GlobalVarObj = new Object();
        
        GlobalVarObj.pjtDataObject = null;
        GlobalVarObj.wonDataObject = null;
        GlobalVarObj.PrevBillData = null;
        
        return GlobalVarObj;
    };
    app.register.factory('GlobalVariable', [GlobalVariable]);
});