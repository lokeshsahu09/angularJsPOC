﻿"use strict";
(function() {
	var dependencies = [ 'app' ];

	define(dependencies, function(app) {
		angular.module("ProjectApp").factory('DialogFactory', DialogFactory);

		DialogFactory.$inject = [ '$dialog'];

		function DialogFactory($dialog) {
			var dialogObj = null;
			var dialog = {
				show : function(_tmPath, _ctrlPath, _callbkfn, _isTemplate, _scopeOptions) {
					var thisObj = this;
					require([ _ctrlPath ], function(_ctrlObj) {
						thisObj.OpenDialog(_tmPath, _ctrlObj.getName(), _callbkfn, _isTemplate, _scopeOptions);
					});
				},
				OpenDialog : function(_tmPath, _ctrlNm, _callbkfn, _isTemplate, _scopeOptions) {
					var dialogOptions = {
						dialogClass : 'modal',
						backdropClass : 'modal-backdrop',
						transitionClass : 'fade',
						triggerClass : 'in',
						backdropFade : true,
						dialogFade : true,
						keyboard : false,
						backdropClick : true,
						position : [ 'center', 'center' ],
						controller : _ctrlNm,
						resolve : {
							scopeOptions : function() {
								if (_scopeOptions)
									return angular.copy(_scopeOptions);
							}
						}
					};
					var templateObject = new Object();
					templateObject = (_isTemplate) ? ({
						template : _tmPath
					}) : ({
						templateUrl : _tmPath
					});
					angular.extend(dialogOptions, templateObject);
					dialogObj = $dialog.dialog(dialogOptions);
					dialogObj.open().then(function(result) {
						if (_callbkfn) {
							_callbkfn(result);
						}
					});
				},
				closeDialog : function(_flag) {
					if (dialogObj != null)
						dialogObj.close(_flag);
				}
			};
			return dialog;
		}
	});
})();