'use strict';
define(['app'], function (app) {
    var GlobalConstants = function () {
        var GlobalConstantObj = {};
        
        GlobalConstantObj.GET_DROPDOWNDATA = 'rs/cache/getAllDropdownData';
        
        GlobalConstantObj.ADD_WON_DETAILS = 'rs/won/create';
        
        GlobalConstantObj.UPDATE_WON_DETAILS = 'rs/won/update';
        
        GlobalConstantObj.FILTER_WON = 'rs/won/filterWON';
        
        GlobalConstantObj.RETRIEVE_WON_DTLS = 'rs/won/searchWONDetails';
        
        GlobalConstantObj.RETRIEVE_BILLING_DTLS = 'rs/WONBilling/searchBillingDetails';
        
        GlobalConstantObj.UPDATE_BILLING_DTLS = 'rs/WONBilling/update';
        
        GlobalConstantObj.PREVIOUS_BILL_DTLS = 'rs/WONBilling/previousBilling';
        
        GlobalConstantObj.EXPORT_RANCHTM = 'rs/spreadsheet/ExportRanchandTM';
        
        GlobalConstantObj.EXPORT_FPSL = 'rs/spreadsheet/ExportFLandSL';
        
        GlobalConstantObj.EXTRACT_RANCH_TM = 'rs/WONBilling/extractBilling_RanchTM';
        
        GlobalConstantObj.EXTRACT_FP_SL = 'rs/WONBilling/extractProjectedBilling';
        
        GlobalConstantObj.RETRIEVE_ASSOCIATE_ALLOCATION = 'rs/WONBilling/retrieveAllocationEffortDtls';
        
        GlobalConstantObj.GET_TIMESTAMPS = 'rs/WONBilling/generatedProjections';
        
        GlobalConstantObj.GET_WON_COUNT = 'rs/WONBilling/getContractTypeWONCount';
        
        GlobalConstantObj.EXPORT_WON_DTLS = 'rs/spreadsheet/ExportWON';
        
        GlobalConstantObj.RETRIEVE_SUMMARY_DTLS = 'rs/WONBilling/searchSummaryDetails';
        
        GlobalConstantObj.EXPORT_SUMMARY = 'rs/spreadsheet/ExportSummary';
        
        GlobalConstantObj.FILTER_DM = 'rs/won/filterDM';
        
        GlobalConstantObj.ALLOCATION_EFFORT_TITLE = "Allocation Effort";
        GlobalConstantObj.ACTUAL_EFFORT_TITLE = "Modify Billable Effort at WON Level";
        GlobalConstantObj.ALLOCATION_EFFORT_LABEL = "Enter Allocation Billable Effort (in PD)";
        GlobalConstantObj.ACTUAL_EFFORT_LABEL = "Enter Actual Billable Effort (in PD)";
        GlobalConstantObj.NO_ROWS = "Please select a row to EDIT.";
        GlobalConstantObj.NO_SEARCH_RESULTS = "No Search Results available. Please refine your search.";
        GlobalConstantObj.INPROGRESS = "INPROGRESS";
        GlobalConstantObj.success = "success";
        GlobalConstantObj.error = "error";
        GlobalConstantObj.NO_ASSOCIATE_EFFORT_CHANGES = "No Changes made to the Allocation Effort Details.";
        GlobalConstantObj.NO_CHANGES_MADE = "No Changes made to the Allocation Effort Details.";
        GlobalConstantObj.YES ="YES";
        GlobalConstantObj.NO = "NO";
        GlobalConstantObj.MANDATORY = "Please Enter all mandatory fields.";
        GlobalConstantObj.STARTDATE_GREATER = "WON End Date should be greater than WON Start Date.";
        GlobalConstantObj.ENDDATE_LESSER = "WON End Date should be greater than Current Date.";
        
        GlobalConstantObj.FIXED_PRICE_CONTRACT_TYPE =  2;
        GlobalConstantObj.SL_CONTRACT_TYPE =  4;
        GlobalConstantObj.RANCH_CONTRACT_TYPE =  1;
        GlobalConstantObj.TM_CONTRACT_TYPE =  3;
        GlobalConstantObj.DM_ROLE_CODE =  5;
        GlobalConstantObj.DM_ROLE_DESC =  "DM";
        GlobalConstantObj.GL_ROLE_CODE =  6;
        GlobalConstantObj.GL_ROLE_DESC =  "GL";
        GlobalConstantObj.PMO_ROLE_CODE =  8;
        GlobalConstantObj.PMO_ROLE_DESC =  "PMO";
        
        return GlobalConstantObj;
    };
    app.register.factory('GlobalConstants', [GlobalConstants]);
});