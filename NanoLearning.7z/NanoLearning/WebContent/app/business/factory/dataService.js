'use strict';
define(['app', 'jquery', 'business/utils/utils'], function (app, $, util) {
    var dataService = function ($http, $rootScope) {
        return {
            Get: function (_url, success, error) {

                if (!_url) return false;
                $http({
                        method: 'GET',
                        url: _url,
                        cache: false,
                        xhrFields: {
                            withCredentials: true
                        }
                    })
                    .success(function (data, status, headers, config) {
                        if (status === 200) {
                            success(data);
                        } else {
                            error(data);
                        }

                        return false;
                    })
                    .error(function (data, status, headers, config) {
                        error(data);
                        return false;
                    });
            },
            Post: function (_url, _reqData, success, error) {
                if (!_url) return false;

                var headerObj = {
                    'Accept': 'application/json',
                    'Content-Type': 'application/x-www-form-urlencoded',
                };
                
                var reqData = $.param(_reqData);
                $http({
                        method: "POST",
                        url: _url,
                        data: reqData,
                        xhrFields: {
                            withCredentials: true
                        },
                        headers: headerObj
                    })
                    .success(function (data, status, headers, config) {
                        if (data && success) {
                            success(data);
                        }
                        return false;
                    })
                    .error(function (data, status, headers, config) {
                        if (error) {
                            error(data);
                        }
                        return false;
                    });
            },
            
            uploadFileToUrl : function(file, uploadUrl){
                var fd = new FormData();
                fd.append('file', file);
                $http.post(uploadUrl, fd, {
                    transformRequest: angular.identity,
                    headers: {'Content-Type': undefined}
                })
                .success(function(){
                })
                .error(function(){
                });
            }
        };
    };
    app.register.factory('dataService', ['$http', '$rootScope', dataService]);
});