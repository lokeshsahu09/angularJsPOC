"use strict";
define(['app', 'business/utils/utils', 'business/directives/onlyNumeric'], function (app, util) {
    var loginController = function ($scope, $rootScope, $location,  dataService, $timeout, GlobalConstants, 
    		GlobalVariable, DialogFactory) {
    	
    	var LOG_USERNAME = "logUserName";
    	var LOG_USERPWD = "logUserPwd";
    	$scope.loginUserNameError = false;
    	$scope.loginUserPwdError = false;
    	//-----------------------------------------------------------------------------------------------------------------
    	 $("input[type = text]").keydown(function(event) {
 	    	if(event.which == 13) {
 	    		$scope.authenticate();
 	    	}
     	});
    	 
    	 $("input[type = password]").keydown(function(event) {
  	    	if(event.which == 13) {
  	    		$scope.authenticate();
  	    	}
      	});
    	//-----------------------------------------------------------------------------------------------------------------
     	/** authenticate Function **/
     	$scope.authenticate = function() {
     		console.log("EvenT Triggered");
     		if($scope.validateLoginForm()) {
     			
     			/***
     			 * Call the Authenticate Service (third party application URL) & 
     			 * 
     			 * from the Response, get the Parameter "IsFirstTime",
     			 * if (IsFirstTime == false)----> Proceed to WON Details Page
     			 * else, Show Error Message "Please login to TSM, and change your Password, then try login again"
     			 * 
     			 * **/
     			var loginRequest = new Object();
     			if (angular.isDefined($scope.logUserName) && $scope.logUserName != "" 
     				&& $scope.logUserName !=null){
     				
     				loginRequest.empNumber = $scope.logUserName;
     			}
     			if (angular.isDefined($scope.logUserPwd) && $scope.logUserPwd != "" 
     					&& $scope.logUserPwd != null){

     				loginRequest.password = $scope.logUserPwd;
     			}  
     			//util.Wait(true);
     			var jsonData = JSON.stringify(loginRequest);
     			var dataToSend = {
 			        data: jsonData,
     			};
     			
     			//dataService.Post('rs/authenticate/login', dataToSend, $scope.onLoginSuccess, $scope.onLoginError);
     			dataService.Get('app/stub/loginData.json', $scope.onLoginSuccess, $scope.onLoginError);
     		}
     		else {
     			console.log("Validation Fails");
     		}
     	};
     	//-----------------------------------------------------------------------------------------------------------------
     	/** onLoginSuccess Function **/
     	$scope.onLoginSuccess = function(result) {
     		util.log(result);
     		
     		if(result.header.status != 200) {
     			$scope.onLoginError(result);
     			return false;
     		}
     		
     		if(result.header.status == 200) {
                $rootScope.loginStatus = true;
                if($rootScope.ngIncludeUrl.userDashBoard == ''){
                            $rootScope.ngIncludeUrl.userDashBoard = 'app/business/views/userDashBoard.html';   
                    }
                if($rootScope.ngIncludeUrl.gameDetails == ''){
                            $rootScope.ngIncludeUrl.gameDetails = 'app/business/views/gameDetails.html';   
                    }
     			$rootScope.userDetails = result.userDetails;
     			$location.path('/learningCart');
     		
     		}
     	};
     	//-----------------------------------------------------------------------------------------------------------------
     	/** onLoginError Function **/
     	$scope.onLoginError = function(result) {
     		util.Wait(false);
     		util.log(result);
     		if(result)
     		{
     			$rootScope.showManageWONMsg(result.header.message);
     		}	
     	};
        
    	//-----------------------------------------------------------------------------------------------------------------
    	/** validateLoginForm Function **/
    	$scope.validateLoginForm = function() {
    		if($scope.logUserName && $scope.logUserName != null && $scope.logUserPwd && $scope.logUserPwd != null) {
    			$scope.loginUserNameError = false;
        		$scope.loginUserPwdError = false;
    			return true;
    		}
    		else
    		{
    			if($scope.logUserName && $scope.logUserName != null) {
    				$scope.loginUserNameError = false;
    				if(!$scope.logUserPwd || $scope.logUserPwd == null) {
    					util.setFocus([LOG_USERPWD]);
    					$scope.loginUserPwdError = true;
    				} else {
    					$scope.loginUserPwdError = false;
    				}
    			} else {
    				$scope.loginUserNameError = true;
    				$scope.loginUserPwdError = false;
    				util.setFocus([LOG_USERNAME]);
    			}
    			return false;
    		}
    	};
    	//-----------------------------------------------------------------------------------------------------------------
    	/** Render Function **/
    	$scope.render = function () {
        	util.log("Hi Im in Login Controller ---- " + $("#ng-view").length);
        	$('.autoDisable').attr('autocomplete','off');
        	$rootScope.loginStatus = false;
			$timeout(function() {
				angular.element("#" + LOG_USERNAME).focus();
			}, 50);
        	
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        };
        //-----------------------------------------------------------------------------------------------------------------
        /** showManageWONMsg Function **/
        $rootScope.showManageWONMsg = function(_msg) {
        	var _scopeOptions = {
				'isOK' : true,
				'isCancel' : false,
				'modalMsg' : _msg
			};
			var _tmPath = "app/business/partials/modalPopupTemplate.html";
			var _ctrlPath = "business/controllers/ModalPopupController";
			
			DialogFactory.show(_tmPath, _ctrlPath, null, false, _scopeOptions);
        };
		//-----------------------------------------------------------------------------------------------------------------
        $scope.render();
    };
    app.register.controller('LoginController', ['$scope', '$rootScope', '$location', 'dataService', '$timeout','GlobalConstants', 
                                                'GlobalVariable', 'DialogFactory', loginController]);
});