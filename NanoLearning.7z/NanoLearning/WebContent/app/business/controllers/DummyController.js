"use strict";
define(['app', 'jquery'], function (app, $) {
    var DummyController = function ($scope, $rootScope, $location) {
    	require(['business/factory/dataService',
		         'business/factory/GlobalConstants',
		         'business/factory/GlobalVariables',
		         'business/factory/DialogFactory'
		         ], function(dataService, GlobalConstants, GlobalVariable, DialogFactory){
    		
    		 $scope.safeApply(function(){
    			 $location.path("/login");	 
    		 });
			
		});
    	//-----------------------------------------------------------------------------------------------------------------
        $scope.render = function () {
        	
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        };
        //-----------------------------------------------------------------------------------------------------------------
        $scope.safeApply = function (fn) {
            var phase = this.$root.$$phase;
            if (phase == '$apply' || phase == '$digest') {
                if (fn && (typeof (fn) === 'function')) {
                    fn();
                }
            } else {
                this.$apply(fn);
            }
        };
        //-----------------------------------------------------------------------------------------------------------------
    };
    app.register.controller('DummyController', ['$scope', '$rootScope', '$location', DummyController]);
});