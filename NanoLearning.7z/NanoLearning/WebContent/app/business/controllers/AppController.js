var projectView = angular.module('ProjectApp');
projectView.factory('$exceptionHandler', function ($injector) {
    return function errorCatcherHandler(exception, cause) {
        /*var $location = $injector.get("$location");
        exception.message += ' (caused by "' + cause + '")';
        console.log("Exception Message ::: " + exception.message);
        $("#ng-view").remove();
        $location.path("/");
        throw exception;*/
        return false;
    };
});
//-----------------------------------------------------------------------------------------------------------------

projectView.controller('AppController', function ($rootScope, $scope, $http, $filter, $location, $cookieStore, $timeout, $modal) {
    
	$http.get("app/stub/data.json")
    .success(function (response) {$rootScope.names = response.records;});
	
	
	$scope.appName = "My Project";
    console.log("App Controller Called");
    
    $scope.logOut = function() {
    	$rootScope.loginStatus = false;
    	$rootScope.ngIncludeUrl = {'userDashBoard' : '','gameDetails' : ''};
    	$location.path('/login');
        $rootScope.gameLaunched = false;
    	
    };
    //-----------------------------------------------------------------------------------------------------------------
    $scope.render = function () {
        $rootScope.gameLaunched = false;
    	$rootScope.loginStatus = false;
    	$rootScope.ngIncludeUrl = {'userDashBoard' : '','gameDetails' : ''};
    };
    //-----------------------------------------------------------------------------------------------------------------
    $scope.render();
    
});

