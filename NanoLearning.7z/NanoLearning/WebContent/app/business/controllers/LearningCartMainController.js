"use strict";
define(['app', 'jquery', 'business/utils/utils', 'jqgrid'], function (app, $, util, jqgrid) {
	
    var learningCartMainController = function ($scope, $rootScope, DialogFactory, GlobalConstants, dataService) {
    	//-----------------------------------------------------------------------------------------------------------------
		$scope.render = function(){
			util.log(" :::::::::::[ TAB CONTROLLER CALLED ]:::::::::: ");
					
			//dataService.Post('rs/authenticate/login', dataToSend, $scope.onLoginSuccess, $scope.onLoginError);
     		dataService.Get('app/stub/productData.json', $scope.onProductSuccess, $scope.onProductFail);
			$scope.list1 = [];
  			$scope.list2 = [];
  			$scope.walletCost = 500;
  			$scope.infoMsg = '';

  			$scope.optionsList2 = {
		        accept: function(dragEl) {
		            if ($scope.list2.length >= 9) {
		              return false;
		            } else {
		              return true;
		            }
		        }
        	};
        	$rootScope.gameLaunched = 'true';
        	$rootScope.validateButton = 'Place Order';
        	/*$('.book.image').click(function(event){
        		$scope.productClicked(event);
        	});*/

  			//tooltipster
  			/*$('.book.image').tooltipster({
				content: $('<p style="text-align:left;"><strong>Soufflé chocolate cake powder.</strong>Applicake lollipop oat cake gingerbread. Applicake lollipop oat cake gingerbread.</p>'),
				// setting a same value to minWidth and maxWidth will result in a fixed width
				minWidth: 300,
				position: 'right',
				trigger: 'click',
				animation: 'grow',
				speed: '600'
			});*/

			if (!$scope.$$phase) {
                $scope.$apply();
            }			
		};

		$scope.onProductSuccess = function(response) {
			if(response.header.status === 200) {
				if (response.productDetails) {
					$scope.list1 = response.productDetails;
				}
			}
		};

		$scope.onProductFail = function(response) {
			//show error msg
		};

		$scope.droppedProduct = function () {
			console.log($scope.list2);
			var walletAmount = 500;
			var afterPickCost = 0;
			for (var i = 0; i < $scope.list2.length; i++) {
				afterPickCost = walletAmount - $scope.list2[i].productCost;
				walletAmount = afterPickCost;
			};
			$scope.walletCost = walletAmount;
		};

		$scope.productClicked = function (index, ev) {
			var msg = '';
			var prodTitle = '';
			for (var i = 0; i < $scope.list1.length; i++) {
				if($scope.list1[i].productId && ev.currentTarget.id === $scope.list1[i].productId.toString()) {
					msg = $scope.list1[i].longDesc;
					prodTitle = $scope.list1[i].shortDesc;
					break;
				}
			};
			
			$scope.infoMsg = msg;
			$scope.infoTitle = prodTitle;
		};

		$scope.finish = function (ev) {
			var result = '';
			var msg = '';
			var prodTitle = '';
			if($scope.list2.length > 0 && $scope.list2.length == 7){
				for (var i = 0; i < $scope.list2.length; i++) {
					var prodId = $scope.list2[i].productId;
					if(i + 1 === prodId) {
						result = true;
					} else {
						result = false;
						break;
					}				
				};
			}
			
			if (result) {
				msg = "Congrats !! You've won the game.";
				prodTitle = 'Awesome';
			} else {
				msg = "Sorry.The products you choose or ordered doesn't belong to SDLC Process";
				prodTitle = 'OOPS !!';
			}

			$scope.infoMsg = msg;
			$scope.infoTitle = prodTitle;
		};
	
		//-++--------------------------------------------------------------------------------------------------------------
		
		$scope.render();
	};
	app.register.controller('LearningCartMainController', ['$scope', '$rootScope', 'DialogFactory', 'GlobalConstants', 'dataService', learningCartMainController]);
});


	
    


