 myapp=angular.module("myApp", []);
	
	
 myapp.controller("dashBoardController", function($rootScope, $scope, $http){
	
	
	$http.get("app/stub/data.json")
    .success(function (response) {$rootScope.names = response.records;});
    
    
	
});
