require(['app', 'angUi', 'angRoute', 'angAnimate', 'angCookies', 'jquery',  'jqueryui', 'jqgrid', 
         'blockui',
         'business/services/routeResolver', 
         'business/controllers/AppController',
         'business/factory/DialogFactory'
         ], function () {
    'use strict';
    jQuery.noConflict();
    angular.bootstrap(document, ['ProjectApp']);
});